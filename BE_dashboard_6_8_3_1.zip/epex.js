// Network access stays in the isolated extension world.
const GM_xmlhttpRequest = opts => {
  chrome.runtime.sendMessage({type:'be-epex-fetch',url:opts.url}, response => {
    if(chrome.runtime.lastError || !response || response.error) { opts.onerror(); return; }
    opts.onload({status:response.status,responseText:response.text});
  });
};
(function () {
  'use strict';
  const ID='be-epex-addon', KEY='be_epex_enabled_v1', CACHE='be_epex_nordpool_prices_v1';
  if(document.getElementById(ID))return;
  const stateNode=document.createElement('script');stateNode.type='application/json';stateNode.id=ID;
  document.documentElement.appendChild(stateNode);
  const read=(key)=>{try{return localStorage.getItem(key);}catch(_){return null;}};
  const save=(key,value)=>{try{localStorage.setItem(key,value);}catch(_){}};
  let enabled=read(KEY)==='aan', rows=[],cache=null,busy=false,retryAt=0,error='',button,status;
  const FORECAST_KEY='be_epex_forecast_enabled_v1',FORECAST_CACHE='be_epex_nordpool_forecast_prices_v1';
  let forecastEnabled=read(FORECAST_KEY)!=='uit',forecastCache={},forecastBusy=false,forecastError='';
  try{forecastCache=JSON.parse(read(FORECAST_CACHE))||{};}catch(_){}
  try{cache=JSON.parse(read(CACHE));if(cache)rows=Array.isArray(cache.rows)?cache.rows:normalise(cache.body);}catch(_){cache=null;}
  function normalise(body){
    if(Array.isArray(body?.multiAreaEntries)){
      if(body.currency!=='EUR'||body.market!=='DayAhead'||!body.deliveryAreas?.includes('NL'))throw Error('Onbekende Nord Pool-markt');
      const rows=body.multiAreaEntries.filter(r=>{const v=r?.entryPerArea?.NL;return (typeof v==='number'||typeof v==='string'&&v.trim()!=='')&&Number.isFinite(Number(v));}).map(r=>{
        const start=Date.parse(r.deliveryStart),end=Date.parse(r.deliveryEnd),price=Number(r.entryPerArea.NL)/1000;
        if(!Number.isFinite(start)||!Number.isFinite(end)||end-start!==900000)throw Error('Onbekende Nord Pool-kwartiertijden');
        return {start,end,price};
      }).sort((a,b)=>a.start-b.start);
      for(let i=1;i<rows.length;i++)if(rows[i].start<rows[i-1].end)throw Error('Overlappende Nord Pool-prijzen');
      return rows;
    }
    if(!body || body.interval!=='RESPONSE_INTERVAL_QUARTER' || !Array.isArray(body.base))throw Error('Onbekend EnergyZero-prijsformaat');
    const rows=body.base.map(r=>{
      const value=r?.price?.value;
      const start=Date.parse(r?.start),end=Date.parse(r?.end);
      // EnergyZero base is EUR/kWh, without VAT, energy tax or supplier markup.
      const price=typeof value==='string' && value.trim()!==''?Number(value):NaN;
      if(!Number.isFinite(start)||!Number.isFinite(end)||end-start!==900000||!Number.isFinite(price))throw Error('Onvolledige EnergyZero-kwartierprijs');
      return {start,end,price};
    }).sort((a,b)=>a.start-b.start);
    for(let i=1;i<rows.length;i++)if(rows[i].start<rows[i-1].end)throw Error('Overlappende EnergyZero-prijzen');
    return rows;
  }
  function coversNow(data){const now=Date.now();return data.some(r=>r.start<=now && now<r.end);}
  function settings(){
    try{return JSON.parse(document.getElementById('be-actueel-allin-data')?.textContent||'{}');}catch(_){return {};}
  }
  const FINANCE_SETTINGS = 'be_overzicht_settings_v1';
  function planPriceSettings() {
    let finance;
    try { finance = JSON.parse(read(FINANCE_SETTINGS) || '{}') || {}; }
    catch (_) { finance = {}; }
    const {tax = true, vat = true, rates} = finance;
    return {
      allin: Boolean(tax && vat),
      rates: {'2025':0.10154, '2026':0.09161, '2027':0.08802, ...Object.fromEntries(Object.entries(rates||{}).filter(([,v])=>Number.isFinite(v)&&v>=0))}
    };
  }
  function publish(){
    const s=settings();
    const storedMode=read('be_cfg_actueel_allin');
    const allin=storedMode===null?s.aan!==false:storedMode!=='uit';
    const planPrice=planPriceSettings();
    const forecastRows=Object.values(forecastCache).flatMap(c=>Array.isArray(c?.rows)?c.rows:[]).sort((a,b)=>a.start-b.start);
    const text=JSON.stringify({enabled,rows,forecastEnabled,forecastRows,planPrice,allin,btw:Number.isFinite(s.btw)?s.btw:1.21,opslag:Number.isFinite(s.opslag)?s.opslag:.02,eb:Number.isFinite(s.eb)?s.eb:.11085});
    if(stateNode.textContent!==text){stateNode.textContent=text;document.dispatchEvent(new Event('be-epex-data'));}
    if(button){
      button.setAttribute('aria-checked',String(enabled));
      button.querySelector('.be-epex-state').textContent=enabled?'AAN':'UIT';
      button.title=error||'Nederlandse EPEX day-ahead-prijs tonen of verbergen';
    }
    if(status){
      status.textContent=enabled&&error?'!':enabled&&busy&&!rows.length?'…':'';
      status.title=error||'Prijzen ophalen';status.hidden=!status.textContent;
    }
    const fb=document.getElementById('be-epex-forecast-switch');
    if(fb){fb.setAttribute('aria-pressed',String(forecastEnabled));fb.title='EPEX-kwartierprijs '+(forecastEnabled?'verbergen':'tonen');fb.querySelector('[data-epex-label]').textContent=planPrice.allin?'EPEX · all-in':'EPEX · excl. EB/btw';}
    const note=document.getElementById('be-epex-forecast-status');
    if(note){const message=forecastError||(forecastBusy&&!forecastRows.length?'Prijzen ophalen…':'');if(note.textContent!==message)note.textContent=message;}

  }
  function range(at=Date.now()){
    const parts=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Amsterdam',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(at));
    const part=t=>parts.find(p=>p.type===t).value;
    const date=part('day')+'-'+part('month')+'-'+part('year');
    return {date,key:date};
  }
  function nordPoolUrl(date){
    const parts=date.split('-'),iso=parts[0].length===4?date:parts[2]+'-'+parts[1]+'-'+parts[0];
    return 'https://dataportal-api.nordpoolgroup.com/api/DayAheadPrices?date='+iso+'&market=DayAhead&deliveryArea=NL&currency=EUR';
  }
  function request(url){
    return new Promise((resolve,reject)=>{
      const fn=typeof GM_xmlhttpRequest==='function'?GM_xmlhttpRequest:typeof GM!=='undefined'&&typeof GM.xmlHttpRequest==='function'?GM.xmlHttpRequest.bind(GM):null;
      if(!fn){reject(Error('De userscriptmanager heeft netwerktoegang nodig'));return;}
      fn({method:'GET',url,anonymous:true,timeout:20000,onload:r=>{
        if(r.status!==200){reject(Error('Prijsbron tijdelijk niet beschikbaar ('+r.status+')'));return;}
        try{resolve(JSON.parse(r.responseText));}catch(_){reject(Error('Ongeldige prijsresponse'));}
      },onerror:()=>reject(Error('Prijsbron niet bereikbaar')),ontimeout:()=>reject(Error('Prijsbron reageert niet'))});
    });
  }
  async function refresh(){
    if(!enabled||busy||document.hidden||!document.getElementById('be-tarief-chart')||Date.now()<retryAt)return;
    const r=range();if(cache&&cache.key===r.key&&Date.now()-cache.at<900000&&coversNow(rows)){publish();return;}
    busy=true;publish();
    try{
      const body=await request(nordPoolUrl(r.date));
      const parsed=normalise(body);if(!coversNow(parsed))throw Error('Geen actuele day-ahead-prijzen beschikbaar');
      const previous=await request(nordPoolUrl(range(Date.now()-86400000).date)).then(normalise).catch(()=>rows.filter(r=>r.end<=parsed[0].start));
      rows=[...new Map([...previous,...parsed].map(r=>[r.start,r])).values()].sort((a,b)=>a.start-b.start);
      cache={key:r.key,at:Date.now(),body,rows};save(CACHE,JSON.stringify(cache));error='';
    }catch(e){error=e.message+(rows.length?' · eerder opgehaalde prijzen zichtbaar':'');retryAt=Date.now()+300000;}
    finally{busy=false;publish();}
  }
  async function refreshForecast(){
    if(!forecastEnabled||forecastBusy||document.hidden||!document.getElementById('soc-forecast-chart'))return;
    let dates=[];try{dates=JSON.parse(document.getElementById('be-epex-forecast-range')?.textContent||'[]');}catch(_){}
    dates=[...new Set(dates)].filter(d=>/^\d{2}-\d{2}-\d{4}$/.test(d)).slice(0,3);
    if(!dates.length){const today=range().date,[d,m,y]=today.split('-').map(Number);dates=[today,range(Date.UTC(y,m-1,d+1,12)).date];}
    forecastBusy=true;forecastError='';
    try{
      for(const date of dates){
        const saved=forecastCache[date];if(saved?.retryAt>Date.now())continue;
        if(cache?.key===date&&Date.now()-cache.at<900000){forecastCache[date]={rows:normalise(cache.body),at:cache.at,retryAt:cache.at+900000};continue;}
        try{
          const body=await request(nordPoolUrl(date));
          const parsed=normalise(body);
          forecastCache[date]={rows:parsed,at:Date.now(),retryAt:Date.now()+(parsed.length?900000:300000)};
        }catch(e){forecastCache[date]={rows:saved?.rows||[],at:saved?.at||0,retryAt:Date.now()+300000};forecastError='Nog niet alle kwartierprijzen beschikbaar';}
      }
      for(const key of Object.keys(forecastCache))if(!dates.includes(key))delete forecastCache[key];
      save(FORECAST_CACHE,JSON.stringify(forecastCache));
    }finally{forecastBusy=false;publish();}
  }
  const style=document.createElement('style');style.textContent=`
    #be-epex-control{display:flex;align-items:center;justify-content:flex-end;gap:8px;width:100%;flex-wrap:wrap;box-sizing:border-box;padding:8px 2px 4px;color:inherit}
    #be-epex-legend{display:flex;align-items:center;gap:12px;margin-right:auto;flex-wrap:wrap;font:11px/1.3 system-ui,sans-serif}
    #be-epex-legend button{display:inline-flex;align-items:center;gap:5px;border:0;padding:3px 0;margin:0;background:transparent;color:inherit;font:inherit;cursor:pointer}
    #be-epex-legend button[aria-pressed="false"]{opacity:.5;text-decoration:line-through}
    #be-epex-legend .swatch{width:13px;height:3px;display:inline-block}
    #be-epex-switch{appearance:none;display:inline-flex;align-items:center;gap:9px;border:0;padding:3px 2px;background:transparent;color:inherit;font:500 11px/1.2 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;white-space:nowrap;cursor:pointer;box-shadow:none;margin:0;min-height:24px}
    #be-epex-switch:focus-visible{outline:2px solid #429ee8;outline-offset:4px;border-radius:4px}
    #be-epex-switch .be-epex-track{position:relative;width:34px;height:18px;flex:none;border-radius:10px;background:#868892;box-shadow:inset 0 0 0 1px rgba(0,0,0,.1)}
    #be-epex-switch .be-epex-thumb{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:#fff;box-shadow:0 1px 3px #0004;transition:transform .15s}
    #be-epex-switch[aria-checked="true"] .be-epex-track{background:#287dbb}
    #be-epex-switch[aria-checked="true"] .be-epex-thumb{transform:translateX(16px)}
    #be-epex-switch .be-epex-state{min-width:24px;font-size:10px;font-weight:700;letter-spacing:.02em}
    #be-epex-source{display:inline-flex;align-items:center;justify-content:center;width:15px;height:15px;border:1px solid currentColor;border-radius:50%;font:italic 10px Georgia,serif;color:inherit;opacity:.55;text-decoration:none}
    #be-epex-source:hover,#be-epex-source:focus{opacity:1}
    #be-epex-status{font-size:11px;font-weight:700;color:#b76a20}
    html[data-be-dark="aan"] #be-epex-switch .be-epex-track{background:#65615b!important}
    html[data-be-dark="aan"] #be-epex-switch[aria-checked="true"] .be-epex-track{background:#287dbb!important}
    html[data-be-dark="aan"] #be-epex-switch .be-epex-thumb{background:#fff!important}
    @media(max-width:700px){#be-epex-control{justify-content:flex-end;width:100%;padding-top:6px}#be-epex-switch{border-left:0}}
    @media(prefers-reduced-motion:reduce){#be-epex-switch .be-epex-thumb{transition:none}}
  `;document.documentElement.appendChild(style);
  style.textContent+=`#be-epex-forecast-switch{display:inline-flex;align-items:center;gap:5px;appearance:none;background:transparent;color:inherit;border:0;padding:3px 0;font:11px/1.3 system-ui,sans-serif;cursor:pointer}#be-epex-forecast-switch[aria-pressed="false"]{opacity:.5;text-decoration:line-through}#be-epex-forecast-switch .be-soc-series-swatch{height:2px;background:var(--be-epex-forecast-color,#9ccced)!important}#be-epex-forecast-status{font:11px/1.4 system-ui,sans-serif;opacity:.7}#be-epex-forecast-switch:focus-visible{outline:2px solid #9ccced;outline-offset:3px;border-radius:3px}`;
  style.textContent+=`
    .be-epex-plan-strip{position:relative;box-sizing:border-box;width:100%;min-width:0;flex:none;margin:4px 0 6px}
    .be-epex-plan-badge{position:absolute;box-sizing:border-box;height:34px;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:2px 6px;border:1px solid #d9e3ec;border-radius:7px;background:#f6f9fc;color:#33485d;font:600 11px/1.2 system-ui,sans-serif;white-space:nowrap}
    .be-epex-plan-amount{font-size:11px;font-variant-numeric:tabular-nums}
    .be-epex-plan-mode{margin-left:4px;color:#617487;font-size:9px;font-weight:500}
    .be-epex-plan-cost{color:#a92027}.be-epex-plan-credit{color:#14714c}
    html[data-be-dark="aan"] .be-epex-plan-badge{background:#272e37;border-color:#445260;color:#edf4fb}
    html[data-be-dark="aan"] .be-epex-plan-mode{color:#b5c2cf}
    html[data-be-dark="aan"] .be-epex-plan-cost{color:#fca5a5}
    html[data-be-dark="aan"] .be-epex-plan-credit{color:#86efac}
  `;
  function mountForecast(){
    const cv=document.getElementById('soc-forecast-chart');if(!cv)return;
    const legend=document.querySelector('[data-be-soc-legend="soc-forecast-chart"]');if(!legend)return;
    const existing=document.getElementById('be-epex-forecast-switch');if(existing){if(existing.parentElement!==legend)legend.appendChild(existing);return;}
    const button=document.createElement('button');button.id='be-epex-forecast-switch';button.type='button';button.className='be-soc-series-toggle';button.setAttribute('aria-label','EPEX per kwartier op forecast');
    button.innerHTML='<span class="be-soc-series-swatch" aria-hidden="true"></span><span data-epex-label>EPEX</span>';
    button.addEventListener('click',()=>{forecastEnabled=!forecastEnabled;save(FORECAST_KEY,forecastEnabled?'aan':'uit');publish();refreshForecast();});
    legend.appendChild(button);publish();refreshForecast();
  }
  function mount(){
    const host=document.getElementById('be-tarief-row');
    if(!host||host.querySelector('#be-epex-control'))return;
    const box=document.createElement('div');box.id='be-epex-control';
    button=document.createElement('button');button.id='be-epex-switch';button.type='button';
    button.setAttribute('role','switch');button.setAttribute('aria-label','EPEX day-ahead');
    button.innerHTML='<span>EPEX</span><span class="be-epex-track" aria-hidden="true"><span class="be-epex-thumb"></span></span><span class="be-epex-state" aria-hidden="true"></span>';
    button.addEventListener('click',()=>{enabled=!enabled;save(KEY,enabled?'aan':'uit');publish();refresh();});
    status=document.createElement('span');status.id='be-epex-status';
    status.setAttribute('role','status');
    const source=document.createElement('a');source.id='be-epex-source';source.textContent='i';
    source.href='https://data.nordpoolgroup.com/auction/day-ahead/prices?deliveryAreas=NL&currency=EUR';source.target='_blank';source.rel='noopener noreferrer';
    source.setAttribute('aria-label','Bron en toelichting EPEX');
    source.title='Nederlandse day-ahead-kwartierprijzen via Nord Pool. Kale beursprijs in EUR/MWh, omgerekend naar EUR/kWh. All-in: kale prijs × btw + opslag + energiebelasting.';
    const legend=document.createElement('div');legend.id='be-epex-legend';legend.setAttribute('aria-label','Grafieklegenda');
    box.append(legend,button,status,source);host.prepend(box);publish();refresh();
  }
  // The main plugin also bridges into the page, where its Chart instance lives.
  const bridge=document.createElement('script');bridge.src=chrome.runtime.getURL('epex-bridge.js');bridge.onload=()=>bridge.remove();document.documentElement.appendChild(bridge);
  let pending=false;
  const observer=new MutationObserver(()=>{if(pending)return;pending=true;setTimeout(()=>{pending=false;mount();mountForecast();},150);});
  observer.observe(document.body||document.documentElement,{childList:true,subtree:true});
  document.addEventListener('be-actueel-allin-update',publish);
  document.addEventListener('be-financial-settings-update',publish);
  window.addEventListener('pageshow',publish);
  document.addEventListener('be-epex-forecast-range',()=>{mountForecast();refreshForecast();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){mount();mountForecast();refresh();refreshForecast();}});
  window.addEventListener('storage',e=>{
    if(e.key===KEY){enabled=e.newValue==='aan';publish();refresh();}
    if(e.key==='be_cfg_actueel_allin'||e.key===FINANCE_SETTINGS||e.key===null)publish();
  });
  mount();mountForecast();setInterval(()=>{refresh();refreshForecast();},60000);
})();
