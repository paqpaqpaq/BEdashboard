// ==UserScript==
// @name         Balansenergie All-in Toggle + FPR
// @version      3.2.0 - aFRR-aanvulling voor ontbrekende dagen
// @description  All-in toggle (incl. EB, opslag en BTW) + Financial Performance Ratio + Voorschot + Saldering + aFRR-aanvulling voor dagen die Balans nog niet heeft verwerkt
// @match        *://dashboard.balansenergie.nl/*
// @run-at       document-start
// @grant        none
// ==/UserScript==
(function() {
  const EB      = 0.111;
  const OPSLAG  = 0.02;
  const BTW     = 1.21;
  // ─── Design tokens (passend bij nieuw dashboard) ──────────────────────────
  // Nieuw dashboard: witte kaarten, licht lavendel body (#eeeaf3), paarse accenten
  const DS = {
    bg:         'white',
    border:     '1px solid #e8e2f0',
    radius:     '10px',
    padding:    '12px 16px 14px',
    labelColor: '#8c6fb5',          // iets donkerder dan oud #9b7ec8
    labelSize:  '10px',
    labelWeight:'600',
    labelSpacing:'0.07em',
    purple:     '#6B3FA0',
    purpleLight:'#9b7ec8',
    red:        '#dc3545',
    green:      '#198754',
    textMuted:  '#6c757d',
    divider:    '#e8e2f0',
  };
  function dsWidget(extra) {
    return 'background:' + DS.bg + ';border:' + DS.border + ';border-radius:' + DS.radius +
      ';padding:' + DS.padding + ';margin-top:12px;margin-bottom:4px;box-shadow:0 1px 4px rgba(107,63,160,0.06);' + (extra || '');
  }
  function dsLabel(txt) {
    return '<div style="font-size:' + DS.labelSize + ';color:' + DS.labelColor + ';font-weight:' + DS.labelWeight +
      ';letter-spacing:' + DS.labelSpacing + ';margin-bottom:10px;text-transform:uppercase;">' + txt + '</div>';
  }
  function dsDivider() {
    return '<div style="border-top:1px solid ' + DS.divider + ';margin:8px 0 10px;"></div>';
  }
  // ─── aFRR-aanvulling ─────────────────────────────────────────────────────
  //
  //  Balans rekent een kwartier af in calculateImportExportFinancials(), en
  //  kapt daar het aFRR-volume af op de gemeten import/export:
  //
  //      afrrImport = Math.min(hasImport ? importVal : 0, afrrImportKwh)
  //      afrrExport = Math.min(hasExport ? exportVal : 0, afrrExportKwh)
  //
  //  Zolang de meterstanden er niet zijn is hasImport/hasExport false, wordt
  //  het aFRR-volume nul en valt de hele dag weg — ook het aFRR-deel, terwijl
  //  dat wél bekend is. Normaal loopt dat twee dagen achter terwijl de
  //  aFRR-cijfers er al na één dag zijn; bij een storing bij de externe
  //  partner duurt het langer.
  //
  //  Deze module vult zulke dagen aan in het antwoord van results_summary_api,
  //  met alleen het aFRR-deel:
  //
  //      kosten    = afrr_import_kwh x afregelen   (val terug op overschot)
  //      opbrengst = afrr_export_kwh x opregelen   (val terug op tekort)
  //
  //  Dezelfde prijstoewijzing als Balans zelf hanteert. Nagerekend over
  //  22-08-2026, een dag mét meterstanden: de volledige formule (regulier +
  //  aFRR) komt uit op inkoop EUR 0,280 en verkoop EUR 1,172, precies gelijk
  //  aan total_buy_eur en total_sell_eur uit de API.
  //
  //  Omdat de aanvulling in de datalaag zit, telt alles wat daarop rekent hem
  //  vanzelf mee: de kaarten van Balans, de staafgrafiek, de dagtabel, en
  //  daarmee ook de all-in berekening, FPR en Voorschot & Verrekening
  //  hieronder. Eén injectiepunt, geen tweede rekenpad dat uit de pas kan gaan.
  //
  //  NOOIT DUBBEL. Vooraf wordt opgehaald wélke dagen Balans zelf al levert
  //  (een verzameling datums, geen datumgrens — zo werken gaten midden in een
  //  maand ook). Alleen dagen die daarin ontbreken worden aangevuld. Komt een
  //  dag alsnog binnen, dan valt de aanvulling voor die dag vanzelf weg en
  //  telt uitsluitend de echte afrekening van Balans.
  //
  //  Lukt die peiling niet, dan doet de module niets. Liever geen aanvulling
  //  dan het risico van dubbeltellen.

  var LS_AFRR = 'be_cfg_afrr';
  var afrrAan = localStorage.getItem(LS_AFRR) !== 'uit';   // standaard aan

  var AFRR_TERUG_DAGEN  = 45;          // hoe ver terug naar gaten gekeken wordt
  var AFRR_MAX_DAGEN    = 20;          // veiligheidsklep: nooit meer dan dit aanvullen
  var AFRR_WACHT_MS     = 8000;        // max wachttijd per verzoek op eigen cijfers
  var AFRR_BEKEND_TTL   = 5 * 60 * 1000;
  var AFRR_ORANJE       = '#ff7a00';
  var AFRR_ORANJE_BAND  = 'rgba(255,122,0,.10)';

  var _origFetch     = window.fetch.bind(window);
  var _afrrPerDag    = {};             // datum -> { kosten, opbrengst, netto, kwhIn, kwhUit }
  var _afrrBekend    = null;           // Set van datums die Balans zelf levert
  var _afrrBekendOp  = 0;
  var _afrrProbeOk   = false;
  var _afrrGevuld    = [];             // datums die dit verzoek zijn aangevuld
  var _afrrKlaarZet  = null;
  var _afrrKlaar     = new Promise(function(res) { _afrrKlaarZet = res; });

  var _afrrKlantMatch = location.pathname.match(/^\/customer\/([^/]+)\//);
  var AFRR_KLANT = _afrrKlantMatch ? _afrrKlantMatch[1] : null;

  function afrrApi(naam, vraag) { return '/customer/' + AFRR_KLANT + '/' + naam + '/?' + vraag; }

  function afrrGetal(v) { return (typeof v === 'number' && isFinite(v)) ? v : 0; }

  function afrrNum(v) {
    if (v === null || v === undefined || v === '') return null;
    var n = typeof v === 'number' ? v : parseFloat(String(v).replace(',', '.'));
    return isFinite(n) ? n : null;
  }

  function afrrIso(d) {
    function p(n) { return String(n).padStart(2, '0'); }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function afrrVandaag() { return afrrIso(new Date()); }
  function afrrPlusDag(s, n) { var d = new Date(s + 'T12:00:00'); d.setDate(d.getDate() + n); return afrrIso(d); }
  function afrrNlDatum(s) { var a = s.split('-'); return a[2] + '-' + a[1] + '-' + a[0]; }
  function afrrIsoUitNl(s) { var a = s.split('-'); return a[2] + '-' + a[1] + '-' + a[0]; }

  /** Hoort deze dag door ons aangevuld te worden? */
  function afrrGeschat(datum) {
    return afrrAan && _afrrProbeOk && !!_afrrPerDag[datum] &&
           !!_afrrBekend && !_afrrBekend.has(datum);
  }

  /** Eén dag ophalen en per kwartier het aFRR-resultaat uitrekenen. */
  function afrrHaalDag(datum) {
    return Promise.all([
      _origFetch(afrrApi('afrr_activated_energy_api', 'date=' + datum), { credentials: 'same-origin' }).then(function(r) { return r.json(); }),
      _origFetch(afrrApi('settlement_prices_api',     'date=' + datum), { credentials: 'same-origin' }).then(function(r) { return r.json(); })
    ]).then(function(res) {
      var afrr = res[0], prijzen = res[1];

      // Onbalansprijzen op starttijd. De API geeft start_hm ("00:15") en
      // period ("00:15-00:30"); beide indexeren voor de zekerheid.
      var prijsOp = {};
      (Array.isArray(prijzen) ? prijzen : []).forEach(function(p) {
        var sleutel = p.start_hm || (typeof p.period === 'string' ? p.period.slice(0, 5) : null);
        if (sleutel) prijsOp[sleutel] = p;
      });

      var kwartieren = {}, kosten = 0, opbrengst = 0, aantal = 0, kwhIn = 0, kwhUit = 0;

      ((afrr && afrr.items) || []).forEach(function(it) {
        var hm = it.start_hm || (typeof it.period === 'string' ? it.period.slice(0, 5) : null);
        if (!hm) return;

        var ai = Math.max(0, afrrNum(it.afrr_import_kwh) || 0);   // afregelen: wij nemen af
        var ae = Math.max(0, afrrNum(it.afrr_export_kwh) || 0);   // opregelen: wij leveren
        if (!ai && !ae) return;

        var p   = prijsOp[hm];
        var pAf = p ? (afrrNum(p.afregelen) !== null ? afrrNum(p.afregelen) : afrrNum(p.overschot)) : null;
        var pOp = p ? (afrrNum(p.opregelen) !== null ? afrrNum(p.opregelen) : afrrNum(p.tekort))    : null;

        // Zonder prijs valt er niets te verrekenen; kwartier overslaan.
        if ((ai > 0 && pAf === null) || (ae > 0 && pOp === null)) return;

        // Let op: een negatieve afregelprijs geeft negatieve kosten. Dat klopt,
        // dan word je betaald om te laden.
        var k = ai > 0 ? ai * pAf : 0;
        var o = ae > 0 ? ae * pOp : 0;

        kwartieren[hm] = { ai: ai, ae: ae, kosten: k, opbrengst: o, netto: o - k };
        kosten += k; opbrengst += o; kwhIn += ai; kwhUit += ae; aantal++;
      });

      if (!aantal) return null;        // nog geen aFRR-cijfers voor deze dag
      return { datum: datum, kwartieren: kwartieren, aantal: aantal,
               kosten: kosten, opbrengst: opbrengst, netto: opbrengst - kosten,
               kwhIn: kwhIn, kwhUit: kwhUit };
    }).catch(function() { return null; });
  }

  /** Welke dagen levert Balans zelf? Gaat langs de originele fetch. */
  function afrrVersBekend(forceer) {
    if (!forceer && _afrrBekend && (Date.now() - _afrrBekendOp) < AFRR_BEKEND_TTL) {
      return Promise.resolve();
    }
    var eind  = afrrVandaag();
    var begin = afrrPlusDag(eind, -AFRR_TERUG_DAGEN);
    return _origFetch(afrrApi('results_summary_api', 'granularity=day&start=' + begin + '&end=' + eind),
                      { credentials: 'same-origin' })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        var set = new Set();
        ((d && d.series) || []).forEach(function(s) { if (s.date) set.add(s.date); });
        _afrrBekend = set;
        _afrrBekendOp = Date.now();
        _afrrProbeOk = true;
      })
      .catch(function() {
        // Peiling mislukt: niet aanvullen. Dubbeltellen is erger dan niets doen.
        _afrrProbeOk = false;
      });
  }

  /** Dagregel in het formaat van results_summary_api. */
  function afrrDagRegel(datum) {
    var dag = _afrrPerDag[datum];
    var kwhIn = afrrGetal(dag.kwhIn), kwhUit = afrrGetal(dag.kwhUit);
    return {
      date: datum,
      deals_count: 0,
      import_kwh: +kwhIn.toFixed(3),
      export_kwh: +kwhUit.toFixed(3),
      battery_charged_kwh: 0,
      battery_discharged_kwh: 0,
      pv_estimated_kwh: 0,
      total_buy_eur: +afrrGetal(dag.kosten).toFixed(3),
      total_sell_eur: +afrrGetal(dag.opbrengst).toFixed(3),
      deal_customer_share_eur: 0,
      stroom_voordeel_eur: +afrrGetal(dag.netto).toFixed(3),
      balance_energie_eur: 0,
      payout_eur: +afrrGetal(dag.netto).toFixed(3),
      customer_total: +afrrGetal(dag.netto).toFixed(3),
      deal_revenue_eur: 0, deal_cost_eur: 0, deal_profit_eur: 0,
      deal_op_amount_eur: 0, deal_af_amount_eur: 0, deals_volume_kwh: 0,
      savings_vs_dynamic_eur: 0, savings_vs_fixed_eur: 0, pv_export_fee_saving_eur: 0,
      avg_buy_price_eur_per_kwh:  kwhIn  ? afrrGetal(dag.kosten) / kwhIn     : null,
      avg_sell_price_eur_per_kwh: kwhUit ? afrrGetal(dag.opbrengst) / kwhUit : null,
      avg_import_settlement_price_eur_per_kwh: null,
      avg_realized_import_price_eur_per_kwh: null,
      weighted_dynamic_price_eur_per_kwh: null,
      afrr_geschat: true              // eigen vlag; Balans kijkt er niet naar
    };
  }

  /** Bedragen van één dag bij een maandregel of bij de totalen optellen. */
  function afrrTelBij(doel, datum) {
    var dag = _afrrPerDag[datum];
    doel.import_kwh     = +(afrrGetal(doel.import_kwh)     + afrrGetal(dag.kwhIn)).toFixed(3);
    doel.export_kwh     = +(afrrGetal(doel.export_kwh)     + afrrGetal(dag.kwhUit)).toFixed(3);
    doel.total_buy_eur  = +(afrrGetal(doel.total_buy_eur)  + afrrGetal(dag.kosten)).toFixed(3);
    doel.total_sell_eur = +(afrrGetal(doel.total_sell_eur) + afrrGetal(dag.opbrengst)).toFixed(3);

    ['stroom_voordeel_eur', 'payout_eur', 'customer_total'].forEach(function(veld) {
      if (veld in doel) doel[veld] = +(afrrGetal(doel[veld]) + afrrGetal(dag.netto)).toFixed(3);
    });

    if (doel.import_kwh) doel.avg_buy_price_eur_per_kwh  = doel.total_buy_eur  / doel.import_kwh;
    if (doel.export_kwh) doel.avg_sell_price_eur_per_kwh = doel.total_sell_eur / doel.export_kwh;
    doel.afrr_geschat = true;
  }

  /** Staat er nergens een NaN of Infinity in het resultaat? */
  function afrrHeelWerk(o, diep) {
    diep = diep || 0;
    if (diep > 4) return true;
    if (typeof o === 'number') return isFinite(o);
    if (Array.isArray(o)) return o.every(function(v) { return afrrHeelWerk(v, diep + 1); });
    if (o && typeof o === 'object') {
      return Object.keys(o).every(function(k) { return afrrHeelWerk(o[k], diep + 1); });
    }
    return true;
  }

  /**
   * Het antwoord van results_summary_api aanvullen. Werkt op een kopie: gaat er
   * onderweg iets mis, dan krijgt het dashboard gewoon de cijfers van Balans.
   */
  function afrrVulAan(origineel, vraag) {
    if (!origineel || !Array.isArray(origineel.series)) return origineel;
    if (!afrrAan || !_afrrProbeOk) return origineel;

    var data = JSON.parse(JSON.stringify(origineel));
    var q = new URLSearchParams(vraag || '');
    var start = q.get('start'), eind = q.get('end');
    var gran  = data.granularity || q.get('granularity') || 'day';

    var dagen = Object.keys(_afrrPerDag).sort().filter(function(d) {
      return afrrGeschat(d) && (!start || d >= start) && (!eind || d <= eind);
    });
    if (!dagen.length) return origineel;

    if (gran === 'day') {
      var bestaat = {};
      data.series.forEach(function(s) { if (s.date) bestaat[s.date] = true; });
      dagen.forEach(function(d) {
        if (bestaat[d]) return;                       // Balans heeft 'm alsnog
        data.series.push(afrrDagRegel(d));
        if (data.totals) afrrTelBij(data.totals, d);
      });
      data.series.sort(function(a, b) { return String(a.date).localeCompare(String(b.date)); });
    } else {
      // Maand- (of andere) granulariteit: bij de bestaande maandregel optellen.
      // Hier is de verzameling bekende dagen de enige bescherming, want de
      // losse dagen zijn in een maandregel niet te zien.
      dagen.forEach(function(d) {
        var mk = d.slice(0, 7);
        var regel = null;
        data.series.forEach(function(s) {
          if (String(s.month || s.date || s.start_date || '').slice(0, 7) === mk) regel = s;
        });
        if (!regel) return;
        afrrTelBij(regel, d);
        if (data.totals) afrrTelBij(data.totals, d);
      });
    }

    if (!afrrHeelWerk(data.series) || !afrrHeelWerk(data.totals)) return origineel;

    _afrrGevuld = dagen;
    data.afrr_aangevuld = dagen.length;
    return data;
  }

  // De onderschepping. Staat hier bovenaan omdat het script op document-start
  // draait: dan is dit vóór de eigen verzoeken van de pagina.
  if (AFRR_KLANT && AFRR_KLANT !== 'account') {
    window.fetch = function(input, init) {
      var url = typeof input === 'string' ? input
              : (input && typeof input.url === 'string') ? input.url : '';

      if (!afrrAan || url.indexOf('results_summary_api') === -1) return _origFetch(input, init);

      return _origFetch(input, init).then(function(antwoord) {
        if (!antwoord.ok) return antwoord;

        // Niet eindeloos wachten: liever de onaangeraakte cijfers dan een
        // dashboard dat blijft hangen.
        var opTijd = Promise.race([
          _afrrKlaar.then(function() { return true; }),
          new Promise(function(r) { setTimeout(function() { r(false); }, AFRR_WACHT_MS); })
        ]);

        return opTijd.then(function(gereed) {
          if (!gereed) return antwoord;
          // Vóór elke aanvulling controleren of Balans inmiddels verder is.
          return afrrVersBekend(false).then(function() {
            return antwoord.clone().json();
          }).then(function(data) {
            var nieuw = afrrVulAan(data, url.split('?')[1] || '');
            if (nieuw === data) return antwoord;
            return new Response(JSON.stringify(nieuw), {
              status: antwoord.status,
              statusText: antwoord.statusText,
              headers: { 'Content-Type': 'application/json' }
            });
          }).catch(function() { return antwoord; });
        });
      });
    };
  }

  /** Ontbrekende dagen opzoeken en hun aFRR-resultaat uitrekenen. */
  function afrrStart() {
    if (!afrrAan || !AFRR_KLANT || AFRR_KLANT === 'account') { _afrrKlaarZet(); return; }

    afrrVersBekend(true).then(function() {
      if (!_afrrProbeOk) { _afrrKlaarZet(); return; }

      var eind = afrrVandaag();
      var begin = afrrPlusDag(eind, -AFRR_TERUG_DAGEN);
      var gaten = [];
      for (var d = begin; d <= eind; d = afrrPlusDag(d, 1)) {
        if (!_afrrBekend.has(d)) gaten.push(d);
      }
      // Veiligheidsklep: de recentste gaten eerst, nooit meer dan AFRR_MAX_DAGEN.
      if (gaten.length > AFRR_MAX_DAGEN) gaten = gaten.slice(gaten.length - AFRR_MAX_DAGEN);
      if (!gaten.length) { _afrrKlaarZet(); return; }

      // Vier tegelijk, zodat het dashboard niet stokt.
      var i = 0;
      function volgendeBlok() {
        if (i >= gaten.length) { _afrrKlaarZet(); return; }
        var blok = gaten.slice(i, i + 4);
        i += 4;
        Promise.all(blok.map(afrrHaalDag)).then(function(res) {
          res.forEach(function(r, k) { if (r) _afrrPerDag[blok[k]] = r; });
          volgendeBlok();
        });
      }
      volgendeBlok();
    });

    // Elk half uur opnieuw kijken: dagen kunnen alsnog binnenkomen, en de
    // aFRR-cijfers van gisteren kunnen nog bijvullen.
    setInterval(function() {
      afrrVersBekend(true).then(function() {
        if (!_afrrProbeOk) return;
        [afrrVandaag(), afrrPlusDag(afrrVandaag(), -1)].forEach(function(d) {
          if (_afrrBekend.has(d)) return;
          afrrHaalDag(d).then(function(r) { if (r) _afrrPerDag[d] = r; });
        });
      });
    }, 30 * 60 * 1000);
  }

  // ─── aFRR-markering in de weergave ───────────────────────────────────────
  //
  //  Een aangevulde dag mag nooit voor een afgerekende dag doorgaan. In de
  //  dagweergave komt er een oranje band achter die dagen te staan, en in de
  //  dagtabel krijgen de rijen een oranje streep.

  var _afrrBandGeregistreerd = false;

  function afrrMarkeerGrafiek() {
    if (!afrrAan || !window.Chart) return;

    if (!_afrrBandGeregistreerd) {
      _afrrBandGeregistreerd = true;
      // Let op: níét via chart.config.plugins. Bij deze grafiek bestaat die
      // array nog niet, en `chart.config.plugins = []` komt niet aan omdat
      // config bij Chart.js 4 een proxy is — de hook wordt dan nooit
      // aangeroepen, zonder foutmelding. Globaal registreren werkt wel; de
      // hook kijkt zelf naar welk canvas hij tekent.
      Chart.register({
        id: 'afrrBand',
        beforeDatasetsDraw: function(c) {
          if (!afrrAan || !c.canvas || c.canvas.id !== 'summary-chart') return;
          var labels = c.data.labels || [];
          if (!labels.length) return;
          // Alleen in de dagweergave; een maandstaaf is deels echt en deels
          // aangevuld, die markeren zou misleiden.
          if (!/^\d{2}-\d{2}-\d{4}$/.test(String(labels[0]))) return;

          var van = -1, tot = -1;
          labels.forEach(function(l, i) {
            if (afrrGeschat(afrrIsoUitNl(String(l)))) { if (van < 0) van = i; tot = i; }
          });
          if (van < 0) return;

          var ctx = c.ctx, x = c.scales.x, ca = c.chartArea;
          var halve = (x.getPixelForValue(1) - x.getPixelForValue(0)) / 2 || 8;
          var links = x.getPixelForValue(van) - halve;
          var rechts = x.getPixelForValue(tot) + halve;

          ctx.save();
          ctx.fillStyle = AFRR_ORANJE_BAND;
          ctx.fillRect(links, ca.top, rechts - links, ca.bottom - ca.top);
          ctx.strokeStyle = AFRR_ORANJE;
          ctx.setLineDash([4, 3]);
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(links, ca.top);
          ctx.lineTo(links, ca.bottom);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = AFRR_ORANJE;
          ctx.font = '600 10px system-ui, -apple-system, sans-serif';
          ctx.textAlign = 'left';
          ctx.fillText('aangevuld · alleen aFRR', links + 4, ca.top + 12);
          ctx.restore();
        }
      });
    }

    // Een globale plugin pakt bij de eerstvolgende tekenbeurt. Balans bouwt de
    // grafiek opnieuw op bij elke periodewissel, dus per instantie één keer een
    // update afdwingen.
    var chart = Chart.getChart('summary-chart');
    if (chart && !chart.$afrrGetekend) { chart.$afrrGetekend = true; chart.update('none'); }
  }

  function afrrMarkeerTabel() {
    var tbody = document.getElementById('summary-table-body');
    if (!tbody) return;
    Array.from(tbody.querySelectorAll('tr')).forEach(function(tr) {
      var eerste = tr.firstElementChild;
      if (!eerste) return;
      var tekst = eerste.textContent.trim();
      if (!/^\d{1,2}-\d{2}-\d{4}/.test(tekst)) return;
      var d = afrrIsoUitNl(tekst.slice(0, 10));
      var hoort = afrrAan && afrrGeschat(d);
      if (hoort === (tr.dataset.afrrGeschat === '1')) return;

      tr.dataset.afrrGeschat = hoort ? '1' : '0';
      Array.from(tr.querySelectorAll('.afrr-merk')).forEach(function(e) { e.remove(); });
      if (hoort) {
        tr.style.background = 'rgba(255,122,0,.055)';
        eerste.style.boxShadow = 'inset 3px 0 0 0 ' + AFRR_ORANJE;
        var merk = document.createElement('div');
        merk.className = 'afrr-merk';
        merk.style.cssText = 'font-size:9px;color:' + AFRR_ORANJE + ';font-weight:600;';
        merk.textContent = 'aangevuld · alleen aFRR';
        eerste.appendChild(merk);
      } else {
        tr.style.background = '';
        eerste.style.boxShadow = '';
      }
    });
  }

  /** Samenvatting voor het belpaneel. */
  function afrrSamenvatting() {
    var datums = Object.keys(_afrrPerDag).filter(afrrGeschat).sort();
    var netto = 0, opbrengst = 0, kosten = 0;
    datums.forEach(function(d) {
      netto += _afrrPerDag[d].netto;
      opbrengst += _afrrPerDag[d].opbrengst;
      kosten += _afrrPerDag[d].kosten;
    });
    return { datums: datums, netto: netto, opbrengst: opbrengst, kosten: kosten };
  }

  let allinMode = false;
  let geen2027 = false;
  let _originals = null;
  let _chartOriginals = null;
  let _dagData = null;
  let _dagLaatsteDag = null;
  let _dagOntbrekend = [];
  let _currentTitle = null;
  let _voorschotRetryTimer = null;
  var _lopendeMaandTotaal = null;
  var _lopendeMaandLabel  = null;
  var _lopendeMaandDagen  = null;
  // ─── Contractdata uit localStorage ───────────────────────────────────────
  var LS_PREFIX     = 'be_allin_';
  var LS_VOORSCHOT  = 'be_cfg_voorschot';
  var LS_STARTDATUM = 'be_cfg_startdatum';
  var LS_SALDERING  = 'be_cfg_saldering';
  var VOORSCHOT_PM = parseFloat(localStorage.getItem(LS_VOORSCHOT) || '42.98');
  var toonSaldering = localStorage.getItem(LS_SALDERING) === 'aan';
  var toonSalderingPrognose = false;
  var LEV_DAG  =  0.2184;
  var TRA_DAG  =  1.3861;
  var VER_DAG  =  1.7232;
  var VAST_DAG = LEV_DAG + TRA_DAG - VER_DAG;
  var NL_MAANDEN_KORT = ['Jan','Feb','Mrt','Apr','Mei','Jun','Jul','Aug','Sep','Okt','Nov','Dec'];
  var NL_MAANDEN_LANG = ['januari','februari','maart','april','mei','juni','juli','augustus','september','oktober','november','december'];
  var IMP_FACTOR = {
    'Jan': 1.00, 'Feb': 0.62, 'Mrt': 0.25, 'Apr': 0.09,
    'Mei': 0.02, 'Jun': 0.01, 'Jul': 0.02, 'Aug': 0.03,
    'Sep': 0.10, 'Okt': 0.32, 'Nov': 0.57, 'Dec': 0.87
  };
  var EXP_FACTOR = {
    'Jan': 0.10, 'Feb': 0.18, 'Mrt': 0.45, 'Apr': 1.00,
    'Mei': 1.30, 'Jun': 1.32, 'Jul': 1.18, 'Aug': 0.96,
    'Sep': 0.74, 'Okt': 0.28, 'Nov': 0.12, 'Dec': 0.08
  };
  function dagenInMaand(label) {
    var delen = label.split(' ');
    var mIdx = NL_MAANDEN_KORT.indexOf(delen[0]);
    var jaar = parseInt(delen[1]);
    if (mIdx === -1 || isNaN(jaar)) return 30;
    return new Date(jaar, mIdx + 1, 0).getDate();
  }
  function dagenVerstreken(label) {
    var delen = label.split(' ');
    var mIdx = NL_MAANDEN_KORT.indexOf(delen[0]);
    var jaar = parseInt(delen[1]);
    if (mIdx === -1 || isNaN(jaar)) return 30;
    var nu = new Date();
    var isMaandNu = nu.getMonth() === mIdx && nu.getFullYear() === jaar;
    return isMaandNu ? nu.getDate() : dagenInMaand(label);
  }
  function leesStartdatum() {
    var s = localStorage.getItem(LS_STARTDATUM);
    if (s) { var d = new Date(s); if (!isNaN(d)) return d; }
    return new Date('2025-11-04');
  }
  function CONTRACT_MAANDEN() {
    var start = leesStartdatum();
    var result = [];
    for (var i = 0; i < 12; i++) {
      var d = new Date(start.getFullYear(), start.getMonth() + i, 1);
      result.push(NL_MAANDEN_KORT[d.getMonth()] + ' ' + d.getFullYear());
    }
    return result;
  }
  var MAAND_MAP = {
    'januari':'Jan','februari':'Feb','maart':'Mrt','april':'Apr',
    'mei':'Mei','juni':'Jun','juli':'Jul','augustus':'Aug',
    'september':'Sep','oktober':'Okt','november':'Nov','december':'Dec'
  };
  function maandLabelUitTitel(titel) {
    if (!titel) return null;
    var m = titel.toLowerCase();
    for (var nl in MAAND_MAP) {
      if (m.indexOf(nl) !== -1) {
        var jaarMatch = titel.match(/\d{4}/);
        if (jaarMatch) return MAAND_MAP[nl] + ' ' + jaarMatch[0];
      }
    }
    return null;
  }
  function maandKortUitLabel(label) { return (label || '').split(' ')[0]; }
  function lsSleutel(label) { return LS_PREFIX + label.replace(' ', '_'); }
  function slaAllinOp(label, totaal, expKwh, impKwh) {
    try {
      localStorage.setItem(lsSleutel(label), totaal.toFixed(2));
      if (expKwh !== undefined) localStorage.setItem(lsSleutel(label) + '_expkwh', expKwh.toFixed(1));
      if (impKwh !== undefined) localStorage.setItem(lsSleutel(label) + '_impkwh', impKwh.toFixed(1));
    } catch(e) {}
  }
  var LS_ONTBREKEND = 'be_ontbrekend_';
  function slaOntbrekendOp(label, dagen) {
    try {
      localStorage.setItem(LS_ONTBREKEND + label.replace(' ', '_'), JSON.stringify(dagen));
    } catch(e) {}
  }
  function leesOntbrekendJaar() {
    var totaal = [];
    CONTRACT_MAANDEN().forEach(function(label) {
      try {
        var v = localStorage.getItem(LS_ONTBREKEND + label.replace(' ', '_'));
        if (v) { var dagen = JSON.parse(v); totaal = totaal.concat(dagen); }
      } catch(e) {}
    });
    return totaal;
  }
  function leesAllin(label) {
    try { var v = localStorage.getItem(lsSleutel(label)); return v !== null ? parseFloat(v) : null; } catch(e) { return null; }
  }
  function leesExpKwh(label) {
    try { var v = localStorage.getItem(lsSleutel(label) + '_expkwh'); return v !== null ? parseFloat(v) : null; } catch(e) { return null; }
  }
  function leesImpKwh(label) {
    try { var v = localStorage.getItem(lsSleutel(label) + '_impkwh'); return v !== null ? parseFloat(v) : null; } catch(e) { return null; }
  }
  function leesAlleMaanden() {
    var nu = new Date();
    var lopendLabel = NL_MAANDEN_KORT[nu.getMonth()] + ' ' + nu.getFullYear();
    return CONTRACT_MAANDEN().map(function(label) {
      var isLopend = label === lopendLabel;
      if (isLopend) {
        var lopend = leesLopendeMaand(label);
        if (lopend) {
          return { label: label, kosten: null, expKwh: lopend.expKwh, impKwh: lopend.impKwh,
                   lopendTotaal: lopend.totaal, lopendDagen: lopend.dagen };
        }
      }
      return { label: label, kosten: leesAllin(label), expKwh: leesExpKwh(label), impKwh: leesImpKwh(label) };
    });
  }
  function vandaagStamp() {
    var nu = new Date();
    return nu.getFullYear() + '-' + (nu.getMonth()+1) + '-' + nu.getDate();
  }
  function slaLopendeMaandOp(label, totaal, expKwh, impKwh, dagen) {
    try {
      var data = { totaal: totaal, expKwh: expKwh, impKwh: impKwh, dagen: dagen, datum: vandaagStamp() };
      localStorage.setItem(lsSleutel(label) + '_lopend', JSON.stringify(data));
    } catch(e) {}
  }
  function leesLopendeMaand(label) {
    try {
      var v = localStorage.getItem(lsSleutel(label) + '_lopend');
      if (!v) return null;
      var data = JSON.parse(v);
      if (data.datum !== vandaagStamp()) return null;
      return data;
    } catch(e) { return null; }
  }
  function verwijderLopendeMaand() {
    var nu = new Date();
    var lopendLabel = NL_MAANDEN_KORT[nu.getMonth()] + ' ' + nu.getFullYear();
    try {
      localStorage.removeItem(lsSleutel(lopendLabel));
      localStorage.removeItem(lsSleutel(lopendLabel) + '_expkwh');
      localStorage.removeItem(lsSleutel(lopendLabel) + '_impkwh');
    } catch(e) {}
  }
  // ─── Schat kWh voor onbekende maanden ────────────────────────────────────
  function schatImpKwhVoorMaand(label, alleMaanden) {
    var maand = maandKortUitLabel(label);
    var bekend = alleMaanden.filter(function(m) {
      return m.impKwh !== null && m.impKwh !== undefined && !isNaN(m.impKwh) && m.impKwh > 0;
    });
    var exact = bekend.find(function(m) { return m.label === label; });
    if (exact) return exact.impKwh;
    if (!bekend.length) return 150 * (IMP_FACTOR[maand] || 0.5);
    var df = IMP_FACTOR[maand] || 0.5;
    var totGewicht = 0, totSchatting = 0;
    bekend.forEach(function(m) {
      var ankerMaand = maandKortUitLabel(m.label);
      var af = IMP_FACTOR[ankerMaand] || 1.0;
      var schatting = m.impKwh * (df / af);
      var vergelijkbaarheid = Math.min(af, df) / Math.max(af, df);
      var gewicht = 0.3 + vergelijkbaarheid * 0.7;
      totGewicht += gewicht;
      totSchatting += schatting * gewicht;
    });
    return totSchatting / totGewicht;
  }
  function schatExpKwhVoorMaand(label, alleMaanden) {
    var maand = maandKortUitLabel(label);
    var bekend = alleMaanden.filter(function(m) {
      return m.expKwh !== null && m.expKwh !== undefined && !isNaN(m.expKwh) && m.expKwh > 0;
    });
    var exact = bekend.find(function(m) { return m.label === label; });
    if (exact) return exact.expKwh;
    if (!bekend.length) return 0;
    var df = EXP_FACTOR[maand] || 0.5;
    var totGewicht = 0, totSchatting = 0;
    bekend.forEach(function(m) {
      var ankerMaand = maandKortUitLabel(m.label);
      var af = EXP_FACTOR[ankerMaand] || 0.1;
      if (af < 0.05) return;
      var schatting = m.expKwh * (df / af);
      var vergelijkbaarheid = Math.min(af, df) / Math.max(af, df);
      var gewicht = 0.3 + vergelijkbaarheid * 0.7;
      totGewicht += gewicht;
      totSchatting += schatting * gewicht;
    });
    if (totGewicht === 0) return 0;
    return totSchatting / totGewicht;
  }
  function isNaSaldering(label) {
    var jaar = parseInt((label || '').split(' ')[1]);
    return jaar >= 2027;
  }
  function berekenSalderingPerMaand(alleMaanden, metPrognose) {
    var cumImp = 0, cumExp = 0;
    return alleMaanden.map(function(m) {
      var heeftImp = m.impKwh !== null && m.impKwh !== undefined && !isNaN(m.impKwh);
      var heeftExp = m.expKwh !== null && m.expKwh !== undefined && !isNaN(m.expKwh);
      var isOnbekend = !heeftImp && !heeftExp;
      var imp, exp;
      if (isOnbekend && !metPrognose) {
        imp = 0; exp = 0;
      } else {
        imp = heeftImp ? m.impKwh : schatImpKwhVoorMaand(m.label, alleMaanden);
        exp = heeftExp ? m.expKwh : schatExpKwhVoorMaand(m.label, alleMaanden);
      }
      if (isNaSaldering(m.label)) {
        return {
          label: m.label, imp: imp, exp: exp,
          cumImp: cumImp + imp, cumExp: cumExp + exp,
          ongesaldeerd: exp, gesaldeerd: 0,
          isSchatting: isOnbekend, isOvergeslagen: isOnbekend && !metPrognose, isNaSaldering: true
        };
      }
      var impVorig = cumImp;
      var expVorig = cumExp;
      cumImp += imp;
      cumExp += exp;
      var ongesaldeerd = 0;
      if (cumExp <= cumImp) {
        ongesaldeerd = 0;
      } else if (expVorig >= impVorig && impVorig > 0) {
        ongesaldeerd = exp;
      } else {
        var resterend = impVorig - expVorig;
        var totaalRuimte = resterend + imp;
        var gesaldeerd = Math.min(exp, totaalRuimte);
        ongesaldeerd = Math.max(0, exp - gesaldeerd);
      }
      return {
        label: m.label, imp: imp, exp: exp,
        cumImp: cumImp, cumExp: cumExp,
        ongesaldeerd: ongesaldeerd, gesaldeerd: exp - ongesaldeerd,
        isSchatting: isOnbekend, isOvergeslagen: isOnbekend && !metPrognose, isNaSaldering: false
      };
    });
  }
  function berekenSalderingsbalans(alleMaanden, metPrognose) {
    var perMaand = berekenSalderingPerMaand(alleMaanden, metPrognose);
    var last = perMaand[perMaand.length - 1];
    var totImp = last ? last.cumImp : 0;
    var totExp = last ? last.cumExp : 0;
    return {
      totImp: totImp, totExp: totExp,
      gesaldeerd: Math.min(totImp, totExp),
      overschotExp: Math.max(0, totExp - totImp),
      resterendRuimte: Math.max(0, totImp - totExp),
      perMaand: perMaand
    };
  }
  // ─── Formatters ──────────────────────────────────────────────────────────
  function verbergBetaBlok() {
    // Verberg de BETA-introkaart via de specifieke class (nieuw dashboard)
    Array.from(document.querySelectorAll('.results-intro-card')).forEach(function(el) {
      el.style.display = 'none';
    });
    // Fallback: oude structuur via h3 (legacy)
    Array.from(document.querySelectorAll('h3')).forEach(function(h) {
      if (h.textContent.trim() === 'Resultaten (BETA)') {
        var parent = h.closest('.card');
        if (parent) parent.style.display = 'none';
      }
    });
  }
  function parseEuro(str) {
    if (!str) return null;
    return parseFloat(str.replace(/[€\s]/g, '').replace(',', '.'));
  }
  function parseKwhPair(str) {
    var parts = str.split('kWh')
      .map(function(s) { return parseFloat(s.trim().replace(/\./g, '').replace(',', '.')); })
      .filter(function(n) { return !isNaN(n) && n >= 0; });
    return { a: parts[0] || 0, b: parts[1] || 0 };
  }
  function fmt(val) {
    var abs = Math.abs(val).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return (val < 0 ? '-' : '+') + ' € ' + abs;
  }
  function fmtV(val) {
    var abs = Math.abs(val).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return (val < 0 ? '−' : '+') + ' € ' + abs;
  }
  function fmtCard(val) {
    var abs = Math.abs(val).toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    return (val < 0 ? '-' : '') + '€ ' + abs;
  }
  function fmtKwh(val) {
    var abs = Math.abs(val).toLocaleString('nl-NL', { minimumFractionDigits: 3, maximumFractionDigits: 3 });
    return (val < 0 ? '-' : '') + '€ ' + abs + ' / kWh';
  }
  function fmtNum(val, dec) {
    return val.toLocaleString('nl-NL', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }
  function fmtDatum(d) {
    return d.getDate() + ' ' + NL_MAANDEN_LANG[d.getMonth()] + ' ' + d.getFullYear();
  }
  // ─── All-in berekeningen ─────────────────────────────────────────────────
  function calcAllinDay(absInk, absVerk, gemInk, gemVerk) {
    var kWhImp = gemInk  !== 0 ? absInk  / Math.abs(gemInk)  : 0;
    var kWhExp = gemVerk !== 0 ? absVerk / Math.abs(gemVerk) : 0;
    var epexInk  = (gemInk  < 0 ?  absInk  : -absInk)  * BTW;
    var epexVerk = (gemVerk < 0 ? -absVerk :  absVerk) * BTW;
    var nettoImp = Math.max(0, kWhImp - kWhExp);
    var nettoExp = Math.max(0, kWhExp - kWhImp);
    var eb     = -nettoImp * EB + nettoExp * EB;
    var opslag = -(kWhImp + kWhExp) * OPSLAG;
    return { ink: epexInk, verk: epexVerk, eb: eb, opslag: opslag, tot: epexInk + epexVerk + eb + opslag };
  }
  function calcAllinMonth(kaalInkoop, kaalVerkoop, gemInkoop, gemVerkoop, kWhExpOngesaldeerd) {
    var absInk  = Math.abs(kaalInkoop);
    var absVerk = Math.abs(kaalVerkoop);
    var kWhImp  = gemInkoop  !== 0 ? absInk  / Math.abs(gemInkoop)  : 0;
    var kWhExp  = gemVerkoop !== 0 ? absVerk / Math.abs(gemVerkoop) : 0;
    var epexInk  = (gemInkoop  < 0 ?  absInk  : -absInk)  * BTW;
    var epexVerk = (gemVerkoop < 0 ? -absVerk :  absVerk) * BTW;
    var ebInk  = -kWhImp * EB;
    var onges = Math.min(kWhExpOngesaldeerd || 0, kWhExp);
    var ges   = Math.max(0, kWhExp - onges);
    var ebVerk = ges * EB;
    var opslagInk  = -kWhImp * OPSLAG;
    var opslagVerk = -kWhExp * OPSLAG;
    var allinInk  = epexInk  + ebInk  + opslagInk;
    var allinVerk = epexVerk + ebVerk + opslagVerk;
    var btw = (epexInk - epexInk/BTW) + (epexVerk - epexVerk/BTW);
    var ebNetto = ebInk + ebVerk;
    var opslagTotaal = opslagInk + opslagVerk;
    var totaal = allinInk + allinVerk;
    var gemAllinInk  = kWhImp > 0 ? Math.abs(allinInk)  / kWhImp : 0;
    var gemAllinVerk = kWhExp > 0 ? Math.abs(allinVerk) / kWhExp : 0;
    var spread = gemAllinVerk - gemAllinInk;
    return {
      inkoop: allinInk, verkoop: allinVerk,
      eb: ebNetto, opslag: opslagTotaal, btw: btw, totaal: totaal,
      impPrijs: gemInkoop, expPrijs: gemVerkoop,
      gemAllinInk: gemAllinInk, gemAllinVerk: gemAllinVerk,
      spread: spread, kWhImp: kWhImp, kWhExp: kWhExp,
      kWhExpGesaldeerd: ges, kWhExpOngesaldeerd: onges
    };
  }
  function calcAllinPriceImp(kaalPrijs) { return (kaalPrijs + EB + OPSLAG) * BTW; }
  function calcAllinPriceExp(kaalPrijs) { return (kaalPrijs + EB - OPSLAG) * BTW; }
  // ─── Data lezen ──────────────────────────────────────────────────────────
  function readOriginals() {
    var inkEl  = document.getElementById('summary-stroom-voordeel');
    var verkEl = document.getElementById('summary-deal-result');
    var totEl  = document.getElementById('summary-total-result');
    var buyEl  = document.getElementById('summary-buy-price');
    var sellEl = document.getElementById('summary-sell-price');
    if (!inkEl || !totEl || !buyEl) return null;
    return {
      inkoop:  parseEuro(inkEl.textContent),
      verkoop: verkEl ? parseEuro(verkEl.textContent) : null,
      totaal:  parseEuro(totEl.textContent),
      gemInk:  parseEuro(buyEl.textContent.split('/')[0]),
      gemVerk: sellEl ? parseEuro(sellEl.textContent.split('/')[0]) : null,
    };
  }
  function readDagData() {
    var tbody = document.getElementById('summary-table-body');
    if (!tbody) return null;
    var rows = tbody.querySelectorAll('tr');
    var data = [];
    var laatsteDag = null;
    var dagDatums = [];
    rows.forEach(function(row) {
      var cells = row.querySelectorAll('td');
      if (cells.length < 5) return;
      var datumTekst = cells[0].textContent.trim();
      var ddmmjjjj = datumTekst.match(/^(\d{1,2})-(\d{2})-(\d{4})$/);
      if (ddmmjjjj) {
        var dag = parseInt(ddmmjjjj[1]);
        var mnd = parseInt(ddmmjjjj[2]);
        var jjj = parseInt(ddmmjjjj[3]);
        dagDatums.push(new Date(jjj, mnd - 1, dag));
        laatsteDag = dag;
      } else {
        var dagMatch = datumTekst.match(/\b(\d{1,2})\b/);
        if (dagMatch) laatsteDag = parseInt(dagMatch[1]);
      }
      var prijsTekst = cells[4].textContent.trim();
      var delen = prijsTekst.split(/kWh/).map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });
      var gemInk  = delen[0] ? parseEuro(delen[0].split('/')[0]) : 0;
      var gemVerk = delen[1] ? parseEuro(delen[1].split('/')[0]) : 0;
      var impExp = cells.length > 7 ? parseKwhPair(cells[7].textContent) : { a: 0, b: 0 };
      var bat    = cells.length > 8 ? parseKwhPair(cells[8].textContent) : { a: 0, b: 0 };
      data.push({
        absInk: Math.abs(parseEuro(cells[1].textContent) || 0),
        absVerk: Math.abs(parseEuro(cells[2].textContent) || 0),
        gemInk: gemInk || 0, gemVerk: gemVerk || 0,
        impKwh: impExp.a, expKwh: impExp.b,
        batLaden: bat.a, batOntladen: bat.b,
      });
    });
    var ontbrekendeDagen = [];
    if (dagDatums.length >= 2) {
      dagDatums.sort(function(a, b) { return a - b; });
      for (var i = 1; i < dagDatums.length; i++) {
        var diff = (dagDatums[i] - dagDatums[i-1]) / (1000 * 60 * 60 * 24);
        if (diff > 1) {
          for (var g = 1; g < diff; g++) {
            var missDag = new Date(dagDatums[i-1]);
            missDag.setDate(missDag.getDate() + g);
            ontbrekendeDagen.push(missDag.getDate() + '-' + String(missDag.getMonth()+1).padStart(2,'0') + '-' + missDag.getFullYear());
          }
        }
      }
    }
    return data.length > 0 ? { data: data, laatsteDag: laatsteDag, ontbrekend: ontbrekendeDagen } : null;
  }
  // ─── FPR ─────────────────────────────────────────────────────────────────
  function calcFpr(dagData) {
    if (!dagData || dagData.length === 0) return null;
    var gemLaden = dagData.reduce(function(a, d) { return a + d.batLaden; }, 0) / dagData.length;
    var isMaand = gemLaden > 200;
    var totLaadWaarde = 0, totOntlaadWaarde = 0, totLaadKwh = 0, totOntlaadKwh = 0;
    dagData.forEach(function(d) {
      var allinImp = calcAllinPriceImp(d.gemInk  || 0);
      var allinExp = calcAllinPriceExp(d.gemVerk || 0);
      var exportViaBat   = Math.min(d.expKwh || 0, d.batOntladen || 0);
      var verbruikViaBat = Math.max(0, (d.batOntladen || 0) - exportViaBat);
      var ontlaadWaarde = (exportViaBat * allinExp) + (verbruikViaBat * allinImp);
      var laadWaarde    = (d.batLaden || 0) * allinImp;
      totLaadKwh    += d.batLaden    || 0;
      totOntlaadKwh += d.batOntladen || 0;
      totLaadWaarde    += laadWaarde;
      totOntlaadWaarde += ontlaadWaarde;
    });
    var gemLaadAllin    = totLaadKwh    > 0 ? totLaadWaarde    / totLaadKwh    : 0;
    var gemOntlaadAllin = totOntlaadKwh > 0 ? totOntlaadWaarde / totOntlaadKwh : 0;
    var fpr = totLaadWaarde > 0 ? totOntlaadWaarde / totLaadWaarde : null;
    return { fpr: fpr, gemLaadAllin: gemLaadAllin, gemOntlaadAllin: gemOntlaadAllin,
      totLaadKwh: totLaadKwh, totOntlaadKwh: totOntlaadKwh,
      nettoResultaat: totOntlaadWaarde - totLaadWaarde,
      perioden: dagData.length, isMaandWeergave: isMaand };
  }
  function removeFprRow() { var el = document.getElementById('be-fpr-row'); if (el) el.remove(); }
  function fprKleur(fpr) {
    if (fpr === null) return DS.textMuted;
    if (fpr >= 1.6) return DS.green;
    if (fpr >= 1.05) return DS.purple;
    if (fpr >= 1.0) return '#fd7e14';
    return DS.red;
  }
  function fprLabel(fpr) {
    if (fpr === null) return '–';
    if (fpr >= 1.8) return 'Uitstekend';
    if (fpr >= 1.6) return 'Zeer goed';
    if (fpr >= 1.4) return 'Goed';
    if (fpr >= 1.2) return 'Redelijk';
    if (fpr >= 1.05) return 'Matig';
    if (fpr >= 1.0) return 'Break-even';
    return 'Verlies';
  }
  function addFprRow(dagData) {
    removeFprRow();
    var kaleWrapper = document.getElementById('be-kale-wrapper');
    if (!kaleWrapper) return;
    var fprData = calcFpr(dagData);
    if (!fprData) return;
    var fpr = fprData.fpr, kleur = fprKleur(fpr), label = fprLabel(fpr);
    var fprTxt = fpr !== null ? fmtNum(fpr, 2) : '–';
    var pct = Math.min(100, Math.max(0, ((fpr || 0) / 2) * 100));
    var periode = fprData.isMaandWeergave ? 'maanden' : 'dagen';
    var rendement = fpr !== null ? fmtNum((fpr - 1) * 100, 0) + '%' : '–';
    var rendementPrefix = fpr !== null && fpr >= 1 ? '+' : '';
    var row = document.createElement('div');
    row.id = 'be-fpr-row';
    row.style.cssText = dsWidget();
    row.innerHTML =
      dsLabel('Financial Performance Ratio (FPR)') +
      '<div style="display:flex;align-items:center;gap:24px;flex-wrap:wrap;">' +
        '<div style="display:flex;align-items:center;gap:12px;min-width:160px;">' +
          '<span style="font-size:40px;font-weight:700;color:' + kleur + ';line-height:1;flex-shrink:0;">' + fprTxt + '</span>' +
          '<div style="display:flex;flex-direction:column;justify-content:center;gap:1px;">' +
            '<div style="font-size:13px;font-weight:700;color:' + kleur + ';">' + rendementPrefix + rendement + ' rendement</div>' +
            '<div style="font-size:11px;font-weight:600;color:' + kleur + ';opacity:0.85;">' + label + '</div>' +
            '<div style="font-size:10px;color:' + DS.textMuted + ';">ontladen ÷ laden</div>' +
          '</div>' +
        '</div>' +
        '<div style="width:1px;background:' + DS.divider + ';height:40px;"></div>' +
        '<div style="display:flex;gap:24px;flex-wrap:wrap;flex:1;align-items:flex-start;">' +
          '<div style="font-size:11px;color:' + DS.textMuted + ';"><div style="font-size:10px;margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Accu laden</div><div style="font-weight:600;">' + fmtNum(fprData.totLaadKwh, 1) + ' kWh</div><div style="font-weight:700;color:' + DS.red + ';">' + fmtNum(fprData.gemLaadAllin * 100, 1) + ' ct/kWh gem.</div></div>' +
          '<div style="font-size:11px;color:' + DS.textMuted + ';"><div style="font-size:10px;margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Accu ontladen</div><div style="font-weight:600;">' + fmtNum(fprData.totOntlaadKwh, 1) + ' kWh</div><div style="font-weight:700;color:' + DS.green + ';">' + fmtNum(fprData.gemOntlaadAllin * 100, 1) + ' ct/kWh gem.</div></div>' +
          '<div style="font-size:11px;color:' + DS.textMuted + ';"><div style="font-size:10px;margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Netto resultaat</div><div style="font-weight:700;font-size:14px;color:' + (fprData.nettoResultaat >= 0 ? DS.green : DS.red) + ';">' + fmt(fprData.nettoResultaat) + '</div><div style="font-size:10px;">' + fprData.perioden + ' ' + periode + '</div></div>' +
        '</div>' +
        '<div style="min-width:180px;flex:1;">' +
          '<div style="display:flex;justify-content:space-between;font-size:9px;color:' + DS.textMuted + ';margin-bottom:3px;"><span>0</span><span>0,5</span><span>1,0</span><span>1,5</span><span>2,0+</span></div>' +
          '<div style="height:8px;border-radius:4px;background:linear-gradient(to right,' + DS.red + ',' + '#fd7e14' + ' 25%,' + DS.purple + ' 50%,' + DS.green + ');position:relative;">' +
            '<div style="position:absolute;top:-3px;left:' + pct + '%;transform:translateX(-50%);width:14px;height:14px;border-radius:50%;background:white;border:2.5px solid ' + kleur + ';box-shadow:0 1px 4px rgba(0,0,0,0.15);"></div>' +
          '</div>' +
          '<div style="margin-top:6px;font-size:10px;color:' + DS.textMuted + ';text-align:right;">spread: ' + fmtNum((fprData.gemOntlaadAllin - fprData.gemLaadAllin) * 100, 1) + ' ct/kWh all-in</div>' +
        '</div>' +
      '</div>' +
      '<div style="margin-top:8px;font-size:10px;color:' + DS.textMuted + ';">factor x elke €1 aan laadkosten (net + PV) via export en eigen verbruik uit de accu</div>';
    kaleWrapper.after(row);
  }
  // ─── Salderingsmeter ─────────────────────────────────────────────────────
  function removeSalderingsRow() { var el = document.getElementById('be-saldering-row'); if (el) el.remove(); }
  function addSalderingsRow(alleMaanden, detailsOpen) {
    removeSalderingsRow();
    if (!toonSaldering) return;
    var voorschotRow = document.getElementById('be-voorschot-row');
    if (!voorschotRow) return;
    var sal = berekenSalderingsbalans(alleMaanden, toonSalderingPrognose);
    var overSchot = sal.overschotExp > 0;
    var ratio = sal.totImp > 0 ? sal.totExp / sal.totImp : 0;
    var naaldPct = Math.min(98, Math.max(2, ratio * 50));
    var naaldKleur = overSchot ? DS.red : DS.green;
    var statusTekst = overSchot
      ? 'Export overschrijdt import met ' + fmtNum(sal.overschotExp, 0) + ' kWh — dit deel zonder EB-voordeel' + (toonSalderingPrognose ? ' (incl. prognose)' : '')
      : 'Nog ' + fmtNum(sal.resterendRuimte, 0) + ' kWh saldeerruimte' + (toonSalderingPrognose ? ' na prognose dit jaar' : ' op basis van bekende maanden');
    var maandTabelHtml = '<div style="margin-top:10px;border-top:1px solid ' + DS.divider + ';padding-top:8px;">' +
      '<div style="display:grid;grid-template-columns:80px 70px 70px 70px 70px 1fr;gap:4px;font-size:10px;color:' + DS.textMuted + ';padding:0 4px 4px;border-bottom:1px solid ' + DS.divider + ';margin-bottom:4px;text-transform:uppercase;letter-spacing:0.04em;">' +
      '<div>Maand</div><div style="text-align:right;">Import</div><div style="text-align:right;">Export</div>' +
      '<div style="text-align:right;">Cum.imp</div><div style="text-align:right;">Cum.exp</div><div style="text-align:right;">Ongesal.</div>' +
      '</div>';
    sal.perMaand.forEach(function(m) {
      if (m.isOvergeslagen) {
        maandTabelHtml +=
          '<div style="display:grid;grid-template-columns:80px 70px 70px 70px 70px 1fr;gap:4px;font-size:10px;padding:3px 4px;opacity:0.3;">' +
          '<div style="color:' + DS.purpleLight + ';font-style:italic;">' + m.label + '</div>' +
          '<div style="text-align:right;">–</div><div style="text-align:right;">–</div>' +
          '<div style="text-align:right;">–</div><div style="text-align:right;">–</div>' +
          '<div style="text-align:right;">–</div></div>';
        return;
      }
      var isKantelpunt = !m.isNaSaldering && m.ongesaldeerd > 0 && (m.cumExp - m.exp) <= (m.cumImp - m.imp);
      var ongesKleur = m.ongesaldeerd > 0 ? DS.red : DS.textMuted;
      var bg = m.isNaSaldering ? 'rgba(220,53,69,0.04)' : (isKantelpunt ? 'rgba(220,53,69,0.06)' : (m.isSchatting ? 'rgba(107,63,160,0.03)' : 'transparent'));
      var stijl = m.isSchatting ? 'opacity:0.65;font-style:italic;' : '';
      maandTabelHtml +=
        '<div style="display:grid;grid-template-columns:80px 70px 70px 70px 70px 1fr;gap:4px;font-size:10px;padding:3px 4px;border-radius:3px;background:' + bg + ';' + stijl + '">' +
          '<div style="color:#555;">' + m.label +
            (isKantelpunt ? ' <span style="color:' + DS.red + ';font-size:9px;">&#9664;</span>' : '') +
            (m.isNaSaldering ? ' <span style="color:' + DS.red + ';font-size:9px;">&#9888;</span>' : '') +
          '</div>' +
          '<div style="text-align:right;">' + fmtNum(m.imp, 0) + '</div>' +
          '<div style="text-align:right;">' + fmtNum(m.exp, 0) + '</div>' +
          '<div style="text-align:right;">' + (m.isNaSaldering ? '–' : fmtNum(m.cumImp, 0)) + '</div>' +
          '<div style="text-align:right;color:' + (m.isNaSaldering ? DS.red : (m.cumExp > m.cumImp ? DS.red : '#333')) + ';">' + (m.isNaSaldering ? '–' : fmtNum(m.cumExp, 0)) + '</div>' +
          '<div style="text-align:right;color:' + ongesKleur + ';font-weight:' + (m.ongesaldeerd > 0 ? '600' : '400') + ';">' +
            (m.ongesaldeerd > 0 ? fmtNum(m.ongesaldeerd, 0) + ' kWh' : '–') +
          '</div>' +
        '</div>';
    });
    maandTabelHtml += '<div style="margin-top:6px;font-size:10px;color:' + DS.textMuted + ';">' +
      (toonSalderingPrognose ? 'Cursief = prognose · ' : 'Alleen bekende maanden · ') +
      '&#9664; = kantelpunt saldering · &#9888; = na 31 dec 2026 (geen saldering)</div></div>';
    var row = document.createElement('div');
    row.id = 'be-saldering-row';
    row.style.cssText = dsWidget();
    row.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;gap:8px;">' +
        '<div style="font-size:' + DS.labelSize + ';color:' + DS.labelColor + ';font-weight:' + DS.labelWeight + ';letter-spacing:' + DS.labelSpacing + ';text-transform:uppercase;">Salderingsbalans contractjaar</div>' +
        '<label id="be-sal-prognose-label" style="display:flex;align-items:center;gap:6px;cursor:pointer;flex-shrink:0;">' +
          '<span style="font-size:10px;color:' + (toonSalderingPrognose ? DS.purple : DS.textMuted) + ';font-weight:500;">incl. prognose</span>' +
          '<div id="be-sal-prognose-track" style="position:relative;width:36px;height:20px;border-radius:10px;background:' + (toonSalderingPrognose ? DS.purple : DS.divider) + ';transition:background 0.2s;flex-shrink:0;">' +
            '<div id="be-sal-prognose-thumb" style="position:absolute;top:3px;left:' + (toonSalderingPrognose ? '18px' : '3px') + ';width:14px;height:14px;border-radius:7px;background:white;transition:left 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>' +
          '</div>' +
        '</label>' +
      '</div>' +
      '<div style="display:flex;gap:0;margin-bottom:8px;border:1px solid ' + DS.divider + ';border-radius:8px;overflow:hidden;flex-wrap:wrap;">' +
        '<div style="flex:1;padding:8px 12px;min-width:100px;">' +
          '<div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Import (jaar)</div>' +
          '<div style="font-size:16px;font-weight:700;color:#333;">' + fmtNum(sal.totImp, 0) + ' kWh</div>' +
        '</div>' +
        '<div style="width:1px;background:' + DS.divider + ';"></div>' +
        '<div style="flex:1;padding:8px 12px;min-width:100px;">' +
          '<div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Export (jaar)</div>' +
          '<div style="font-size:16px;font-weight:700;color:' + (overSchot ? DS.red : DS.green) + ';">' + fmtNum(sal.totExp, 0) + ' kWh</div>' +
        '</div>' +
        '<div style="width:1px;background:' + DS.divider + ';"></div>' +
        '<div style="flex:1;padding:8px 12px;min-width:100px;">' +
          '<div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">' + (overSchot ? 'Overschot export' : 'Saldeerruimte') + '</div>' +
          '<div style="font-size:16px;font-weight:700;color:' + naaldKleur + ';">' + fmtNum(overSchot ? sal.overschotExp : sal.resterendRuimte, 0) + ' kWh</div>' +
        '</div>' +
      '</div>' +
      '<div style="margin-bottom:8px;">' +
        '<div style="display:flex;justify-content:space-between;font-size:10px;color:' + DS.textMuted + ';margin-bottom:4px;">' +
          '<span>← import domineert</span><span>break-even</span><span>export overschot →</span>' +
        '</div>' +
        '<div style="height:8px;border-radius:4px;background:linear-gradient(to right,' + DS.green + ' 0%,#a8d5b5 45%,#f0edf7 50%,#f5c0c0 55%,' + DS.red + ' 100%);position:relative;border:1px solid ' + DS.divider + ';">' +
          '<div style="position:absolute;top:0;left:50%;width:2px;height:100%;background:' + DS.purple + ';opacity:0.3;"></div>' +
          '<div style="position:absolute;top:-3px;left:' + naaldPct + '%;transform:translateX(-50%);width:14px;height:14px;border-radius:50%;background:white;border:2.5px solid ' + naaldKleur + ';box-shadow:0 1px 4px rgba(0,0,0,0.15);"></div>' +
        '</div>' +
      '</div>' +
      (overSchot ? '<div style="margin-bottom:8px;font-size:10px;color:' + DS.red + ';background:rgba(220,53,69,0.06);border-radius:6px;padding:5px 8px;">' +
        '⚠️ ' + fmtNum(sal.overschotExp, 0) + ' kWh export buiten saldering — geen EB-voordeel op dit deel.' +
        '</div>' : '') +
      '<details id="be-saldering-details"' + (detailsOpen ? ' open' : '') + '><summary style="cursor:pointer;font-size:11px;color:' + DS.textMuted + ';list-style:none;">' + (detailsOpen ? '▼ Maanddetails verbergen' : '▶ Maanddetails tonen') + '</summary>' +
      maandTabelHtml + '</details>' +
      '<div style="margin-top:4px;font-size:10px;color:' + DS.textMuted + ';">2026 is het laatste jaar met volledige saldering</div>';
    voorschotRow.after(row);
    document.getElementById('be-sal-prognose-label').addEventListener('click', function(e) {
      e.stopPropagation();
      var det = document.getElementById('be-saldering-details');
      var wasOpen = det ? det.open : false;
      toonSalderingPrognose = !toonSalderingPrognose;
      addSalderingsRow(alleMaanden, wasOpen);
    });
    var det = document.getElementById('be-saldering-details');
    if (det) {
      det.addEventListener('toggle', function() {
        var sum = det.querySelector('summary');
        if (sum) sum.textContent = det.open ? '▼ Maanddetails verbergen' : '▶ Maanddetails tonen';
      });
    }
  }
  // ─── Voorschot widget ────────────────────────────────────────────────────
  function bepaalAnkersWaarde(alleMaanden) {
    var bekend = alleMaanden.filter(function(m) { return m.kosten !== null && m.kosten !== undefined; });
    function mk(l) { return (l || '').split(' ')[0]; }
    function fil(arr, labs) { return arr.filter(function(m) { return labs.indexOf(mk(m.label)) !== -1; }); }
    function minK(arr) { if (!arr.length) return null; return Math.min.apply(null, arr.map(function(m) { return m.kosten; })); }
    function maxK(arr) { if (!arr.length) return null; return Math.max.apply(null, arr.map(function(m) { return m.kosten; })); }
    function avgK(arr) { if (!arr.length) return null; return arr.reduce(function(a, m) { return a + m.kosten; }, 0) / arr.length; }
    var wb = fil(bekend, ['Nov','Dec','Jan','Feb']), zb = fil(bekend, ['Mei','Jun','Jul','Aug']), ob = fil(bekend, ['Mrt','Apr','Sep','Okt']);
    var winter = -260, ok = 25, zomer = 110;
    var wd = minK(wb); if (wd !== null) winter = wd;
    var od = avgK(ob); if (od !== null) ok = od;
    var zd = maxK(zb); if (zd !== null) zomer = zd;
    if (zd === null) {
      var lb = bekend.filter(function(m) { var k = mk(m.label); return k === 'Apr' || k === 'Mei'; });
      var lm = maxK(lb); if (lm !== null) zomer = Math.max(zomer, lm * 1.35);
    }
    if (ok < winter) ok = winter + 40;
    if (zomer < ok)  zomer = ok + 40;
    return { winter: winter, ok: ok, zomer: zomer };
  }
  function prognoseWaardeVoorMaand(label, ankers) {
    var maand = maandKortUitLabel(label);
    var PROFIEL = {
      'Jan': { winter: 1.00, zomer: 0.00 }, 'Feb': { winter: 0.72, zomer: 0.00 },
      'Mrt': { winter: 0.28, zomer: 0.10 }, 'Apr': { winter: 0.08, zomer: 0.28 },
      'Mei': { winter: 0.00, zomer: 0.62 }, 'Jun': { winter: 0.00, zomer: 1.00 },
      'Jul': { winter: 0.00, zomer: 0.86 }, 'Aug': { winter: 0.04, zomer: 0.52 },
      'Sep': { winter: 0.14, zomer: 0.24 }, 'Okt': { winter: 0.26, zomer: 0.08 },
      'Nov': { winter: 0.64, zomer: 0.00 }, 'Dec': { winter: 0.90, zomer: 0.00 }
    };
    var p = PROFIEL[maand] || { winter: 0.25, zomer: 0.20 };
    return ankers.ok - (ankers.ok - ankers.winter) * p.winter + (ankers.zomer - ankers.ok) * p.zomer;
  }
  function removeVoorschotRow() {
    if (_voorschotRetryTimer) { clearTimeout(_voorschotRetryTimer); _voorschotRetryTimer = null; }
    var el = document.getElementById('be-voorschot-row');
    if (el) el.remove();
    // reset ook lopende maand cache bij verwijderen
    _lopendeMaandTotaal = null;
    _lopendeMaandLabel  = null;
    _lopendeMaandDagen  = null;
  }
  function addVoorschotRow() {
    removeVoorschotRow();
    removeSalderingsRow();
    var fprRow = document.getElementById('be-fpr-row');
    if (!fprRow) {
      _voorschotRetryTimer = setTimeout(function() {
        _voorschotRetryTimer = null;
        if (allinMode && isMaandTab()) addVoorschotRow();
      }, 250);
      return;
    }
    var alleMaanden = leesAlleMaanden();
    VOORSCHOT_PM = parseFloat(localStorage.getItem(LS_VOORSCHOT) || '42.98');
    toonSaldering = localStorage.getItem(LS_SALDERING) === 'aan';
    function ebVerlies(m) {
      if (m.expKwh === null || m.expKwh === undefined) return 0;
      return m.expKwh * EB * BTW;
    }
    var bekendeMaanden = alleMaanden.filter(function(m) { return m.kosten !== null; });
    var totaalVast = bekendeMaanden.reduce(function(a, m) { return a + dagenVerstreken(m.label) * VAST_DAG; }, 0);
    var totaalWerkelijk = bekendeMaanden.reduce(function(a, m) { return a + m.kosten; }, 0);
    var lopendeMaand = alleMaanden.find(function(m) { return m.lopendTotaal !== undefined && m.lopendTotaal !== null; });
    if (lopendeMaand) {
      totaalWerkelijk += lopendeMaand.lopendTotaal;
      totaalVast += lopendeMaand.lopendDagen * VAST_DAG;
    }
    var totaalEbVerlies = geen2027 ? bekendeMaanden.reduce(function(a, m) { return a + ebVerlies(m); }, 0) : 0;
    var totaalWerkelijkInclVast = totaalWerkelijk - totaalVast - totaalEbVerlies;
    var aantalBetaald = bekendeMaanden.length + (lopendeMaand ? 1 : 0);
    var totaalBetaald = aantalBetaald * VOORSCHOT_PM;
    var openstaand    = totaalWerkelijkInclVast + totaalBetaald;
    var alleMaandenMetLopend = alleMaanden.map(function(m) {
      if (m.lopendTotaal !== undefined && m.lopendTotaal !== null) {
        return { label: m.label, kosten: m.lopendTotaal, expKwh: m.expKwh || 0, impKwh: m.impKwh || 0 };
      }
      return m;
    });
    var salPerMaand = berekenSalderingPerMaand(alleMaandenMetLopend, false);
    var ebCorrectie = 0;
    salPerMaand.forEach(function(s) {
      var heeftData = alleMaanden.some(function(m) {
        return m.label === s.label && (m.kosten !== null || (m.lopendTotaal !== undefined && m.lopendTotaal !== null));
      });
      if (heeftData && s.ongesaldeerd > 0) {
        ebCorrectie -= s.ongesaldeerd * EB * BTW;
      }
    });
    var totaalWerkelijkSald = totaalWerkelijkInclVast + ebCorrectie;
    var openstaandSald = totaalWerkelijkSald + totaalBetaald;
    var verstreken = bekendeMaanden.length + (lopendeMaand ? 1 : 0);
    var pct = Math.round((verstreken / 12) * 100);
    var saldoKleur     = openstaand < 0 ? DS.red : DS.green;
    var werkelijkKleur = totaalWerkelijkInclVast < 0 ? DS.red : DS.green;
    var huidigLabel    = maandLabelUitTitel(_currentTitle);
    var contractStart  = leesStartdatum();
    var contractEind   = new Date(contractStart.getFullYear(), contractStart.getMonth() + 12, contractStart.getDate() - 1);
    var ankersWaarde   = bepaalAnkersWaarde(alleMaanden);
    var cum = 0, maandHtml = '';
    alleMaanden.forEach(function(m, i) {
      var isCurrent = m.label === huidigLabel;
      var isOnbekend = m.kosten === null;
      var progKosten;
      if (isOnbekend) {
        var basisProg  = prognoseWaardeVoorMaand(m.label, ankersWaarde);
        var progExpKwh = schatExpKwhVoorMaand(m.label, alleMaanden);
        var progEbVerlies = geen2027 ? (progExpKwh * EB * BTW) : 0;
        progKosten = Math.round(basisProg - progEbVerlies);
      } else {
        progKosten = m.kosten - (geen2027 ? ebVerlies(m) : 0);
      }
      var kostVoorCum = progKosten;
      var dagenVoorCum = dagenVerstreken(m.label);
      if (isOnbekend && m.lopendTotaal !== undefined && m.lopendTotaal !== null) {
        kostVoorCum = m.lopendTotaal;
        dagenVoorCum = m.lopendDagen || dagenVerstreken(m.label);
      } else if (isOnbekend && isCurrent) {
        var lsCheck = leesLopendeMaand(m.label);
        if (lsCheck) { kostVoorCum = lsCheck.totaal; dagenVoorCum = lsCheck.dagen; }
      }
      cum += kostVoorCum + VOORSCHOT_PM - dagenVoorCum * VAST_DAG;
      var cumKleur = cum < 0 ? DS.red : DS.green;
      var bg = isCurrent ? 'rgba(107,63,160,0.05)' : (i % 2 === 0 ? 'rgba(107,63,160,0.02)' : 'transparent');
      if (isOnbekend) {
        var lopendData = null;
        if (isCurrent) {
          if (_lopendeMaandTotaal !== null && _lopendeMaandLabel === m.label) {
            lopendData = { totaal: _lopendeMaandTotaal, dagen: _lopendeMaandDagen };
          } else {
            var lsLopend = leesLopendeMaand(m.label);
            if (lsLopend) lopendData = { totaal: lsLopend.totaal, dagen: lsLopend.dagen };
          }
        }
        if (!lopendData && m.lopendTotaal !== undefined) {
          lopendData = { totaal: m.lopendTotaal, dagen: m.lopendDagen };
        }
        var heeftDeeldata = lopendData !== null;
        if (heeftDeeldata) {
          var pctBekend = Math.min(100, (lopendData.dagen / dagenInMaand(m.label)) * 100);
          var balkBreedte = Math.min(100, Math.abs(progKosten) / 4);
          var balkBekend  = Math.min(100, Math.abs(lopendData.totaal) / 4);
          var balkRest    = Math.max(0, balkBreedte - balkBekend);
          var kk = progKosten < 0 ? '#c8a0a0' : '#90c8a0';
          var kkFel = progKosten < 0 ? DS.red : DS.green;
          var vasteKostenL = dagenVoorCum * VAST_DAG;
          var vasteKleurL = vasteKostenL >= 0 ? DS.red : DS.green;
          var progOverstegen = Math.abs(lopendData.totaal) >= Math.abs(progKosten);
          var allinTekst = '<span style="color:' + (lopendData.totaal < 0 ? DS.red : DS.green) + ';font-weight:600;font-style:normal;">' + (lopendData.totaal < 0 ? '−' : '+') + '€' + Math.abs(lopendData.totaal).toFixed(0) + '</span>' +
            (progOverstegen ? '' : '<span style="color:' + DS.purpleLight + ';"> / </span>~' + (progKosten < 0 ? '−' : '+') + '€' + Math.abs(progKosten).toFixed(0));
          var lopendDatumTekst = (function() {
            var mIdx = NL_MAANDEN_KORT.indexOf(maandKortUitLabel(m.label));
            var mNaam = mIdx >= 0 ? NL_MAANDEN_LANG[mIdx] : m.label;
            return 'berekend t/m ' + lopendData.dagen + ' ' + mNaam;
          })();
          maandHtml += '<div style="display:grid;grid-template-columns:90px 1fr 110px 70px 68px 72px;gap:4px;align-items:start;padding:5px 4px 4px;border-radius:4px;background:' + bg + ';opacity:0.8;">' +
              '<div style="font-size:11px;color:' + DS.purple + ';font-style:italic;font-weight:600;padding-top:1px;">' + m.label + ' <span style="font-size:9px;color:' + DS.purpleLight + ';">●</span></div>' +
              '<div>' +
                '<div style="height:5px;border-radius:3px;background:#eee;overflow:hidden;display:flex;">' +
                  '<div style="height:100%;width:' + balkBekend + '%;background:' + kkFel + ';border-radius:3px 0 0 3px;flex-shrink:0;"></div>' +
                  '<div style="height:100%;width:' + (progOverstegen ? 0 : balkRest) + '%;background:' + kk + ';flex-shrink:0;"></div>' +
                '</div>' +
                '<div style="font-size:10px;color:' + DS.purple + ';font-weight:600;margin-top:3px;white-space:nowrap;">' + lopendDatumTekst + '</div>' +
              '</div>' +
              '<div style="text-align:right;font-size:11px;color:' + kk + ';font-style:italic;padding-top:1px;">' + allinTekst + '</div>' +
              '<div style="text-align:right;font-size:11px;color:' + DS.textMuted + ';padding-top:1px;">+€' + VOORSCHOT_PM.toFixed(2) + '</div>' +
              '<div style="text-align:right;font-size:11px;color:' + vasteKleurL + ';font-style:italic;padding-top:1px;">' + (vasteKostenL < 0 ? '−' : '+') + '€' + Math.abs(vasteKostenL).toFixed(2) + '</div>' +
              '<div style="text-align:right;font-size:11px;font-style:italic;color:' + (cum < 0 ? '#c8a0a0' : '#90c8a0') + ';padding-top:1px;">~' + (cum < 0 ? '−' : '+') + '€' + Math.abs(cum).toFixed(0) + '</div>' +
              '</div>';
        } else {
          var kk2 = progKosten < 0 ? '#c8a0a0' : '#90c8a0';
          var ck2 = cum < 0 ? '#c8a0a0' : '#90c8a0';
          var balk2 = Math.min(100, Math.abs(progKosten) / 4);
          var vasteKostenP = dagenInMaand(m.label) * VAST_DAG;
          var vasteKleurP = vasteKostenP >= 0 ? '#c8a0a0' : '#90c8a0';
          maandHtml += '<div style="display:grid;grid-template-columns:90px 1fr 110px 70px 68px 72px;gap:4px;align-items:start;padding:5px 4px 4px;border-radius:4px;background:' + bg + ';opacity:0.55;">' +
            '<div style="font-size:11px;color:' + DS.purpleLight + ';font-style:italic;padding-top:1px;">' + m.label + '</div>' +
            '<div>' +
              '<div style="height:5px;border-radius:3px;background:#eee;overflow:hidden;">' +
                '<div style="height:100%;width:' + balk2 + '%;background:' + kk2 + ';border-radius:3px;"></div>' +
              '</div>' +
              '<div style="height:13px;"></div>' +
            '</div>' +
            '<div style="text-align:right;font-size:11px;color:' + kk2 + ';font-style:italic;padding-top:1px;">~' + (progKosten < 0 ? '−' : '+') + '€' + Math.abs(progKosten).toFixed(0) + '</div>' +
            '<div style="text-align:right;font-size:11px;color:' + DS.textMuted + ';padding-top:1px;">+€' + VOORSCHOT_PM.toFixed(2) + '</div>' +
            '<div style="text-align:right;font-size:11px;color:' + vasteKleurP + ';font-style:italic;padding-top:1px;">' + (vasteKostenP < 0 ? '−' : '+') + '€' + Math.abs(vasteKostenP).toFixed(2) + '</div>' +
            '<div style="text-align:right;font-size:11px;font-style:italic;color:' + ck2 + ';padding-top:1px;">~' + (cum < 0 ? '−' : '+') + '€' + Math.abs(cum).toFixed(0) + '</div>' +
            '</div>';
        }
      } else {
        var kk3 = m.kosten < 0 ? DS.red : DS.green;
        var balk3 = Math.min(100, Math.abs(m.kosten) / 4);
        var vasteKosten3 = dagenVerstreken(m.label) * VAST_DAG;
        var vasteKleur3 = vasteKosten3 >= 0 ? DS.red : DS.green;
        maandHtml += '<div style="display:grid;grid-template-columns:90px 1fr 110px 70px 68px 72px;gap:4px;align-items:start;padding:5px 4px 4px;border-radius:4px;background:' + bg + ';">' +
          '<div style="font-size:11px;color:#333;font-weight:' + (isCurrent ? '600' : '400') + ';padding-top:1px;">' + m.label + (isCurrent ? ' <span style="font-size:9px;color:' + DS.purpleLight + ';">●</span>' : '') + '</div>' +
          '<div>' +
            '<div style="height:5px;border-radius:3px;background:#eee;overflow:hidden;">' +
              '<div style="height:100%;width:' + balk3 + '%;background:' + kk3 + ';border-radius:3px;"></div>' +
            '</div>' +
            '<div style="height:13px;"></div>' +
          '</div>' +
          '<div style="text-align:right;font-size:11px;font-weight:500;color:' + kk3 + ';padding-top:1px;">' + (m.kosten < 0 ? '−' : '+') + '€' + Math.abs(m.kosten).toFixed(2) + '</div>' +
          '<div style="text-align:right;font-size:11px;color:' + DS.textMuted + ';padding-top:1px;">+€' + VOORSCHOT_PM.toFixed(2) + '</div>' +
          '<div style="text-align:right;font-size:11px;color:' + vasteKleur3 + ';padding-top:1px;">' + (vasteKosten3 < 0 ? '−' : '+') + '€' + Math.abs(vasteKosten3).toFixed(2) + '</div>' +
          '<div style="text-align:right;font-size:11px;font-weight:500;color:' + cumKleur + ';padding-top:1px;">' + (cum < 0 ? '−' : '+') + '€' + Math.abs(cum).toFixed(0) + '</div>' +
          '</div>';
      }
    });
    var totAllin = 0, totVaste = 0;
    alleMaanden.forEach(function(m) {
      var dagen = dagenInMaand(m.label);
      if (m.kosten !== null) {
        totAllin += m.kosten;
        totVaste += dagenVerstreken(m.label) * VAST_DAG;
      } else if (m.lopendTotaal !== undefined && m.lopendTotaal !== null) {
        var basisProgLopend = prognoseWaardeVoorMaand(m.label, ankersWaarde);
        var gebruikLopend = Math.abs(m.lopendTotaal) >= Math.abs(Math.round(basisProgLopend));
        totAllin += gebruikLopend ? m.lopendTotaal : Math.round(basisProgLopend);
        totVaste += (gebruikLopend ? (m.lopendDagen || 0) : dagenInMaand(m.label)) * VAST_DAG;
      } else {
        var lsLopendCheck = leesLopendeMaand(m.label);
        if (lsLopendCheck) {
          var basisProgLs = prognoseWaardeVoorMaand(m.label, ankersWaarde);
          var gebruikLs = Math.abs(lsLopendCheck.totaal) >= Math.abs(Math.round(basisProgLs));
          totAllin += gebruikLs ? lsLopendCheck.totaal : Math.round(basisProgLs);
          totVaste += (gebruikLs ? (lsLopendCheck.dagen || 0) : dagenInMaand(m.label)) * VAST_DAG;
        } else {
          var basisProg2 = prognoseWaardeVoorMaand(m.label, ankersWaarde);
          totAllin += Math.round(basisProg2);
          totVaste += dagen * VAST_DAG;
        }
      }
    });
    var totVoorschot = 12 * VOORSCHOT_PM;
    var totEindSaldo = totAllin + totVoorschot + totVaste;
    var eindKleur = totEindSaldo >= 0 ? DS.green : DS.red;
    var totAllinKleur = totAllin >= 0 ? DS.green : DS.red;
    var totVasteKleur = totVaste >= 0 ? DS.red : DS.green;
    var totaalRij =
      '<div style="display:grid;grid-template-columns:110px 1fr 110px 70px 68px 72px;gap:4px;align-items:center;padding:6px 4px;border-top:1px solid ' + DS.divider + ';margin-top:4px;">' +
        '<div style="font-size:10px;color:' + DS.labelColor + ';font-weight:700;text-transform:uppercase;letter-spacing:0.05em;">Prognose jaar</div>' +
        '<div></div>' +
        '<div style="text-align:right;font-size:11px;font-weight:700;color:' + totAllinKleur + ';">' + (totAllin < 0 ? '−' : '+') + '€' + Math.abs(totAllin).toFixed(0) + '</div>' +
        '<div style="text-align:right;font-size:11px;font-weight:700;color:#333;">+€' + totVoorschot.toFixed(0) + '</div>' +
        '<div style="text-align:right;font-size:11px;font-weight:700;color:' + totVasteKleur + ';">' + (totVaste < 0 ? '−' : '+') + '€' + Math.abs(totVaste).toFixed(0) + '</div>' +
        '<div style="text-align:right;font-size:11px;font-weight:700;color:' + eindKleur + ';">' + (totEindSaldo < 0 ? '−' : '+') + '€' + Math.abs(totEindSaldo).toFixed(0) + '</div>' +
      '</div>';
    var saldCorrectieHtml = '';
    if (ebCorrectie < 0) {
      var saldWerkelijkKleur = totaalWerkelijkSald < 0 ? DS.red : DS.green;
      var saldSaldoKleur = openstaandSald < 0 ? DS.red : DS.green;
      saldCorrectieHtml =
        '<div style="margin-bottom:10px;border:1.5px solid ' + DS.purple + ';border-radius:8px;overflow:hidden;background:rgba(107,63,160,0.03);">' +
          '<div style="font-size:10px;color:' + DS.purple + ';font-weight:700;padding:6px 14px 4px;border-bottom:1px solid ' + DS.divider + ';letter-spacing:0.05em;text-transform:uppercase;">Incl. salderingscorrectie EB · <span style="font-weight:400;color:' + DS.purpleLight + ';">schatting op basis van bekende maanden</span></div>' +
          '<div style="display:flex;gap:0;flex-wrap:wrap;">' +
            '<div style="flex:1;padding:8px 14px;min-width:140px;"></div>' +
            '<div style="width:1px;background:' + DS.divider + ';"></div>' +
            '<div style="flex:1;padding:8px 14px;min-width:140px;">' +
              '<div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Werkelijk gecorrigeerd</div>' +
              '<div style="font-size:20px;font-weight:700;color:' + saldWerkelijkKleur + ';">' + (totaalWerkelijkSald < 0 ? '−' : '+') + '€ ' + Math.abs(totaalWerkelijkSald).toFixed(2) + '</div>' +
              '<div style="font-size:10px;color:' + DS.purpleLight + ';">EB-correctie: ' + (ebCorrectie < 0 ? '−' : '+') + '€ ' + Math.abs(ebCorrectie).toFixed(2) + '</div>' +
            '</div>' +
            '<div style="width:1px;background:' + DS.divider + ';"></div>' +
            '<div style="flex:1;padding:8px 14px;min-width:140px;">' +
              '<div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Saldo gecorrigeerd</div>' +
              '<div style="font-size:20px;font-weight:700;color:' + saldSaldoKleur + ';">' + fmtV(openstaandSald) + '</div>' +
              '<div style="font-size:10px;color:' + DS.textMuted + ';">' + (openstaandSald < 0 ? 'nog te betalen' : 'te ontvangen') + '</div>' +
            '</div>' +
          '</div>' +
        '</div>';
    }
    var row = document.createElement('div');
    row.id = 'be-voorschot-row';
    row.style.cssText = dsWidget();
    row.innerHTML =
      dsLabel('Voorschot &amp; verrekening') +
      '<div style="display:flex;gap:0;margin-bottom:14px;border:1px solid ' + DS.divider + ';border-radius:8px;overflow:hidden;flex-wrap:wrap;">' +
        '<div style="flex:1;padding:10px 14px;min-width:140px;"><div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Betaald t/m nu</div><div style="font-size:20px;font-weight:700;color:#333;">+€ ' + totaalBetaald.toFixed(2) + '</div><div style="font-size:10px;color:' + DS.textMuted + ';">' + aantalBetaald + ' × € ' + VOORSCHOT_PM.toFixed(2) + '</div></div>' +
        '<div style="width:1px;background:' + DS.divider + ';"></div>' +
        '<div style="flex:1;padding:10px 14px;min-width:140px;"><div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Werkelijk t/m nu</div><div style="font-size:20px;font-weight:700;color:' + werkelijkKleur + ';">' + (totaalWerkelijkInclVast < 0 ? '−' : '+') + ' € ' + Math.abs(totaalWerkelijkInclVast).toFixed(2) + '</div><div style="font-size:10px;color:' + DS.textMuted + ';">stroom + netbeheer + belastingen</div></div>' +
        '<div style="width:1px;background:' + DS.divider + ';"></div>' +
        '<div style="flex:1;padding:10px 14px;min-width:140px;"><div style="font-size:10px;color:' + DS.textMuted + ';margin-bottom:2px;text-transform:uppercase;letter-spacing:0.05em;">Huidig saldo</div><div style="font-size:20px;font-weight:700;color:' + saldoKleur + ';">' + fmtV(openstaand) + '</div><div style="font-size:10px;color:' + DS.textMuted + ';">' + (openstaand < 0 ? 'nog te betalen' : 'te ontvangen') + '</div></div>' +
      '</div>' +
      saldCorrectieHtml +
      '<div style="margin-bottom:12px;">' +
        '<div style="display:flex;justify-content:space-between;font-size:10px;color:' + DS.textMuted + ';margin-bottom:3px;"><span>' + fmtDatum(contractStart) + '</span><span style="color:' + DS.purple + ';font-weight:600;">● nu (' + verstreken + ' mnd)</span><span>' + fmtDatum(contractEind) + '</span></div>' +
        '<div style="height:8px;background:#ede8f5;border-radius:4px;position:relative;"><div style="height:100%;width:' + pct + '%;background:' + DS.purple + ';border-radius:4px;"></div><div style="position:absolute;top:-3px;left:' + pct + '%;transform:translateX(-50%);width:14px;height:14px;border-radius:50%;background:white;border:2.5px solid ' + DS.purple + ';box-shadow:0 1px 3px rgba(0,0,0,0.15);"></div></div>' +
        '<div style="font-size:10px;color:' + DS.textMuted + ';margin-top:3px;">' + verstreken + ' van 12 maanden · ' + pct + '% van contractjaar</div>' +
      '</div>' +
      '<details id="be-maand-details" style="margin-top:8px;"><summary style="cursor:pointer;font-size:11px;color:' + DS.textMuted + ';list-style:none;">▶ Maanddetails tonen</summary>' +
      '<div style="margin-top:8px;border-top:1px solid ' + DS.divider + ';padding-top:8px;">' +
        '<div style="display:grid;grid-template-columns:90px 1fr 110px 70px 68px 72px;gap:4px;font-size:10px;color:' + DS.textMuted + ';padding:0 4px 5px;border-bottom:1px solid ' + DS.divider + ';margin-bottom:4px;text-transform:uppercase;letter-spacing:0.04em;white-space:nowrap;"><div>Maand</div><div></div><div style="text-align:right;">All-in</div><div style="text-align:right;">Vschot</div><div style="text-align:right;">Vaste k.</div><div style="text-align:right;">Saldo</div></div>' +
        maandHtml + totaalRij +
        '<div style="margin-top:8px;font-size:10px;color:' + DS.textMuted + ';">Automatisch opgeslagen per bezochte maand · gedempt = prognose</div>' +
      '</div></details>';
    fprRow.after(row);
    addSalderingsRow(alleMaanden);
    var det = document.getElementById('be-maand-details');
    if (det) {
      det.addEventListener('toggle', function() {
        var sum = det.querySelector('summary');
        if (sum) sum.textContent = det.open ? '▼ Maanddetails verbergen' : '▶ Maanddetails tonen';
      });
    }
  }
  // ─── Kaart UI ────────────────────────────────────────────────────────────
  function removeKaleWrapper() {
    var wrapper = document.getElementById('be-kale-wrapper');
    if (!wrapper) return;
    var savings = document.getElementById('summary-savings');
    if (savings) wrapper.parentElement.insertBefore(savings, wrapper);
    wrapper.remove();
  }
  function addKaleWrapper() {
    removeKaleWrapper();
    var savings = document.getElementById('summary-savings');
    if (!savings) return;
    var wrapper = document.createElement('div');
    wrapper.id = 'be-kale-wrapper';
    // Passend bij de witte kaarten in het nieuwe dashboard
    wrapper.style.cssText = 'background:white;border:1px solid ' + DS.divider + ';border-radius:' + DS.radius + ';padding:6px 12px 10px;margin-top:12px;margin-bottom:4px;box-shadow:0 1px 4px rgba(107,63,160,0.06);display:none;';
    var label = document.createElement('p');
    label.style.cssText = 'font-size:' + DS.labelSize + ';color:' + DS.labelColor + ';margin:0 0 -12px;font-weight:' + DS.labelWeight + ';letter-spacing:' + DS.labelSpacing + ';text-transform:uppercase;';
    label.textContent = 'Kale tarieven';
    wrapper.appendChild(label);
    savings.parentElement.insertBefore(wrapper, savings);
    savings.style.marginTop = '0';
    wrapper.appendChild(savings);
  }
  function removeExtraCards() { var el = document.getElementById('be-extra-cards'); if (el) el.remove(); }
  function addBreakdown(ai) {
    removeExtraCards();
    var totEl = document.getElementById('summary-total-result');
    if (!totEl) return;
    var card = totEl.closest('.border');
    if (!card) return;
    var epexNetto = ai.inkoop + ai.verkoop - ai.btw - ai.eb - ai.opslag;
    var rows = [
      { label: 'Kale stroom',      val: epexNetto },
      { label: 'BTW',              val: ai.btw    },
      { label: 'Energiebelasting', val: ai.eb     },
      { label: '2ct opslag',       val: ai.opslag },
    ];
    var breakdown = document.createElement('div');
    breakdown.id = 'be-extra-cards';
    breakdown.style.cssText = 'margin-top:8px;border-top:1px solid ' + DS.divider + ';padding-top:6px;';
    var grid = document.createElement('div');
    grid.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:2px 0;';
    rows.forEach(function(r, idx) {
      var cell = document.createElement('div');
      var isRight = idx % 2 === 1;
      cell.style.cssText = 'display:flex;justify-content:space-between;align-items:baseline;font-size:11px;padding:1px 0;' +
        (isRight ? 'border-left:1px solid ' + DS.divider + ';padding-left:12px;' : 'padding-right:12px;');
      cell.innerHTML = '<span style="color:' + DS.textMuted + ';">' + r.label + '</span>' +
        '<span style="font-weight:600;color:' + (r.val >= 0 ? DS.green : DS.red) + ';white-space:nowrap;">' + fmt(r.val) + '</span>';
      grid.appendChild(cell);
    });
    breakdown.appendChild(grid);
    var sep = document.createElement('div');
    sep.style.cssText = 'border-top:1px solid ' + DS.divider + ';margin:4px 0 2px;';
    breakdown.appendChild(sep);
    var totRow = document.createElement('div');
    totRow.style.cssText = 'display:flex;justify-content:space-between;font-size:12px;font-weight:700;';
    totRow.innerHTML = '<span style="color:#555;">Totaal</span><span style="color:' + (ai.totaal >= 0 ? DS.green : DS.red) + ';">' + fmt(ai.totaal) + '</span>';
    breakdown.appendChild(totRow);
    card.appendChild(breakdown);
  }
  function addSubInfo(el, kWh, gemPrijs, kleur) {
    var existing = el.parentElement.querySelector('.be-sub-info');
    if (existing) existing.remove();
    var sub = document.createElement('div');
    sub.className = 'be-sub-info';
    sub.style.cssText = 'margin-top:6px;font-size:11px;color:' + DS.textMuted + ';';
    sub.innerHTML = kWh.toLocaleString('nl-NL', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) +
      ' kWh @ <span style="color:' + kleur + ';font-weight:600;">' + fmtKwh(gemPrijs) + ' all-in</span>';
    el.parentElement.appendChild(sub);
  }
  function addSpread(inkEl, spread) {
    if (!inkEl) return;
    document.querySelectorAll('.be-spread-col').forEach(function(el) { el.remove(); });
    var inkCol  = inkEl.closest('.col-12');
    var verkEl2 = document.getElementById('summary-deal-result');
    var verkCol = verkEl2 ? verkEl2.closest('.col-12') : null;
    if (!inkCol || !verkCol) return;
    var spCol = document.createElement('div');
    spCol.className = 'be-spread-col';
    spCol.style.cssText = 'flex:0 0 140px;max-width:140px;';
    var sp = document.createElement('div');
    sp.className = 'be-spread border h-100';
    sp.style.cssText = 'display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding:24px;border-radius:8px;background:white;min-height:100%;border:1px solid ' + DS.divider + ';box-shadow:0 1px 4px rgba(107,63,160,0.06);';
    sp.innerHTML =
      '<div style="font-size:10px;color:' + DS.labelColor + ';font-weight:' + DS.labelWeight + ';letter-spacing:' + DS.labelSpacing + ';text-transform:uppercase;">Spread</div>' +
      '<div style="font-size:22px;color:' + DS.purple + ';line-height:1.1;margin:2px 0;">→</div>' +
      '<div style="font-size:11px;font-weight:700;color:' + DS.purple + ';white-space:nowrap;">+' + fmtKwh(spread) + '</div>';
    spCol.appendChild(sp);
    inkCol.style.flex = '1 1 0';
    verkCol.style.flex = '1 1 0';
    inkCol.after(spCol);
  }
  function setCardLabel(allin) {
    var inkEl = document.getElementById('summary-stroom-voordeel');
    if (!inkEl) return;
    var label = inkEl.closest('.border') ? inkEl.closest('.border').querySelector('.text-muted') : null;
    if (label) label.textContent = allin ? 'Netto verbruikskosten' : 'Kale stroom kosten';
  }
  function removeSubInfo() {
    document.querySelectorAll('.be-sub-info').forEach(function(el) { el.remove(); });
    document.querySelectorAll('.be-spread-col').forEach(function(el) { el.remove(); });
    document.querySelectorAll('.be-spread').forEach(function(el) { el.remove(); });
  }
  function isMaandTab() {
    var knoppen = Array.from(document.querySelectorAll('button, .btn, [role="button"], [role="tab"]'));
    var maandKnop = knoppen.find(function(el) { return el.textContent && el.textContent.trim() === 'Maand'; });
    if (!maandKnop) return false;
    return maandKnop.classList.contains('active') ||
           maandKnop.getAttribute('aria-pressed') === 'true' ||
           maandKnop.getAttribute('aria-selected') === 'true' ||
           maandKnop.getAttribute('data-active') === 'true' ||
           maandKnop.classList.contains('btn-primary') ||
           maandKnop.classList.contains('selected');
  }
  function applyCards(ai) {
    var inkEl  = document.getElementById('summary-stroom-voordeel');
    var verkEl = document.getElementById('summary-deal-result');
    var totEl  = document.getElementById('summary-total-result');
    var buyEl  = document.getElementById('summary-buy-price');
    var sellEl = document.getElementById('summary-sell-price');
    if (!allinMode) {
      removeExtraCards(); removeKaleWrapper(); removeSubInfo(); removeFprRow(); removeVoorschotRow(); removeSalderingsRow();
      setCardLabel(false);
      if (inkEl)  { inkEl.textContent = fmtCard(_originals.inkoop); inkEl.style.color = ''; }
      if (verkEl) verkEl.textContent = fmtCard(_originals.verkoop);
      if (totEl)  { totEl.textContent = fmtCard(_originals.totaal); totEl.style.color = ''; }
      if (buyEl)  buyEl.textContent  = fmtKwh(_originals.gemInk);
      if (sellEl) sellEl.textContent = fmtKwh(_originals.gemVerk);
    } else {
      setCardLabel(true);
      var maandLabel = maandLabelUitTitel(_currentTitle);
      if (maandLabel && ai && ai.totaal !== null) {
        var nu = new Date();
        var mIdx = NL_MAANDEN_KORT.indexOf(maandLabel.split(' ')[0]);
        var jaar = parseInt(maandLabel.split(' ')[1]);
        var isLopend = nu.getMonth() === mIdx && nu.getFullYear() === jaar;
        if (!isLopend) {
          slaAllinOp(maandLabel, ai.totaal, ai.kWhExp || 0, ai.kWhImp || 0);
          slaOntbrekendOp(maandLabel, _dagOntbrekend || []);
        } else {
          var dagenNu = _dagLaatsteDag || dagenVerstreken(maandLabel);
          slaLopendeMaandOp(maandLabel, ai.totaal, ai.kWhExp || 0, ai.kWhImp || 0, dagenNu);
          _lopendeMaandTotaal = ai.totaal;
          _lopendeMaandLabel  = maandLabel;
          _lopendeMaandDagen  = dagenNu;
        }
      }
      var totKWhImp = _dagData ? _dagData.reduce(function(a, d) { return a + (d.impKwh || 0); }, 0) : 0;
      var totKWhExp = _dagData ? _dagData.reduce(function(a, d) { return a + (d.expKwh || 0); }, 0) : 0;
      var gemAllinInk  = totKWhImp > 0 ? Math.abs(ai.inkoop)  / totKWhImp : 0;
      var gemAllinVerk = totKWhExp > 0 ? Math.abs(ai.verkoop) / totKWhExp : 0;
      if (inkEl) {
        var absInk = Math.abs(ai.inkoop);
        inkEl.textContent = '€ ' + absInk.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        inkEl.style.setProperty('color', DS.red, 'important');
        addSubInfo(inkEl, totKWhImp, gemAllinInk, DS.red);
      }
      if (verkEl) {
        var absVerk = Math.abs(ai.verkoop);
        verkEl.textContent = '+€ ' + absVerk.toLocaleString('nl-NL', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        addSubInfo(verkEl, totKWhExp, gemAllinVerk, DS.green);
      }
      if (totEl)  { totEl.textContent = fmtCard(ai.totaal); totEl.style.setProperty('color', ai.totaal >= 0 ? DS.green : DS.red, 'important'); }
      if (buyEl)  buyEl.textContent  = fmtKwh(ai.impPrijs);
      if (sellEl) sellEl.textContent = fmtKwh(ai.expPrijs);
      addSpread(inkEl, ai.spread);
      addBreakdown(ai);
      addKaleWrapper();
      addFprRow(_dagData);
      if (isMaandTab()) {
        addVoorschotRow();
      } else {
        _voorschotRetryTimer = setTimeout(function() {
          _voorschotRetryTimer = null;
          if (allinMode && isMaandTab()) addVoorschotRow();
        }, 300);
        removeVoorschotRow();
        removeSalderingsRow();
      }
    }
  }
  // ─── Toggle ──────────────────────────────────────────────────────────────
  function getChart() {
    var canvas = document.getElementById('summary-chart');
    if (!canvas || !window.Chart) return null;
    return Chart.getChart(canvas);
  }
  function applyChart(ai) {
    var chart = getChart();
    if (!chart) return;
    if (!_chartOriginals) {
      _chartOriginals = chart.data.datasets.map(function(ds) {
        return { label: ds.label, data: ds.data.slice(), backgroundColor: ds.backgroundColor };
      });
    }
    var orig = _chartOriginals;
    var n = chart.data.labels.length;
    chart.data.datasets = chart.data.datasets.filter(function(d) { return d.label !== 'Energiebelasting' && d.label !== '2ct opslag'; });
    if (!allinMode) {
      chart.data.datasets.forEach(function(ds) {
        var o = orig.find(function(x) { return x.label === ds.label; });
        if (o) ds.data = o.data.slice();
      });
    } else {
      var dd = _dagData;
      if (dd && dd.length === n) {
        var res = dd.map(function(d) { return calcAllinDay(d.absInk, d.absVerk, d.gemInk, d.gemVerk); });
        chart.data.datasets.forEach(function(ds) {
          if (ds.label === 'Inkoop kosten')       ds.data = res.map(function(r) { return -r.ink; });
          if (ds.label === 'Verkoop opbrengsten') ds.data = res.map(function(r) { return r.verk; });
          if (ds.label === 'Totaal')              ds.data = res.map(function(r) { return r.tot; });
        });
        chart.data.datasets.push({ label: 'Energiebelasting', data: res.map(function(r) { return r.eb; }),     backgroundColor: '#1D9E75', borderRadius: 0, order: 2 });
        chart.data.datasets.push({ label: '2ct opslag',       data: res.map(function(r) { return r.opslag; }), backgroundColor: '#7F77DD', borderRadius: 0, order: 2 });
      }
    }
    chart.options.scales.y.min = undefined;
    chart.options.scales.y.max = undefined;
    chart.update('active');
  }
  function _doToggle() {
    allinMode = !allinMode;
    var kWhExpOngesaldeerd = 0;
    var ai = allinMode ? calcAllinMonth(
      _originals.inkoop, _originals.verkoop || 0,
      _originals.gemInk, _originals.gemVerk || 0,
      kWhExpOngesaldeerd) : null;
    applyCards(ai);
    applyChart(ai);
    var track  = document.getElementById('be-toggle-track');
    var thumb  = document.getElementById('be-toggle-thumb');
    var labelR = document.getElementById('be-label-allin');
    if (track && thumb) {
      track.style.background = allinMode ? DS.purple : DS.divider;
      thumb.style.transform  = allinMode ? 'translateX(20px)' : 'translateX(0)';
      thumb.style.background = allinMode ? 'white' : DS.purpleLight;
      if (labelR) labelR.style.color = allinMode ? DS.purple : DS.purpleLight;
    }
  }
  function updateNotifBadge() {
    var notif = document.getElementById('be-notif');
    if (!notif) return;
    var alle = leesOntbrekendJaar();
    var totaal = alle.length;
    var badgeTxt = totaal > 0 ? (totaal > 9 ? '9+' : String(totaal)) : '';
    var oud = notif.querySelector('.be-badge');
    var svg = notif.querySelector('svg');
    if (svg) {
      var gewensteOpacity = totaal > 0 ? '1' : '0.55';
      if (svg.style.opacity !== gewensteOpacity) svg.style.opacity = gewensteOpacity;
    }
    if (!badgeTxt) { if (oud) oud.remove(); return; }
    if (oud) { if (oud.textContent !== badgeTxt) oud.textContent = badgeTxt; return; }
    var badge = document.createElement('div');
    badge.className = 'be-badge';
    badge.style.cssText = 'position:absolute;top:-4px;right:-4px;background:' + DS.red + ';color:white;border-radius:50%;width:14px;height:14px;font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;line-height:1;';
    badge.textContent = badgeTxt;
    notif.appendChild(badge);
  }
  function toggle() {
    if (!_originals) { _originals = readOriginals(); if (!_originals) return; }
    if (!_dagData) {
      var toggleBtn = document.getElementById('summary-table-toggle');
      var isCollapsed = toggleBtn && toggleBtn.classList.contains('collapsed');
      if (isCollapsed) {
        toggleBtn.click();
        setTimeout(function() {
          var result = readDagData();
          _dagData = result ? result.data : null;
          _dagLaatsteDag = result ? result.laatsteDag : null;
          _dagOntbrekend = result ? (result.ontbrekend || []) : [];
          _doToggle();
        }, 400);
        return;
      }
      var result = readDagData();
      _dagData = result ? result.data : null;
      _dagLaatsteDag = result ? result.laatsteDag : null;
      _dagOntbrekend = result ? (result.ontbrekend || []) : [];
    }
    _doToggle();
  }
  function injectToggle() {
    if (document.getElementById('be-toggle-track')) return;
    var header = document.querySelector('.card-header.custom-purple');
    if (!header) return;
    var chartNow = getChart();
    if (chartNow && !_chartOriginals) {
      _chartOriginals = chartNow.data.datasets.map(function(ds) {
        return { label: ds.label, data: ds.data.slice(), backgroundColor: ds.backgroundColor };
      });
    }
    var wrapper = document.createElement('div');
    wrapper.style.cssText = 'display:flex;align-items:center;gap:10px;margin-left:20px;user-select:none;line-height:1;';
    var toggleLabel = document.createElement('label');
    toggleLabel.style.cssText = 'display:flex;align-items:center;gap:8px;cursor:pointer;';
    toggleLabel.addEventListener('click', function(e) { e.preventDefault(); toggle(); });
    // Header is nu licht (lila gradient) — gebruik donkere kleuren voor leesbaarheid
    var headerIconCleur = DS.purple;
    var headerIconMuted = DS.purpleLight;
    var labelR = document.createElement('span');
    labelR.id = 'be-label-allin'; labelR.textContent = 'All-in';
    labelR.style.cssText = 'font-size:13px;color:' + headerIconMuted + ';font-weight:600;letter-spacing:0.03em;transition:color 0.2s;';
    var track = document.createElement('div');
    track.id = 'be-toggle-track';
    track.style.cssText = 'position:relative;width:44px;height:24px;border-radius:12px;background:' + DS.divider + ';border:1.5px solid ' + DS.purpleLight + ';transition:background 0.25s;flex-shrink:0;';
    var thumb = document.createElement('div');
    thumb.id = 'be-toggle-thumb';
    thumb.style.cssText = 'position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:white;transition:transform 0.25s;box-shadow:0 1px 4px rgba(0,0,0,0.25);';
    track.appendChild(thumb);
    toggleLabel.appendChild(labelR);
    toggleLabel.appendChild(track);
    wrapper.appendChild(toggleLabel);
    var gear = document.createElement('div');
    gear.id = 'be-gear'; gear.title = 'Instellingen v3.2.0';
    gear.style.cssText = 'width:18px;height:18px;cursor:pointer;opacity:0.6;transition:opacity 0.2s;flex-shrink:0;display:flex;align-items:center;justify-content:center;';
    gear.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="' + headerIconCleur + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:100%;height:100%;"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
    gear.addEventListener('mouseenter', function() { gear.style.opacity = '1'; });
    gear.addEventListener('mouseleave', function() { gear.style.opacity = '0.55'; });
    gear.addEventListener('click', function(e) {
      e.stopPropagation();
      var panel = document.getElementById('be-settings-panel');
      if (panel) { panel.remove(); return; }
      openSettingsPanel();
    });
    wrapper.appendChild(gear);
    var notif = document.createElement('div');
    notif.id = 'be-notif';
    notif.style.cssText = 'position:relative;width:18px;height:18px;cursor:pointer;flex-shrink:0;display:flex;align-items:center;justify-content:center;';
    notif.title = 'Ontbrekende dagen';
    notif.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="' + headerIconCleur + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:100%;height:100%;opacity:0.6;"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>';
    notif.addEventListener('click', function(e) {
      e.stopPropagation();
      var panel = document.getElementById('be-notif-panel');
      if (panel) { panel.remove(); return; }
      var alle = leesOntbrekendJaar();
      var huidig = _dagOntbrekend || [];
      var p = document.createElement('div');
      p.id = 'be-notif-panel';
      p.style.cssText = 'position:absolute;top:60px;right:50px;z-index:9999;background:white;border:1px solid ' + DS.divider + ';border-radius:10px;padding:14px 18px;min-width:260px;box-shadow:0 4px 16px rgba(107,63,160,0.12);font-family:inherit;';
      var totTekst = alle.length === 0 ? 'Geen ontbrekende dagen gevonden.' :
        '<span style="color:' + DS.red + ';font-weight:700;">' + alle.length + ' dag' + (alle.length !== 1 ? 'en' : '') + '</span> ontbreken in het contractjaar.';
      var huidigTekst = huidig.length > 0 ?
        '<div style="margin-top:8px;font-size:11px;color:#555;">Deze maand: <span style="color:' + DS.red + ';">' + huidig.map(function(d) { return d.split('-')[0]; }).join(', ') + '</span></div>' : '';
      var lijstTekst = alle.length > 0 ?
        '<div style="margin-top:8px;font-size:10px;color:' + DS.textMuted + ';max-height:120px;overflow-y:auto;">' + alle.map(function(d) {
          var delen = d.split('-');
          return delen[0] + ' ' + NL_MAANDEN_LANG[parseInt(delen[1])-1] + ' ' + delen[2];
        }).join('<br>') + '</div>' : '';
      var afrrSam = afrrSamenvatting();
      var afrrTekst = afrrSam.datums.length ?
        '<div style="margin-top:10px;padding-top:8px;border-top:1px solid ' + DS.divider + ';font-size:11px;color:#555;">' +
          '<span style="color:' + AFRR_ORANJE + ';font-weight:700;">' + afrrSam.datums.length + ' dag' + (afrrSam.datums.length !== 1 ? 'en' : '') + '</span> aangevuld met aFRR-schatting' +
          '<div style="font-size:10px;color:' + AFRR_ORANJE + ';margin-top:3px;">netto ' + fmt(afrrSam.netto) + ' · ' + afrrSam.datums.map(afrrNlDatum).join(', ') + '</div>' +
          '<div style="font-size:10px;color:' + DS.textMuted + ';margin-top:3px;">Alleen het aFRR-deel; het reguliere import/export-deel volgt zodra Balans die dag verwerkt.</div>' +
        '</div>' : '';
      p.innerHTML = '<div style="font-size:11px;font-weight:700;color:' + DS.purple + ';margin-bottom:8px;text-transform:uppercase;letter-spacing:0.05em;">Ontbrekende dagen</div>' +
        '<div style="font-size:12px;color:#333;">' + totTekst + '</div>' +
        huidigTekst + lijstTekst + afrrTekst +
        '<div style="font-size:10px;color:' + DS.purpleLight + ';margin-top:10px;">Alleen zichtbaar voor bezochte maanden.</div>';
      document.body.appendChild(p);
      document.addEventListener('click', function handler() { p.remove(); document.removeEventListener('click', handler); }, { once: true });
    });
    wrapper.appendChild(notif);
    setTimeout(function() { updateNotifBadge(); }, 0);
    var titleDiv = header.querySelector('.d-flex');
    if (titleDiv) titleDiv.appendChild(wrapper);
    else header.appendChild(wrapper);
  }
  // ─── Instellingen ─────────────────────────────────────────────────────────
  function openSettingsPanel() {
    var start = leesStartdatum();
    var startStr = String(start.getDate()).padStart(2,'0') + '-' + String(start.getMonth()+1).padStart(2,'0') + '-' + start.getFullYear();
    toonSaldering = localStorage.getItem(LS_SALDERING) === 'aan';
    var panel = document.createElement('div');
    panel.id = 'be-settings-panel';
    panel.style.cssText = 'position:absolute;top:60px;right:16px;z-index:9999;background:white;border:1px solid ' + DS.divider + ';border-radius:10px;padding:16px 20px;min-width:300px;box-shadow:0 4px 16px rgba(107,63,160,0.12);font-family:inherit;';
    panel.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">' +
        '<div style="font-size:12px;font-weight:700;color:' + DS.purple + ';letter-spacing:0.05em;text-transform:uppercase;">Instellingen v3.2.0</div>' +
        '<span id="be-settings-close" style="cursor:pointer;font-size:18px;color:#aaa;line-height:1;">×</span>' +
      '</div>' +
      '<div style="margin-bottom:12px;"><label style="font-size:11px;color:#555;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.04em;">Voorschot per maand (€)</label>' +
        '<input id="be-cfg-voorschot" type="number" step="0.01" min="0" value="' + VOORSCHOT_PM.toFixed(2) + '" style="width:100%;box-sizing:border-box;padding:7px 10px;border:1px solid ' + DS.divider + ';border-radius:6px;font-size:13px;"></div>' +
      '<div style="margin-bottom:12px;"><label style="font-size:11px;color:#555;display:block;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.04em;">Startdatum contract (dd-mm-jjjj)</label>' +
        '<input id="be-cfg-startdatum" type="text" placeholder="04-11-2025" value="' + startStr + '" style="width:100%;box-sizing:border-box;padding:7px 10px;border:1px solid ' + DS.divider + ';border-radius:6px;font-size:13px;"></div>' +
      '<div style="margin-bottom:16px;padding:10px 12px;background:#faf9fd;border-radius:8px;border:1px solid ' + DS.divider + ';">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;">' +
          '<div><div style="font-size:11px;color:#555;font-weight:600;">Salderingsbalans tonen</div><div style="font-size:10px;color:' + DS.purpleLight + ';margin-top:2px;">Meter + correctie buiten-saldering export</div></div>' +
          '<label id="be-saldering-label" style="display:flex;align-items:center;cursor:pointer;">' +
            '<div id="be-saldering-track" style="position:relative;width:36px;height:20px;border-radius:10px;background:' + (toonSaldering ? DS.purple : DS.divider) + ';transition:background 0.2s;flex-shrink:0;">' +
              '<div id="be-saldering-thumb" style="position:absolute;top:3px;left:' + (toonSaldering ? '18px' : '3px') + ';width:14px;height:14px;border-radius:7px;background:white;transition:left 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>' +
            '</div>' +
          '</label>' +
        '</div>' +
      '</div>' +
      '<div style="margin-bottom:16px;padding:10px 12px;background:#fff8f2;border-radius:8px;border:1px solid #ffd9b8;">' +
        '<div style="display:flex;align-items:center;justify-content:space-between;">' +
          '<div><div style="font-size:11px;color:#555;font-weight:600;">Ontbrekende dagen aanvullen met aFRR</div><div style="font-size:10px;color:' + AFRR_ORANJE + ';margin-top:2px;">Alleen dagen die Balans nog niet verwerkt heeft</div></div>' +
          '<label id="be-afrr-label" style="display:flex;align-items:center;cursor:pointer;">' +
            '<div id="be-afrr-track" style="position:relative;width:36px;height:20px;border-radius:10px;background:' + (afrrAan ? AFRR_ORANJE : DS.divider) + ';transition:background 0.2s;flex-shrink:0;">' +
              '<div id="be-afrr-thumb" style="position:absolute;top:3px;left:' + (afrrAan ? '18px' : '3px') + ';width:14px;height:14px;border-radius:7px;background:white;transition:left 0.2s;box-shadow:0 1px 3px rgba(0,0,0,0.2);"></div>' +
            '</div>' +
          '</label>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;gap:8px;">' +
        '<button id="be-cfg-opslaan" style="flex:1;padding:8px;background:' + DS.purple + ';color:white;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">Opslaan</button>' +
        '<button id="be-cfg-wis" style="padding:8px 12px;background:white;color:' + DS.red + ';border:1px solid ' + DS.red + ';border-radius:6px;font-size:12px;cursor:pointer;" title="Wis alle opgeslagen maanddata">Wis data</button>' +
      '</div>' +
      '<div id="be-cfg-melding" style="margin-top:10px;font-size:11px;color:' + DS.green + ';display:none;"></div>';
    document.body.appendChild(panel);
    document.getElementById('be-settings-close').addEventListener('click', function() { panel.remove(); });
    var saldTrack = document.getElementById('be-saldering-track');
    var saldThumb = document.getElementById('be-saldering-thumb');
    document.getElementById('be-saldering-label').addEventListener('click', function() {
      toonSaldering = !toonSaldering;
      saldTrack.style.background = toonSaldering ? DS.purple : DS.divider;
      saldThumb.style.left = toonSaldering ? '18px' : '3px';
    });
    var afrrTrack = document.getElementById('be-afrr-track');
    var afrrThumb = document.getElementById('be-afrr-thumb');
    document.getElementById('be-afrr-label').addEventListener('click', function() {
      afrrAan = !afrrAan;
      afrrTrack.style.background = afrrAan ? AFRR_ORANJE : DS.divider;
      afrrThumb.style.left = afrrAan ? '18px' : '3px';
    });
    document.getElementById('be-cfg-opslaan').addEventListener('click', function() {
      var v = parseFloat(document.getElementById('be-cfg-voorschot').value);
      var s = document.getElementById('be-cfg-startdatum').value.trim();
      var delen = s.split('-');
      var melding = document.getElementById('be-cfg-melding');
      if (isNaN(v) || v <= 0) { melding.style.color = DS.red; melding.textContent = 'Ongeldig voorschotbedrag.'; melding.style.display = 'block'; return; }
      if (delen.length !== 3) { melding.style.color = DS.red; melding.textContent = 'Datum moet dd-mm-jjjj zijn.'; melding.style.display = 'block'; return; }
      var datum = new Date(parseInt(delen[2]), parseInt(delen[1])-1, parseInt(delen[0]));
      if (isNaN(datum.getTime())) { melding.style.color = DS.red; melding.textContent = 'Ongeldige datum.'; melding.style.display = 'block'; return; }
      localStorage.setItem(LS_VOORSCHOT, v.toFixed(2));
      var iso = datum.getFullYear() + '-' + String(datum.getMonth()+1).padStart(2,'0') + '-' + String(datum.getDate()).padStart(2,'0');
      localStorage.setItem(LS_STARTDATUM, iso);
      localStorage.setItem(LS_SALDERING, toonSaldering ? 'aan' : 'uit');
      localStorage.setItem(LS_AFRR, afrrAan ? 'aan' : 'uit');
      VOORSCHOT_PM = v;
      melding.style.color = DS.green; melding.textContent = 'Opgeslagen! Pagina herladen om toe te passen.'; melding.style.display = 'block';
    });
    document.getElementById('be-cfg-wis').addEventListener('click', function() {
      var melding = document.getElementById('be-cfg-melding');
      if (!confirm('Wis alle opgeslagen maanddata uit localStorage?')) return;
      Object.keys(localStorage).forEach(function(k) { if (k.startsWith(LS_PREFIX)) localStorage.removeItem(k); });
      melding.style.color = '#fd7e14'; melding.textContent = 'Maanddata gewist.'; melding.style.display = 'block';
    });
  }
  // ─── Hoofd observer ──────────────────────────────────────────────────────
  function tryInject() {
    verwijderLopendeMaand();
    var titleEl = document.querySelector('.card-header.custom-purple');
    var newTitle = null;
    if (titleEl) {
      var titleClone = titleEl.cloneNode(true);
      Array.from(titleClone.querySelectorAll('#be-toggle-track, #be-toggle-thumb, #be-label-allin, #be-gear, #be-notif, #be-settings-panel, #be-notif-panel')).forEach(function(el) {
        el.remove();
      });
      newTitle = titleClone.textContent.trim();
    }
    if (newTitle && newTitle !== _currentTitle) {
      _currentTitle = newTitle;
      _originals = null; _chartOriginals = null; _dagData = null; _dagLaatsteDag = null; _dagOntbrekend = []; allinMode = false;
      _lopendeMaandTotaal = null; _lopendeMaandLabel = null; _lopendeMaandDagen = null;
      removeExtraCards(); removeKaleWrapper(); removeSubInfo(); removeFprRow(); removeVoorschotRow(); removeSalderingsRow();
      verbergBetaBlok();
      var track  = document.getElementById('be-toggle-track');
      var thumb  = document.getElementById('be-toggle-thumb');
      if (track) track.style.background = 'rgba(255,255,255,0.2)';
      if (thumb) { thumb.style.transform = 'translateX(0)'; thumb.style.background = 'white'; }
      var labelR2 = document.getElementById('be-label-allin');
      if (labelR2) labelR2.style.color = 'rgba(255,255,255,0.6)';
    }
    if (document.getElementById('summary-total-result')) injectToggle();
    // Aangevulde dagen herkenbaar houden. Lift mee op de observer die er al is,
    // dus geen extra timer; beide functies zijn goedkoop en idempotent.
    afrrMarkeerGrafiek();
    afrrMarkeerTabel();
  }
  // Het script draait nu op document-start, zodat de fetch-onderschepping
  // hierboven vóór de eigen verzoeken van de pagina staat. Op dat moment
  // bestaat document.body nog niet, dus de observer moet daarop wachten.
  function startPlugin() {
    var observer = new MutationObserver(tryInject);
    observer.observe(document.body, { childList: true, subtree: true });
    tryInject();
  }
  afrrStart();
  if (document.body) startPlugin();
  else document.addEventListener('DOMContentLoaded', startPlugin);
})();