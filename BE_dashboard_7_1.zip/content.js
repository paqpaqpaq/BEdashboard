(function () {
  'use strict';
  if (window.__beSocDisplayGuard615) return;
  window.__beSocDisplayGuard615 = true;
  const id = 'be-soc-display-guard-615';
  const duplicate = '[data-be-soc-legend="soc-chart"]';
  // Run before Chart.js, cached SOC data, or the mobile layout is ready.
  // The second selector also overrides the legacy display:contents rule.
  const css = 'html ' + duplicate + ',html [data-be-soc-compact]>' + duplicate +
    '{display:none!important}';
  let queued = false;
  function repair() {
    queued = false;
    const host = document.head || document.documentElement;
    if (!host) return;
    let style = document.getElementById(id);
    if (!style) {
      style = document.createElement('style');
      style.id = id;
      style.textContent = css;
      host.appendChild(style);
    } else if (style.textContent !== css) style.textContent = css;
    document.querySelectorAll(duplicate).forEach(row => row.remove());
  }
  function schedule() {
    if (queued) return;
    queued = true;
    Promise.resolve().then(repair);
  }
  new MutationObserver(records => {
    if (!document.getElementById(id) || records.some(record =>
      record.type === 'attributes' || Array.from(record.addedNodes).some(node =>
        node.nodeType === 1 && (node.matches?.(duplicate) || node.querySelector?.(duplicate))
      )
    )) schedule();
  }).observe(document, {childList: true, subtree: true, attributes: true, attributeFilter: ['data-be-soc-legend']});
  document.addEventListener('DOMContentLoaded', repair, {once: true});
  window.addEventListener('pageshow', repair);
  window.addEventListener('resize', schedule);
  window.addEventListener('orientationchange', schedule);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) repair(); });
  repair();
})();

// Balansenergie All-in 7.1 — MAIN world; generated from stable userscript.
(function () {
  'use strict';
  function beDashboardMain() {
/* Persistent colour themes. Runs at document-start, before dashboard UI work. */
(function () {
  'use strict';
  if (window.BETheme) return;
  var KEY = 'be_cfg_darkmode', STYLE_KEY = 'be_cfg_darkstyle';
  function read(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }
  function save(key, value) { try { localStorage.setItem(key, value); } catch (_) {} }
  var enabled = read(KEY) === 'aan';
  var selected = read(STYLE_KEY) === 'grafiet' ? 'grafiet' : 'bruingrijs';
  var palettes = {
    bruingrijs: {bg:'#2c2924',paper:'#37322b',raised:'#454036',nav:'#211e1a',ink:'#f5f0e8',muted:'#c7beb0',line:'#675e4f',accent:'#cbb58f',control:'#7b6445',green:'#33c071',red:'#f24f5b',blue:'#31adde',yellow:'#eca524'},
    grafiet: {bg:'#111316',paper:'#1c1f26',raised:'#262a34',nav:'#15171c',ink:'#f5f7fa',muted:'#b6c0cf',line:'#3c4351',accent:'#a879ff',control:'#7340b5',green:'#23d9a0',red:'#ff6079',blue:'#4398ff',yellow:'#ffc64a'}
  };
  var base, inlineSheet, serial=0, ruleIds=new Map(), pending=new Set(), queued=false;
  var sourceSheets=new WeakMap(), inlineCache=new WeakMap(), importantCache=new WeakMap();
  var marker='data-be-theme-inline', own='data-be-theme-sheet';
  function palette() { return palettes[selected]; }
  function token(name, canvas) { return canvas ? palette()[name] : 'var(--be-theme-'+name+')'; }
  function rgba(value) {
    value=String(value).trim().toLowerCase();
    var named={white:'#ffffff',black:'#000000',gray:'#808080',grey:'#808080',transparent:'#00000000'};
    value=named[value]||value;
    if (/^#[\da-f]{3,8}$/.test(value)) {
      var hex=value.slice(1);
      if(hex.length===3||hex.length===4)hex=hex.split('').map(function(c){return c+c;}).join('');
      if(hex.length!==6&&hex.length!==8)return null;
      return [parseInt(hex.slice(0,2),16),parseInt(hex.slice(2,4),16),parseInt(hex.slice(4,6),16),hex.length===8?parseInt(hex.slice(6,8),16)/255:1];
    }
    var srgb=value.match(/^color\(srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)(?:\s*\/\s*([\d.]+))?\)$/);
    if(srgb)return [+srgb[1]*255,+srgb[2]*255,+srgb[3]*255,srgb[4]==null?1:+srgb[4]];
    var hsl=value.match(/^hsla?\(\s*([-\d.]+)(?:deg)?[, ]+([\d.]+)%[, ]+([\d.]+)%(?:\s*[,/]\s*([\d.]+)(%)?)?\s*\)$/);
    if(hsl){
      var hue=((+hsl[1]%360)+360)%360/360,saturation=+hsl[2]/100,lum=+hsl[3]/100;
      var amplitude=saturation*Math.min(lum,1-lum);
      return [0,8,4].map(function(n){var k=(n+hue*12)%12;return 255*(lum-amplitude*Math.max(-1,Math.min(k-3,9-k,1)));}).concat(hsl[4]==null?1:+hsl[4]/(hsl[5]?100:1));
    }
    var m=value.match(/^rgba?\(\s*([\d.]+)(%)?[, ]+([\d.]+)(%)?[, ]+([\d.]+)(%)?(?:\s*[,/]\s*([\d.]+)(%)?)?\s*\)$/);
    return m?[+m[1]*(m[2]?2.55:1),+m[3]*(m[4]?2.55:1),+m[5]*(m[6]?2.55:1),m[7]==null?1:+m[7]/(m[8]?100:1)]:null;
  }
  function lighter(value,amount) {
    return 'rgb('+rgba(value).slice(0,3).map(function(v){return Math.round(v+(255-v)*amount);}).join(',')+')';
  }
  // Canvas lines and HTML legend markers share these exact series colours.
  function seriesColor(series) {
    var light={coulomb:'#0891b2','coulomb-forecast':'rgba(8,145,178,.55)','bid-import':'#b65c72','bid-export':'#73b9a1'};
    if(!enabled)return light[series];
    if(series==='coulomb')return palette().blue;
    if(series==='coulomb-forecast')return lighter(palette().blue,.48);
    if(series==='bid-import')return lighter(palette().red,.25);
    if(series==='bid-export')return lighter(palette().green,.25);
  }
  function convertColor(value,kind,canvas) {
    var c=rgba(value);if(!c||c[3]===0)return value;
    var r=c[0],g=c[1],b=c[2],hi=Math.max(r,g,b),lo=Math.min(r,g,b),light=(r+g+b)/3,name;
    // A thin coloured stroke is a data series, not a neutral chart grid line.
    if(canvas&&['coulomb','coulomb-forecast','bid-import','bid-export'].some(function(series){return JSON.stringify(c)===JSON.stringify(rgba(seriesColor(series)));}))return value;
    if(hi-lo<48)name=kind==='border'?'line':kind==='background'?(light>245?'paper':light>95?'raised':null):(light<100||light>205?'ink':'muted');
    else if(kind==='background'&&!canvas)name=(b>g*1.12&&r>b*.6)?'control':'raised';
    else if(r>=g*.9&&g>b*1.3&&r>b*1.3)name='yellow';
    else if(g>r*1.15&&g>b*1.05)name='green';
    else if(r>g*1.4&&r>b*1.2)name=g>75&&g>b*1.5?'yellow':'red';
    else if(b>g*1.12&&r>b*.6)name='accent';
    else if(b>r*1.1)name='blue';
    else name=kind==='background'?'raised':'ink';
    if(!name)return value;
    var mapped=token(name,canvas);
    // Forecast solar production is a filled bar series, including low-alpha source colours.
    if(canvas&&kind==='background'&&name==='yellow')c[3]=Math.max(c[3],.85);
    if(kind==='text'&&hi-lo<48)return mapped;
    if(c[3]<1)return canvas?'rgba('+rgba(mapped).slice(0,3).join(',')+','+c[3]+')':'color-mix(in srgb,'+mapped+' '+(c[3]*100)+'%,transparent)';
    return mapped;
  }
  var canvasColors=new Map();
  function color(value,kind,canvas) {
    if(!canvas)return convertColor(value,kind,false);
    // Gradients/patterns already describe their own colours. Repeated canvas
    // primitives otherwise share a small set of strings within each palette.
    if(typeof value!=='string')return value;
    var key=(enabled?'1':'0')+'|'+selected+'|'+kind+'|'+value;
    if(canvasColors.has(key))return canvasColors.get(key);
    var mapped=convertColor(value,kind,true);
    if(canvasColors.size>=512)canvasColors.clear();
    canvasColors.set(key,mapped);
    return mapped;
  }
  var colorPattern=/(?:rgba?|hsla?|color)\([^)]*\)|#[\da-f]{3,8}\b|\b(?:white|black|gr[ae]y|transparent)\b/gi;
  function colours(value,kind) {
    if(!value||/url\(|var\(/i.test(value))return value;
    return value.replace(colorPattern,function(v){return color(v,kind,false);});
  }
  function declarations(style) {
    var out=[];
    Array.from(style).forEach(function(prop){
      var value=style.getPropertyValue(prop),kind,next;
      if(/^(?:color|fill|stroke|caret-color|text-decoration-color|outline-color)$/.test(prop))kind='text';
      else if(/^border(?:-(?:top|right|bottom|left))?(?:-color)?$/.test(prop)||prop==='outline')kind='border';
      else if(/^background(?:-color|-image)?$/.test(prop))kind='background';
      else if((prop==='box-shadow'||prop==='text-shadow')&&!/var\(/i.test(value)){next=value.replace(colorPattern,'rgba(0,0,0,.2)');}
      else if(prop.indexOf('--')===0&&/(?:color|bg|surface|border|ink|muted|purple|green|red|blue)/.test(prop))kind=/bg|background|surface/.test(prop)?'background':/border/.test(prop)?'border':'text';
      if(kind)next=colours(value,kind);
      if(next&&next!==value)out.push(prop+':'+next+'!important');
    });
    return out.join(';');
  }
  function selectors(text) {
    var list=[],start=0,depth=0,quote='';
    for(var i=0;i<text.length;i++){
      var c=text[i];if(quote){if(c===quote&&text[i-1]!=='\\')quote='';continue;}
      if(c==='"'||c==="'"){quote=c;continue;}
      if(c==='('||c==='[')depth++;if(c===')'||c===']')depth--;
      if(c===','&&depth===0){list.push(text.slice(start,i));start=i+1;}
    }list.push(text.slice(start));
    return list.map(function(s){s=s.trim();return /^(?:html|:root)(?=[\s.#:[>+~]|$)/.test(s)?s.replace(/^(?:html|:root)/,'html[data-be-dark="aan"]'):'html[data-be-dark="aan"] '+s;}).join(',');
  }
  function convert(rules) {
    var css='';Array.from(rules).forEach(function(rule){
      if(rule.selectorText&&rule.style){
        // Never recolour an already authored dark theme or our own output.
        if(/data-be-dark|data-be-theme|data-dark/.test(rule.selectorText))return;
        var decl=declarations(rule.style);if(decl)css+=selectors(rule.selectorText)+'{'+decl+'}\n';
      }else if(rule.cssRules&&rule.conditionText){
        var nested=convert(rule.cssRules);if(nested)css+=(rule.constructor.name==='CSSSupportsRule'?'@supports ':'@media ')+rule.conditionText+'{'+nested+'}\n';
      }
    });return css;
  }
  function compile(owner) {
    if(!owner||owner.hasAttribute(own)||!owner.sheet)return;
    var rules;try{rules=owner.sheet.cssRules;}catch(_){return;}
    var source=owner.tagName==='STYLE'?owner.textContent:String(rules.length);
    var prior=sourceSheets.get(owner);if(prior&&prior.source===source){prior.style.media=owner.media||'';prior.style.disabled=!!owner.disabled;return;}
    var result=convert(rules),style=prior&&prior.style;
    if(!style){style=document.createElement('style');style.setAttribute(own,'compiled');(document.head||document.documentElement).appendChild(style);}
    if(style.textContent!==result)style.textContent=result;
    style.media=owner.media||'';style.disabled=!!owner.disabled;
    sourceSheets.set(owner,{source:source,style:style});
  }
  function inline(element) {
    if(!element||element.nodeType!==1||element.hasAttribute(own)||/^(SCRIPT|STYLE|LINK|META|NOSCRIPT|CANVAS)$/.test(element.tagName))return;
    var source=(element.getAttribute('style')||'')+'|'+(element.getAttribute('fill')||'')+'|'+(element.getAttribute('stroke')||'');
    if(inlineCache.get(element)===source)return;
    inlineCache.set(element,source);
    var special=[],tracked=importantCache.get(element)||{};
    Array.from(element.style).forEach(function(prop){
      var value=element.style.getPropertyValue(prop),old=tracked[prop];
      if(old&&value===old.applied){special.push(old.definition);return;}
      if(old)delete tracked[prop];
      if(element.style.getPropertyPriority(prop)!=='important')return;
      var probe=document.createElement('span');probe.style.setProperty(prop,value);
      var converted=declarations(probe.style);
      if(!converted)return;
      var mapped=converted.slice(converted.indexOf(':')+1).replace(/!important$/,'');
      var variable='--be-theme-important-'+(++serial),applied='var('+variable+','+value+')';
      element.style.setProperty(prop,applied,'important');
      tracked[prop]={applied:element.style.getPropertyValue(prop),definition:variable+':'+mapped+'!important'};
      special.push(tracked[prop].definition);
    });
    importantCache.set(element,tracked);
    var decl=declarations(element.style)+(special.length?';'+special.join(';'):'');
    ['fill','stroke'].forEach(function(prop){var raw=element.getAttribute(prop);if(raw){var mapped=colours(raw,'text');if(mapped!==raw)decl+=';'+prop+':'+mapped+'!important';}});
    if(!decl){element.removeAttribute(marker);return;}
    var id=ruleIds.get(decl);
    if(!id){id='t'+(++serial);ruleIds.set(decl,id);inlineSheet.sheet.insertRule('html[data-be-dark="aan"] :is(#be-theme-inline-priority,['+marker+'="'+id+'"]){'+decl+'}',inlineSheet.sheet.cssRules.length);}
    if(element.getAttribute(marker)!==id)element.setAttribute(marker,id);
    inlineCache.set(element,(element.getAttribute('style')||'')+'|'+(element.getAttribute('fill')||'')+'|'+(element.getAttribute('stroke')||''));
  }
  function refresh(root) {
    if(!root||root.nodeType!==1)return;
    if(root.matches('style,link[rel="stylesheet"]'))compile(root);
    else inline(root);
    root.querySelectorAll('style,link[rel="stylesheet"],[style],[fill],[stroke]').forEach(function(e){if(e.matches('style,link[rel="stylesheet"]'))compile(e);else inline(e);});
  }
  function queue(root) {
    if(!root||root.nodeType!==1||root.hasAttribute(own))return;
    pending.add(root);
    if(!queued){queued=true;queueMicrotask(function(){queued=false;var nodes=Array.from(pending);pending.clear();nodes.forEach(refresh);});}
  }
  function emit() { document.dispatchEvent(new Event('be-dark-change')); }
  function state() {
    var html=document.documentElement;if(!html)return;
    html.setAttribute('data-be-dark-style',selected);
    html.setAttribute('data-be-dark',enabled?'aan':'uit');
  }
  function apply(on,style) {
    enabled=!!on;if(style==='grafiet'||style==='bruingrijs')selected=style;
    save(KEY,enabled?'aan':'uit');save(STYLE_KEY,selected);state();emit();
  }
  function init() {
    if(base||!document.documentElement)return;
    base=document.createElement('style');base.id='be-dark-style';base.setAttribute(own,'base');
    var css='';Object.keys(palettes).forEach(function(name){css+='html[data-be-dark-style="'+name+'"]{'+Object.keys(palettes[name]).map(function(key){return '--be-theme-'+key+':'+palettes[name][key];}).join(';')+'}\n';});
    css+=':root{--be-coulomb-line:#0891b2;--be-coulomb-forecast:rgba(8,145,178,.55)}\n';
    Object.keys(palettes).forEach(function(name){css+='html[data-be-dark="aan"][data-be-dark-style="'+name+'"]{--be-coulomb-line:'+palettes[name].blue+';--be-coulomb-forecast:'+lighter(palettes[name].blue,.48)+'}\n';});
    css+=`
html[data-be-dark="aan"]{color-scheme:dark;background:var(--be-theme-bg)!important;color:var(--be-theme-ink)!important;--bs-body-bg:var(--be-theme-bg);--bs-body-color:var(--be-theme-ink);--bs-border-color:var(--be-theme-line)}
html[data-be-dark="aan"] body{background:var(--be-theme-bg)!important;color:var(--be-theme-ink)!important}
html[data-be-dark="aan"] body :where(*):not(svg):not(svg *){color:var(--be-theme-ink)!important}
html[data-be-dark="aan"] :is(.card,.card-header,.card-body,.modal-content,.dropdown-menu,.offcanvas){background-color:var(--be-theme-paper)!important;border-color:var(--be-theme-line)!important;color:var(--be-theme-ink)!important}
html[data-be-dark="aan"] :is(nav,.sidebar,.sidenav,#mobileSidebar){background-color:var(--be-theme-nav)!important;color:var(--be-theme-ink)!important}
html[data-be-dark="aan"] :is(input,select,textarea,option){color:var(--be-theme-ink)!important;background-color:var(--be-theme-raised)!important;border-color:var(--be-theme-line)!important}
html[data-be-dark="aan"] :is(.text-muted,.form-text,.summary-compact-label){color:var(--be-theme-muted)!important}
html[data-be-dark="aan"] :is(.summary-compact-metric){background:var(--be-theme-raised)!important;border-color:var(--be-theme-line)!important}
html[data-be-dark="aan"] :is(.btn-primary,.btn-check:checked+.btn,.nav-link.active){background:var(--be-theme-control)!important;color:#fff!important;border-color:var(--be-theme-control)!important}
html[data-be-dark="aan"] :is(.btn-light,.btn-outline-primary){background:var(--be-theme-raised)!important;color:var(--be-theme-ink)!important;border-color:var(--be-theme-line)!important}
html[data-be-dark="aan"] :is(.sidebar,.sidenav,#mobileSidebar) a{color:var(--be-theme-ink)!important}
html[data-be-dark="aan"] :is(.sidebar,.sidenav,#mobileSidebar) a:is(.active,[aria-current="page"]){background:var(--be-theme-control)!important;color:#fff!important}
html[data-be-dark="aan"] #be-panelen tr:nth-child(odd){background:var(--be-theme-paper)!important}
html[data-be-dark="aan"] #be-panelen tr:nth-child(even){background:var(--be-theme-raised)!important}
html[data-be-dark="aan"] #be-panelen details{background:var(--be-theme-paper)!important}
html[data-be-dark="aan"] :is(#be-tariefgrafiek-knop,[data-be-actueel-allin]) :is([data-be-tg-track],[data-be-track]){background:#65615b!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.25)!important}
html[data-be-dark="aan"] :is(#be-tariefgrafiek-knop,[data-be-actueel-allin])[aria-pressed="true"] :is([data-be-tg-track],[data-be-track]){background:#287dbb!important}
html[data-be-dark="aan"] :is(#be-tariefgrafiek-knop,[data-be-actueel-allin]) :is([data-be-tg-thumb],[data-be-thumb]){background:#fff!important;box-shadow:0 1px 3px #0004!important}
html[data-be-dark="aan"] :is(#be-tariefgrafiek-knop,[data-be-actueel-allin]):focus-visible{outline:2px solid #429ee8!important;outline-offset:4px;border-radius:4px}
html[data-be-dark="aan"] .be-own-soc{--be-cap-border:var(--be-theme-line);--be-cap-surface:var(--be-theme-paper);--be-cap-control:var(--be-theme-raised);--be-cap-muted:var(--be-theme-muted);--be-cap-accent:var(--be-theme-control)}
`;
    base.textContent=css;document.documentElement.appendChild(base);
    inlineSheet=document.createElement('style');inlineSheet.setAttribute(own,'inline');document.documentElement.appendChild(inlineSheet);
    state();refresh(document.documentElement);
  }
  // Read declarations, never getComputedStyle or switch off the visible sheet.
  // Live class changes now stay entirely in CSS; numerical updates do no theme work.
  new MutationObserver(function(records){
    init();records.forEach(function(r){
      var target=r.target.nodeType===1?r.target:r.target.parentElement;
      if(!target||target.closest('['+own+']'))return;
      if(r.type==='attributes'){
        if(target.matches('style,link[rel="stylesheet"]'))compile(target);else inline(target);
      }else if(target.tagName==='STYLE')compile(target);
      else {
        r.addedNodes.forEach(queue);
        r.removedNodes.forEach(function(node){if(node.nodeType!==1)return;var owners=[node].concat(Array.from(node.querySelectorAll('style,link[rel="stylesheet"]')));owners.forEach(function(owner){var entry=sourceSheets.get(owner);if(entry&&!owner.isConnected){entry.style.remove();sourceSheets.delete(owner);}});});
      }
    });
  }).observe(document,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['style','fill','stroke','media','disabled','href']});
  document.addEventListener('load',function(event){if(event.target.matches&&event.target.matches('link[rel="stylesheet"]'))compile(event.target);},true);
  window.addEventListener('storage',function(event){if(event.key===KEY||event.key===STYLE_KEY){enabled=read(KEY)==='aan';selected=read(STYLE_KEY)==='grafiet'?'grafiet':'bruingrijs';state();emit();}});
  window.addEventListener('pageshow',function(){enabled=read(KEY)==='aan';selected=read(STYLE_KEY)==='grafiet'?'grafiet':'bruingrijs';state();emit();});
  window.BETheme={apply:apply,setStyle:function(style){apply(enabled,style);},isDark:function(){return enabled;},style:function(){return selected;},color:color,seriesColor:seriesColor,refresh:queue};
  if(typeof CanvasRenderingContext2D!=='undefined'){
    var proto=CanvasRenderingContext2D.prototype;
    ['fill','fillRect','fillText','stroke','strokeRect','strokeText'].forEach(function(name){
      var original=proto[name];if(!original)return;
      proto[name]=function(){
        if(!enabled)return original.apply(this,arguments);
        var property=name.indexOf('stroke')===0?'strokeStyle':'fillStyle',previous=this[property];
        var kind=name.indexOf('Text')!==-1?'text':name.indexOf('stroke')===0?(this.lineWidth<1.5?'border':'text'):'background';
        this[property]=color(previous,kind,true);
        try{return original.apply(this,arguments);}finally{this[property]=previous;}
      };
    });
    document.addEventListener('be-dark-change',function(){if(window.Chart&&window.Chart.getChart)document.querySelectorAll('canvas').forEach(function(canvas){var chart=window.Chart.getChart(canvas);if(chart)chart.draw();});});
  }
  init();
})();

/* Short-lived observations of the running quarter; settled prices and BID history are separate. */
(function () {
  'use strict';
  if(window.BECurrentTariffCache)return;
  var TTL=30*60*1000,QUARTER=900000,PREFIX='be_current_tariffs_v1:',memory=new Map(),expires=new Map(),timer;
  var fields=['onbalans_import','onbalans_export'],PRICE_MODEL=2;
  function planningContext(payload){
    var plans=payload&&payload.dayAheadPlans,windows=payload&&payload.dayAheadUnavailableWindows,planned=new Set(),exported=new Set();
    (Array.isArray(plans)?plans:[]).forEach(function(p){
      if(!p||!Number.isFinite(p.start)||p.start%QUARTER!==0||p.end!==p.start+QUARTER)return;
      if(p.direction==='import')planned.add(p.start);
      if(p.direction==='export')exported.add(p.start);
    });
    return {authoritative:Array.isArray(plans)||Array.isArray(windows),planned:planned,exported:exported,
      unknown:(Array.isArray(windows)?windows:[]).filter(function(w){return Array.isArray(w)&&Number.isFinite(w[0])&&Number.isFinite(w[1])&&w[1]>w[0];})};
  }
  function unknownPlanning(context,start){
    return context.unknown.some(function(w){return start>=w[0]&&start<w[1];});
  }
  // Store the planning decision alongside each quote. A day-ahead price may
  // exist outside a planned quarter, so its presence alone never selects it.
  function preparePrices(prices,payload){
    var context=planningContext(payload),planned=context.planned;
    var rows=(prices||[]).slice(),missing=new Set(planned),current=Math.floor(Date.now()/QUARTER)*QUARTER;
    if(unknownPlanning(context,current))missing.add(current);
    rows.forEach(function(p){if(p)missing.delete(p.start);});
    missing.forEach(function(start){rows.push({start:start,end:start+QUARTER,values:{},provisional:true,dayAheadPlaceholder:true});});
    return rows.map(function(p){
      if(!p)return p;
      var state=context.authoritative?(planned.has(p.start)?'planned':unknownPlanning(context,p.start)?'unavailable':'none')
        :['planned','unavailable','none'].includes(p.dayAheadState)?p.dayAheadState:
          Object.keys(p.values||{}).some(function(key){return key.indexOf('day_ahead_')===0;})?'unavailable':'none';
      var dayAheadExport=context.authoritative?context.exported.has(p.start):p.dayAheadExport===true;
      return Object.assign({},p,{dayAheadState:state,dayAheadExport:dayAheadExport,priceModel:PRICE_MODEL});
    });
  }
  // A partial response can omit old price rows. Its explicit plans/windows still
  // update those rows, while an empty plan list says nothing about their scope.
  function applyPlanning(prices,payload){
    var context=planningContext(payload);
    return preparePrices(prices).map(function(p){
      if(!p)return p;
      var unknown=unknownPlanning(context,p.start);
      var state=context.planned.has(p.start)?'planned':unknown?'unavailable':p.dayAheadState;
      var dayAheadExport=context.exported.has(p.start)||(!unknown&&p.dayAheadExport===true);
      return state===p.dayAheadState&&dayAheadExport===p.dayAheadExport?p:
        Object.assign({},p,{dayAheadState:state,dayAheadExport:dayAheadExport,priceModel:PRICE_MODEL});
    });
  }
  function importMarket(p,afrr){
    if(p.dayAheadState==='unavailable')return {key:null,label:'Prijsbron onbekend',planned:true,mixed:false};
    if(p.dayAheadState==='planned')return {key:afrr?'day_ahead_afrr_import':'day_ahead_import',label:afrr?'Dynamisch + aFRR':'Dynamisch',planned:true,mixed:!!afrr};
    return {key:afrr?'afrr_import':'onbalans_import',label:afrr?'aFRR':'onbalans',planned:false,mixed:false};
  }
  function write(id,rows){
    memory.set(id,rows);
    var next=Infinity;Object.keys(rows).forEach(function(key){
      fields.forEach(function(field){var q=rows[key].quotes[field];if(q)next=Math.min(next,q.at+TTL);});
      rows[key].samples.forEach(function(s){next=Math.min(next,s.t+TTL);});
    });expires.set(id,next);
    try{if(Object.keys(rows).length)localStorage.setItem(PREFIX+id,JSON.stringify(rows));else localStorage.removeItem(PREFIX+id);}catch(_){}
  }
  function read(id){
    var now=Date.now();if(memory.has(id)&&now<expires.get(id))return memory.get(id);
    var rows=memory.get(id)||{},clean={};
    try{rows=JSON.parse(localStorage.getItem(PREFIX+id)||'null')||rows;}catch(_){}
    Object.keys(rows).forEach(function(key){
      var p=rows[key];if(!p||p.priceModel!==PRICE_MODEL||!Number.isFinite(p.start)||p.start%QUARTER||p.end!==p.start+QUARTER)return;
      var quotes={};fields.forEach(function(field){
        var q=p.quotes&&p.quotes[field];
        if(q&&Number.isFinite(q.value)&&Number.isFinite(q.at)&&q.at<=now&&now-q.at<TTL)quotes[field]={value:q.value,at:q.at};
      });
      if(!Object.keys(quotes).length)return;
      clean[p.start]={start:p.start,end:p.end,afrr:!!p.afrr,directions:Array.isArray(p.directions)?p.directions.slice():null,sourceUpdatedAt:p.sourceUpdatedAt,quotes:quotes,priceModel:PRICE_MODEL,dayAheadState:p.dayAheadState||'none',dayAheadExport:p.dayAheadExport===true,
        samples:(p.dayAheadState==='planned'||p.dayAheadState==='unavailable'?[]:Array.isArray(p.samples)?p.samples:[]).filter(function(s){return s&&Number.isFinite(s.t)&&s.t>=p.start&&s.t<p.end&&s.t<=now&&now-s.t<TTL&&Number.isFinite(s.ki)&&Number.isFinite(s.ke);})};
    });
    write(id,clean);return clean;
  }
  function schedule(){
    clearTimeout(timer);var next=Infinity;
    expires.forEach(function(at){next=Math.min(next,at);});
    if(Number.isFinite(next))timer=setTimeout(function(){memory.forEach(function(_,id){read(id);});schedule();},Math.max(1,next-Date.now()));
  }
  function remember(id,payload){
    if(!id||!payload||!Array.isArray(payload.prices))return;
    var now=Date.now(),rows=read(id);
    preparePrices(payload.prices,payload).forEach(function(p){
      if(!p||p.carried||p.temporaryTariffs||!Number.isFinite(p.start)||p.start%QUARTER||p.end!==p.start+QUARTER||p.start>now||now>=p.end)return;
      var row=rows[p.start]||{start:p.start,end:p.end,quotes:{},samples:[]},v=p.values||{};
      var revision=Date.parse(p.updatedAt);
      if(Number.isFinite(revision)&&Number.isFinite(row.sourceUpdatedAt)&&revision<row.sourceUpdatedAt)return;
      if(Number.isFinite(revision))row.sourceUpdatedAt=revision;
      row.priceModel=PRICE_MODEL;row.dayAheadState=p.dayAheadState;row.dayAheadExport=p.dayAheadExport;
      if(p.dayAheadState!=='none'){delete row.quotes.onbalans_import;row.samples=[];}
      var discovery=(payload.afrrDiscovery||[]).find(function(d){return d.start===p.start;});
      row.afrr=Array.isArray(payload.afrrEventIsps)?payload.afrrEventIsps.indexOf(p.start)!==-1:!!p.afrr;
      row.directions=discovery&&Array.isArray(discovery.directions)?discovery.directions.slice():Array.isArray(p.directions)?p.directions.slice():null;
      fields.forEach(function(field){if((field!=='onbalans_import'||p.dayAheadState==='none')&&Number.isFinite(v[field]))row.quotes[field]={value:v[field],at:now};});
      var imbalance=p.dayAheadState==='none'&&(Array.isArray(row.directions)?!row.directions.length:!row.afrr);
      if(imbalance&&fields.every(function(field){return Number.isFinite(v[field]);})){
        var last=row.samples[row.samples.length-1];
        if(!last||last.ki!==v.onbalans_import||last.ke!==v.onbalans_export)row.samples.push({t:now,ki:v.onbalans_import,ke:v.onbalans_export,marktImport:'onbalans',marktExport:'onbalans',temporaryTariffs:true});
      }
      if(Object.keys(row.quotes).length)rows[p.start]=row;
    });
    write(id,rows);schedule();
  }
  function get(id,start){return id?read(id)[start]||null:null;}
  function restore(id,source){
    var rows=(source||[]).filter(function(p){return !p.temporaryTariffs;}),saved=id?read(id):{};
    Object.keys(saved).forEach(function(key){var p=saved[key];if(!rows.some(function(r){return r.start===p.start;}))rows.push({start:p.start,end:p.end,afrr:p.afrr,directions:p.directions,dayAheadState:p.dayAheadState,dayAheadExport:p.dayAheadExport,priceModel:PRICE_MODEL,values:{},provisional:true,temporaryTariffs:true});});
    return rows.sort(function(a,b){return a.start-b.start;});
  }
  try{Array.from({length:localStorage.length},function(_,i){return localStorage.key(i);}).filter(function(key){return key&&key.indexOf(PREFIX)===0;}).forEach(function(key){read(key.slice(PREFIX.length));});}catch(_){}
  window.addEventListener('storage',function(event){if(event.key&&event.key.indexOf(PREFIX)===0){var id=event.key.slice(PREFIX.length);memory.delete(id);expires.delete(id);read(id);schedule();}});
  window.BECurrentTariffCache={remember:remember,get:get,restore:restore,preparePrices:preparePrices,applyPlanning:applyPlanning,importMarket:importMarket,priceModel:PRICE_MODEL};schedule();
})();




(function () {
  'use strict';

  /*
   * Safari Userscripts kan dezelfde userscriptbron zowel in de paginawereld
   * als via zijn content-fallback starten. Beide werelden delen de DOM.
   * Laat daarom precies één instantie de Resultaten-UI en zijn periodecache
   * beheren; anders kan een tweede instantie de gekozen jaarstand weer met
   * zijn eigen beginstand overschrijven.
   */
  var BE_RUNTIME_GUARD =
    'data-be-allin-runtime';

  if (
    document.documentElement.hasAttribute(
      BE_RUNTIME_GUARD
    )
  ) {
    return;
  }

  document.documentElement.setAttribute(
    BE_RUNTIME_GUARD,
    '7.1'
  );

  // 6.8.3.4: klein balkje bovenin als er op GitHub een nieuwere versie staat.
  (function beUpdateMelding() {
    var HUIDIG = '7.1', BASIS = 'https://raw.githubusercontent.com/paqpaqpaq/BEdashboard/main/';
    var CACHE = 'be_update_check_v1', NEGEER = 'be_update_genegeerd_v1', UUR = 600000;
    function vergelijk(a, b) {
      a = String(a).split('.').map(Number); b = String(b).split('.').map(Number);
      for (var i = 0; i < Math.max(a.length, b.length); i++) { var x = a[i] || 0, y = b[i] || 0; if (x !== y) return x > y ? 1 : -1; }
      return 0;
    }
    function toon(v) {
      if (!document.body || document.getElementById('be-update-balk') || localStorage.getItem(NEGEER) === v) return;
      var d = document.createElement('div'); d.id = 'be-update-balk'; d.setAttribute('role', 'status');
      d.style.cssText = 'position:fixed;top:8px;left:50%;transform:translateX(-50%);z-index:2147483000;display:flex;align-items:center;gap:10px;' +
        'padding:6px 8px 6px 14px;border-radius:999px;background:#6B3FA0;color:#fff;font:600 13px/1.2 system-ui,-apple-system,sans-serif;box-shadow:0 6px 18px rgba(40,20,70,.25)';
      var a = 'color:#fff;text-decoration:underline;text-underline-offset:2px';
      d.innerHTML = '<span>Balansenergie All-in ' + v + ' is beschikbaar <span style="opacity:.75;font-weight:500">(je hebt ' + HUIDIG + ')</span></span>' +
        '<a href="' + BASIS + 'Balansenergie-All-in.user.js" target="_blank" rel="noopener" style="' + a + '">Bijwerken</a>' +
        '<a href="https://github.com/paqpaqpaq/BEdashboard/blob/main/CHANGELOG.md" target="_blank" rel="noopener" style="' + a + ';font-weight:500">Wat is nieuw</a>' +
        '<button type="button" aria-label="Verbergen" style="border:0;background:rgba(255,255,255,.18);color:#fff;width:22px;height:22px;border-radius:50%;cursor:pointer;font:600 14px/22px system-ui;padding:0">×</button>';
      d.querySelector('button').addEventListener('click', function () { try { localStorage.setItem(NEGEER, v); } catch (e) {} d.remove(); });
      document.body.appendChild(d);
    }
    // De pagina mag GitHub niet zelf benaderen (CSP); de userscript-kant haalt de versie op
    // en zet hem in localStorage ('be_update_check_v1') met event 'be-update-check'.
    function controleer() {
      var c = null; try { c = JSON.parse(localStorage.getItem(CACHE) || 'null'); } catch (e) {}
      if (c && c.v && vergelijk(c.v, HUIDIG) > 0) toon(c.v);
    }
    document.addEventListener('be-update-check', controleer);
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', controleer); else controleer();
    setInterval(controleer, UUR);
  })();

  // The theme starts before the dashboard, including on full page navigation.
  var BE_DARK_KEY = 'be_cfg_darkmode';
  var beDarkOn = window.BETheme.isDark();
  function beDarkApply(on, style) { window.BETheme.apply(on, style); beDarkOn=window.BETheme.isDark(); }
  document.addEventListener('be-dark-change',function(){beDarkOn=window.BETheme.isDark();});
  function beAfrrMarketEnabled(){return localStorage.getItem('be_cfg_afrr_market')!=='uit';}
  function beAfrrMarketSet(on){
    localStorage.setItem('be_cfg_afrr_market',on?'aan':'uit');
    document.dispatchEvent(new Event('be-afrr-market-change'));
  }


  var EB_BASIS = 0.09161;
  var BTW      = 1.21;
  var EB       = 0.11085;
  var OPSLAG   = 0.02;

  var LEV_DAG = 0.21839;  // vaste leveringskosten Balans, incl. btw
  var TRA_DAG = 1.30365;  // netbeheer Enexis 2026 zoals Balans factureert, incl. btw
  var VER_DAG = 628.96 / 365;
  var VAST_DAG = VER_DAG - LEV_DAG - TRA_DAG;

  // 6.7: tarieven per kalenderjaar. Balans rekent EB en vermindering per jaar
  // (jaarafrekening 2025/2026: EB 0,12286 resp. 0,11085 incl. btw; vermindering
  // 635,19/365 resp. 628,96/365 per dag). Instellingen in Financieel winnen.
  // 2027: Belastingplan 2027 na rectificatie (16-09-2026), nog niet door de Eerste Kamer.
  var EB_JAAR  = {'2025': 0.10154, '2026': 0.09161, '2027': 0.08802};   // excl. btw, schijf 1
  var VER_JAAR = {'2025': 524.95,  '2026': 519.80,  '2027': 519.58};    // excl. btw, per jaar
  // Netbeheer incl. btw per dag zoals Balans Enexis factureert (2025: 1,30390; 2026: 1,30365).
  // 2027 staat nog niet vast; dan geldt het algemene netbeheerbedrag.
  var NET_JAAR = {'2025': 1.30390, '2026': 1.30365};
  function beJaarVan(key) {
    var m = /^(\d{4})/.exec(String(key || ''));
    return m ? m[1] : String(new Date().getFullYear());
  }
  function beJaarDagen(y) { return ((y % 4 === 0 && y % 100 !== 0) || y % 400 === 0) ? 366 : 365; }
  function beOk(v) { return typeof v === 'number' && isFinite(v) && v >= 0; }
  function beJaarInst() { return (typeof beOvSettings !== 'undefined' && beOvSettings) ? beOvSettings : null; }
  // EB per kWh incl. btw voor de datum/maand in key; onbekend jaar valt terug op EB.
  function ebVoor(key) {
    var y = beJaarVan(key), s = beJaarInst(), r = s && s.rates ? s.rates[y] : undefined;
    if (!beOk(r)) r = EB_JAAR[y];
    return beOk(r) ? r * BTW : EB;
  }
  function netbeheerVoor(key) {
    var y = beJaarVan(key), s = beJaarInst(), n = s && s.networkRates ? s.networkRates[y] : undefined;
    if (!beOk(n) && !s) n = NET_JAAR[y];
    if (!beOk(n)) n = s && beOk(s.network) ? s.network : TRA_DAG;
    return n;
  }
  // Vaste dagpost incl. btw: vermindering − levering − netbeheer, per jaar.
  function vastDag(key) {
    var y = beJaarVan(key), s = beJaarInst(), c = s && s.credit ? s.credit[y] : undefined;
    if (!beOk(c)) c = VER_JAAR[y];
    var ver = beOk(c) ? c * BTW / beJaarDagen(+y) : VER_DAG;
    var lev = s && beOk(s.supplier) ? s.supplier : LEV_DAG;
    return ver - lev - netbeheerVoor(key);
  }
  // Som van vastDag over een datumbereik (YYYY-MM-DD, inclusief), zodat de jaargrens klopt.
  function vastBereik(van, n) {
    var d = new Date(van + 'T12:00:00Z'), som = 0;
    for (var i = 0; i < n; i++) { som += vastDag(d.toISOString().slice(0, 10)); d.setUTCDate(d.getUTCDate() + 1); }
    return som;
  }

  var LS = {
    voorschot:    'be_cfg_voorschot',
    startdatum:   'be_cfg_startdatum',
    saldering:    'be_cfg_saldering',
    balansBlok:      'be_cfg_balansblok',
    allin:           'be_cfg_allin_aan',
    actueelAllin:    'be_cfg_actueel_allin',
    voorlopigeDagen: 'be_provisional_days_v43',
    voorlopigeAudit: 'be_provisional_audit_v1'
  };

  var MND_KORT = [
    'Jan', 'Feb', 'Mrt', 'Apr', 'Mei', 'Jun',
    'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'
  ];

  var MND_LANG = [
    'januari', 'februari', 'maart', 'april',
    'mei', 'juni', 'juli', 'augustus',
    'september', 'oktober', 'november', 'december'
  ];

  var D = {
    rand:       '#e8e2f0',
    label:      '#8c6fb5',
    paars:      '#6B3FA0',
    paarsLicht: '#9b7ec8',
    rood:       '#dc3545',
    groen:      '#198754',
    oranje:     '#e07b00',
    grijs:      '#6c757d',
    inkt:       '#2b2733',
    roodZacht:  '#c8a0a0',
    groenZacht: '#90c8a0'
  };

  var cfg = {
    voorschotHistorie: (function(){try{return beVoorschotValideer(JSON.parse(localStorage.getItem('be_cfg_voorschot_historie')||'[]'));}catch(e){return [];}})(),
    voorschot: parseFloat(
      localStorage.getItem(LS.voorschot) || '42.98'
    ),

    start: (function () {
      var s = localStorage.getItem(LS.startdatum);

      if (s) {
        var d = new Date(s);
        if (!isNaN(d)) return d;
      }

      return new Date('2025-11-04');
    })(),

    saldering:
      localStorage.getItem(LS.saldering) !== 'uit',

    balansBlok:
      localStorage.getItem(LS.balansBlok) !== 'uit',

    // Resultaten begint bij iedere paginalaad met de originele Balans-data.
    allin: localStorage.getItem(LS.allin) === 'aan',
    resultaatBelastingen: localStorage.getItem('be_cfg_resultaat_belastingen') !== 'uit'
  };

  var salderingPrognose = false;

  function n2(v) {
    return String(v).padStart(2, '0');
  }

  function iso(d) {
    return (
      d.getFullYear() +
      '-' +
      n2(d.getMonth() + 1) +
      '-' +
      n2(d.getDate())
    );
  }

  function datumPlusMaanden(d, aantal) {
    var jaar =
      d.getFullYear();

    var maand =
      d.getMonth() + aantal;

    var laatsteDag =
      new Date(
        jaar,
        maand + 1,
        0
      ).getDate();

    return new Date(
      jaar,
      maand,
      Math.min(
        d.getDate(),
        laatsteDag
      )
    );
  }

  function datumDagNummer(d) {
    return Math.floor(
      Date.UTC(
        d.getFullYear(),
        d.getMonth(),
        d.getDate()
      ) /
      86400000
    );
  }

  function contractVoortgang(start, nu) {
    var begin =
      new Date(
        start.getFullYear(),
        start.getMonth(),
        start.getDate()
      );

    var vandaag =
      new Date(
        nu.getFullYear(),
        nu.getMonth(),
        nu.getDate()
      );

    var grens =
      datumPlusMaanden(
        begin,
        12
      );

    var totaalDagen =
      datumDagNummer(grens) -
      datumDagNummer(begin);

    var verstrekenDagen =
      Math.max(
        0,
        Math.min(
          totaalDagen,
          datumDagNummer(vandaag) -
          datumDagNummer(begin)
        )
      );

    var maanden =
      (
        vandaag.getFullYear() -
        begin.getFullYear()
      ) *
      12 +
      vandaag.getMonth() -
      begin.getMonth();

    maanden =
      Math.max(
        0,
        Math.min(
          12,
          maanden
        )
      );

    var maandAnker =
      datumPlusMaanden(
        begin,
        maanden
      );

    if (
      maanden > 0 &&
      datumDagNummer(maandAnker) >
        datumDagNummer(vandaag)
    ) {
      maanden--;
      maandAnker =
        datumPlusMaanden(
          begin,
          maanden
        );
    }

    var restDagen =
      vandaag < begin ||
      vandaag >= grens
        ? 0
        : Math.max(
            0,
            datumDagNummer(vandaag) -
            datumDagNummer(maandAnker)
          );

    var pctExact =
      totaalDagen > 0
        ? verstrekenDagen /
          totaalDagen *
          100
        : 0;

    return {
      grens: grens,
      totaalDagen: totaalDagen,
      verstrekenDagen: verstrekenDagen,
      contractDag:
        vandaag < begin
          ? 0
          : Math.min(
              totaalDagen,
              verstrekenDagen + 1
            ),
      maanden: maanden,
      restDagen: restDagen,
      pctExact: pctExact,
      gestart: vandaag >= begin,
      voltooid: vandaag >= grens
    };
  }

  // Alleen in deze pagina opnieuw gevalideerde resultaten mogen worden gebruikt.
  var voorlopigeSessie = String(Date.now()) + ':' + Math.random();

  function voorlopigeDagGrenzen(key) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(key))) return null;
    var start = new Date(key + 'T00:00:00');
    if (!Number.isFinite(start.getTime()) || iso(start) !== key) return null;
    var eind = new Date(start.getTime());
    eind.setDate(eind.getDate() + 1);
    return { start: start.getTime(), eind: eind.getTime() };
  }

  function voorlopigeBerekeningGeldig(key, res, vanaf, tot, explicietHerzien) {
    var g = voorlopigeDagGrenzen(key);
    var ongeprijsd=!!(explicietHerzien&&res&&res.prijsOnvolledig&&res.stukken===0&&Number.isFinite(res.gemetenMs)&&res.gemetenMs>0);
    if (!g || !res || (!(res.stukken > 0)&&!ongeprijsd) || res.ongeldig) return false;
    if (vanaf !== g.start || tot <= vanaf || tot > g.eind || tot > Date.now()) return false;
    if(ongeprijsd&&res.gemetenMs>tot-vanaf)return false;
    if (res.bronVanaf !== vanaf || res.bronTot !== tot) return false;
    if (!['importKwh', 'exportKwh', 'inkoopEur', 'verkoopEur', 'gedekt'].every(function (k) {
      return Number.isFinite(res[k]);
    }) || res.importKwh < 0 || res.exportKwh < 0) return false;
    // Datumzekerheid staat los van dekking: een aantoonbaar deelresultaat is geldig.
    return (res.gedekt > 0||ongeprijsd&&res.gedekt===0) && res.gedekt <= tot - vanaf;

  }

  // Duurzaam bronarchief; geen automatische verwijdering van eerdere dagen.
  var beArchiefDb = null;
  var beArchiefFout = '';
  var beArchiefWachtrij = Promise.resolve();
  function beOpenArchief() {
    if (!beArchiefDb) beArchiefDb = new Promise(function (resolve, reject) {
      var req = indexedDB.open('balansenergie-bronnen-v1', 1);
      req.onupgradeneeded = function () { req.result.createObjectStore('dagen'); };
      req.onsuccess = function () { resolve(req.result); };
      req.onerror = function () { reject(req.error); };
      req.onblocked = function () { reject(new Error('Archief geblokkeerd')); };
    });
    return beArchiefDb;
  }
  async function beLeesBron(key) {
    var db = await beOpenArchief();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('dagen', 'readonly');
      var req = tx.objectStore('dagen').get(KLANT + ':' + key);
      req.onsuccess = function () {
        var r = req.result || {};
        if (key === 'prijzen' && Array.isArray(r.rows) && typeof BETenergy !== 'undefined' && BETenergy) BETenergy.vulAanRijen(r.rows);
        if (key === 'prijzen' && Array.isArray(r.rows) && typeof BEDayAhead !== 'undefined' && BEDayAhead) BEDayAhead.vulAanRijen(r.rows);
        resolve(r);
      };
      req.onerror = function () { reject(req.error); };
    });
  }
  async function beSchrijfBron(key, value) {
    var db = await beOpenArchief();
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('dagen', 'readwrite');
      tx.objectStore('dagen').put(value, KLANT + ':' + key);
      tx.oncomplete = function () { resolve(); };
      tx.onerror = tx.onabort = function () { reject(tx.error || new Error('Opslaan mislukt')); };
    });
  }
  // Historical quotes are recovered from this browser’s own archive.
  var beLokalePrijsHistorie = {};
  function beHistorieMetingen(j) {
    var coarse = (j && j.rows || []).filter(function(r){return r && Number.isFinite(r.t) && Number.isFinite(r.po);});
    var fine = (j && j.priceSamples || []).filter(function(r){return r && Number.isFinite(r.x) && Number.isFinite(r.y);})
      .map(function(r){return {t:r.x,po:r.y,detail:2};});
    return beVoegMetingenSamen(coarse, fine);
  }
  function beVoegMetingenSamen(oud, nieuw) {
    var map = new Map();
    [].concat(oud || [], nieuw || []).forEach(function(r){
      if (!r || !Number.isFinite(r.t) || !Number.isFinite(r.po)) return;
      var old = map.get(r.t);
      if (!old || (r.detail || 1) >= (old.detail || 1))
        map.set(r.t, {t:r.t,po:r.po,detail:r.detail || 1});
    });
    var rows = Array.from(map.values()).sort(function(a,b){return a.t-b.t;});
    var fine = rows.filter(function(r){return r.detail === 2;}), intervals=[];
    for(var i=1;i<fine.length;i++) if(fine[i].t-fine[i-1].t<=300000)
      intervals.push([fine[i-1].t,fine[i].t]);
    var n=0;
    return rows.filter(function(r){
      if(r.detail===2)return true;
      while(n<intervals.length && intervals[n][1]<r.t)n++;
      return !(n<intervals.length && intervals[n][0]<=r.t && r.t<=intervals[n][1]);
    });
  }
  function beVoegPrijzenSamen(oud, nieuw, events, discovery, planning) {
    var eerdereRows=window.BECurrentTariffCache.preparePrices(oud).filter(Boolean);
    var eerdere=new Map(eerdereRows.map(function(p){return [p.start,p];}));
    var map = new Map(window.BECurrentTariffCache.applyPlanning(eerdereRows,planning).map(function (p) { return [p.start, p]; }));
    var bijgewerkt=new Set((nieuw||[]).filter(Boolean).map(function(p){return p.start;}));
    map.forEach(function(p,start){
      var windows=planning&&planning.dayAheadUnavailableWindows;
      var expliciet=Array.isArray(windows)&&windows.some(function(w){return Array.isArray(w)&&Number.isFinite(w[0])&&Number.isFinite(w[1])&&w[1]>w[0]&&start>=w[0]&&start<w[1];});
      if(expliciet||p.dayAheadState!==eerdere.get(start).dayAheadState)bijgewerkt.add(start);
    });
    var richtingen = {};
    (discovery || []).forEach(function (d) { richtingen[d.start] = d; });
    window.BECurrentTariffCache.preparePrices(nieuw, planning).forEach(function (p) {
      if (!p || !Number.isFinite(p.start) || !Number.isFinite(p.end) || p.end <= p.start) return;
      bijgewerkt.add(p.start);
      var vorig = map.get(p.start);
      if(p.dayAheadPlaceholder&&vorig&&!vorig.carried)
        p=Object.assign({},vorig,{dayAheadState:p.dayAheadState,dayAheadExport:p.dayAheadExport,priceModel:p.priceModel});
      // An explicitly final source cannot be downgraded by an older provisional response.
      if (vorig && !vorig.carried && vorig.provisional === false && p.provisional === true) {
        map.set(p.start,window.BECurrentTariffCache.preparePrices([vorig],planning)[0]);return;
      }
      var oudT = vorig && Date.parse(vorig.updatedAt);
      var nieuwT = Date.parse(p.updatedAt);
      if (vorig && !vorig.carried && vorig.provisional === p.provisional && Number.isFinite(oudT) && Number.isFinite(nieuwT) && nieuwT < oudT) {
        map.set(p.start,window.BECurrentTariffCache.preparePrices([vorig],planning)[0]);return;
      }
      var d = richtingen[p.start];
      var afrr = Array.isArray(events) ? events.indexOf(p.start) !== -1 : !!p.afrr;
      // Replace this snapshot, including nulls and corrections; do not mix tariff revisions.
      var snapshot = Object.assign({}, p, {
        values: Object.assign({}, p.values || {}), afrr: afrr,
        directions: d && Array.isArray(d.directions) ? d.directions.slice() :
          (Array.isArray(p.directions) ? p.directions.slice() : null)
      });
      // Preserve last finite same-quarter quotes separately from source nulls.
      snapshot.bewaardeTarieven = Object.assign({},
        beLokalePrijsHistorie[p.start] || {}, vorig && vorig.bewaardeTarieven || {}, p.bewaardeTarieven || {});
      [vorig && vorig.values || {}, p.values || {}].forEach(function(values){
        Object.keys(values).forEach(function(key){
          if(Number.isFinite(values[key])) snapshot.bewaardeTarieven[key]=values[key];
        });
      });
      // Keep observations separately from the latest quarter settlement snapshot.
      var verloop = Array.from(new Map([].concat(vorig && vorig.verloop || [], p.verloop || []).map(function(v){return [v.t,v];})).values()).sort(function(a,b){return a.t-b.t;});
      var nu = Date.now();
      if (p.start <= nu && nu < p.end) {
        var r = actueelPrijsRij(snapshot);
        if ((Number.isFinite(r.ki) || Number.isFinite(r.ke)) && !r.historischImport && !r.historischExport) {
          var last = verloop[verloop.length - 1];
          if (!last || last.ki !== r.ki || last.ke !== r.ke ||
              last.marktImport !== r.marktImport || last.marktExport !== r.marktExport) {
            // Observation time: never invent a historical transition from a revised snapshot.
            verloop.push({ t:nu, ki:r.ki, ke:r.ke,
              marktImport:r.marktImport, marktExport:r.marktExport });
          }
        }
      }
      snapshot.verloop = verloop;
      map.set(p.start, snapshot);
    });
    // An explicit source correction invalidates only overlapping provisional
    // amounts. A failed request has no planning payload and preserves good data.
    if(planning&&Array.isArray(planning.prices)&&typeof leesVoorlopigeDagen==='function'&&typeof schrijfVoorlopigeDagen==='function'){
      var opslag=leesVoorlopigeDagen(),gewijzigd=false;
      function signature(p){
        if(!p)return null;
        var ds=p.directions,ai=Array.isArray(ds)?ds.indexOf('import')!==-1:!!p.afrr;
        var markt=window.BECurrentTariffCache.importMarket(p,ai),waarde=markt.key&&(p.values||{})[markt.key];
        return [p.dayAheadState,markt.key,Number.isFinite(waarde)?waarde:null];
      }
      map.forEach(function(p,start){
        if(!bijgewerkt.has(start))return;
        var vorig=eerdere.get(start),was=signature(vorig),wordt=signature(p);
        if(p.dayAheadState==='none'&&(!vorig||vorig.dayAheadState==='none'))return;
        var key=iso(new Date(start)),dag=opslag[key];
        if(!dag||dag.voorlopig!==true||!(dag.gemetenVanaf<p.end&&dag.gemetenTot>p.start))return;
        var explicietOnbekend=p.dayAheadState==='unavailable'||p.dayAheadState==='planned'&&wordt[2]===null;
        // Legacy partial days may already contain a stale amount for this
        // quarter. A scoped correction gets one reprice, even if another missing
        // quarter had previously marked the day as partial.
        if(JSON.stringify(was)===JSON.stringify(wordt)&&(!explicietOnbekend||dag.prijsBronVersie===1))return;
        dag.prijsHerberekenen=true;dag.prijsOnvolledig=true;dag.deelresultaat=true;dag.prijsHerzienOp=Date.now();gewijzigd=true;
      });
      if(gewijzigd)schrijfVoorlopigeDagen(opslag);
    }
    return Array.from(map.values()).sort(function (a,b) { return a.start-b.start; });
  }

  function actueelPrijsRij(p) {
    var v = p.values || {}, ds = p.directions;
    var ai = Array.isArray(ds) ? ds.indexOf('import') !== -1 : !!p.afrr;
    var ae = Array.isArray(ds) ? ds.indexOf('export') !== -1 : !!p.afrr;
    var saved=Object.assign({},beLokalePrijsHistorie[p.start]||{},p.bewaardeTarieven||{});
    var cached=window.BECurrentTariffCache.get(KLANT,p.start),live=p.start<=Date.now()&&Date.now()<p.end;
    var verloop=(p.temporaryTariffs?[]:p.verloop||[]).filter(function(o){return !o.temporaryTariffs||Date.now()-o.t<30*60*1000;});
    if(cached)verloop=Array.from(new Map(verloop.concat(cached.samples).map(function(o){return [o.t,o];})).values()).sort(function(a,b){return a.t-b.t;});
    ['onbalans_import','onbalans_export'].forEach(function(field){
      if(live||p.temporaryTariffs)delete saved[field];
      if(cached&&cached.quotes[field])saved[field]=cached.quotes[field].value;
    });
    var market=window.BECurrentTariffCache.importMarket(p,ai);
    var ik=market.key,ek=ae?'afrr_export':'onbalans_export',exportMarket=ae?'aFRR':'onbalans';
    var ki=ik?v[ik]:null,ke=v[ek],hi=false,he=false;
    // Planned imports use only the API's corresponding day-ahead/mix quote.
    // Unknown planning or a missing quote must never become an imbalance price.
    if(!market.planned && !Number.isFinite(ki) && Number.isFinite(saved[ik])){ki=saved[ik];hi=true;}
    if(!Number.isFinite(ke) && Number.isFinite(saved[ek])){ke=saved[ek];he=true;}
    // Recorded live observations can repair a same-market quote as well.
    verloop.slice().reverse().forEach(function(o){
      if(!market.planned && !Number.isFinite(ki) && o.marktImport===market.label && Number.isFinite(o.ki)){ki=o.ki;hi=true;}
      if(!Number.isFinite(ke) && o.marktExport===exportMarket && Number.isFinite(o.ke)){ke=o.ke;he=true;}
    });
    verloop=verloop.map(function(o){return Object.assign({},o,{
      ki:ik&&Number.isFinite(ki)&&o.marktImport===market.label&&Number.isFinite(o.ki)?o.ki:null,
      ke:Number.isFinite(ke)&&o.marktExport===exportMarket&&Number.isFinite(o.ke)?o.ke:null
    });}).filter(function(o){return Number.isFinite(o.ki)||Number.isFinite(o.ke);});
    var vergelijkOnbalans=(p.dayAheadState==='planned'||p.dayAheadExport===true)&&!p.carried&&
      (!Number.isFinite(p.sourceStart)||p.sourceStart===p.start);
    return {start:p.start,end:p.end,afrr:ai||ae,
      dayAheadExport:p.dayAheadExport===true,
      onbalansVergelijking:vergelijkOnbalans?{
        ki:Number.isFinite(v.onbalans_import)?v.onbalans_import:null,
        ke:Number.isFinite(v.onbalans_export)?v.onbalans_export:null
      }:null,
      marktImport:market.label,marktExport:exportMarket,ki:ki,ke:ke,
      dayAheadState:p.dayAheadState||'none',gemengdImport:market.mixed,
      historischImport:hi,historischExport:he,epexInjectie:!!p.beDayAheadBron&&(ik==='day_ahead_import'||ik==='day_ahead_afrr_import'),
      provisional:hi||he?true:p.provisional,fresh:p.fresh,updatedAt:p.updatedAt,
      carried:!!p.carried,sourceStart:p.sourceStart,verloop:verloop,values:Object.assign({},v)};
  }

  async function beVerwerkBron(u, j) {
    var prijs = u.pathname.indexOf('current-prices') !== -1;
    if (prijs) {
      var oud = await beLeesBron('prijzen');
      var rows = beVoegPrijzenSamen(oud.rows, j && j.prices, j && j.afrrEventIsps, j && j.afrrDiscovery, j);
      if (j && Array.isArray(j.prices)) await beSchrijfBron('prijzen', { rows: rows });
      return { generatedAt:j && j.generatedAt, prices: rows, afrrEventIsps: rows.filter(function (p) { return p.afrr; }).map(function (p) { return p.start; }) };
    }
    var vanaf = Number(u.searchParams.get('start')), tot = Number(u.searchParams.get('end'));
    if (!Number.isFinite(vanaf) || !Number.isFinite(tot) || tot <= vanaf) throw new Error('Ongeldig archiefbereik');
    var nieuwPerDag = {};
    beHistorieMetingen(j).forEach(function (r) {
      if (!r || !Number.isFinite(r.t) || !Number.isFinite(r.po) || r.t < vanaf || r.t > tot) return;
      var key = iso(new Date(r.t));
      (nieuwPerDag[key] || (nieuwPerDag[key] = [])).push(r);
    });
    var dagen = await beLeesBron('index');
    var keys = dagen.keys || [];
    for (var key of Object.keys(nieuwPerDag)) {
      var oud = await beLeesBron(key);
      await beSchrijfBron(key, { rows: beVoegMetingenSamen(oud.rows, nieuwPerDag[key]) });
      if (keys.indexOf(key) === -1) keys.push(key);
    }
    await beSchrijfBron('index', { keys: keys.sort() });
    var samen = [];
    for (var key of keys) {
      var g = voorlopigeDagGrenzen(key);
      if (!g || g.eind < vanaf || g.start > tot) continue;
      var dag = await beLeesBron(key);
      samen = samen.concat((dag.rows || []).filter(function (r) { return r.t >= vanaf && r.t <= tot; }));
    }
    return { rows: samen.sort(function (a,b) { return a.t-b.t; }) };
  }
  async function beHaalBron(input, init) {
    var u = new URL(typeof input === 'string' ? input : input.href || input.url, location.origin);
    if (!/\/customer\/current-(history|prices)\/api\/$/.test(u.pathname)) return origFetch(input, init);
    var j = null;
    try {
      var resp = await origFetch(u.href, init);
      if (resp.ok) j = await resp.json();
    } catch (e) { /* Bij netwerkuitval blijft het archief leesbaar. */ }
    var werk = beArchiefWachtrij.then(function () { return beVerwerkBron(u, j); });
    beArchiefWachtrij = werk.catch(function () {});
    try {
      var data = await werk;
      beArchiefFout = '';
      return { ok: true, json: function () { return Promise.resolve(data); } };
    } catch (e) {
      beArchiefFout = 'Lokale opslag mislukt: ' + e.message;
      console.error('[BE archief]', beArchiefFout);
      return { ok: !!j, json: function () { return Promise.resolve(j); } };
    }
  }
  var beArchiefBezig = false;
  var beArchiefImportKlaar = false;
  async function beArchiefOnderhoud() {
    if (!KLANT || KLANT === 'account' || beArchiefBezig || document.hidden) return;
    var onderhoudKey='be_onderhoud_laatst:'+KLANT;
    if(Date.now()-Number(sessionStorage.getItem(onderhoudKey)||0)<300000)return;
    sessionStorage.setItem(onderhoudKey,String(Date.now()));
    beArchiefBezig = true;
    try {
      if (!beArchiefImportKlaar) {
        var migratie = await beLeesBron('console-import');
        var oudRapport = localStorage.getItem('be_brononderzoek_v1:' + KLANT);
        if (oudRapport) {
          var importData = JSON.parse(oudRapport);
          var prijsUrl = new URL('/customer/current-prices/api/', location.origin);
          var taak = beArchiefWachtrij.then(function () {
            return beVerwerkBron(prijsUrl, { prices: Object.values(importData.prijzen || {}), afrrEventIsps: importData.afrrEventIsps || [] });
          });
          beArchiefWachtrij = taak.catch(function () {});
          await taak;
          await beSchrijfBron('console-import', { klaar: true });
        }
        beArchiefImportKlaar = true;
      }
      var nu = Date.now();
      var u = new URL('/customer/current-history/api/', location.origin);
      u.searchParams.set('installation', KLANT);
      u.searchParams.set('start', String(nu - 26 * 3600000));
      u.searchParams.set('end', String(nu));
      var res = await Promise.all([
        beHaalBron(u.href, { credentials:'same-origin', cache:'no-store' }),
        beHaalBron(location.origin + '/customer/current-prices/api/', { credentials:'same-origin', cache:'no-store' })
      ]);
      var prijzen = await res[1].json();
      if (!prijzen) return;
      var rijPrijzen = prijzen.prices.map(actueelPrijsRij);
      var index = await beLeesBron('index');
      for (var key of index.keys || []) {
        var g = voorlopigeDagGrenzen(key), dag = await beLeesBron(key);
        var tot = Math.min(nu, g.eind);
        if (tot <= g.start) continue;
        var berekend = actueelProjectieBereken((dag.rows || []).map(function (r) { return {x:r.t,y:r.po}; }), rijPrijzen, g.start, tot, nu);
        bewaarVoorlopigeDag(key, berekend, g.start, tot);
      }
      if (laatste) plan();
    } catch (e) {
      beArchiefFout = 'Lokale opslag niet beschikbaar: ' + e.message;
      console.error('[BE archief]', beArchiefFout);
    } finally { beArchiefBezig = false; }
    var melding = document.getElementById('be-archief-status');
    if (beArchiefFout && !melding && document.body) {
      melding = document.createElement('div'); melding.id='be-archief-status';
      melding.style.cssText='padding:10px;background:#fff0d6;color:#743900';
      document.body.prepend(melding);
    }
    if (melding) { melding.textContent=beArchiefFout; melding.hidden=!beArchiefFout; }
  }

  function leesVoorlopigeDagen() {
    try {
      var o =
        JSON.parse(
          localStorage.getItem(
            LS.voorlopigeDagen + ':' + KLANT
          ) || '{}'
        );

      if (!o || typeof o !== 'object' || Array.isArray(o)) return {};
      Object.keys(o).forEach(function (k) {
        var r = o[k];
        if (!r || r.key !== k || r.archiefVersie !== 1 || r.klant !== KLANT) delete o[k];
        else if (r.prijsModel !== window.BECurrentTariffCache.priceModel) {
          // Retain the measured source and audit, but do not show amounts
          // computed with an older market selector while rebuilding the day.
          r.prijsOnvolledig = true; r.prijsHerberekenen = true;
        }
      });
      return o;

    } catch (e) {
      return {};
    }
  }

  function schrijfVoorlopigeDagen(o) {
    try {
      localStorage.setItem(
        LS.voorlopigeDagen + ':' + KLANT,
        JSON.stringify(o || {})
      );
    } catch (e) {}
  }

  /*
   * Bewaar de laatste voorlopige berekening wanneer Balans dezelfde dag
   * definitief publiceert. Zo blijft een verschil achteraf controleerbaar;
   * de actieve voorlopige cache zelf kan daarna gewoon worden opgeruimd.
   */
  function bewaarVoorlopigeAudit(dagKey, voorlopig, definitief) {
    if (!voorlopig || !/^\d{4}-\d{2}-\d{2}$/.test(String(dagKey || ''))) {
      return;
    }

    try {
      var sleutel =
        LS.voorlopigeAudit + ':' + KLANT;

      var audit = JSON.parse(
        localStorage.getItem(sleutel) || '{}'
      );

      if (!audit || typeof audit !== 'object' || Array.isArray(audit)) {
        audit = {};
      }

      audit[dagKey] = {
        klant: KLANT,
        key: dagKey,
        voorlopig: voorlopig,
        definitief: definitief || null,
        vervangenOp: Date.now()
      };

      localStorage.setItem(
        sleutel,
        JSON.stringify(audit)
      );
    } catch (e) {}
  }

  function bewaarVoorlopigeDag(
    dagKey,
    res,
    vanaf,
    tot
  ) {
    var opslag = leesVoorlopigeDagen();
    var eerder = opslag[dagKey];
    if (!voorlopigeBerekeningGeldig(dagKey, res, vanaf, tot, !!(eerder&&eerder.prijsHerberekenen))) {
      // Minder beschikbare bronnen wissen nooit een eerder bewezen resultaat.
      return false;
    }
    // Reject truncated measurement windows, not a reduced availability of prices.
    var gemetenMs = Number.isFinite(res.gemetenMs) ? res.gemetenMs : res.gedekt;
    if (eerder && ((Number.isFinite(eerder.gemetenTot) && tot < eerder.gemetenTot) ||
        (Number.isFinite(eerder.gemetenMs) && gemetenMs < eerder.gemetenMs))) return false;
    var nu = Date.now();
    var grenzen = voorlopigeDagGrenzen(dagKey);
    var volleDag = grenzen.eind - grenzen.start;

    opslag[dagKey] = {
      validatie: voorlopigeSessie,
      archiefVersie: 1,
      prijsModel: window.BECurrentTariffCache.priceModel,
      prijsBronVersie: 1,
      // All-unpriced measurements are retained, but may not become a zero-euro
      // financial day. Existing consumers already exclude this pending state.
      prijsHerberekenen: !(res.stukken > 0),
      klant: KLANT,
      key:
        dagKey,

      voorlopig:
        true,

      deelresultaat: !!res.prijsOnvolledig || res.gedekt < volleDag * 0.995,
      prijsOnvolledig: !!res.prijsOnvolledig,
      gemetenMs: gemetenMs,
      geprijsdeImportKwh: Number.isFinite(res.geprijsdeImportKwh) ? res.geprijsdeImportKwh : res.importKwh,
      geprijsdeExportKwh: Number.isFinite(res.geprijsdeExportKwh) ? res.geprijsdeExportKwh : res.exportKwh,
      historischKwh: res.historischKwh || 0,

      imp:
        res.importKwh,

      exp:
        res.exportKwh,

      inkoop:
        res.inkoopEur,

      verkoop:
        res.verkoopEur,

      laden:
        0,

      ontladen:
        0,

      pv:
        0,

      afrrImp:
        0,

      afrrExp:
        0,

      afrrVergoeding:
        0,

      dealsAantal:
        0,

      gedektMs:
        res.gedekt,

      volledigheid:
        Math.min(
          100,
          Math.max(
            0,
            100 *
            res.gedekt /
            volleDag
          )
        ),

      gemetenVanaf:
        vanaf,

      gemetenTot:
        tot,

      bijgewerkt:
        nu
    };

    if (eerder) {
      var vergelijk = Object.assign({}, opslag[dagKey], { bijgewerkt: eerder.bijgewerkt });
      if (JSON.stringify(vergelijk) === JSON.stringify(eerder)) return true;
    }
    schrijfVoorlopigeDagen(
      opslag
    );
    return true;
  }

  function voorlopigeDagenVoorMaand(
    mk,
    echteRijen
  ) {
    if (
      !/^\d{4}-\d{2}$/.test(
        String(mk || '')
      )
    ) {
      return [];
    }

    var opslag =
      leesVoorlopigeDagen();

    var echt = {};
    var gewijzigd = false;

    (echteRijen || [])
      .forEach(
        function (r) {
          if (
            r && r.bronAanwezig !== false &&
            /^\d{4}-\d{2}-\d{2}$/.test(
              String(r.key || '')
            )
          ) {
            echt[r.key] = r;

          }
        }
      );

    /*
     * Zodra Balans een datum zelf levert, wint die altijd.
     * De lokale voorlopige kopie kan dan meteen weg.
     */
    Object.keys(opslag)
      .forEach(
        function (k) {
          if (echt[k]) {
            bewaarVoorlopigeAudit(
              k,
              opslag[k],
              echt[k]
            );

            delete opslag[k];
            gewijzigd = true;
          }
        }
      );

    if (gewijzigd) {
      schrijfVoorlopigeDagen(
        opslag
      );
    }

    var vandaag =
      iso(new Date());

    return Object.keys(opslag)
      .filter(
        function (k) {
          var r =
            opslag[k];

          return (
            k.indexOf(
              mk + '-'
            ) === 0 &&
            k <= vandaag &&
            !echt[k] &&
            r &&
            !r.prijsHerberekenen &&
            r.voorlopig &&
            Number.isFinite(
              r.inkoop
            ) &&
            Number.isFinite(
              r.verkoop
            )
          );
        }
      )
      .sort()
      .map(
        function (k) {
          return opslag[k];
        }
      );
  }

  function voorlopigDagLabel(key) {
    var p =
      String(key || '')
        .split('-');

    if (p.length !== 3) {
      return '~';
    }

    var maand =
      MND_KORT[
        parseInt(p[1], 10) - 1
      ] || '';

    return (
      '~' +
      parseInt(p[2], 10) +
      ' ' +
      maand.toLowerCase()
    );
  }

  function voorlopigeDagenTekst(
    rijen,
    mk
  ) {
    var dagen = {};

    (rijen || [])
      .forEach(
        function (r) {
          if (
            !r ||
            !r.voorlopig ||
            String(r.key || '')
              .indexOf(
                mk + '-'
              ) !== 0
          ) {
            return;
          }

          var d =
            parseInt(
              String(r.key)
                .slice(8, 10),
              10
            );

          if (d > 0) {
            dagen[d] = true;
          }
        }
      );

    var lijst =
      Object.keys(dagen)
        .map(
          function (d) {
            return parseInt(
              d,
              10
            );
          }
        )
        .sort(
          function (a, b) {
            return a - b;
          }
        );

    if (!lijst.length) {
      return '';
    }

    if (lijst.length === 1) {
      return (
        lijst[0] +
        ' voorlopig'
      );
    }

    if (lijst.length === 2) {
      return (
        lijst[0] +
        ' en ' +
        lijst[1] +
        ' voorlopig'
      );
    }

    return (
      lijst
        .slice(0, -1)
        .join(', ') +
      ' en ' +
      lijst[
        lijst.length - 1
      ] +
      ' voorlopig'
    );
  }

  function getal(v) {
    return (
      typeof v === 'number' &&
      isFinite(v)
    )
      ? v
      : 0;
  }

  function eur(v, dec) {
    if (dec === undefined) dec = 2;

    return (
      '\u20ac\u00a0' +
      Math.abs(v).toLocaleString(
        'nl-NL',
        {
          minimumFractionDigits: dec,
          maximumFractionDigits: dec
        }
      )
    );
  }

  function eurT(v, dec) {
    if (dec === undefined) dec = 2;

    return (
      (v < 0 ? '\u2212' : '+') +
      '\u00a0\u20ac\u00a0' +
      Math.abs(v).toLocaleString(
        'nl-NL',
        {
          minimumFractionDigits: dec,
          maximumFractionDigits: dec
        }
      )
    );
  }

  function eurCent(v) {
    return (
      (v < 0 ? '\u2212' : '+') +
      '\u20ac' +
      Math.abs(v).toLocaleString(
        'nl-NL',
        {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        }
      )
    );
  }

  function eurKort(v) {
    return (
      (v < 0 ? '\u2212' : '+') +
      '\u20ac' +
      Math.round(
        Math.abs(v)
      ).toLocaleString('nl-NL')
    );
  }

  function num(v, dec) {
    return getal(v).toLocaleString(
      'nl-NL',
      {
        minimumFractionDigits: dec,
        maximumFractionDigits: dec
      }
    );
  }

  function kwh(v) {
    return num(v, 0) + ' kWh';
  }

  function ct(v) {
    return num(v * 100, 1) + ' ct';
  }

  function prijs(v) {
    return eur(v, 3) + ' / kWh';
  }

  function kleur(v) {
    return v < 0
      ? D.rood
      : D.groen;
  }

  function kleurZacht(v) {
    return v < 0
      ? D.roodZacht
      : D.groenZacht;
  }

  function maandLabel(mk) {
    var p = String(mk).split('-');

    return (
      MND_KORT[
        parseInt(p[1], 10) - 1
      ] +
      ' ' +
      p[0]
    );
  }

  function maandNaam(mk) {
    return MND_LANG[
      parseInt(
        String(mk).split('-')[1],
        10
      ) - 1
    ];
  }

  function dagenInMaand(mk) {
    var p = String(mk).split('-');

    return new Date(
      parseInt(p[0], 10),
      parseInt(p[1], 10),
      0
    ).getDate();
  }

  var dagenLopend = null;

  function haalLopendeDagen() {
    if (dagenLopend !== null) {
      return Promise.resolve(
        dagenLopend
      );
    }

    var mk =
      iso(new Date()).slice(0, 7);

    var u =
      new URL(
        location.origin +
        '/customer/' +
        KLANT +
        '/results-v2-api/'
      );

    u.searchParams.set(
      'interval',
      'month'
    );

    u.searchParams.set(
      'period',
      mk
    );

    u.searchParams.set(
      'include_vat',
      '1'
    );

    u.searchParams.set(
      'include_delivery_cost',
      '1'
    );

    return origFetch(
      u,
      {
        credentials: 'same-origin'
      }
    )

      .then(function (r) {
        return r.ok
          ? r.json()
          : null;
      })

      .then(function (j) {
        dagenLopend =
          (
            j &&
            Array.isArray(j.series)
          )
            ? j.series.length
            : 0;

        return dagenLopend;
      })

      .catch(function () {
        dagenLopend = 0;
        return 0;
      });
  }

  var cacheMaandDagen = {};

  function haalMaandDagen(mk) {
    if (cacheMaandDagen[mk]) {
      return Promise.resolve(
        cacheMaandDagen[mk]
      );
    }

    var u =
      new URL(
        location.origin +
        '/customer/' +
        KLANT +
        '/results-v2-api/'
      );

    u.searchParams.set(
      'interval',
      'month'
    );

    u.searchParams.set(
      'period',
      mk
    );

    u.searchParams.set(
      'include_vat',
      '1'
    );

    u.searchParams.set(
      'include_delivery_cost',
      '1'
    );

    return origFetch(
      u,
      {
        credentials: 'same-origin'
      }
    )

      .then(function (r) {
        return r.ok
          ? r.json()
          : null;
      })

      .then(function (j) {
        var pv =
          (j && j.pricing) || {};

        var rijen =
          (
            j &&
            Array.isArray(j.series)
          )
            ? j.series.map(
                function (s) {
                  return naarIncl(
                    s,
                    pv
                  );
                }
              )
            : [];

        cacheMaandDagen[mk] =
          rijen;

        return rijen;
      })

      .catch(function () {
        cacheMaandDagen[mk] = [];
        return [];
      });
  }

  function dagenVerstreken(mk) {
    var nu = new Date();

    var lopend =
      iso(nu).slice(0, 7);

    if (mk === lopend) {
      return dagenLopend !== null
        ? dagenLopend
        : nu.getDate();
    }

    if (mk > lopend) {
      return 0;
    }

    return dagenInMaand(mk);
  }

  // Kalenderdagen rekenen voorkomt afwijkingen bij zomer- en wintertijd.
  function beVoorschotValideer(rows) {
    if(!Array.isArray(rows))throw Error('Ongeldige voorschothistorie.');
    var gezien=new Set();
    return rows.map(function(r){
      var datum=String(r.datum||''),bedrag=Number(r.bedrag);
      if(!/^\d{4}-\d{2}-\d{2}$/.test(datum)||!Number.isFinite(Date.parse(datum))||new Date(datum).toISOString().slice(0,10)!==datum||gezien.has(datum)||!Number.isFinite(bedrag)||bedrag<0||r.bedrag==='')throw Error('Vul een geldige, unieke ingangsdatum en een bedrag vanaf € 0 in.');
      gezien.add(datum);return {datum:datum,bedrag:bedrag};
    }).sort(function(a,b){return a.datum.localeCompare(b.datum);});
  }
  function beVoorschotSom(van,aantal) {
    var totaal=0,start=Date.parse(van),historie=cfg.voorschotHistorie||[];
    for(var i=0;i<Math.max(0,aantal);i++){
      var dag=new Date(start+i*86400000).toISOString().slice(0,10),bedrag=cfg.voorschot;
      historie.forEach(function(r){if(r.datum<=dag)bedrag=r.bedrag;});
      totaal+=bedrag/dagenInMaand(dag.slice(0,7));
    }
    return totaal;
  }
  function voorschotVoor(mk,dagen,geschat) {
    if(!/^\d{4}-\d{2}$/.test(String(mk)))return cfg.voorschot;
    var totaal=dagenInMaand(mk);
    return beVoorschotSom(mk+'-01',geschat?totaal:Math.max(0,Math.min(totaal,Number(dagen)||0)));
  }
  function beVoorschotInstellingen(host) {
    host.innerHTML='<div style="font-weight:600;margin:12px 0 6px">Wijzigingen maandbedrag</div><div style="font-size:11px;margin-bottom:8px">Het basisbedrag geldt tot de eerste wijziging. Het nieuwe bedrag geldt vanaf de ingangsdatum, inclusief die dag, naar rato van kalenderdagen.</div><div class="be-vs-rijen"></div><button type="button" class="be-vs-toevoegen">+ Wijziging toevoegen</button>';
    var lijst=host.querySelector('.be-vs-rijen');
    var toevoegen=host.querySelector('.be-vs-toevoegen');
    toevoegen.style.cssText='border:1px solid '+D.paarsLicht+';border-radius:6px;padding:8px 12px;background:transparent;color:'+D.paars+';font:600 11px system-ui;cursor:pointer;margin:4px 0 8px';
    function rij(r){
      var el=document.createElement('div');el.style.cssText='display:flex;gap:6px;margin:6px 0;align-items:center';
      var datum=document.createElement('input'),bedrag=document.createElement('input'),weg=document.createElement('button');
      datum.type='date';datum.value=r.datum;datum.setAttribute('aria-label','Ingangsdatum voorschot');
      bedrag.type='number';bedrag.min='0';bedrag.step='.01';bedrag.value=r.bedrag;bedrag.setAttribute('aria-label','Nieuw maandbedrag');
      [datum,bedrag].forEach(function(i){i.style.cssText='min-width:0;width:44%;padding:7px;border:1px solid '+D.rand+';border-radius:6px';});
      weg.type='button';weg.style.cssText='border:1px solid '+D.rand+';border-radius:6px;background:transparent;color:'+D.paars+';padding:5px 9px;font:600 16px system-ui;cursor:pointer';weg.textContent='×';weg.setAttribute('aria-label','Wijziging verwijderen');weg.onclick=function(){el.remove();};
      el.append(datum,bedrag,weg);lijst.appendChild(el);
    }
    (cfg.voorschotHistorie||[]).forEach(rij);
    toevoegen.onclick=function(){rij({datum:iso(new Date()),bedrag:cfg.voorschot});};
  }

  function isLopendeMaand(mk) {
    return (
      mk ===
      iso(
        new Date()
      ).slice(0, 7)
    );
  }

  function naSaldering(mk) {
    return (
      parseInt(
        String(mk).slice(0, 4),
        10
      ) >= 2027
    );
  }

  // De aansluitdatum blijft vast; het zichtbare contractjaar schuift op de jaardag door.
  function huidigContract(nu) {
    nu = nu || new Date();
    var index = Math.max(0, nu.getFullYear() - cfg.start.getFullYear());
    var begin = datumPlusMaanden(cfg.start, index * 12);
    if (index > 0 && datumDagNummer(nu) < datumDagNummer(begin)) {
      index--;
      begin = datumPlusMaanden(cfg.start, index * 12);
    }
    var grens = datumPlusMaanden(cfg.start, (index + 1) * 12);
    var einde = new Date(grens); einde.setDate(einde.getDate() - 1);
    var delen = [], cursor = new Date(begin.getFullYear(), begin.getMonth(), 1);
    while (cursor < grens) {
      var volgend = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1);
      var van = new Date(Math.max(+cursor, +begin));
      var tot = new Date(Math.min(+volgend, +grens));
      var laatste = new Date(tot); laatste.setDate(laatste.getDate() - 1);
      delen.push({ key: iso(cursor).slice(0,7), van: iso(van), tot: iso(laatste),
        dagen: datumDagNummer(tot) - datumDagNummer(van),
        eerste: delen.length === 0, laatste: +tot === +grens });
      cursor = volgend;
    }
    var termijnen = [];
    for (var i = 0; i < 12; i++) termijnen.push(iso(datumPlusMaanden(begin, i)));
    return {index:index, begin:begin, grens:grens, einde:einde, delen:delen, termijnen:termijnen};
  }

  function contractVoorschot(deel, dagen) {
    return beVoorschotSom(deel.van, Math.max(0, Math.min(deel.dagen, dagen)));
  }

  function contractDatumTekst(key) { return key.split('-').reverse().join('-'); }

  function contractSomDagen(dagen, deel) {
    var velden = ['imp','exp','inkoop','verkoop','laden','ontladen','pv','afrrImp','afrrExp','afrrVergoeding','dealsAantal'];
    var op = {};
    dagen.forEach(function(r) {
      if (r && r.bronAanwezig !== false && r.key >= deel.van && r.key <= deel.tot) op[r.key] = r;
    });
    var keys = Object.keys(op).sort(), totaal = {key:deel.key, leeg:!keys.length, contractDeel:deel, contractDagKeys:keys};
    velden.forEach(function(k){totaal[k]=keys.reduce(function(n,key){return n+getal(op[key][k]);},0);});
    totaal.contractBekendeDagen = keys.length;
    return totaal;
  }

  function contractPrognose(r, historie, ank, aantalVolledig) {
    var deel = r.contractDeel, fractie = deel.dagen / dagenInMaand(r.key);
    var basis = prognoseBedrag(r.key, ank) * fractie;
    var oud = historie.find(function(h){return h.key===String(+r.key.slice(0,4)-1)+r.key.slice(4) && !h.leeg && h.bronAanwezig!==false;});
    if (!oud) return basis;
    // Hergebruik kWh en kale opbrengsten; pas de huidige rekenregels toe op het doeljaar.
    var vergelijkbaar = Object.assign({}, oud, {key:r.key});
    var vorig = bereken(vergelijkbaar, naSaldering(r.key) ? oud.exp : Math.max(0,oud.exp-oud.imp), 0).stroom * fractie;
    return aantalVolledig >= 2 ? vorig * 0.60 + basis * 0.40 : vorig;
  }

  function contractMaanden() { return huidigContract().delen.map(function(d){return d.key;}); }

  function el(
    tag,
    css,
    html
  ) {
    var e =
      document.createElement(tag);

    if (css) {
      e.style.cssText = css;
    }

    if (html !== undefined) {
      e.innerHTML = html;
    }

    return e;
  }

  function kaart(
    id,
    titel,
    rechts
  ) {
    var c =
      el(
        'div',
        'background:#fff;' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:10px;' +
        'padding:15px 18px 17px;' +
        'margin-top:14px;' +
        'box-shadow:0 1px 4px rgba(107,63,160,.06);'
      );

    c.id = id;

    if (titel) {
      c.appendChild(
        el(
          'div',
          'display:flex;' +
          'align-items:center;' +
          'justify-content:space-between;' +
          'gap:12px;' +
          'margin-bottom:13px;',
          '<span style="' +
          'font-size:10px;' +
          'font-weight:700;' +
          'letter-spacing:.08em;' +
          'text-transform:uppercase;' +
          'color:' +
          D.label +
          ';">' +
          titel +
          '</span>' +
          (rechts || '')
        )
      );
    }

    return c;
  }

  function sectie(
    id,
    titel,
    rechts
  ) {
    var c =
      el(
        'div',
        'margin-top:20px;' +
        'padding-top:17px;' +
        'border-top:1px solid ' +
        D.rand +
        ';'
      );

    c.id = id;

    if (titel) {
      c.appendChild(
        el(
          'div',
          'display:flex;' +
          'align-items:center;' +
          'justify-content:space-between;' +
          'gap:12px;' +
          'margin-bottom:13px;',
          '<span style="' +
          'font-size:10px;' +
          'font-weight:700;' +
          'letter-spacing:.08em;' +
          'text-transform:uppercase;' +
          'color:' +
          D.label +
          ';">' +
          titel +
          '</span>' +
          (rechts || '')
        )
      );
    }

    return c;
  }

  var klantMatch =
    location.pathname.match(
      /^\/customer\/([^/]+)(?:\/|$)/
    );

  var KLANT =
    klantMatch
      ? klantMatch[1]
      : localStorage.getItem(
          'be_laatste_installatie'
        );

  function geldigeKlant(id) {
    return (
      !!id &&
      !/^(?:account|results|current-history|current-prices|undefined|null)$/i.test(
        id
      )
    );
  }

  function onthoudKlant(id) {
    if (!geldigeKlant(id)) {
      return false;
    }

    var gewijzigd =
      KLANT !== id;

    KLANT = id;

    try {
      localStorage.setItem(
        'be_laatste_installatie',
        id
      );
    } catch (e) {}

    return gewijzigd;
  }

  function klantUitUrl(waarde) {
    try {
      var u =
        new URL(
          waarde,
          location.origin
        );

      var installatie =
        u.searchParams.get(
          'installation'
        );

      if (
        geldigeKlant(
          installatie
        )
      ) {
        return installatie;
      }

      var m =
        u.pathname.match(
          /^\/customer\/([^/]+)\/(?:results|account)(?:\/|$)/
        );

      return (
        m &&
        geldigeKlant(m[1])
      )
        ? m[1]
        : null;

    } catch (e) {
      return null;
    }
  }

  function verversKlantUitPad() {
    var m = location.pathname.match(
      /^\/customer\/([^/]+)(?:\/|$)/
    );

    if (
      m &&
      geldigeKlant(m[1])
    ) {
      onthoudKlant(m[1]);

      return KLANT;
    }

    /*
     * Op de nieuwe Actueel-route staat het installatie-id niet meer in
     * location.pathname. De eigen history-aanvraag van het dashboard bevat
     * het id nog wel. Resource Timing werkt ook in Safari voor deze
     * same-origin-aanvraag en verandert niets aan de netwerklaag van Balans.
     */
    try {
      var bronnen =
        performance.getEntriesByType(
          'resource'
        );

      for (
        var i = bronnen.length - 1;
        i >= 0;
        i--
      ) {
        if (
          String(bronnen[i].name).indexOf(
            '/customer/current-history/api/'
          ) === -1
        ) {
          continue;
        }

        var uitBron =
          klantUitUrl(
            bronnen[i].name
          );

        if (uitBron) {
          onthoudKlant(
            uitBron
          );

          return KLANT;
        }
      }
    } catch (e) {}

    /*
     * Vang ook de situatie af waarin Safari Resource Timing opschoont:
     * de navigatielinks naar Resultaten/Account dragen hetzelfde id.
     */
    var links =
      document.querySelectorAll(
        'a[href*="/customer/"]'
      );

    for (
      var j = 0;
      j < links.length;
      j++
    ) {
      var uitLink =
        klantUitUrl(
          links[j].href
        );

      if (uitLink) {
        onthoudKlant(
          uitLink
        );

        break;
      }
    }

    return KLANT;
  }

  window.BEInstallation = {
    resolve: function () {
      var id = verversKlantUitPad();
      return geldigeKlant(id) ? id : null;
    },
    wait: async function () {
      for (var attempt = 0; attempt < 120; attempt++) {
        var id = this.resolve();
        if (id) return id;
        await new Promise(function (done) { setTimeout(done, 500); });
      }
      return null;
    }
  };

  var beNativeFetch = window.fetch.bind(window);
  var beApiPending = new Map(), beApiCache = new Map();
  function beApiFetch(input, init) {
    var u=new URL(typeof input==='string'?input:input.url||input.href,location.origin);
    var method=(init&&init.method)||input.method||'GET';
    if(method.toUpperCase()!=='GET'||u.origin!==location.origin||!u.pathname.includes('api'))return beNativeFetch(input,init);
    u.searchParams.sort();var key=u.href;
    var ttl=u.pathname.includes('current-prices')?15000:u.pathname.includes('current-history')?30000:60000;
    var now=Date.now(),cached=beApiCache.get(key);
    var diskKey='be_api_cache:'+key;
    if(!cached&&u.pathname.includes('results')){
      try{var saved=JSON.parse(sessionStorage.getItem(diskKey)||'null');
        if(saved&&now-saved.time<ttl)cached={time:saved.time,response:new Response(saved.body,{status:200,headers:{'Content-Type':'application/json'}})};
      }catch(e){}
    }
    if(cached&&now-cached.time<ttl)return Promise.resolve(cached.response.clone());
    if(beApiPending.has(key))return beApiPending.get(key).then(function(r){return r.clone();});
    var until=Number(localStorage.getItem('be_api_retry_until')||0);
    if(now<until)return Promise.resolve(new Response('',{status:429,headers:{'Retry-After':String(Math.ceil((until-now)/1000))}}));
    var request=beNativeFetch(input,init).then(function(r){return r.ok&&u.pathname==='/customer/current-prices/api/'?beOnbalansResponse(r):r;}).then(function(r){
      if(r.status===429){
        var retry=r.headers.get('Retry-After'),seconds=Number(retry);
        var delay=retry?(Number.isFinite(seconds)?seconds*1000:Date.parse(retry)-Date.now()):60000;
        if(!Number.isFinite(delay)||delay<1000)delay=60000;
        localStorage.setItem('be_api_retry_until',String(Date.now()+delay));
      }
      if(r.ok&&u.pathname.includes('results'))r.clone().text().then(function(body){
      if(body.length>300000)return;
      try{sessionStorage.setItem(diskKey,JSON.stringify({time:Date.now(),body:body}));}catch(e){}
    }).catch(function(){});
    if(r.ok){beApiCache.set(key,{time:Date.now(),response:r.clone()});if(beApiCache.size>40)beApiCache.delete(beApiCache.keys().next().value);}
      return r;
    }).finally(function(){beApiPending.delete(key);});
    beApiPending.set(key,request);
    return request.then(function(r){return r.clone();});
  }
  var origFetch = beApiFetch;
  /* 6.8 — Onbalansprijzen zonder Balans (paginadeel).
   * Sinds 17-11-2026 levert current-prices/api alleen nog de prijs van kwartieren
   * waarin de accu iets deed. Ontbrekende onbalans_import/onbalans_export worden
   * aangevuld uit een lokale cache (localStorage) die het userscriptdeel vult:
   *  - Tenergy: minuutwaarden, ~1,5 dag terug. Lopend kwartier = dunne live-lijn;
   *    de laatste minuut van een afgesloten kwartier is ~1-2 min na afloop bekend
   *    en kwam op 17-11 in 7 van 8 kwartieren exact overeen met Balans.
   *  Indicatief: TenneT publiceert de officiële verrekenprijs pas >1 uur later en
   *  wijkt bij regeltoestand 2 vaak af (vergelijking 17-11: 5 van 10 kwartieren exact).
   * Rangorde: prijs van Balans zelf > Tenergy afgesloten > Tenergy lopend.
   * Gevulde kwartieren dragen beOnbalansBron. Bij een nieuw bezoek wordt direct uit
   * de cache aangevuld, ook in het lokale archief. */
  var BETenergy = (function () {
    var OPSLAG = 'be_onbalans_tenergy_v1', STATUS = 'be_onbalans_tenergy_status_v1';
    var KWARTIER = 900000;
    var kwartieren = laad();
    function laad() {
      try {
        var o = JSON.parse(localStorage.getItem(OPSLAG) || '{}');
        return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
      } catch (e) { return {}; }
    }
    document.addEventListener('be-onbalans-tenergy-update', function () { kwartieren = laad(); });
    function label(t) { return t.bron === 'tennet' ? 'tennet' : t.klaar ? 'tenergy' : 'tenergy-voorlopig'; }
    function vulRij(p, nu) {
      if (!p || !Number.isFinite(p.start) || p.start > nu) return;
      var v = p.values && typeof p.values === 'object' ? p.values : (p.values = {});
      var t = kwartieren[p.start], bron = {};
      // Eerder aangevulde waarden kunnen zonder kenmerk in het archief staan; herken ze aan de cache.
      function vanOns(waarde, sleutel) {
        return !!t && (waarde === t[sleutel] || (t.tg && waarde === t.tg[sleutel]));
      }
      var eigenI = Number.isFinite(v.onbalans_import) && !(p.beOnbalansBron && p.beOnbalansBron.import) && !vanOns(v.onbalans_import, 'ki');
      var eigenE = Number.isFinite(v.onbalans_export) && !(p.beOnbalansBron && p.beOnbalansBron.export) && !vanOns(v.onbalans_export, 'ke');
      if (t) {
        if (!eigenI && Number.isFinite(t.ki)) { v.onbalans_import = t.ki; bron.import = label(t); }
        if (!eigenE && Number.isFinite(t.ke)) { v.onbalans_export = t.ke; bron.export = label(t); }
        if (bron.import || bron.export) p.beOnbalansBron = bron;
      }
    }
    function vulAan(j, nu) {
      if (!j || !Array.isArray(j.prices)) return j;
      nu = nu || Date.now();
      var gezien = new Set();
      j.prices.forEach(function (p) { if (p && Number.isFinite(p.start)) gezien.add(p.start); vulRij(p, nu); });
      // Lopend kwartier: Balans levert die rij niet; voorlopig toevoegen voor de live-lijn.
      var lopend = nu - (nu % KWARTIER), t = kwartieren[lopend];
      if (t && !gezien.has(lopend) && Number.isFinite(t.ki) && Number.isFinite(t.ke)) {
        j.prices.push({ start: lopend, end: lopend + KWARTIER, provisional: true, fresh: true, updatedAt: null,
          values: { onbalans_import: t.ki, onbalans_export: t.ke },
          beOnbalansBron: { import: label(t), export: label(t) } });
      }
      return j;
    }
    // Lokaal archief (IndexedDB 'prijzen'): direct aanvullen bij lezen.
    function vulAanRijen(rows) {
      if (!Array.isArray(rows)) return rows;
      var nu = Date.now();
      rows.forEach(function (p) { vulRij(p, nu); });
      return rows;
    }
    function status() {
      var keys = Object.keys(kwartieren).map(Number).sort(function (a, b) { return a - b; }), st = {};
      try { st = JSON.parse(localStorage.getItem(STATUS) || '{}') || {}; } catch (e) {}
      var tennet = keys.filter(function (k) { return kwartieren[k].bron === 'tennet'; }).length;
      return { kwartieren: keys.length, tennet: tennet, tenergy: keys.length - tennet,
        eerste: keys[0] || null, laatste: keys[keys.length - 1] || null,
        laatsteTenergy: st.laatsteHaal || 0, fout: st.fout || '' };
    }
    return { vulAan: vulAan, vulAanRijen: vulAanRijen, status: status, kwartier: function (q) { return kwartieren[q] || null; } };
  })();
  window.BETenergy = { status: BETenergy.status, kwartier: BETenergy.kwartier };

  /* 6.8.3 — Dynamisch tarief (EPEX day-ahead) aanvullen.
   * Sinds 20-11-2026 levert current-prices voor ingeplande importkwartieren
   * day_ahead_import: null. Alleen dán vullen we de openbare EPEX-prijs (Nord Pool,
   * NL, €/MWh ÷ 1000, kaal) in die de plugin al ophaalt. Een waarde van Balans zelf
   * wordt nooit overschreven. Gevulde kwartieren dragen beDayAheadBron = 'epex' en
   * krijgen in de labels een stekker (🔌). Geen onbalans- of aFRR-terugval. */
  var BEDayAhead = (function () {
    var HIST = 'be_epex_kwartier_v1', BRONNEN = ['be_epex_nordpool_prices_v1', 'be_epex_nordpool_forecast_prices_v1'];
    var BEWAAR = 14 * 86400000;
    function lees(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
    function prijzen() {
      var h = lees(HIST); h = h && typeof h === 'object' && !Array.isArray(h) ? h : {};
      var nieuw = false;
      BRONNEN.forEach(function (k) {
        var c = lees(k), e = c && c.body && c.body.multiAreaEntries;
        (Array.isArray(e) ? e : []).forEach(function (x) {
          var t = Date.parse(x && x.deliveryStart), eind = Date.parse(x && x.deliveryEnd), p = x && x.entryPerArea && x.entryPerArea.NL;
          if (!Number.isFinite(t) || !Number.isFinite(p) || eind - t !== 900000) return;
          var v = Math.round(p * 100) / 100000;
          if (h[t] !== v) { h[t] = v; nieuw = true; }
        });
      });
      if (nieuw) {
        var grens = Date.now() - BEWAAR;
        Object.keys(h).forEach(function (t) { if (+t < grens) delete h[t]; });
        try { localStorage.setItem(HIST, JSON.stringify(h)); } catch (e) {}
      }
      return h;
    }
    // Ook bij dynamisch + aFRR (day_ahead_afrr_import leeg) rekenen we met de EPEX-prijs:
    // voor het ingeplande EPEX-volume is dat de dynamische prijs (keuze Luc, 21-11-2026).
    var SLEUTELS = ['day_ahead_import', 'day_ahead_afrr_import'];
    function vulRij(p, gepland, h) {
      if (!p || !Number.isFinite(p.start) || !gepland) return;
      var v = p.values && typeof p.values === 'object' ? p.values : (p.values = {});
      var epex = h[p.start], ons = p.beDayAheadBron === 'epex', gevuld = false, eigen = false;
      SLEUTELS.forEach(function (k) {
        var aanwezig = Object.prototype.hasOwnProperty.call(v, k);
        if (Number.isFinite(v[k])) { if (!ons || v[k] !== epex) eigen = true; else gevuld = true; return; }
        if (!Number.isFinite(epex) || (!aanwezig && k !== 'day_ahead_import')) return;
        v[k] = epex; gevuld = true;
      });
      // Een waarde die afwijkt van onze EPEX-prijs komt van Balans zelf: geen stekker.
      if (gevuld && !eigen) p.beDayAheadBron = 'epex'; else if (eigen) delete p.beDayAheadBron;
    }
    function vulAan(j) {
      if (!j || !Array.isArray(j.prices)) return j;
      var plan = new Set((Array.isArray(j.dayAheadPlans) ? j.dayAheadPlans : []).filter(function (x) { return x && x.direction === 'import'; }).map(function (x) { return x.start; }));
      if (!plan.size) return j;
      var h = prijzen();
      j.prices.forEach(function (p) { vulRij(p, p && plan.has(p.start), h); });
      return j;
    }
    function vulAanRijen(rows) {
      if (!Array.isArray(rows)) return rows;
      var h = prijzen();
      rows.forEach(function (p) { vulRij(p, p && p.dayAheadState === 'planned', h); });
      return rows;
    }
    return { vulAan: vulAan, vulAanRijen: vulAanRijen, prijzen: prijzen };
  })();
  window.BEDayAhead = { prijzen: BEDayAhead.prijzen };

  function beOnbalansResponse(r) {
    return r.clone().json().then(function (j) {
      return new Response(JSON.stringify(BEDayAhead.vulAan(BETenergy.vulAan(j))), { status: r.status, statusText: r.statusText, headers: r.headers });
    }).catch(function () { return r; });
  }


  /*
   * ============================================================
   * ACTUEEL
   * ============================================================
   */

  var ACTUEEL_SALDEERT =
    true;

  var actueelAan =
    localStorage.getItem(
      LS.actueelAllin
    ) !== 'uit';

  var actueelRijen = [];
  var actueelDagPunten = [];
  var actueelDagBerekening = null;
  var actueelLaatstGeschreven = null;
  var actueelGestart = false;
  var actueelWasPagina = false;
  var actueelLaatsteKlant = null;
  var actueelHaalTimer = null;
  var actueelOnderhoudTimer = null;
  var actueelVoetnootTimer = null;

  function isActueelPagina() {
    return (
      /^\/customer\/?$/.test(
        location.pathname
      ) ||
      /^\/customer\/(?!account(?:\/|$)|results(?:\/|$))[^/]+\/?$/.test(
        location.pathname
      )
    );
  }

  function actueelEuro(v) {
    return (
      '\u20ac ' +
      v
        .toFixed(3)
        .replace(
          '.',
          ','
        )
    );
  }

  function actueelAllin(
    kaal,
    isExport
  ) {
    return isExport
      ? (
          kaal * BTW -
          OPSLAG +
          (
            ACTUEEL_SALDEERT
              ? EB
              : 0
          )
        )
      : (
          kaal * BTW +
          OPSLAG +
          EB
        );
  }

  var ACTUEEL_BRIDGE_CODE =
    "(function startBEActueel(){\n" +
    " if(typeof Chart==='undefined'||!Chart.getChart||!Chart.getChart('battery-chart')){setTimeout(startBEActueel,150);return;}\n" +
    "\n" +
    " if(window.__beActueelAllinBridge)return;\n" +
    " window.__beActueelAllinBridge=true;\n" +
    " function beChartRefresh(){\n" +
    "  if(window.BEChartRefresh)return window.BEChartRefresh;\n" +
    "  var pending=new Map(),queued=false;\n" +
    "  function schedule(){\n" +
    "   if(queued||document.hidden||!pending.size)return;\n" +
    "   queued=true;\n" +
    "   (typeof requestAnimationFrame==='function'?requestAnimationFrame:function(f){setTimeout(f,0);})(flush);\n" +
    "  }\n" +
    "  function flush(){\n" +
    "   queued=false;if(document.hidden)return;\n" +
    "   var work=Array.from(pending);pending.clear();\n" +
    "   work.forEach(function(pair){\n" +
    "    var c=pair[0],job=pair[1];if(!c.canvas||c.canvas.isConnected===false)return;\n" +
    "    try{\n" +
    "     var update=job.update;\n" +
    "     job.prepare.forEach(function(prepare){if(prepare())update=true;});\n" +
    "     if(update&&typeof c.update==='function')c.update('none');\n" +
    "     else if(job.draw&&typeof c.draw==='function')c.draw();\n" +
    "    }catch(e){console.error('[BE grafiekupdate]',e);}\n" +
    "   });\n" +
    "  }\n" +
    "  var api={request:function(c,mode,prepare){\n" +
    "   if(!c)return;\n" +
    "   var job=pending.get(c);if(!job){job={update:false,draw:false,prepare:new Set()};pending.set(c,job);}\n" +
    "   if(mode==='update')job.update=true;else if(mode==='draw')job.draw=true;\n" +
    "   if(prepare)job.prepare.add(prepare);\n" +
    "   schedule();\n" +
    "  }};\n" +
    "  document.addEventListener('visibilitychange',schedule);\n" +
    "  window.BEChartRefresh=api;return api;\n" +
    " }\n" +
    " var CANVAS='battery-chart';\n" +
    " var st={rijen:[],aan:true,eb:0.11085,btw:1.21,opslag:0.02,saldeert:true};\n" +
    " var ctxRef=null;\n" +
    " function chart(){return (typeof Chart!=='undefined'&&Chart.getChart)?Chart.getChart(CANVAS):null;}\n" +
    " function euro(v){return '\\u20ac '+v.toFixed(3).replace('.',',');}\n" +
    " function allin(kaal,isExport){return isExport?kaal*st.btw-st.opslag+(st.saldeert?st.eb:0):kaal*st.btw+st.opslag+st.eb;}\n" +
    " function prijsRij(c,tekst,x,y){\n" +
    "  var t;\n" +
    "  if(/^\\s*(?:Nu|ISP)\\b/i.test(tekst))t=Date.now();\n" +
    "  else{\n" +
    "   var pixel=x,transform=c.ctx.getTransform?.(),ratio=c.currentDevicePixelRatio||1;\n" +
    "   if(transform&&[transform.a,transform.c,transform.e].every(Number.isFinite))pixel=(transform.a*x+transform.c*y+transform.e)/ratio;\n" +
    "   t=c.scales?.x?.getValueForPixel?.(pixel);\n" +
    "  }\n" +
    "  if(!Number.isFinite(t))return null;\n" +
    "  return (Array.isArray(st.rijen)?st.rijen:[]).find(function(r){return r.start<=t&&t<r.end&&!r.carried&&(!Number.isFinite(r.sourceStart)||r.sourceStart===r.start);})||null;\n" +
    " }\n" +
    " function prijsLabel(tekst,rij){\n" +
    "  var bedrag=/(?:[+\\-−]\\s*)?€\\s*(?:[+\\-−]\\s*)?\\d+(?:[.,]\\d+)?/g;\n" +
    "  return tekst.split(/(?=\\b(?:Import|Inkoop|Afname|Export|Invoeding|Teruglevering|Teruglever|Injectie)\\b)/i).map(function(deel){\n" +
    "   if(!deel.match(bedrag))return deel;\n" +
    "   var richting=deel.match(/^\\s*(Import|Inkoop|Afname|Export|Invoeding|Teruglevering|Teruglever|Injectie)\\b/i);\n" +
    "   var uitvoer=richting&&/^(Export|Invoeding|Teruglevering|Teruglever|Injectie)$/i.test(richting[1]);\n" +
    "   var kaal=richting&&rij?rij[uitvoer?'ke':'ki']:null,bekend=Number.isFinite(kaal);\n" +
    "   var nieuw=deel.replace(bedrag,bekend?euro(allin(kaal,!!uitvoer)):'prijs volgt (all-in)');\n" +
    "   return bekend?nieuw:nieuw.replace(/\\s*\\/\\s*kWh\\b/gi,'');\n" +
    "  }).join('');\n" +
    " }\n" +
    " function stekker(ctx,tekst,x,y){\n" +
    "  // Paars rondje met stekker vóór het label: deze prijs is door de plugin ingevuld (EPEX).\n" +
    "  var w=ctx.measureText(tekst).width,al=ctx.textAlign,lx=al==='center'?x-w/2:(al==='right'||al==='end')?x-w:x;\n" +
    "  var fs=parseFloat((String(ctx.font).match(/(\\d+(?:\\.\\d+)?)px/)||[])[1])||11,h=Math.round(fs*1.25),bw=h,bx=lx-5-bw;\n" +
    "  var bl=ctx.textBaseline,cy=bl==='top'||bl==='hanging'?y+fs/2:bl==='middle'?y:y-fs*0.35;\n" +
    "  var m=ctx.getTransform?ctx.getTransform():null;\n" +
    "  // Liggende labels staan vaak tegen elkaar: zet de stekker dan onder het begin van het label.\n" +
    "  if(m&&Math.abs(m.b)<Math.abs(m.a)){bx=lx;cy+=h+1;}\n" +
    "  ctx.save();ctx.beginPath();\n" +
    "  if(ctx.roundRect)ctx.roundRect(bx,cy-h/2,bw,h,h/2);else ctx.rect(bx,cy-h/2,bw,h);\n" +
    "  ctx.fillStyle='#6B3FA0';ctx.fill();\n" +
    "  ctx.translate(bx+bw/2,cy);ctx.rotate(Math.PI/2);\n" +
    "  var s=h/14;ctx.fillStyle='#fff';ctx.strokeStyle='#fff';ctx.lineWidth=Math.max(1,1.4*s);ctx.lineCap='round';\n" +
    "  ctx.fillRect(-3.2*s,-1.6*s,6.4*s,4.2*s);\n" +
    "  ctx.fillRect(-2.4*s,-4.6*s,1.4*s,3.2*s);ctx.fillRect(1*s,-4.6*s,1.4*s,3.2*s);\n" +
    "  ctx.beginPath();ctx.moveTo(0,2.6*s);ctx.lineTo(0,5.2*s);ctx.stroke();\n" +
    "  ctx.restore();\n" +
    " }\n" +
    " function wikkel(){\n" +
    "  var c=chart(); if(!c||!c.ctx)return;\n" +
    "  if(ctxRef===c.ctx&&c.ctx.__beAllinFillText)return;\n" +
    "  ctxRef=c.ctx;\n" +
    "  var basisFill=(c.ctx.__beAllinOrigFill||c.ctx.fillText).bind(c.ctx);\n" +
    "  c.ctx.__beAllinOrigFill=basisFill;\n" +
    "  c.ctx.fillText=function(tekst,x,y,mw){\n" +
    "   var markeer=false;\n" +
    "   try{\n" +
    "    if(st.aan&&typeof tekst==='string'&&tekst.indexOf('\\u20ac')!==-1&&/(?:\\u2248|Import|Inkoop|Afname|Export|Invoeding|Teruglever|Injectie|ISP|Nu)/i.test(tekst)){\n" +
    "     var rij=prijsRij(c,tekst,x,y);tekst=prijsLabel(tekst,rij);\n" +
    "     if(rij&&rij.epexInjectie&&/\\b(?:Import|Inkoop|Afname)\\b/i.test(tekst))markeer=true;\n" +
    "    }\n" +
    "   }catch(e){tekst=prijsLabel(tekst,null);}\n" +
    "   // 6.8.3.1: Balans tekent na laden/zoomen eerst 'Import —' tot zijn volgende ronde (~15-20 s).\n" +
    "   // Hebben wij de prijs al (bijv. EPEX-aanvulling), toon die dan meteen.\n" +
    "   try{\n" +
    "    if(st.aan&&typeof tekst==='string'&&/^\\s*Import\\s*[\\u2014\\u2013-]\\s*$/.test(tekst)){\n" +
    "     var leeg=prijsRij(c,tekst,x,y);\n" +
    "     if(leeg&&Number.isFinite(leeg.ki)){tekst='Import '+euro(allin(leeg.ki,false));if(leeg.epexInjectie)markeer=true;}\n" +
    "    }\n" +
    "   }catch(e){}\n" +
    "   var uit=basisFill(tekst,x,y,mw);\n" +
    "   if(markeer)try{stekker(c.ctx,tekst,x,y);}catch(e){}\n" +
    "   return uit;\n" +
    "  };\n" +
    "  c.ctx.__beAllinFillText=true;\n" +
    " }\n" +
    " function verver(){var c=chart();if(c)beChartRefresh().request(c,'draw');}\n" +
    " document.addEventListener('be-actueel-allin-update',function(){\n" +
    "  var n=document.getElementById('be-actueel-allin-data');if(!n)return;\n" +
    "  try{st=Object.assign(st,JSON.parse(n.textContent||'{}'));wikkel();verver();}\n" +
    "  catch(e){console.error('[BE Actueel all-in bridge]',e);}\n" +
    " });\n" +
    " // 6.8.3.1: labelvertaling (all-in + stekker) meteen bij de eerste tekening installeren,\n" +
    " // niet pas bij de volgende gegevensronde (~15-20 s) als de grafiek er bij de eerste nog niet was.\n" +
    " Chart.register({id:'beAllinLabelWrap',beforeDraw:function(c){if(c.canvas&&c.canvas.id===CANVAS&&!(c.ctx&&c.ctx.__beAllinFillText))wikkel();}});\n" +
    " var gridSwatches=new WeakMap(),tooltipSwatches=new WeakMap();\n" +
    " function restoreGridSwatch(tip){\n" +
    "  var saved=tip&&tooltipSwatches.get(tip);if(!saved)return;\n" +
    "  if(tip.labelColors===saved.themed)tip.labelColors=saved.source;\n" +
    "  tooltipSwatches.delete(tip);\n" +
    " }\n" +
    " Chart.register({id:'beGrafietGridSwatch',\n" +
    "  beforeDraw:function(c){if(c.canvas?.id===CANVAS)restoreGridSwatch(c.tooltip);},\n" +
    "  beforeTooltipDraw:function(c,args){\n" +
    "   if(c.canvas?.id!==CANVAS)return;\n" +
    "   var tip=args.tooltip,html=document.documentElement;\n" +
    "   if(html.getAttribute('data-be-dark')!=='aan'||html.getAttribute('data-be-dark-style')!=='grafiet'||\n" +
    "      !Array.isArray(tip?.labelColors)||!Array.isArray(tip.dataPoints)||!c.ctx?.createLinearGradient)return;\n" +
    "   var source=tip.labelColors,themed=source.slice(),changed=false;\n" +
    "   tip.dataPoints.forEach(function(item,i){\n" +
    "    var label=item.dataset?.label??c.data.datasets[item.datasetIndex]?.label;\n" +
    "    if(!source[i]||!/^\\s*Netaansluiting\\b/i.test(label||''))return;\n" +
    "    var white=gridSwatches.get(c.ctx);\n" +
    "    if(!white){\n" +
    "     // A solid gradient stays a foreground swatch through the canvas theme's\n" +
    "     // background recolouring; a plain white fill would turn dark again.\n" +
    "     white=c.ctx.createLinearGradient(0,0,1,0);\n" +
    "     white.addColorStop(0,'#fff');white.addColorStop(1,'#fff');gridSwatches.set(c.ctx,white);\n" +
    "    }\n" +
    "    themed[i]=Object.assign({},source[i],{backgroundColor:white,borderColor:white});changed=true;\n" +
    "   });\n" +
    "   if(changed){tooltipSwatches.set(tip,{source:source,themed:themed});tip.labelColors=themed;}\n" +
    "  },\n" +
    "  afterTooltipDraw:function(c,args){restoreGridSwatch(args.tooltip);}\n" +
    " });\n" +
    " var TG_KW=900000;\n" +
    " var TG={rijen:[],aan:false,allin:true},tgRevision=0,tgSource=null;\n" +
    " var tgSettlement=new Map(),tgSettlementSource=null;\n" +
    " function tgLeesSettlement(){\n" +
    "  var raw=document.getElementById('be-onbalans-settlement-data')?.textContent||'[]';\n" +
    "  if(raw===tgSettlementSource)return;\n" +
    "  tgSettlementSource=raw;\n" +
    "  var rows=JSON.parse(raw);\n" +
    "  tgSettlement=new Map((Array.isArray(rows)?rows:[]).filter(function(r){\n" +
    "   return r&&Number.isFinite(r.start)&&r.start%TG_KW===0&&r.end===r.start+TG_KW&&r.end<=Date.now();\n" +
    "  }).map(function(r){return [r.start,r];}));\n" +
    "  tgRevision++;\n" +
    " }\n" +
    " function tgVergelijking(r,live){\n" +
    "  if(!r.onbalansVergelijking)return null;\n" +
    "  var prices=r.onbalansVergelijking,backfill=live?null:tgSettlement.get(r.start);\n" +
    "  var comparison={};\n" +
    "  ['ki','ke'].forEach(function(key){\n" +
    "   var primary=prices[key],backup=backfill?.[key],known=Number.isFinite(primary);\n" +
    "   var value=known?primary:backup;\n" +
    "   comparison[key]=Number.isFinite(value)?(TG.allin?allin(value,key==='ke'):value):null;\n" +
    "   comparison[key+'Bron']=known?'Balans':Number.isFinite(backup)?'TenneT':null;\n" +
    "  });\n" +
    "  return comparison;\n" +
    " }\n" +
    " function tgPrijs(v){\n" +
    "  return Number.isFinite(v)?v.toLocaleString('nl-NL',{minimumFractionDigits:3,maximumFractionDigits:3}):'—';\n" +
    " }\n" +
    " function tgLees(n){var raw=n.textContent||'{}';if(raw===tgSource)return;TG=Object.assign(TG,JSON.parse(raw));tgSource=raw;tgRevision++;}\n" +
    " function tgMarkt(q,kort){\n" +
    "  if(q.marktImport==='Prijsbron onbekend')return kort?'bron?':'prijsbron onbekend';\n" +
    "  if(q.gemengdImport||q.marktImport==='Dynamisch + aFRR')return kort?'dyn.+aFRR':'dynamisch + aFRR';\n" +
    "  if(q.marktImport==='Dynamisch')return kort?'dyn.':'dynamisch';\n" +
    "  if(q.dayAheadExport)return kort?'dyn. uit':'dynamische invoeding';\n" +
    "  if(q.wacht)return kort?'wacht':'geen prijs';\n" +
    "  return q.afrr?'aFRR':kort?'onb.':'onbalans';\n" +
    " }\n" +
    " function tgWaarde(value){return Number.isFinite(value)?value:null;}\n" +
    " function tgBedrag(v){return (v<0?'\\u2212 ':'+ ')+Math.abs(v).toLocaleString('nl-NL',{minimumFractionDigits:2,maximumFractionDigits:2});}\n" +
    " Chart.register({id:'beTariefBanden',beforeDatasetsDraw:function(c){\n" +
    "  if(!c.canvas||c.canvas.id!=='be-tarief-chart')return;\n" +
    "  var x=c.scales.x,a=c.chartArea,t=c.ctx; if(!x||!a)return;\n" +
    "  t.save(); t.beginPath(); t.rect(a.left,a.top,a.right-a.left,a.bottom-a.top); t.clip();\n" +
    "  t.fillStyle='#ffffff'; t.fillRect(a.left,a.top,a.right-a.left,a.bottom-a.top);\n" +
    "  t.textAlign='center';\n" +
    "  (c.$beKwartieren||[]).forEach(function(q){\n" +
    "   var p1=Math.max(a.left,x.getPixelForValue(q.start));\n" +
    "   var p2=Math.min(a.right,x.getPixelForValue(q.end));\n" +
    "   if(p2<=p1)return;\n" +
    "   if(Math.floor(q.start/TG_KW)%2){t.fillStyle='#f1f2f4';t.fillRect(p1,a.top,p2-p1,a.bottom-a.top);}\n" +
    "   var mid=(p1+p2)/2;\n" +
    "   var lab=q.carried?'laatst bekend':tgMarkt(q,false);\n" +
    "   var live=q.start<=Date.now()&&Date.now()<q.end;\n" +
    "   \n" +
    "   t.font='600 9.5px system-ui,-apple-system,sans-serif';\n" +
    "   t.fillStyle=q.wacht||q.marktImport==='Prijsbron onbekend'?'#8a8f98':(q.afrr||q.gemengdImport?'#6B3FA0':'#2f6f9f');\n" +
    "   var ruimte=p2-p1-4;\n" +
    "   if(ruimte>=t.measureText(lab).width){\n" +
    "    t.fillText(lab,mid,a.top+11);\n" +
    "   }else if(ruimte>=8){\n" +
    "    t.font='600 8px system-ui,-apple-system,sans-serif';\n" +
    "    var kort=q.carried?'bekend':tgMarkt(q,true);\n" +
    "    if(ruimte>=t.measureText(kort).width)t.fillText(kort,mid,a.top+11);\n" +
    "    else{\n" +
    "     t.save();t.translate(mid,a.top+4);t.rotate(-Math.PI/2);t.textAlign='right';\n" +
    "     t.fillText(lab,0,3);t.restore();\n" +
    "    }\n" +
    "   }\n" +
    "   if(ruimte<24)return;\n" +
    "   if(q.res==null||Math.abs(q.res)<0.005)return;\n" +
    "   var bt=tgBedrag(q.res)+(q.deel?'\\u2026':'');\n" +
    "   t.font='700 12px system-ui,-apple-system,sans-serif';\n" +
    "   if(p2-p1<t.measureText(bt).width+8)return;\n" +
    "   t.fillStyle=q.deel?'#8a8f98':(q.res<0?'#dc3545':'#198754');\n" +
    "   t.fillText(bt,mid,a.top+25);\n" +
    "  });\n" +
    "  t.restore();\n" +
    " }});\n" +
    " var tgChart=null;\n" +
    " function tgMaak(){\n" +
    "  if(tgChart&&tgChart.canvas&&tgChart.canvas.isConnected)return tgChart;\n" +
    "  var cv=document.getElementById('be-tarief-chart'); if(!cv)return null;\n" +
    "  var o=Chart.getChart(cv); if(o)o.destroy();\n" +
    "  tgChart=new Chart(cv,{type:'line',data:{datasets:[\n" +
    "   {label:'Afname',borderColor:'#dc3545',borderWidth:2,pointRadius:0,stepped:'before',fill:false,tension:0,segment:{borderDash:[],borderWidth:function(s){return s.p0.raw.beLive?1:2;},borderColor:function(s){return s.p0.raw.beLive?'#dc354588':'#dc3545';}}},\n" +
    "   {label:'Invoeding',borderColor:'#198754',borderWidth:2,pointRadius:0,stepped:'before',fill:false,tension:0,segment:{borderDash:[],borderWidth:function(s){return s.p0.raw.beLive?1:2;},borderColor:function(s){return s.p0.raw.beLive?'#19875488':'#198754';}}}]},\n" +
    "   options:{responsive:true,maintainAspectRatio:false,animation:false,locale:'nl-NL',\n" +
    "    layout:{padding:{top:6}},interaction:{mode:'index',intersect:false},\n" +
    "    scales:{y:{grid:{color:'rgba(0,0,0,.05)'},ticks:{font:{size:11},callback:function(v){return v.toLocaleString('nl-NL',{minimumFractionDigits:2,maximumFractionDigits:2});}}}},\n" +
    "    plugins:{legend:{display:true,position:'top',align:'end',labels:{boxWidth:12,boxHeight:2,padding:6,font:{size:11}}},\n" +
    "     tooltip:{callbacks:{title:function(i){\n" +
    "       if(!i.length)return '';\n" +
    "       var tm=i[0].parsed.x;\n" +
    "       var q=(i[0].chart.$beKwartieren||[]).find(function(r){return r.start<=tm&&tm<r.end;});\n" +
    "       return new Date(tm).toLocaleTimeString('nl-NL',{hour:'2-digit',minute:'2-digit'})+(q?' · afname '+(q.marktImport||'Prijsbron onbekend')+' / invoeding '+(q.marktExport||'Prijsbron onbekend'):'');\n" +
    "      },afterBody:function(i){\n" +
    "       if(!i.length)return [];\n" +
    "       var tm=i[0].parsed.x, q=(i[0].chart.$beKwartieren||[]).find(function(r){return r.start<=tm&&tm<r.end;});\n" +
    "       if(!q)return [];\n" +
    "       var out=[q.carried?'Laatst bekende prijs':Date.now()<q.end?'Lopend · voorlopig':q.provisional===false?'Definitief':'Voorlopig'];\n" +
    "       if(q.gemengdImport)out.push('Afname: ongewogen gemiddelde van dynamisch en aFRR; indicatieve API-prijs.');\n" +
    "       if(q.marktImport==='Prijsbron onbekend')out.push('Day-aheadplanning niet beschikbaar; afnameprijs onbekend.');\n" +
    "       if(q.vergelijking){\n" +
    "        if(Number.isFinite(q.pi))out.push('Toegepaste afname ('+(q.marktImport||'—')+'): '+tgPrijs(q.pi)+' / kWh');\n" +
    "        if(Number.isFinite(q.pe))out.push('Toegepaste invoeding ('+(q.marktExport||'—')+'): '+tgPrijs(q.pe)+' / kWh');\n" +
    "       }\n" +
    "       return out;\n" +
    "      },\n" +
    "      label:function(z){\n" +
    "       var tm=z.parsed.x,q=(z.chart.$beKwartieren||[]).find(function(r){return r.start<=tm&&tm<r.end;});\n" +
    "       var prijs=tgPrijs(z.parsed.y);\n" +
    "       if(q?.vergelijking&&z.datasetIndex<2){\n" +
    "        var invoeding=z.datasetIndex===1,bron=q.vergelijking[invoeding?'keBron':'kiBron'];\n" +
    "        return 'Onbalans '+(invoeding?'invoeding':'afname')+(bron?' · '+bron:'')+': '+prijs+' / kWh';\n" +
    "       }\n" +
    "       return z.dataset.label+': '+(z.datasetIndex===0&&q?.gemengdImport?'≈ ':'')+prijs+' / kWh';\n" +
    "      }}}}}});\n" +
    "  return tgChart;\n" +
    " }\n" +
    " function tgVul(){\n" +
    "  var rij=document.getElementById('be-tarief-row');if(rij)rij.hidden=!TG.aan;\n" +
    "  if(!TG.aan)return;\n" +
    "  var ch=tgMaak();if(ch)beChartRefresh().request(ch,'prepare',tgWerkBij);\n" +
    " }\n" +
    " function tgWerkBij(){\n" +
    "  var rij=document.getElementById('be-tarief-row');\n" +
    "  if(rij)rij.hidden=!TG.aan;\n" +
    "  if(!TG.aan)return;\n" +
    "  var ch=tgMaak(); if(!ch)return;\n" +
    "  var bv=chart(),nu=Date.now(),xs=bv&&bv.scales&&bv.scales.x;\n" +
    "  var srcRect=bv&&bv.canvas&&bv.canvas.getBoundingClientRect?bv.canvas.getBoundingClientRect():null;\n" +
    "  var dstRect=ch.canvas.getBoundingClientRect?ch.canvas.getBoundingClientRect():null;\n" +
    "  var active=(TG.rijen||[]).some(function(r){return r.start<=nu&&nu<r.end&&(!xs||r.end>=xs.min&&r.start<=xs.max);});\n" +
    "  var bx=bv&&bv.options.scales&&bv.options.scales.x;\n" +
    "  var ticks=xs&&xs.ticks?xs.ticks.map(function(t){return {value:t.value};}):[];\n" +
    "  // A historical/still view needs no repaint. Keep the moving endpoint of a\n" +
    "  // visible running quarter at its existing three-second cadence.\n" +
    "  var signature=JSON.stringify([tgRevision,xs&&xs.min,xs&&xs.max,bx&&bx.type,bx&&bx.time,bx&&bx.bounds,bx&&bx.offset,\n" +
    "   bx&&bx.ticks&&[bx.ticks.maxRotation,bx.ticks.autoSkip,bx.ticks.source,bx.ticks.font,bx.ticks.color,bx.ticks.autoSkipPadding,bx.ticks.padding],\n" +
    "   ticks,bv&&bv.width,bv&&bv.chartArea&&[bv.chartArea.left,bv.chartArea.right],ch.width,\n" +
    "   srcRect&&[srcRect.left,srcRect.width],dstRect&&[dstRect.left,dstRect.width],active?Math.floor(nu/3000):0]);\n" +
    "  if(ch.$beTariefSignature===signature)return false;\n" +
    "  if(bv&&bv.options.scales&&bv.options.scales.x){\n" +
    "   var bx=bv.options.scales.x;\n" +
    "   ch.options.scales.x=JSON.parse(JSON.stringify({type:bx.type,time:bx.time,bounds:bx.bounds,offset:bx.offset,grid:{display:false},\n" +
    "    ticks:{maxRotation:bx.ticks.maxRotation,autoSkip:bx.ticks.autoSkip,source:bx.ticks.source,font:bx.ticks.font,color:bx.ticks.color,autoSkipPadding:bx.ticks.autoSkipPadding,padding:bx.ticks.padding}}));\n" +
    "   if(bv.scales.x){ch.options.scales.x.min=bv.scales.x.min;ch.options.scales.x.max=bv.scales.x.max;}\n" +
    "  }\n" +
    "  var mn=ch.options.scales.x.min,mx=ch.options.scales.x.max;\n" +
    "  var imp=[],exp=[],kw=[],gezien={};\n" +
    "  (TG.rijen||[]).forEach(function(r){\n" +
    "   if(mn!=null&&r.end<mn)return;\n" +
    "   if(mx!=null&&r.start>mx)return;\n" +
    "   if(gezien[r.start])return; gezien[r.start]=true;\n" +
    "   var live=r.start<=nu&&nu<r.end;\n" +
    "   var vergelijking=tgVergelijking(r,live);\n" +
    "   if(vergelijking){\n" +
    "    kw.push(Object.assign({},r,{vergelijking:vergelijking,wacht:vergelijking.ki===null&&vergelijking.ke===null}));\n" +
    "    if(live){\n" +
    "     var observed=Date.parse(r.updatedAt);\n" +
    "     var from=Number.isFinite(observed)&&observed>=r.start&&observed<=nu?observed:nu;\n" +
    "     if(from>r.start){\n" +
    "      imp.push({x:r.start,y:null});exp.push({x:r.start,y:null});\n" +
    "     }\n" +
    "     imp.push({x:from,y:vergelijking.ki,beLive:true},{x:nu,y:vergelijking.ki,beLive:true});\n" +
    "     exp.push({x:from,y:vergelijking.ke,beLive:true},{x:nu,y:vergelijking.ke,beLive:true});\n" +
    "    }else{\n" +
    "     imp.push({x:r.start,y:vergelijking.ki,beLive:false},{x:r.end,y:vergelijking.ki,beLive:false});\n" +
    "     exp.push({x:r.start,y:vergelijking.ke,beLive:false},{x:r.end,y:vergelijking.ke,beLive:false});\n" +
    "    }\n" +
    "    return;\n" +
    "   }\n" +
    "   kw.push(r);\n" +
    "   if(live){\n" +
    "    // Never connect a settled quarter to a later first observation: stepped\n" +
    "    // interpolation would falsely backdate its price to the quarter boundary.\n" +
    "    imp.push({x:r.start,y:null}); exp.push({x:r.start,y:null});\n" +
    "    var samples=(r.verloop||[]).filter(function(v){return v.t>=r.start&&v.t<=nu;});\n" +
    "    if(samples.length){\n" +
    "     samples.forEach(function(v){\n" +
    "      imp.push({x:v.t,y:tgWaarde(v.pi),beLive:true});\n" +
    "      exp.push({x:v.t,y:tgWaarde(v.pe),beLive:true});\n" +
    "     });\n" +
    "     var last=samples[samples.length-1];\n" +
    "     imp.push({x:nu,y:tgWaarde(last.pi),beLive:true});\n" +
    "     exp.push({x:nu,y:tgWaarde(last.pe),beLive:true});\n" +
    "    }else{\n" +
    "     imp.push({x:nu,y:tgWaarde(r.pi),beLive:true});\n" +
    "     exp.push({x:nu,y:tgWaarde(r.pe),beLive:true});\n" +
    "    }\n" +
    "   }else{\n" +
    "    imp.push({x:r.start,y:tgWaarde(r.pi),beLive:false},{x:r.end,y:tgWaarde(r.pi),beLive:false});\n" +
    "    exp.push({x:r.start,y:tgWaarde(r.pe),beLive:false},{x:r.end,y:tgWaarde(r.pe),beLive:false});\n" +
    "   }\n" +
    "  });\n" +
    "  ch.data.datasets[0].data=imp; ch.data.datasets[1].data=exp;\n" +
    "  // Match both plot edges in screen coordinates, including differing canvas offsets.\n" +
    "  if(bv&&bv.chartArea&&bv.scales.x&&srcRect&&dstRect){\n" +
    "   var srcRatio=srcRect.width/bv.width,dstRatio=dstRect.width/ch.width;\n" +
    "   if(srcRatio>0&&dstRatio>0){\n" +
    "    var left=(srcRect.left+bv.chartArea.left*srcRatio-dstRect.left)/dstRatio;\n" +
    "    var right=(srcRect.left+bv.chartArea.right*srcRatio-dstRect.left)/dstRatio;\n" +
    "    ch.options.layout.padding={top:6,left:0,right:Math.max(0,ch.width-right)};\n" +
    "    ch.options.scales.y.afterFit=function(axis){axis.width=Math.max(0,left);};\n" +
    "    ch.options.scales.x.afterBuildTicks=function(axis){axis.ticks=ticks;};\n" +
    "    ch.options.scales.x.ticks.autoSkip=false;\n" +
    "   }\n" +
    "  }\n" +
    "  ch.$beKwartieren=kw; ch.$beTariefSignature=signature; return true;\n" +
    " }\n" +
    " document.addEventListener('be-tarief-update',function(){\n" +
    "  var n=document.getElementById('be-tarief-data'); if(!n)return;\n" +
    "  try{tgLees(n);tgVul();}\n" +
    "  catch(e){console.error('[BE tariefgrafiek bridge]',e);}\n" +
    " });\n" +
    " document.addEventListener('be-onbalans-settlement-update',function(){\n" +
    "  try{tgLeesSettlement();tgVul();}catch(e){console.error('[BE onbalansvergelijking]',e);}\n" +
    " });\n" +
    " try{tgLeesSettlement();}catch(e){}\n" +
    " var initial=document.getElementById('be-actueel-allin-data');\n" +
    " try{if(initial)st=Object.assign(st,JSON.parse(initial.textContent||'{}'));}catch(e){}\n" +
    " var initialTarief=document.getElementById('be-tarief-data');\n" +
    " try{if(initialTarief)tgLees(initialTarief);}catch(e){}\n" +
    " wikkel();tgVul();\n" +
    " Chart.register({id:'beTariefViewportSync',afterUpdate:function(c){if(c.canvas?.id===CANVAS)tgVul();}});\n" +
    " document.addEventListener('visibilitychange',function(){if(!document.hidden){wikkel();tgVul();}});\n" +
    " window.addEventListener('resize',tgVul,{passive:true});\n" +
    " setInterval(function(){ if(TG.aan&&!document.hidden) tgVul(); },3000);\n" +
    " setInterval(wikkel,3000);\n" +
    " console.log('[BE Actueel all-in bridge] actief');\n" +
    "})();\n";

  function actueelInstalleerBridge() {
    if (!isActueelPagina()) {
      return;
    }

    /*
     * De bridge hoeft maar één keer geïnstalleerd te worden.
     * Belangrijk: hier NIET opnieuw actueelStuur() aanroepen,
     * anders wordt de Chart.js-grafiek iedere onderhoudsronde
     * opnieuw gerenderd.
     */
    if (
      document.getElementById(
        'be-actueel-allin-data'
      )
    ) {
      return;
    }

    var s =
      document.createElement(
        'script'
      );

    s.id =
      'be-actueel-allin-bridge';

    s.textContent =
      ACTUEEL_BRIDGE_CODE;

    (
      document.head ||
      document.documentElement
    ).appendChild(s);

    s.remove();
  }

  function actueelStuur() {
    if (!isActueelPagina()) {
      return;
    }

    var n =
      document.getElementById(
        'be-actueel-allin-data'
      );

    if (!n) {
      n =
        document.createElement(
          'script'
        );

      n.type =
        'application/json';

      n.id =
        'be-actueel-allin-data';

      document.documentElement
        .appendChild(n);
    }

    n.textContent =
      JSON.stringify({
        rijen:
          actueelRijen,

        aan:
          actueelAan,

        eb:
          EB,

        btw:
          BTW,

        opslag:
          OPSLAG,

        saldeert:
          ACTUEEL_SALDEERT
      });

    document.dispatchEvent(
      new Event(
        'be-actueel-allin-update'
      )
    );
  }

  /* ──────────────────────────────────────────────────────────────────
   *  Tariefgrafiek (v5.0)
   *
   *  Een tweede grafiek tussen de vermogensgrafiek en de SOC-rij, met het
   *  afname- en invoedtarief per kwartier. Dezelfde kwartiervakken, dezelfde
   *  tijdas en hetzelfde witte tekenvlak als de grafiek erboven; per vak het
   *  etiket onbalans of aFRR en het resultaat van dat kwartier in euro.
   *
   *  Twee dingen die eerder fout gingen en hier bewust anders staan:
   *
   *  - Het etiket komt uit afrrEventIsps, nooit uit een prijsvergelijking.
   *    Bij gewone onbalans verschillen afname en invoeding ook, want
   *    opregelen en afregelen zijn twee tarieven. Over 141 kwartieren zat
   *    een test op "de prijzen lopen uiteen" er 69 keer naast.
   *
   *  - Het bedrag komt uit actueelProjectieBereken, dezelfde motor als het
   *    dagresultaat. Een eigen integratie met een gatgrens van twee minuten
   *    haalde bijna de helft van de energie uit een kwartier; deze functie
   *    gebruikt vijf minuten en interpoleert bovendien netjes.
   * ────────────────────────────────────────────────────────────────── */

  var TARIEF_SLEUTEL = 'be_cfg_tariefgrafiek';

  var tariefAan =
    localStorage.getItem(TARIEF_SLEUTEL) !== 'uit';

  function tariefZorgBlok() {
    if (!isActueelPagina()) {
      return null;
    }

    var bestaand =
      document.getElementById('be-tarief-row');

    if (bestaand && bestaand.parentElement) {
      return bestaand;
    }

    var soc =
      document.querySelector('.energy-chart-soc-row');

    if (!soc || !soc.parentElement) {
      return null;
    }

    var rij =
      document.createElement('div');

    rij.id = 'be-tarief-row';
    rij.className = 'energy-chart-soc-row';

    rij.innerHTML =
      '<div class="chart-frame" style="height:340px;">' +
        '<canvas id="be-tarief-chart"></canvas>' +
      '</div>' +
      '<p class="charging-chart-note" id="be-tarief-noot"></p>';

    soc.parentElement.insertBefore(rij, soc);

    return rij;
  }

  function tariefStuur() {
    if (!isActueelPagina()) {
      return;
    }

    var blok = tariefZorgBlok();

    if (blok) {
      blok.hidden = !tariefAan;
    }

    var n =
      document.getElementById('be-tarief-data');

    if (!n) {
      n = document.createElement('script');
      n.type = 'application/json';
      n.id = 'be-tarief-data';
      document.documentElement.appendChild(n);
    }

    n.textContent =
      JSON.stringify({
        rijen: tariefAan ? tariefKwartieren() : [],
        aan: tariefAan,
        allin: actueelAan
      });

    document.dispatchEvent(
      new Event('be-tarief-update')
    );

    tariefZetNoot();
  }

  /* Per kwartier de prijzen en het resultaat. Het resultaat loopt via
     actueelProjectieBereken zodat het exact dezelfde regels volgt als het
     dagbedrag in de bedieningsrij. */
  function tariefKwartieren() {
    var KW = 15 * 60 * 1000;
    var nu = Date.now();
    beLivePrijsRows=window.BECurrentTariffCache.restore(KLANT,beLivePrijsRows);
    var grafiekRijen=actueelRijen;
    if (beLivePrijsRows) {
      beLivePrijsRows=beOverbrugPrijzen(beLivePrijsRows,nu);
      var rijen=beLivePrijsRows.map(actueelPrijsRij);
      actueelRijen=rijen.filter(function(r){return Number.isFinite(r.ki)||Number.isFinite(r.ke);});
      grafiekRijen=rijen.filter(function(r){return Number.isFinite(r.ki)||Number.isFinite(r.ke)||r.onbalansVergelijking;});
    }
    var uit = [];
    // Sort the daily measurements once, then integrate just the points that
    // bracket each quarter. Keep both edge neighbours for exact interpolation.
    var dagPunten = actueelDagPunten.filter(function(p){
      return p && Number.isFinite(p.x) && Number.isFinite(p.y);
    }).sort(function(a,b){return a.x-b.x;});

    var bekend = {};

    grafiekRijen.forEach(function (r) {
      bekend[r.start] = r;
    });

    /* Balans publiceert een kwartier pas twee a drie minuten na het begin.
       De lege kwartieren gaan toch mee, zodat het vak en het etiket
       "prijs volgt" er alvast staan. */
    var starts = Object.keys(bekend).map(Number);

    var laatste = Math.floor(nu / KW) * KW;

    if (starts.length) {
      var vroegste = Math.min.apply(null, starts);

      for (var k = vroegste; k <= laatste; k += KW) {
        if (!bekend[k]) {
          bekend[k] = { start: k, end: k + KW, ki: null, ke: null, afrr: false };
        }
      }
    }

    Object.keys(bekend).map(Number).sort(function (a, b) {
      return a - b;
    }).forEach(function (k) {
      var r = bekend[k];

      var heeftPrijs =
        Number.isFinite(r.ki) &&
        Number.isFinite(r.ke);

      var res = null;
      var deel = false;
      var breakEven = null;

      if (!r.carried && actueelDagPunten.length) {
        var b =
          actueelProjectieBereken(
            dagPunten,
            [r],
            r.start,
            r.end,
            nu,
            true
          );

        if (b && !b.ongeldig && b.gemetenMs > 0) {
          // Match Resultaat vandaag: sum known prices without inventing missing ones.
          // Keep meter coverage separate from tariff coverage.
          breakEven = {
            bedrag: b.bedrag,
            gemetenMs: b.gemetenMs,
            prijsOnvolledig: !!b.prijsOnvolledig,
            tot: Math.min(r.end, nu, actueelDagPunten[actueelDagPunten.length - 1].x)
          };
          if (b.stukken) {
            res = b.bedrag;
            deel = b.gedekt < (r.end - r.start) * 0.97;
          }
        }
      }

      uit.push({
        start: r.start,
        end: r.end,
        afrr: !!r.afrr,
        marktImport:r.marktImport, marktExport:r.marktExport,gemengdImport:!!r.gemengdImport,epexInjectie:!!r.epexInjectie,
        carried:!!r.carried, sourceStart:r.sourceStart,
        provisional:r.provisional, fresh:r.fresh, updatedAt:r.updatedAt,
        values:r.values,dayAheadExport:r.dayAheadExport,onbalansVergelijking:r.onbalansVergelijking,
        verloop:(r.verloop || []).map(function (v) {
          return { t:v.t, carried:!!v.carried,
            pi:Number.isFinite(v.ki)?(actueelAan ? actueelAllin(v.ki, false) : v.ki):null,
            pe:Number.isFinite(v.ke)?(actueelAan ? actueelAllin(v.ke, true) : v.ke):null };
        }),
        wacht: !Number.isFinite(r.ki) && !Number.isFinite(r.ke),
        res: res,
        breakEven: breakEven,
        deel: deel,

        pi: Number.isFinite(r.ki)
          ? (actueelAan ? actueelAllin(r.ki, false) : r.ki)
          : null,

        pe: Number.isFinite(r.ke)
          ? (actueelAan ? actueelAllin(r.ke, true) : r.ke)
          : null
      });
    });

    return uit;
  }

  function tariefZetNoot() {
    var n =
      document.getElementById('be-tarief-noot');

    if (!n) {
      return;
    }

    n.textContent = (actueelAan
      ? 'All-in, incl. btw, leverkosten en energiebelasting. '
      : 'Kale tarieven, excl. btw, leverkosten en energiebelasting. ') +
      'Dunne, lichtere lijn = lopend kwartier. Tijdens Day Ahead tonen rood en groen de onbalansvergelijking. Details in de tooltip.';
  }

  /* De schakelaar hoort naast de All-in knop in de bedieningsrij. In de
     grafiek zelf zou hij mee verdwijnen zodra je hem uitzet. */
  function tariefZorgKnop() {
    if (!isActueelPagina()) {
      return;
    }

    var rij =
      document.getElementById('be-actueel-bedieningsrij') ||
      document.querySelector('.energy-chart-legend');

    if (!rij) {
      return;
    }

    var b =
      document.getElementById('be-tariefgrafiek-knop');

    if (!b) {
      b = document.createElement('button');
      b.type = 'button';
      b.id = 'be-tariefgrafiek-knop';

      b.style.cssText =
        'appearance:none;-webkit-appearance:none;display:flex;' +
        'align-items:center;gap:8px;border:0;border-left:1px solid #e8e2f0;' +
        'background:transparent;padding:3px 14px;cursor:pointer;font:inherit;' +
        'font-size:12px;color:#2b2733;white-space:nowrap;flex:0 0 auto;' +
        'margin-left:auto;box-shadow:none;';

      b.innerHTML =
        '<span>Tariefgrafiek</span>' +
        '<span data-be-tg-track style="position:relative;display:inline-block;' +
          'width:34px;height:18px;border-radius:999px;flex-shrink:0;' +
          'transition:background .18s ease;">' +
          '<span data-be-tg-thumb style="position:absolute;left:2px;top:2px;' +
            'width:14px;height:14px;border-radius:50%;background:#fff;' +
            'box-shadow:0 1px 3px rgba(0,0,0,.35);' +
            'transition:transform .18s ease;"></span>' +
        '</span>' +
        '<span data-be-tg-status style="min-width:24px;font-size:10px;' +
          'font-weight:700;line-height:1;"></span>';

      b.addEventListener('click', function () {
        tariefAan = !tariefAan;

        try {
          localStorage.setItem(
            TARIEF_SLEUTEL,
            tariefAan ? 'aan' : 'uit'
          );
        } catch (e) {}

        tariefTekenKnop();
        tariefStuur();
      });
    }

    var allin =
      rij.querySelector('[data-be-actueel-allin]');

    if (allin) {
      if (b.nextElementSibling !== allin) {
        rij.insertBefore(b, allin);
      }
    } else if (b.parentElement !== rij) {
      rij.appendChild(b);
    }

    tariefTekenKnop();
  }

  function tariefTekenKnop() {
    var b =
      document.getElementById('be-tariefgrafiek-knop');

    if (!b) {
      return;
    }

    b.setAttribute(
      'aria-pressed',
      tariefAan ? 'true' : 'false'
    );

    b.title =
      tariefAan
        ? 'Tariefgrafiek verbergen'
        : 'Tariefgrafiek tonen';

    var track = b.querySelector('[data-be-tg-track]');
    var thumb = b.querySelector('[data-be-tg-thumb]');
    var status = b.querySelector('[data-be-tg-status]');

    if (track) {
      track.style.background = tariefAan ? '#6B3FA0' : '#9ca3af';
    }

    if (thumb) {
      thumb.style.transform =
        tariefAan ? 'translateX(16px)' : 'translateX(0)';
    }

    if (status) {
      status.textContent = tariefAan ? 'AAN' : 'UIT';
    }
  }

  function actueelPasPrijzenToe(j) {
        if (
          !j ||
          !Array.isArray(
            j.prices
          )
        ) {
          return;
        }

        actueelRijen = j.prices.map(actueelPrijsRij).filter(function (r) {
          return Number.isFinite(r.ki) || Number.isFinite(r.ke);
        });

        actueelStuur();

        tariefStuur();

        actueelWerkSchemaBij();
        actueelProjectieToon();

        console.log(
          '[BE Actueel all-in]',
          actueelRijen.length,
          'kwartieren, schakelaar',
          actueelAan
            ? 'aan'
            : 'uit'
        );
  }

  var beLivePrijsRows = [];
  var bePrijsHydratie = null;
  function beHerstelPrijsVerloop(){
    if(bePrijsHydratie)return;
    beLivePrijsRows=window.BECurrentTariffCache.restore(KLANT,beLivePrijsRows);
    if(beLivePrijsRows.length&&isActueelPagina())actueelPasPrijzenToe({prices:beLivePrijsRows});
    bePrijsHydratie=beLeesBron('prijzen').then(function(saved){
      beLivePrijsRows=window.BECurrentTariffCache.restore(KLANT,beVoegPrijzenSamen(saved.rows||[],beLivePrijsRows));
      beLivePrijsRows=beOverbrugPrijzen(beLivePrijsRows,Date.now());
      if(isActueelPagina())actueelPasPrijzenToe({prices:beLivePrijsRows});
    }).catch(function(e){console.warn('[BE prijsarchief lezen]',e.message);});
  }
  function beOverbrugPrijzen(rows, nu) {
    var start=Math.floor(nu/900000)*900000;
    var current=rows.find(function(p){return p.start===start;});
    var prior=rows.filter(function(p){return p.end===start;}).pop();
    if(!prior)return rows;
    // A day-ahead plan belongs to one exact quarter. Never extend it, or
    // hide a missing planned/unknown import beneath a previous market price.
    if((current&&current.dayAheadState&&current.dayAheadState!=='none')||
       (prior.dayAheadState&&prior.dayAheadState!=='none'))return rows;
    var previous=actueelPrijsRij(prior),r=current&&actueelPrijsRij(current);
    if(!Number.isFinite(previous.ki)||!Number.isFinite(previous.ke))return rows;
    var seed={t:start,ki:previous.ki,ke:previous.ke,marktImport:previous.marktImport,marktExport:previous.marktExport,carried:true};
    var history=(current&&current.verloop||[]).slice();
    if(!history.length||history[0].t>start)history.unshift(seed);
    var usable=r&&Number.isFinite(r.ki)&&Number.isFinite(r.ke);
    var replacement=usable?Object.assign({},current,{verloop:history}):
      Object.assign({},prior,{start:start,end:start+900000,provisional:true,carried:true,sourceStart:prior.start,verloop:history});
    return rows.filter(function(p){return p.start!==start;}).concat([replacement]).sort(function(a,b){return a.start-b.start;});
  }
  function beOntvangLivePrijzen(j) {
    if(!j||!Array.isArray(j.prices))return;
    window.BECurrentTariffCache.remember(KLANT,j);
    beLivePrijsRows=window.BECurrentTariffCache.restore(KLANT,beLivePrijsRows);
    document.dispatchEvent(new CustomEvent('be-afrr-source',{detail:j}));
    beLivePrijsRows=beVoegPrijzenSamen(beLivePrijsRows,j.prices,j.afrrEventIsps,j.afrrDiscovery,j);
    beLivePrijsRows=beOverbrugPrijzen(beLivePrijsRows,Date.now());
    actueelPasPrijzenToe({prices:beLivePrijsRows});
  }
  function beBewaarPrijzenLater(j) {
    var werk=beArchiefWachtrij.then(function(){return beVerwerkBron(new URL('/customer/current-prices/api/',location.origin),j);});
    beArchiefWachtrij=werk.catch(function(e){console.warn('[BE prijsarchief]',e.message);});
  }
  var actueelPrijsBezig = false;
  function actueelHaal() {
    if (
      !isActueelPagina()
    ) {
      return Promise.resolve();
    }

    if (actueelPrijsBezig) return Promise.resolve();
    actueelPrijsBezig = true;
    beHerstelPrijsVerloop();
    var controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 12000);
    return origFetch(
      location.origin +
      '/customer/current-prices/api/',
      {
        credentials:
          'same-origin',

        signal: controller.signal,
        cache:
          'no-store'
      }
    )

      .then(function (r) {
        return r.ok
          ? r.json()
          : null;
      })

      .then(function(j){beOntvangLivePrijzen(j);if(j)beBewaarPrijzenLater(j);})

      .catch(
        function (e) {
          console.warn(
            '[BE Actueel all-in] ophalen mislukt:',
            e.message
          );
        }
      ).finally(function () {
        clearTimeout(timeout);
        actueelPrijsBezig = false;
      });
  }

  var actueelDagOphaling = null;
  var actueelDagPuntenScope = '';
  var actueelDagRevisie = 0;
  var actueelDagEnergie = null;
  var actueelDagKlok = new Intl.DateTimeFormat('en-GB', {
    timeZone:'Europe/Amsterdam',year:'numeric',month:'2-digit',day:'2-digit',
    hour:'2-digit',minute:'2-digit',hourCycle:'h23'
  });
  var actueelDagGetal = new Intl.NumberFormat('nl-NL', {minimumFractionDigits:1,maximumFractionDigits:1});
  function actueelEnergieDag(nu) {
    function delen(t){return Object.fromEntries(actueelDagKlok.formatToParts(t).map(function(p){return [p.type,p.value];}));}
    var lokaal=delen(nu),utc=Date.UTC(+lokaal.year,+lokaal.month-1,+lokaal.day),offset=delen(utc);
    // At 00:00 UTC the Amsterdam clock is one or two hours ahead; the
    // summer-time change is later in the local night, not at midnight.
    return {key:lokaal.year+'-'+lokaal.month+'-'+lokaal.day,start:utc-(+offset.hour*60 + +offset.minute)*60000};
  }
  function actueelTelDagEnergie(rows,veld,vanaf,tot) {
    var plus=0,min=0,dekking=0;
    function tel(kwh){if(kwh>=0)plus+=kwh;else min-=kwh;}
    for(var i=1;i<rows.length;i++){
      var a=rows[i-1],b=rows[i],dt=b.t-a.t;
      if(!(dt>0&&dt<=300000)||!Number.isFinite(a[veld])||!Number.isFinite(b[veld]))continue;
      var x=Math.max(vanaf,a.t),y=Math.min(tot,b.t);
      if(y<=x)continue;
      var w1=a[veld]+(b[veld]-a[veld])*(x-a.t)/dt,w2=a[veld]+(b[veld]-a[veld])*(y-a.t)/dt;
      var uren=(y-x)/3600000000;
      if(w1*w2<0){
        var fractie=Math.abs(w1)/(Math.abs(w1)+Math.abs(w2));
        tel(w1*uren*fractie/2);tel(w2*uren*(1-fractie)/2);
      }else tel((w1+w2)*uren/2);
      dekking+=y-x;
    }
    return dekking?{plus:plus,min:min,deel:tot-vanaf-dekking>300000}:null;
  }
  function actueelMeetDagEnergie(j,netRows,dag,tot) {
    j=j||{};
    var metingen=new Map();
    (Array.isArray(j.rows)?j.rows:[]).concat(j.latest||[]).forEach(function(r){
      if(!r||!Number.isFinite(r.t)||r.t<dag.start-300000||r.t>tot) return;
      var sample=metingen.get(r.t)||{t:r.t};
      ['bo','l','p','g'].forEach(function(k){if(Number.isFinite(r[k]))sample[k]=r[k];});
      metingen.set(r.t,sample);
    });
    var rows=Array.from(metingen.values()).sort(function(a,b){return a.t-b.t;});
    var pv=actueelTelDagEnergie(rows,'p',dag.start,tot),lokaal=actueelTelDagEnergie(rows,'g',dag.start,tot);
    return {
      scope:KLANT+':'+dag.key,tot:tot,
      grid:actueelTelDagEnergie(netRows,'po',dag.start,tot),
      battery:actueelTelDagEnergie(rows,'bo',dag.start,tot),
      load:actueelTelDagEnergie(rows,'l',dag.start,tot),
      pv:pv||lokaal?{plus:(pv?.plus||0)+(lokaal?.plus||0),min:(pv?.min||0)+(lokaal?.min||0),deel:!pv||!lokaal||pv.deel||lokaal.deel}:null
    };
  }
  function actueelTekenDagEnergie() {
    var legenda=document.querySelector('.energy-chart-legend');if(!legenda)return;
    var nu=Date.now(),dag=actueelEnergieDag(nu);
    var data=actueelDagEnergie?.scope===KLANT+':'+dag.key?actueelDagEnergie:null;
    var stijl=document.getElementById('be-dagenergie-css');
    if(!stijl){
      stijl=document.createElement('style');stijl.id='be-dagenergie-css';
      stijl.textContent='.energy-chart-legend [data-be-dagenergie]::after{content:attr(data-be-dagenergie);display:inline-block;margin-inline-start:.35em;font-size:.74em;font-weight:600;opacity:.76;white-space:nowrap}'+
        '@media(max-width:900px){.energy-chart-legend [data-be-dagenergie]::after{display:block;margin-inline-start:0;text-align:end}}';
      (document.head||document.documentElement).appendChild(stijl);
    }
    function energie(v){return actueelDagGetal.format(Math.abs(v)<.05?0:v)+' kWh';}
    [['grid','import','export'],['battery','ontladen','laden'],['load'],['pv']].forEach(function(richting){
      var key=richting[0],node=legenda.querySelector('#legend-'+key+'-power');if(!node)return;
      var r=data&&data[key],deel=r&&(r.deel||nu-data.tot>300000);
      var tekst=' / '+(r?(deel?'~ ':'')+energie(r.plus-r.min):'— kWh');
      var tip=r?'Dagtotaal: '+(deel?'~ ':'')+energie(r.plus-r.min):'Dagtotaal: nog geen meetgegevens.';
      if(r&&richting[1])tip+=' · '+richting[1]+' '+energie(r.plus)+' · '+richting[2]+' '+energie(r.min);
      if(deel)tip+=' · Deel van de meetgegevens beschikbaar.';
      if(node.getAttribute('data-be-dagenergie')!==tekst)node.setAttribute('data-be-dagenergie',tekst);
      if(node.title!==tip)node.title=tip;
    });
  }
  function actueelHaalDagPunten() {
    if (!isActueelPagina() || !KLANT) return Promise.resolve();
    var klant = KLANT, beginVandaag = new Date();
    beginVandaag.setHours(0,0,0,0);
    var vanaf = beginVandaag.getTime(), tot = Date.now(), dagKey = iso(beginVandaag);
    var energiedag = actueelEnergieDag(tot);
    var scope = klant + ':' + dagKey;
    if (actueelDagOphaling && actueelDagOphaling.scope === scope) return actueelDagOphaling.promise;
    if (actueelDagPuntenScope !== scope) {
      actueelDagPunten = [];
      actueelDagPuntenScope = scope;
    }
    var revisie = ++actueelDagRevisie;
    function ontvang(rows) {
      if (revisie !== actueelDagRevisie) return;
      if (KLANT !== klant || iso(new Date()) !== dagKey || actueelDagPuntenScope !== scope) return;
      var map = new Map(actueelDagPunten.map(function(p){return [p.x,p];})), gewijzigd = false;
      (rows || []).forEach(function(r){
        if(r && Number.isFinite(r.t) && Number.isFinite(r.po) && r.t >= vanaf && r.t <= tot) {
          var oud = map.get(r.t);
          if (!oud || oud.y !== r.po) { map.set(r.t,{x:r.t,y:r.po}); gewijzigd = true; }
        }
      });
      if (gewijzigd) actueelDagPunten = Array.from(map.values()).sort(function(a,b){return a.x-b.x;});
      actueelProjectieToon();
      tariefStuur();
    }
    // Render existing day measurements without waiting for network or archive writes.
    var versOntvangen = false;
    beLeesBron(dagKey).then(function(dag){
      // An older storage snapshot must not overwrite a fresh response.
      if (!versOntvangen) ontvang(dag.rows);
    }).catch(function(e){console.warn('[BE Actueel] dagcache:',e.message);});
    var u = new URL('/customer/current-history/api/',location.origin);
    u.searchParams.set('installation',klant);
    u.searchParams.set('start',String(Math.min(vanaf,energiedag.start)));
    u.searchParams.set('end',String(tot));
    var controller = new AbortController();
    var timeout = setTimeout(function(){controller.abort();},12000);
    var taak = {scope:scope,promise:null};
    actueelDagOphaling = taak;
    taak.promise = Promise.resolve().then(function(){
      return origFetch(u.href,{credentials:'same-origin',cache:'no-store',signal:controller.signal});
    }).then(function(r){
      if(!r.ok)throw new Error('HTTP '+r.status);
      return r.json();
    }).then(function(j){
      if(revisie!==actueelDagRevisie || KLANT!==klant || iso(new Date())!==dagKey)return;
      // Publish raw measurements first; storage latency cannot hide the result.
      versOntvangen = true;
      var netRows=beHistorieMetingen(j);
      actueelDagEnergie=actueelMeetDagEnergie(j,netRows,energiedag,tot);
      actueelTekenDagEnergie();
      ontvang(netRows);
      var werk = beArchiefWachtrij.then(function(){
        if(KLANT!==klant)return null;
        return beVerwerkBron(u,j);
      });
      beArchiefWachtrij = werk.catch(function(e){console.warn('[BE Actueel] dagarchief:',e.message);});
      werk.then(function(archief){if(archief)ontvang(archief.rows);}).catch(function(){});
    }).catch(function(e){
      console.warn('[BE Actueel] daghistorie ophalen mislukt:',e.message);
    }).finally(function(){
      clearTimeout(timeout);
      if(actueelDagOphaling===taak)actueelDagOphaling=null;
    });
    return taak.promise;
  }

  function actueelHuidigeRij() {
    var nu =
      Date.now();

    for (
      var i = 0;
      i < actueelRijen.length;
      i++
    ) {
      if (
        actueelRijen[i].start <= nu &&
        actueelRijen[i].end > nu
      ) {
        return actueelRijen[i];
      }
    }

    return null;
  }

  var actueelSchemaBronnen = new WeakMap();
  function actueelMaakPrijsLabel(tekst,rij){
    var geraakt=false,details=[],metStekker=false;
    // 6.8.3.3: Balans toont tot zijn volgende ronde 'Prijs niet beschikbaar'. Hebben wij de prijs
    // al (bijv. EPEX-aanvulling), vervang dat dan meteen; de rest van de functie zet hem all-in.
    var okRij=rij&&!rij.carried&&(!Number.isFinite(rij.sourceStart)||rij.sourceStart===rij.start);
    tekst=String(tekst).replace(/\b(Import|Inkoop|Afname)(\s+)Prijs niet beschikbaar/i,function(m,w,sp){return okRij&&Number.isFinite(rij.ki)?w+sp+'€ 0/kWh':m;})
      .replace(/\b(Export|Invoeding|Teruglevering)(\s+)Prijs niet beschikbaar/i,function(m,w,sp){return okRij&&Number.isFinite(rij.ke)?w+sp+'€ 0/kWh':m;});
    var delen=String(tekst).split(/(?=\b(?:Import|Inkoop|Afname|Export|Invoeding|Teruglevering|Teruglever|Injectie)\b)/i);
    var bedrag=/(?:[+\-−]\s*)?€\s*(?:[+\-−]\s*)?\d+(?:[.,]\d+)?/g;
    var geldigeRij=rij&&!rij.carried&&(!Number.isFinite(rij.sourceStart)||rij.sourceStart===rij.start);
    var nieuw=delen.map(function(deel){
      if(!deel.match(bedrag))return deel;
      geraakt=true;
      var richting=deel.match(/^\s*(Import|Inkoop|Afname|Export|Invoeding|Teruglevering|Teruglever|Injectie)\b/i);
      var uitvoer=richting&&/^(Export|Invoeding|Teruglevering|Teruglever|Injectie)$/i.test(richting[1]);
      var kaal=richting&&geldigeRij?rij[uitvoer?'ke':'ki']:null;
      var bekend=Number.isFinite(kaal),prijs=bekend?actueelEuro(actueelAllin(kaal,!!uitvoer)):'prijs volgt (all-in)';
      // 6.8.3: door de plugin ingevulde EPEX-prijs herkenbaar maken.
      var stekker=bekend&&!uitvoer&&!!rij&&!!rij.epexInjectie;
      var markt=rij&&rij[uitvoer?'marktExport':'marktImport'];
      details.push((richting?(uitvoer?'Export':'Import'):'Prijs')+(markt?' · '+markt:'')+': '+prijs+(bekend?'/kWh':'')+
        (bekend&&(!uitvoer&&rij.gemengdImport)?' · indicatief ongewogen gemiddelde van dynamisch en aFRR':
          bekend&&(rij[uitvoer?'historischExport':'historischImport']||deel.indexOf('≈')!==-1)?' · indicatief / laatst bekende bronprijs':''));
      if(stekker)details[details.length-1]+=' · EPEX-prijs ingevuld door de plugin 🔌';
      if(stekker)metStekker=true;
      var resultaat=deel.replace(bedrag,prijs);
      return bekend?resultaat:resultaat.replace(/\s*\/\s*kWh\b/gi,'');
    }).join('');
    return {text:nieuw,matched:geraakt,details:details,stekker:metStekker};
  }
  function actueelWerkSchemaBij() {
    if(!isActueelPagina())return;
    var e=document.getElementById('flow-grid-price');if(!e)return;
    var tekst=e.textContent||'',titel=e.title||'',vorig=actueelSchemaBronnen.get(e);
    var bronTekst=vorig&&tekst===vorig.text?vorig.sourceText:tekst;
    var bronTitel=vorig&&titel===vorig.title?vorig.sourceTitle:titel;
    var nieuwTekst=bronTekst,nieuwTitel=bronTitel;
    if(actueelAan){
      var label=actueelMaakPrijsLabel(bronTekst,actueelHuidigeRij());
      if(label.matched){
        nieuwTekst=label.text;
        nieuwTitel='All-in per kWh: inclusief btw en leverkosten; energiebelasting volgens de instellingen.\n'+label.details.join('\n');
      }
    }
    actueelSchemaBronnen.set(e,{sourceText:bronTekst,sourceTitle:bronTitel,text:nieuwTekst,title:nieuwTitel});
    if(tekst!==nieuwTekst)e.textContent=nieuwTekst;
    // 6.8.3.2: zelfde paarse stekker als in de grafiek (CSS, geen emoji).
    var epex=!!(actueelAan&&label&&label.matched&&label.stekker);
    if(e.toggleAttribute&&epex!==e.hasAttribute('data-be-epex'))e.toggleAttribute('data-be-epex',epex);
    if(epex&&!document.getElementById('be-epex-stekker-css')){var cs=document.createElement('style');cs.id='be-epex-stekker-css';cs.textContent='#flow-grid-price[data-be-epex]::after{content:\'\';display:inline-block;width:1.15em;height:1.15em;margin-left:.35em;vertical-align:-.22em;background:url("data:image/svg+xml,<svg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 14 14\'><circle cx=\'7\' cy=\'7\' r=\'7\' fill=\'%236B3FA0\'/><g fill=\'%23fff\' stroke=\'%23fff\' stroke-linecap=\'round\' transform=\'rotate(90 7 7)\'><rect x=\'3.8\' y=\'5.4\' width=\'6.4\' height=\'4.2\' stroke=\'none\'/><rect x=\'4.6\' y=\'2.4\' width=\'1.4\' height=\'3.2\' stroke=\'none\'/><rect x=\'8\' y=\'2.4\' width=\'1.4\' height=\'3.2\' stroke=\'none\'/><line x1=\'7\' y1=\'9.6\' x2=\'7\' y2=\'12.2\' stroke-width=\'1.4\'/></g></svg>") center/contain no-repeat}';document.head.appendChild(cs);}
    if(titel!==nieuwTitel)e.title=nieuwTitel;
    actueelLaatstGeschreven=actueelAan?nieuwTekst:null;
  }

  function actueelVolgSchema() {
    if (!isActueelPagina()) {
      return;
    }

    var e =
      document.getElementById(
        'flow-grid-price'
      );

    if (
      !e ||
      e.getAttribute(
        'data-be-actueel-volgt'
      ) === '1'
    ) {
      return;
    }

    e.setAttribute(
      'data-be-actueel-volgt',
      '1'
    );

    new MutationObserver(
      function () {
        actueelWerkSchemaBij();
      }
    ).observe(
      e,
      {
        childList: true,
        characterData: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['title']
      }
    );
  }

  function actueelLegenda() {
    if (!isActueelPagina()) {
      return null;
    }

    var legenda =
      document.querySelector(
        '.energy-chart-legend'
      );

    var fallback =
      document.getElementById(
        'be-actueel-bedieningshost'
      );

    if (legenda) {
      if (
        fallback &&
        !fallback.children.length
      ) {
        fallback.remove();
      }

      return legenda;
    }

    /*
     * Bij een verse landing ontbreekt de Balans-legenda in mobiele Safari
     * soms geheel. Maak dan direct een neutrale host buiten de grafiek.
     * Zodra Balans zijn eigen legenda toevoegt, verhuist de rij daarheen.
     */
    var canvas =
      document.getElementById(
        'battery-chart'
      );

    if (!canvas || !canvas.parentElement) {
      return null;
    }

    if (!fallback) {
      fallback =
        document.createElement(
          'div'
        );

      fallback.id =
        'be-actueel-bedieningshost';

      fallback.style.cssText =
        'display:block;' +
        'width:100%;' +
        'box-sizing:border-box;';

      var grafiekHost =
        canvas.parentElement;

      if (grafiekHost.parentElement) {
        grafiekHost.parentElement.insertBefore(
          fallback,
          grafiekHost.nextSibling
        );

      } else {
        grafiekHost.appendChild(
          fallback
        );
      }
    }

    return fallback;
  }

  function actueelVoegMobieleStijlToe() {
    if (
      document.getElementById(
        'be-actueel-mobiel-css'
      )
    ) {
      return;
    }

    var stijl =
      document.createElement(
        'style'
      );

    stijl.id =
      'be-actueel-mobiel-css';

    stijl.textContent =
      "#be-actueel-resultaat { flex-wrap:wrap; row-gap:8px!important; }\n.be-dag-label { font-size:10px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; color:#9274bb; background:rgba(107,63,160,.06); border-radius:6px; padding:4px 7px; }\n.be-dag-saldo { font-size:16px; font-weight:700; white-space:nowrap; }\n.be-dag-info { position:relative; min-width:0; color:#6c757d; font-size:11px; }\n.be-dag-info summary { cursor:pointer; list-style:none; white-space:normal; line-height:1.5; border-radius:4px; }\n.be-dag-info summary::-webkit-details-marker { display:none; }\n.be-dag-info summary:focus-visible { outline:2px solid #9274bb; outline-offset:4px; }\n.be-dag-info-icoon { color:#9274bb; margin-left:3px; }\n.be-dag-popup { display:none; position:absolute; top:100%; right:0; z-index:1000; width:280px; max-width:calc(100vw - 48px); padding:14px 16px; background:#fff; color:#302c36; border:1px solid #e6ddef; border-radius:10px; box-shadow:0 6px 22px #30203a24; white-space:normal; text-align:left; }\n.be-dag-info[open]>.be-dag-popup { display:block; }\n@media(hover:hover) and (pointer:fine) { .be-dag-info:not([data-dismissed]):hover>.be-dag-popup { display:block; } }\n.be-dag-popup-kop { font-size:11px; font-weight:600; color:#9274bb; margin-bottom:10px; }\n.be-dag-stroom { display:flex; flex-direction:column; gap:4px; }\n.be-dag-stroom+.be-dag-stroom { margin-top:10px; padding-top:10px; border-top:1px solid #e6ddef; }\n.be-dag-volume { font-size:12px; color:#6c757d; }\n.be-dag-detail { display:flex; flex-wrap:wrap; align-items:baseline; gap:3px 8px; font-size:13px; }\n.be-dag-bedrag { font-weight:600; white-space:nowrap; }\n.be-dag-prijs { color:#6c757d; font-size:11px; white-space:nowrap; }\n.be-dag-onvolledig { font-size:10px; color:#6c757d; }\n@media(max-width:700px) {\n  #be-actueel-resultaat { white-space:normal!important; width:100%; }\n  #be-actueel-resultaat .be-dag-info { flex:1 1 100%; }\n  .be-dag-popup { left:0; right:auto; }\n}\n" +
      '@media (max-width: 700px) and (orientation: portrait){' +
        '#be-actueel-bedieningsrij{' +
          'display:flex!important;' +
          'flex-wrap:wrap!important;' +
          'align-items:stretch!important;' +
          'gap:8px!important;' +
        '}' +
        '#be-actueel-resultaat{' +
          'display:flex!important;' +
          'flex:1 1 100%!important;' +
          'width:100%!important;' +
          'min-width:0!important;' +
          'white-space:normal!important;' +
          'flex-wrap:wrap!important;' +
          'gap:6px 10px!important;' +
        '}' +
        '#be-actueel-resultaat>span:last-child{' +
          'flex:1 1 100%!important;' +
        '}' +
        '.be-actueel-toggle{' +
          'width:100%!important;' +
          'margin-left:0!important;' +
          'padding:9px 2px 1px!important;' +
          'border-left:0!important;' +
          'border-top:1px solid ' + D.rand + '!important;' +
          'justify-content:flex-end!important;' +
        '}' +
      '}';

    (
      document.head ||
      document.documentElement
    ).appendChild(
      stijl
    );
  }

    function actueelZorgBedieningsRij() {
      if (!isActueelPagina()) {
        return null;
      }

      var legenda =
        actueelLegenda();

      if (!legenda) {
        return null;
      }

      var rij =
        document.getElementById(
          'be-actueel-bedieningsrij'
        );

      if (!rij) {
        rij =
          document.createElement(
            'div'
          );

        rij.id =
          'be-actueel-bedieningsrij';
      }

      rij.style.cssText =
        'display:flex;' +
        'align-items:center;' +
        'width:100%;' +
        'box-sizing:border-box;' +
        'gap:16px;' +
        'margin-top:10px;' +
        'padding:9px 12px;' +
        'min-height:42px;' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:10px;' +
        'background:#fff;' +
        'box-shadow:0 1px 4px rgba(107,63,160,.05);' +
        'font-size:12px;' +
        'line-height:1.2;' +
        'color:' +
        D.inkt +
        ';flex:0 0 100%;' +
        'grid-column:1 / -1;';

      /*
       * Gebruik het BESTAANDE resultaat als dat er al is.
       * Zo ontstaan geen twee elementen met hetzelfde ID.
       */
      var resultaten =
        document.querySelectorAll(
          '#be-actueel-resultaat'
        );

      var info =
        resultaten.length
          ? resultaten[0]
          : null;

      /*
       * Eventuele dubbele oude resultaat-elementen opruimen.
       */
      for (
        var i = 1;
        i < resultaten.length;
        i++
      ) {
        resultaten[i].remove();
      }

      if (!info) {
        info =
          document.createElement(
            'div'
          );

        info.id =
          'be-actueel-resultaat';

        info.setAttribute(
          'data-be-vandaag-info',
          '1'
        );
      }

      info.style.cssText =
        'display:flex;' +
        'align-items:center;' +
        'gap:11px;' +
        'white-space:nowrap;' +
        'min-width:0;' +
        'flex:1 1 auto;' +
        'font-variant-numeric:tabular-nums;';

      /*
       * Resultaat MOET links IN onze balk staan.
       */
      if (
        info.parentElement !==
        rij
      ) {
        rij.insertBefore(
          info,
          rij.firstChild
        );
      }

      /*
       * Balk MOET als volledige regel IN de Balans-legenda staan.
       */
      if (
        rij.parentElement !==
        legenda
      ) {
        legenda.appendChild(
          rij
        );
      }

      return rij;
    }

  function actueelTekenSchakelaar(b) {
    b =
      b ||
      document.querySelector(
        '[data-be-actueel-allin]'
      );

    if (!b) {
      return;
    }

    b.setAttribute(
      'aria-pressed',
      actueelAan
        ? 'true'
        : 'false'
    );

    b.title =
      actueelAan
        ? 'All-in prijzen uitschakelen'
        : 'All-in prijzen inschakelen';

    var track =
      b.querySelector(
        '[data-be-track]'
      );

    var thumb =
      b.querySelector(
        '[data-be-thumb]'
      );

    var status =
      b.querySelector(
        '[data-be-status]'
      );

    if (track) {
      track.style.background =
        actueelAan
          ? D.paars
          : '#9ca3af';
    }

    if (thumb) {
      thumb.style.transform =
        actueelAan
          ? 'translateX(16px)'
          : 'translateX(0)';
    }

    if (status) {
      status.textContent =
        actueelAan
          ? 'AAN'
          : 'UIT';
    }
  }

  function actueelZetAan(
    nieuweStand,
    b
  ) {
    actueelAan =
      !!nieuweStand;

    localStorage.setItem(
      LS.actueelAllin,
      actueelAan
        ? 'aan'
        : 'uit'
    );

    actueelTekenSchakelaar(
      b
    );

    actueelStuur();

    /* De tariefgrafiek toont dezelfde prijzen, dus die kantelt mee. */
    tariefStuur();

    actueelWerkSchemaBij();

    actueelZetVoetnoot();
    actueelProjectieToon();

    if (actueelAan) {
      actueelHaal();
    }

    console.log(
      '[BE Actueel all-in] plugin',
      actueelAan
        ? 'aan'
        : 'uit'
    );
  }

    function actueelBouwSchakelaar() {
      var rij =
        actueelZorgBedieningsRij();

      if (!rij) {
        return;
      }

      var b =
        document.querySelector(
          '[data-be-actueel-allin]'
        );

      if (!b) {
        b =
          document.createElement(
            'button'
          );

        b.type =
          'button';

        b.dataset.beActueelAllin =
          '1';

        b.className =
          'be-actueel-toggle';

        b.innerHTML =
          '<span>All-in prijzen</span>' +

          '<span data-be-track style="' +
            'position:relative;' +
            'display:inline-block;' +
            'width:34px;' +
            'height:18px;' +
            'border-radius:999px;' +
            'flex-shrink:0;' +
            'transition:background .18s ease;' +
          '">' +

            '<span data-be-thumb style="' +
              'position:absolute;' +
              'left:2px;' +
              'top:2px;' +
              'width:14px;' +
              'height:14px;' +
              'border-radius:50%;' +
              'background:#fff;' +
              'box-shadow:0 1px 3px rgba(0,0,0,.35);' +
              'transition:transform .18s ease;' +
            '">' +
            '</span>' +

          '</span>' +

          '<span data-be-status style="' +
            'min-width:24px;' +
            'font-size:10px;' +
            'font-weight:700;' +
            'line-height:1;' +
          '">' +
          '</span>';

        b.addEventListener(
          'click',
          function () {
            actueelZetAan(
              !actueelAan,
              b
            );
          }
        );
      }

      b.className =
        'be-actueel-toggle';

      b.style.cssText =
        'appearance:none;' +
        '-webkit-appearance:none;' +
        'display:flex;' +
        'align-items:center;' +
        'gap:8px;' +
        'width:auto;' +
        'height:auto;' +
        'cursor:pointer;' +
        'border:0;' +
        'border-left:1px solid ' +
        D.rand +
        ';background:transparent;' +
        'padding:3px 2px 3px 14px;' +
        'margin-left:auto;' +
        'flex:0 0 auto;' +
        'white-space:nowrap;' +
        'color:' +
        D.inkt +
        ';font:inherit;' +
        'box-shadow:none;';

      /*
       * Toggle hoort ALTIJD rechts in onze eigen rij.
       *
       * Normaal gebeurt hier niets.
       * Alleen een foutief geplaatste/oude toggle wordt één keer
       * naar de juiste plek verplaatst.
       */
      if (
        b.parentElement !==
        rij
      ) {
        rij.appendChild(
          b
        );
      }

      actueelTekenSchakelaar(
        b
      );
    }

  var ACTUEEL_NOOT_ALLIN =
    'All-in prijzen per kWh: ' +
    'kale prijs × 1,21, ' +
    'plus € 0,02 leverkosten en ' +
    '€ 0,11085 energiebelasting incl. btw. ' +
    'Lopende kwartieren (ISP) zijn een schatting ' +
    'en worden ongeveer twee minuten na afloop vastgesteld.';

  var ACTUEEL_NOOT_KAAL =
    'Kale prijzen per kWh: ' +
    'actuele onbalans-, aFRR- of dynamische prijs zonder btw, ' +
    'leverkosten en energiebelasting. ' +
    'Lopende kwartieren (ISP) zijn een schatting ' +
    'en worden ongeveer twee minuten na afloop vastgesteld.';

  function actueelZetVoetnoot() {
    if (!isActueelPagina()) {
      return;
    }

    var n =
      document.querySelector(
        'p.current-price-note'
      );

    if (!n) {
      return;
    }

    var tekst =
      actueelAan
        ? ACTUEEL_NOOT_ALLIN
        : ACTUEEL_NOOT_KAAL;

    if (
      n.textContent !==
      tekst
    ) {
      n.textContent =
        tekst;
    }

    n.style.color =
      actueelAan
        ? D.paars
        : D.grijs;
  }

  function actueelVolgVoetnoot() {
    if (actueelVoetnootTimer) {
      return;
    }

    /*
     * Geen MutationObserver op document.body:
     * Balans en de plugin kunnen anders elkaars tekstwijzigingen
     * direct blijven terugschrijven en zo de pagina blokkeren.
     * Een rustige timer houdt de voetnoot wel netjes actueel.
     */
    actueelVoetnootTimer =
      setInterval(
        function () {
          if (isActueelPagina()) {
            actueelZetVoetnoot();
          }
        },
        500
      );
  }


  /* Actueel: voorlopig variabel stroomresultaat over de grafiekperiode.
   * Netaansluiting is gemeten in W; positief = import, negatief = export.
   * Integreer lineair tussen metingen, gesplitst op prijsgrenzen en nul.
   * Geen extrapolatie voorbij de laatste meting; hiaten blijven zichtbaar.
   */
  function actueelProjectieBereken(punten, prijzen, vanaf, tot, nu, gesorteerd) {
    var uit = { bedrag: 0, importKwh: 0, exportKwh: 0, gedekt: 0,
      inkoopEur: 0, verkoopEur: 0,
      resultaatImportEur: 0, resultaatExportEur: 0,
      ouder: 0, recent: 0, huidig: 0, stukken: 0,
      bronVanaf: vanaf, bronTot: tot, gaten: 0, ongeldig: false };
    var kwartier = 15 * 60 * 1000;
    var huidigStart = Math.floor(nu / kwartier) * kwartier;
    var reeks = gesorteerd ? punten : punten.filter(function (p) {
      return p && Number.isFinite(p.x) && Number.isFinite(p.y);
    }).slice().sort(function (a, b) { return a.x - b.x; });
    // Ignore points outside the integration window, retaining the adjacent
    // observations on either side. Original gap and zero-crossing rules stay.
    function ondergrens(t) {
      var l=0,h=reeks.length;
      while(l<h){var m=(l+h)>>>1;if(reeks[m].x<t)l=m+1;else h=m;}
      return l;
    }
    var eerste=Math.max(0,ondergrens(vanaf)-1),laatste=Math.min(reeks.length,ondergrens(tot)+1);
    reeks=reeks.slice(eerste,laatste);
    // Meter totals are independent of tariff availability. Split sign changes
    // before integrating, so simultaneous daily import/export never cancel out.
    var gemetenImport = 0, gemetenExport = 0, gemetenMs = 0;
    for (var mi = 1; mi < reeks.length; mi++) {
      var ma = reeks[mi - 1], mb = reeks[mi], md = mb.x - ma.x;
      if (md <= 0 || md > 300000) continue;
      var ml = Math.max(ma.x, vanaf), mr = Math.min(mb.x, tot, nu);
      if (mr <= ml) continue;
      gemetenMs += mr - ml;
      var mc = [ml, mr];
      if (ma.y * mb.y < 0) {
        var mz = ma.x + md * (-ma.y) / (mb.y - ma.y);
        if (mz > ml && mz < mr) mc.splice(1, 0, mz);
      }
      for (var mk = 1; mk < mc.length; mk++) {
        var mx = mc[mk - 1], my = mc[mk];
        var mw1 = ma.y + (mb.y - ma.y) * (mx - ma.x) / md;
        var mw2 = ma.y + (mb.y - ma.y) * (my - ma.x) / md;
        var me = (mw1 + mw2) / 2 * (my - mx) / 3600000000;
        gemetenImport += Math.max(0, me);
        gemetenExport += Math.max(0, -me);
      }
    }
    var ps = prijzen.filter(function (p) {
      return Number.isFinite(p.start) && Number.isFinite(p.end) && p.end > p.start;
    }).slice().sort(function (a, b) { return a.start - b.start; });
    for (var z = 1; z < ps.length; z++) {
      if (ps[z].start < ps[z - 1].end && ps[z].start < tot && ps[z - 1].end > vanaf) {
        uit.ongeldig = true;
        return uit;
      }
    }
    var gedektTot = null;
    var pi = 0;
    for (var i = 1; i < reeks.length; i++) {
      var a = reeks[i - 1], b = reeks[i];
      var duur = b.x - a.x;
      if (duur === 0 && a.y !== b.y && a.x >= vanaf && a.x < tot) uit.ongeldig = true;
      if (duur <= 0 || duur > 5 * 60 * 1000) continue;
      var links = Math.max(a.x, vanaf), rechts = Math.min(b.x, tot, nu);
      if (rechts <= links) continue;
      while (pi < ps.length && ps[pi].end <= links) pi++;
      for (var j = pi; j < ps.length && ps[j].start < rechts; j++) {
        var prijsRij = ps[j];
        var l = Math.max(links, prijsRij.start), r = Math.min(rechts, prijsRij.end);
        if (r <= l) continue;
        var grenzen = [l, r];
        if (a.y * b.y < 0) {
          var nul = a.x + duur * (-a.y) / (b.y - a.y);
          if (nul > l && nul < r) grenzen.push(nul);
        }
        for (var q = (Math.floor(l / kwartier) + 1) * kwartier; q < r; q += kwartier) {
          grenzen.push(q);
        }
        grenzen.sort(function (x, y) { return x - y; });
        for (var k = 1; k < grenzen.length; k++) {
          var x = grenzen[k - 1], y = grenzen[k];
          var w1 = a.y + (b.y - a.y) * (x - a.x) / duur;
          var w2 = a.y + (b.y - a.y) * (y - a.x) / duur;
          var energie = ((w1 + w2) / 2) * (y - x) / 3600000000;
          var exp = energie < 0;
          var kaal = exp ? prijsRij.ke : prijsRij.ki;
          if (!Number.isFinite(kaal)) continue;
          if(exp ? prijsRij.historischExport : prijsRij.historischImport)
            uit.historischKwh=(uit.historischKwh||0)+Math.abs(energie);
          var balansPrijs =
            exp
              ? (
                  kaal * BTW -
                  OPSLAG
                )
              : (
                  kaal * BTW +
                  OPSLAG
                );

          if (exp) {
            uit.verkoopEur +=
              -energie *
              balansPrijs;

          } else {
            uit.inkoopEur +=
              energie *
              balansPrijs;
          }

          var prijsVoorResultaat =
            actueelAan
              ? actueelAllin(
                  kaal,
                  exp
                )
              : kaal;

          var bedrag =
            -energie *
            prijsVoorResultaat;
          var slot = Math.floor(x / kwartier) * kwartier;
          var groep = slot >= huidigStart ? 'huidig'
            : slot + kwartier <= nu - 20 * 60 * 1000 ? 'ouder' : 'recent';
          uit[groep] += bedrag;
          uit.bedrag += bedrag;
          if (exp) {
            uit.resultaatExportEur += bedrag;
          } else {
            uit.resultaatImportEur -= bedrag;
          }
          uit.importKwh += Math.max(0, energie);
          uit.exportKwh += Math.max(0, -energie);
          if (gedektTot !== null && x > gedektTot) uit.gaten++;
          gedektTot = y;
          uit.gedekt += y - x;
          uit.stukken++;
        }
      }
    }
    uit.geprijsdeImportKwh = uit.importKwh;
    uit.geprijsdeExportKwh = uit.exportKwh;
    uit.ongeprijsdeImportKwh = Math.max(0, gemetenImport - uit.importKwh);
    uit.ongeprijsdeExportKwh = Math.max(0, gemetenExport - uit.exportKwh);
    uit.importKwh = gemetenImport;
    uit.exportKwh = gemetenExport;
    uit.gemetenMs = gemetenMs;
    uit.prijsOnvolledig = uit.ongeprijsdeImportKwh + uit.ongeprijsdeExportKwh > 0.000001;
    return uit;
  }

  // Bedragen en gemiddelden gebruiken dezelfde tariefstand als het dagsaldo.
  function actueelResultaatHtml(res, aan) {
    function getal(n, decimalen) {
      return n.toLocaleString('nl-NL', {
        minimumFractionDigits: decimalen,
        maximumFractionDigits: decimalen
      });
    }
    function geld(n) {
      return (n < 0 ? '− ' : '+ ') + '€ ' + getal(Math.abs(n), 2);
    }
    function kleur(n) {
      return n < 0 ? '#dc3545' : '#198754';
    }
    function stroom(exportStroom) {
      var kwh = exportStroom ? res.exportKwh : res.importKwh;
      var geprijsd = exportStroom ? res.geprijsdeExportKwh : res.geprijsdeImportKwh;
      var ongeprijsd = exportStroom ? res.ongeprijsdeExportKwh : res.ongeprijsdeImportKwh;
      var kosten = exportStroom ? res.resultaatExportEur : res.resultaatImportEur;
      var bedrag = exportStroom ? kosten : -kosten;
      var bekend = geprijsd > 0 || kwh === 0;
      var gedeeltelijk = ongeprijsd > 0.000001;
      var gemiddelde = geprijsd > 0 ? '€ ' + getal(kosten / geprijsd, 3) : '—';
      return '<span class="be-dag-stroom">' +
        '<span class="be-dag-volume">' + getal(kwh, 1) + ' kWh ' +
          (exportStroom ? 'export' : 'import') + '</span>' +
        '<span class="be-dag-detail">' +
          '<span class="be-dag-bedrag" style="color:' + (bekend ? kleur(bedrag) : '#6c757d') + '">' +
            (bekend ? geld(bedrag) : '—') + '</span>' +
          '<span class="be-dag-prijs">gem. ' + gemiddelde + '/kWh</span>' +
        '</span>' +
        (gedeeltelijk ? '<span class="be-dag-onvolledig">' +
          (bekend ? 'deels geprijsd' : 'prijzen ontbreken') + '</span>' : '') +
      '</span>';
    }
    return '<span class="be-dag-label">Resultaat vandaag</span>' +
      '<span class="be-dag-saldo" style="color:' + kleur(res.bedrag) + '">' +
        (res.stukken ? geld(res.bedrag) : '— · prijzen ontbreken') + '</span>' +
      '<details class="be-dag-info">' +
        '<summary aria-label="Details import en export">' +
          getal(res.importKwh, 1) + ' kWh import · ' + getal(res.exportKwh, 1) +
          ' kWh export <span class="be-dag-info-icoon" aria-hidden="true">ⓘ</span>' +
        '</summary>' +
        '<div class="be-dag-popup">' +
          '<div class="be-dag-popup-kop">Vandaag · ' + (aan ? 'all-in' : 'kaal') + '</div>' +
          stroom(false) + stroom(true) +
        '</div>' +
      '</details>';
  }

  // Native details ondersteunt tikken en Enter/Spatie, hover is alleen voor muizen.
  function actueelResultaatInfoBediening() {
    if (document.__beDagInfoBediening) return;
    document.__beDagInfoBediening = true;
    document.addEventListener('pointerdown', function (event) {
      var info = document.querySelector('#be-actueel-resultaat .be-dag-info');
      if (info && !info.contains(event.target)) { info.open = false; delete info.dataset.pinned; }
    });
    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') return;
      var info = document.querySelector('#be-actueel-resultaat .be-dag-info');
      if (!info) return;
      info.open = false;
      delete info.dataset.pinned;
      info.setAttribute('data-dismissed', '1');
    });
    document.addEventListener('pointerover', function (event) {
      var info = event.target.closest && event.target.closest('.be-dag-info');
      if (info && !info.contains(event.relatedTarget)) {
        info.removeAttribute('data-dismissed');
        if (event.pointerType === 'mouse' && matchMedia('(hover:hover)').matches) info.open = true;
      }
    });
    document.addEventListener('pointerout', function (event) {
      var info = event.target.closest && event.target.closest('.be-dag-info');
      if (info && event.pointerType === 'mouse' && !info.dataset.pinned && !info.contains(event.relatedTarget)) info.open = false;
    });
    document.addEventListener('click', function (event) {
      var info = event.target.closest && event.target.closest('.be-dag-info');
      if (!info || !event.target.closest('summary')) return;
      event.preventDefault();
      var openen = info.dataset.pinned !== '1';
      info.open = openen;
      if (openen) {
        info.dataset.pinned = '1';
        info.removeAttribute('data-dismissed');
      } else {
        delete info.dataset.pinned;
        info.setAttribute('data-dismissed', '1');
      }
    });
  }

    function actueelProjectieToon() {
      if (!isActueelPagina()) {
        return;
      }

      var bestaand =
        actueelZorgBedieningsRij();

      if (!bestaand) {
        return;
      }

      var info =
        document.getElementById(
          'be-actueel-resultaat'
        );

      if (!info) {
        return;
      }

      /*
       * Het dagresultaat blijft altijd zichtbaar.
       * Toggle AAN = all-in resultaat.
       * Toggle UIT = kaal resultaat.
       */
      info.hidden = false;


    var nu =
      Date.now();

    var vorig = actueelDagBerekening;
    var punten = vorig && vorig.bron === actueelDagPunten ? vorig.punten :
      actueelDagPunten
        .filter(
          function (p) {
            return (
              p &&
              Number.isFinite(p.x) &&
              Number.isFinite(p.y)
            );
          }
        );
      if (punten.length < 2) {
        info.__beResultaatTekst = null;
        info.textContent =
          actueelAan
            ? 'Voorlopig all-in resultaat — wachten op meetgegevens.'
            : 'Voorlopig kaal resultaat — wachten op meetgegevens.';

        return;
      }
    var beginVandaag =
      new Date();

    beginVandaag.setHours(
      0,
      0,
      0,
      0
    );

    var vanaf =
      beginVandaag.getTime();

    var tot =
      Math.min(
        nu,
        punten[
          punten.length - 1
        ].x
      );

    // Reuse the same measured-day result between source changes. Both time
    // buckets matter: a completed quarter becomes 'older' after 20 minutes.
    var klok = Math.floor(nu / 900000) + ':' + Math.floor((nu - 1200000) / 900000);
    var gelijk = vorig && vorig.bron === actueelDagPunten && vorig.prijzen === actueelRijen &&
      vorig.klant === KLANT && vorig.aan === actueelAan && vorig.vanaf === vanaf &&
      vorig.tot === tot && vorig.klok === klok;
    var res = gelijk ? vorig.res : actueelProjectieBereken(punten, actueelRijen, vanaf, tot, nu);
    if (!gelijk) actueelDagBerekening = {
      bron: actueelDagPunten, punten: punten, prijzen: actueelRijen, klant: KLANT,
      aan: actueelAan, vanaf: vanaf, tot: tot, klok: klok, res: res
    };
    bewaarVoorlopigeDag(
      iso(beginVandaag),
      res,
      vanaf,
      tot
    );

    if (res.ongeldig || !(res.gemetenMs > 0)) {
      info.__beResultaatTekst = null;
      info.textContent = 'Resultaat vandaag — nog geen passende metingen en prijzen';
      return;
    }

    var tekst = actueelResultaatHtml(res, actueelAan);

    info.title = res.prijsOnvolledig
      ? 'Voorlopig bedrag. Tarief ontbreekt voor ' +
        (res.ongeprijsdeImportKwh + res.ongeprijsdeExportKwh).toLocaleString('nl-NL', {maximumFractionDigits:2}) + ' kWh.'
      : res.historischKwh > 0.000001 ? 'Voorlopig bedrag met herstelde historische tarieven.' : '';

    if (
      info.__beResultaatTekst !== tekst
    ) {
      var vorigeInfo = info.querySelector('.be-dag-info');
      var wasOpen = vorigeInfo && vorigeInfo.open;
      var wasPinned = vorigeInfo && vorigeInfo.dataset.pinned;
      var hadFocus = vorigeInfo && vorigeInfo.contains(document.activeElement);
      info.innerHTML = tekst;
      var nieuweInfo = info.querySelector('.be-dag-info');
      if (nieuweInfo) {
        nieuweInfo.open = !!wasOpen;
        if (wasPinned) nieuweInfo.dataset.pinned = wasPinned;
        if (hadFocus) nieuweInfo.querySelector('summary').focus({ preventScroll: true });
      }
      actueelResultaatInfoBediening();
      info.__beResultaatTekst = tekst;
      if(beDarkOn)window.BETheme.refresh(info);
    }
  }

  function actueelOnderhoud() {
    verversKlantUitPad();

    var nieuweKlant =
      !!KLANT &&
      KLANT !==
        actueelLaatsteKlant;

    var nuActueel =
      isActueelPagina();

    if (!nuActueel) {
      actueelWasPagina =
        false;

      if (actueelVoetnootTimer) {
        clearInterval(
          actueelVoetnootTimer
        );

        actueelVoetnootTimer =
          null;
      }

      return;
    }

    actueelInstalleerBridge();

    actueelBouwSchakelaar();

    actueelTekenDagEnergie();

    tariefZorgKnop();

    actueelProjectieToon();

    actueelZetVoetnoot();

    actueelVolgVoetnoot();

    actueelVolgSchema();

    actueelWerkSchemaBij();

    if (
      !actueelWasPagina ||
      nieuweKlant
    ) {
      actueelWasPagina =
        true;

      actueelLaatsteKlant =
        KLANT;

      actueelStuur();

      if (!actueelRijen.length) {
        actueelHaal();
      }

      actueelHaalDagPunten();

      tariefStuur();
    }
  }

  function startActueelAllin() {
    if (actueelGestart) {
      return;
    }

    actueelGestart =
      true;

    actueelVoegMobieleStijlToe();

    actueelOnderhoud();

    actueelOnderhoudTimer =
      setInterval(
        function () {
          actueelOnderhoud();
        },
        3000
      );

    setInterval(function () {
      if (isActueelPagina()) actueelHaal();
    }, 15000);
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden && isActueelPagina()) actueelHaal();
    });
    actueelHaalTimer =
      setInterval(
        function () {
          if (
            isActueelPagina()
          ) {
            actueelHaalDagPunten();
          }
        },
        30000
      );

    if (isActueelPagina()) {
      actueelInstalleerBridge();

      actueelStuur();

      var pogingen = 0;

      var wacht =
        setInterval(
          function () {
            pogingen++;

            actueelOnderhoud();

            if (
              actueelLegenda() &&
              document.getElementById(
                'battery-chart'
              )
            ) {
              clearInterval(
                wacht
              );

              actueelHaal();
              actueelHaalDagPunten();

            } else if (
              pogingen > 120 ||
              !isActueelPagina()
            ) {
              clearInterval(
                wacht
              );
            }
          },
          500
        );
    }
  }


  var voorlopigResultatenBezig = false;
  var voorlopigResultatenLaatst = 0;

  function resultatenHaalVoorlopigeDagen(voorOverzicht) {
    if (
      (!voorOverzicht && location.pathname.indexOf(
        '/results'
      ) === -1) ||
      !KLANT
    ) {
      return Promise.resolve(
        false
      );
    }

    var nu =
      Date.now();

    if (
      voorlopigResultatenBezig ||
      nu -
        voorlopigResultatenLaatst <
        30000
    ) {
      return Promise.resolve(
        false
      );
    }

    voorlopigResultatenBezig =
      true;

    voorlopigResultatenLaatst =
      nu;

    /*
     * Vandaag plus de laatste vier kalenderdagen controleren.
     *
     * Belangrijk:
     * - Echte maanddata wint altijd.
     * - Ook opgeslagen voorlopige dagen worden opnieuw gecontroleerd.
     * - Vandaag mag wel blijven verversen zolang hij nog provisional is.
     * - Ontbrekende dagen worden uitsluitend uit gedateerde historie en prijzen gereconstrueerd.
     */
    var beginBereik =
      new Date();

    beginBereik.setHours(
      0,
      0,
      0,
      0
    );

    beginBereik.setDate(
      beginBereik.getDate() - 4
    );

    var dagKeys = [];
    var maanden = {};

    var cursor =
      new Date(
        beginBereik.getTime()
      );

    var vandaag =
      new Date();

    vandaag.setHours(
      0,
      0,
      0,
      0
    );

    var vandaagKey =
      iso(vandaag);

    while (
      cursor.getTime() <=
      vandaag.getTime()
    ) {
      var key =
        iso(cursor);

      dagKeys.push(
        key
      );

      maanden[
        key.slice(0, 7)
      ] = true;

      cursor.setDate(
        cursor.getDate() + 1
      );
    }

    var maandControles =
      Promise.all(
        Object.keys(maanden)
          .map(
            function (mk) {
              var m =
                new URL(
                  location.origin +
                    '/customer/' +
                    KLANT +
                    '/results-v2-api/'
                );

              m.searchParams.set(
                'interval',
                'month'
              );

              m.searchParams.set(
                'period',
                mk
              );

              m.searchParams.set(
                'include_vat',
                '1'
              );

              m.searchParams.set(
                'include_delivery_cost',
                '1'
              );

              return beHaalBron(
                m,
                {
                  credentials:
                    'same-origin',

                  cache:
                    'no-store'
                }
              )
                .then(
                  function (r) {
                    return r.ok
                      ? r.json()
                      : null;
                  }
                )
                .then(
                  function (j) {
                    return {
                      key:
                        mk,

                      data:
                        j
                    };
                  }
                )
                .catch(
                  function () {
                    return {
                      key:
                        mk,

                      data:
                        null
                    };
                  }
                );
            }
          )
      );

    return maandControles
      .then(
        function (maandSets) {
          var opslag =
            leesVoorlopigeDagen();

          var echt = {};
          var gewijzigd = false;

          (maandSets || [])
            .forEach(
              function (set) {
                var j =
                  set &&
                  set.data;

                if (
                  !j || j.interval !== 'month' || j.period !== set.key ||
                  !Array.isArray(
                    j.series
                  )
                ) {
                  return;
                }

                j.series.forEach(
                  function (r) {
                    var k =
                      r &&
                      (
                        r.date ||
                        r.day
                      );

                    if (
                      k && String(k).slice(0, 7) === set.key &&
                      ['import_kwh', 'export_kwh', 'total_buy_eur', 'total_sell_eur'].every(function (f) { return Number.isFinite(r[f]); }) &&
                      /^\d{4}-\d{2}-\d{2}$/.test(
                        String(k)
                      )
                    ) {
                      echt[
                        String(k)
                      ] = r;
                    }
                  }
                );
              }
            );

          /*
           * Zodra de echte datum in results-v2-api staat,
           * de lokale provisional meteen opruimen.
           */
          Object.keys(opslag)
            .forEach(
              function (k) {
                if (echt[k]) {
                  bewaarVoorlopigeAudit(
                    k,
                    opslag[k],
                    echt[k]
                  );

                  delete opslag[k];
                  gewijzigd = true;
                }
              }
            );

          if (gewijzigd) {
            schrijfVoorlopigeDagen(
              opslag
            );
          }

          var kandidaten =
            dagKeys.filter(
              function (k) {
                if (echt[k]) {
                  return false;
                }

                return true;
              }
            );

          if (!kandidaten.length) {
            return gewijzigd;
          }

          // Bestaande, bewezen snapshots blijven tijdens opnieuw ophalen behouden.
          schrijfVoorlopigeDagen(opslag);
          // Geef verwijderde resultaten direct door, ook wanneer herladen mislukt.
          gewijzigd = true;
          if (laatste) plan();

          var dagApi = Promise.resolve(kandidaten.map(function (key) {
            return { key: key, data: null };
          }));

          return dagApi
            .then(
              function (dagResultaten) {
                var fallbackKeys = [];
                var veranderd =
                  gewijzigd;

                (dagResultaten || [])
                  .forEach(
                    function (item) {
                      var j =
                        item &&
                        item.data;

                      var dagKey =
                        item &&
                        item.key;

                      var bruikbaar =
                        false;

                      // Dagtotalen alleen zijn geen reproduceerbare kwartierbron.
                      // Gebruik uitsluitend historie + prijzen met exacte tijdstippen.
                      if (
                        dagKey &&
                        !bruikbaar
                      ) {
                        fallbackKeys.push(
                          dagKey
                        );
                      }
                    }
                  );

                if (!fallbackKeys.length) {
                  return veranderd;
                }

                var eerste =
                  new Date(
                    fallbackKeys[0] +
                      'T00:00:00'
                  );

                fallbackKeys.forEach(
                  function (k) {
                    var d =
                      new Date(
                        k +
                          'T00:00:00'
                      );

                    if (
                      d.getTime() <
                      eerste.getTime()
                    ) {
                      eerste = d;
                    }
                  }
                );

                var u =
                  new URL(
                    location.origin +
                      '/customer/current-history/api/'
                  );

                u.searchParams.set(
                  'installation',
                  KLANT
                );

                u.searchParams.set(
                  'start',
                  String(
                    eerste.getTime()
                  )
                );

                u.searchParams.set(
                  'end',
                  String(nu)
                );

                var prijzen =
                  beHaalBron(
                    location.origin +
                      '/customer/current-prices/api/',
                    {
                      credentials:
                        'same-origin',

                      cache:
                        'no-store'
                    }
                  ).then(
                    function (r) {
                      return r.ok
                        ? r.json()
                        : null;
                    }
                  );

                // Vraag iedere dag apart op: een groot bereik kan door de API
                // worden begrensd, waardoor de recente dagen ontbreken.
                var historie = Promise.all(fallbackKeys.map(function (key) {
                  var grenzen = voorlopigeDagGrenzen(key);
                  var dagUrl = new URL('/customer/current-history/api/', location.origin);
                  dagUrl.searchParams.set('installation', KLANT);
                  dagUrl.searchParams.set('start', String(grenzen.start));
                  dagUrl.searchParams.set('end', String(Math.min(nu, grenzen.eind)));
                  return beHaalBron(dagUrl.href, { credentials: 'same-origin', cache: 'no-store' })
                    .then(function (r) { return r.ok ? r.json() : null; })
                    .then(function (j) {
                      return j && Array.isArray(j.rows) ? j.rows.filter(function (r) {
                        return r && Number.isFinite(r.t) && r.t >= grenzen.start &&
                          r.t <= Math.min(nu, grenzen.eind) && Number.isFinite(r.po);
                      }) : [];
                    }).catch(function () { return []; });
                })).then(function (dagen) {
                  var perTijd = new Map();
                  dagen.forEach(function (rijen) { rijen.forEach(function (r) { perTijd.set(r.t, r); }); });
                  return { rows: Array.from(perTijd.values()) };
                });

                return Promise.all([
                  prijzen,
                  historie
                ]).then(
                  function (res) {
                    var jp =
                      res[0];

                    var jh =
                      res[1];

                    if (
                      !jp ||
                      !Array.isArray(
                        jp.prices
                      ) ||
                      !jh ||
                      !Array.isArray(
                        jh.rows
                      )
                    ) {
                      return veranderd;
                    }

                    var evts = {};

                    (
                      jp.afrrEventIsps || []
                    ).forEach(
                      function (t) {
                        evts[t] = true;
                      }
                    );

                    var prijsRijen = jp.prices.map(actueelPrijsRij)
                      .filter(function(r){return Number.isFinite(r.ki)||Number.isFinite(r.ke);});

                    var punten =
                      jh.rows
                        .filter(
                          function (r) {
                            return (
                              r &&
                              Number.isFinite(r.t) &&
                              Number.isFinite(r.po)
                            );
                          }
                        )
                        .map(
                          function (r) {
                            return {
                              x:
                                r.t,

                              y:
                                r.po
                            };
                          }
                        )
                        .sort(
                          function (a, b) {
                            return a.x - b.x;
                          }
                        );

                    if (
                      punten.length < 2 ||
                      !prijsRijen.length
                    ) {
                      return veranderd;
                    }

                    fallbackKeys.forEach(
                      function (dagKey) {
                        var dag =
                          new Date(
                            dagKey +
                              'T00:00:00'
                          );

                        var volgende =
                          new Date(
                            dag.getTime()
                          );

                        volgende.setDate(
                          volgende.getDate() + 1
                        );

                        var vanaf =
                          dag.getTime();

                        var tot =
                          Math.min(
                            nu,
                            volgende.getTime()
                          );

                        var berekend =
                          actueelProjectieBereken(
                            punten,
                            prijsRijen,
                            vanaf,
                            tot,
                            nu
                          );

                        if (
                          bewaarVoorlopigeDag(
                            dagKey,
                            berekend,
                            vanaf,
                            tot
                          )
                        ) {
                          veranderd =
                            true;
                        }
                      }
                    );

                    return veranderd;
                  }
                );
              }
            );
        }
      )
      .catch(
        function (e) {
          console.warn(
            '[BE Resultaten voorlopig] ophalen mislukt:',
            e.message
          );

          return false;
        }
      )
      .then(
        function (ok) {
          voorlopigResultatenBezig =
            false;

          return ok;
        }
      );
  }


  /*
   * ============================================================
   * RESULTATEN — datalaag
   * ============================================================
   */

  function naarIncl(
    rij,
    pv
  ) {
    var imp =
      getal(
        rij.import_kwh
      );

    var exp =
      getal(
        rij.export_kwh
      );

    var buy =
      getal(
        rij.total_buy_eur
      );

    var sell =
      getal(
        rij.total_sell_eur
      );

    if (!pv.include_vat) {
      buy *= BTW;
      sell *= BTW;
    }

    if (
      !pv.include_delivery_cost
    ) {
      buy +=
        imp * OPSLAG;

      sell -=
        exp * OPSLAG;
    }

    return {
      bronAanwezig: ['import_kwh', 'export_kwh', 'total_buy_eur', 'total_sell_eur'].every(function (k) {
        return Number.isFinite(rij[k]);
      }),
      key:
        rij.month ||
        rij.date ||
        rij.day ||
        null,

      status:
        rij.status ||
        null,

      imp:
        imp,

      exp:
        exp,

      inkoop:
        buy,

      verkoop:
        sell,

      afrrImp:
        getal(
          rij.afrr_import_kwh
        ),

      afrrExp:
        getal(
          rij.afrr_export_kwh
        ),

      laden:
        getal(
          rij.battery_charged_kwh
        ),

      ontladen:
        getal(
          rij.battery_discharged_kwh
        ),

      pv:
        getal(
          rij.pv_estimated_kwh
        ),

      // 6.8.4: alleen een echt geleverd getal telt als bekende opwek.
      pvBekend:
        typeof rij.pv_estimated_kwh === 'number' &&
        isFinite(rij.pv_estimated_kwh),

      afrrVergoeding:
        getal(
          rij.balance_energie_eur
        ) +
        getal(
          rij.deal_customer_share_eur
        ),

      dealsAantal:
        getal(
          rij.deals_count
        ),

      ruwInkoop:
        getal(
          rij.total_buy_eur
        ),

      ruwVerkoop:
        getal(
          rij.total_sell_eur
        ),

      ruwPrijsInk:
        rij.avg_buy_price_eur_per_kwh,

      ruwPrijsVerk:
        rij.avg_sell_price_eur_per_kwh
    };
  }

  var cacheJaar = {};

  function haalJaar(jaar) {
    if (cacheJaar[jaar]) {
      return Promise.resolve(
        cacheJaar[jaar]
      );
    }

    var u =
      new URL(
        location.origin +
        '/customer/' +
        KLANT +
        '/results-v2-api/'
      );

    u.searchParams.set(
      'interval',
      'year'
    );

    u.searchParams.set(
      'period',
      String(jaar)
    );

    u.searchParams.set(
      'include_vat',
      '1'
    );

    u.searchParams.set(
      'include_delivery_cost',
      '1'
    );

    return origFetch(
      u,
      {
        credentials:
          'same-origin'
      }
    )

      .then(
        function (r) {
          return r.ok
            ? r.json()
            : null;
        }
      )

      .then(
        function (j) {
          var rijen =
            (
              j &&
              Array.isArray(
                j.series
              )
            )
              ? j.series.map(
                  function (s) {
                    return naarIncl(
                      s,
                      j.pricing || {}
                    );
                  }
                )
              : [];

          cacheJaar[jaar] =
            rijen;

          return rijen;
        }
      )

      .catch(
        function () {
          cacheJaar[jaar] = [];
          return [];
        }
      );
  }

  var contractCache = null;
  var contractCacheSleutel = '';
  var contractHistorie = [];

  function haalContractjaar() {
    var periode = huidigContract(), vandaag = iso(new Date());
    var sleutel = KLANT + ':' + iso(periode.begin) + ':' + vandaag;
    if (contractCache && contractCacheSleutel === sleutel) return Promise.resolve(contractCache);
    var jaren = {};
    periode.delen.forEach(function(d){jaren[d.key.slice(0,4)]=true;});
    // Vorige kalenderjaren leveren de vergelijkbare maand; originele historie blijft intact.
    periode.delen.forEach(function(d){if(periode.index>0)jaren[String(+d.key.slice(0,4)-1)]=true;});
    return Promise.all(Object.keys(jaren).map(haalJaar)).then(function(sets){
      var op = {};
      sets.forEach(function(rs){rs.forEach(function(r){op[r.key]=r;});});
      contractHistorie = Object.keys(op).sort().filter(function(k){
        return k < vandaag.slice(0,7) && k+'-01' >= iso(cfg.start);
      }).map(function(k){return op[k];});
      return Promise.all(periode.delen.map(function(deel){
        var r = op[deel.key];
        if (deel.van > vandaag) return contractSomDagen([],deel);
        // Alleen gehele afgesloten maanden kunnen veilig uit maandtotalen komen.
        if (deel.dagen === dagenInMaand(deel.key) && deel.key < vandaag.slice(0,7) && r && !r.leeg && r.bronAanwezig!==false) {
          return Object.assign({},r,{contractDeel:deel,contractBekendeDagen:deel.dagen});
        }
        return haalMaandDagen(deel.key).then(function(dagen){return contractSomDagen(dagen.filter(function(d){return d.key<=vandaag;}),deel);});
      }));
    }).then(function(rijen){
      if (iso(huidigContract().begin) === iso(periode.begin)) {
        contractCache=rijen; contractCacheSleutel=sleutel;
      }
      return rijen;
    });
  }

  function grenzen() {
    try {
      var e =
        document.getElementById(
          'results-bounds-data'
        );

      return e
        ? JSON.parse(
            e.textContent
          )
        : null;

    } catch (e) {
      return null;
    }
  }

  var IMP_FACTOR = {
    Jan: 1.00,
    Feb: 0.62,
    Mrt: 0.25,
    Apr: 0.09,
    Mei: 0.02,
    Jun: 0.01,
    Jul: 0.02,
    Aug: 0.03,
    Sep: 0.10,
    Okt: 0.32,
    Nov: 0.57,
    Dec: 0.87
  };

  var EXP_FACTOR = {
    Jan: 0.10,
    Feb: 0.18,
    Mrt: 0.45,
    Apr: 1.00,
    Mei: 1.30,
    Jun: 1.32,
    Jul: 1.18,
    Aug: 0.96,
    Sep: 0.74,
    Okt: 0.28,
    Nov: 0.12,
    Dec: 0.08
  };

  var PROFIEL = {
    Jan: {
      w: 1.00,
      z: 0.00
    },

    Feb: {
      w: 0.72,
      z: 0.00
    },

    Mrt: {
      w: 0.28,
      z: 0.10
    },

    Apr: {
      w: 0.08,
      z: 0.28
    },

    Mei: {
      w: 0.00,
      z: 0.62
    },

    Jun: {
      w: 0.00,
      z: 1.00
    },

    Jul: {
      w: 0.00,
      z: 0.86
    },

    Aug: {
      w: 0.04,
      z: 0.52
    },

    Sep: {
      w: 0.14,
      z: 0.24
    },

    Okt: {
      w: 0.26,
      z: 0.08
    },

    Nov: {
      w: 0.64,
      z: 0.00
    },

    Dec: {
      w: 0.90,
      z: 0.00
    }
  };

  function mk3(mk) {
    return MND_KORT[
      parseInt(
        String(mk)
          .split('-')[1],
        10
      ) - 1
    ];
  }

  function schatKwh(
    mk,
    bekend,
    factoren,
    terugval
  ) {
    var doelF =
      factoren[
        mk3(mk)
      ] || 0.5;

    if (!bekend.length) {
      return (
        terugval *
        doelF
      );
    }

    var gew = 0;
    var som = 0;

    bekend.forEach(
      function (b) {
        var ankerF =
          factoren[
            mk3(b.key)
          ] || 0.1;

        if (
          ankerF < 0.05
        ) {
          return;
        }

        var vergelijkbaar =
          Math.min(
            ankerF,
            doelF
          ) /
          Math.max(
            ankerF,
            doelF
          );

        var g =
          0.3 +
          vergelijkbaar *
          0.7;

        gew += g;

        som +=
          b.waarde *
          (
            doelF /
            ankerF
          ) *
          g;
      }
    );

    return gew > 0
      ? som / gew
      : 0;
  }

  function ankers(
    bedragPerMaand
  ) {
    var bekend =
      Object.keys(
        bedragPerMaand
      ).map(
        function (k) {
          return {
            m:
              mk3(k),

            v:
              bedragPerMaand[k]
          };
        }
      );

    function kies(namen) {
      return bekend.filter(
        function (b) {
          return (
            namen.indexOf(
              b.m
            ) !== -1
          );
        }
      );
    }

    var winterSet =
      kies([
        'Nov',
        'Dec',
        'Jan',
        'Feb'
      ]);

    var zomerSet =
      kies([
        'Mei',
        'Jun',
        'Jul',
        'Aug'
      ]);

    var tussenSet =
      kies([
        'Mrt',
        'Apr',
        'Sep',
        'Okt'
      ]);

    var winter =
      winterSet.length
        ? Math.min.apply(
            null,
            winterSet.map(
              function (b) {
                return b.v;
              }
            )
          )
        : -260;

    var zomer =
      zomerSet.length
        ? Math.max.apply(
            null,
            zomerSet.map(
              function (b) {
                return b.v;
              }
            )
          )
        : 110;

    var tussen =
      tussenSet.length
        ? (
            tussenSet.reduce(
              function (
                a,
                b
              ) {
                return (
                  a +
                  b.v
                );
              },
              0
            ) /
            tussenSet.length
          )
        : 25;

    if (
      tussen < winter
    ) {
      tussen =
        winter + 40;
    }

    if (
      zomer < tussen
    ) {
      zomer =
        tussen + 40;
    }

    return {
      winter:
        winter,

      tussen:
        tussen,

      zomer:
        zomer
    };
  }

  function prognoseBedrag(
    mk,
    a
  ) {
    var p =
      PROFIEL[
        mk3(mk)
      ] || {
        w: 0.25,
        z: 0.20
      };

    return (
      a.tussen -
      (
        a.tussen -
        a.winter
      ) *
      p.w +
      (
        a.zomer -
        a.tussen
      ) *
      p.z
    );
  }

  function salderingReeks(
    rijen,
    metPrognose
  ) {
    var bekendImp = [];
    var bekendExp = [];

    rijen.forEach(
      function (r) {
        if (r.leeg) {
          return;
        }

        if (r.imp > 0) {
          bekendImp.push({
            key:
              r.key,

            waarde:
              r.imp
          });
        }

        if (r.exp > 0) {
          bekendExp.push({
            key:
              r.key,

            waarde:
              r.exp
          });
        }
      }
    );

    var cumImp = 0;
    var cumExp = 0;

    var reeks =
      rijen.map(
        function (r) {
          var geschat =
            !!r.leeg;

          var imp =
            r.imp;

          var exp =
            r.exp;

          if (geschat) {
            if (metPrognose) {
              imp =
                schatKwh(
                  r.key,
                  bekendImp,
                  IMP_FACTOR,
                  150
                );

              exp =
                schatKwh(
                  r.key,
                  bekendExp,
                  EXP_FACTOR,
                  0
                );

            } else {
              imp = 0;
              exp = 0;
            }
          }

          if (geschat && metPrognose && r.contractDeel) {
            var fractie = r.contractDeel.dagen / dagenInMaand(r.key);
            imp *= fractie; exp *= fractie;
          }
          cumImp += imp;
          cumExp += exp;

          return {
            key:
              r.key,

            imp:
              imp,

            exp:
              exp,

            cumImp:
              cumImp,

            cumExp:
              cumExp,

            ongesaldeerd:
              0,

            gesaldeerd:
              exp,

            geschat:
              geschat,

            overgeslagen:
              geschat &&
              !metPrognose,

            naSaldering:
              naSaldering(
                r.key
              )
          };
        }
      );

    var saldImp = 0;
    var saldExp = 0;

    reeks.forEach(
      function (s) {
        if (
          !s.naSaldering
        ) {
          saldImp +=
            s.imp;

          saldExp +=
            s.exp;
        }
      }
    );

    var over =
      Math.max(
        0,
        saldExp -
        saldImp
      );

    for (
      var i =
        reeks.length - 1;

      i >= 0;

      i--
    ) {
      var s =
        reeks[i];

      if (s.naSaldering) {
        s.ongesaldeerd =
          s.exp;

      } else {
        s.ongesaldeerd =
          Math.min(
            s.exp,
            over
          );

        over -=
          s.ongesaldeerd;
      }

      s.gesaldeerd =
        s.exp -
        s.ongesaldeerd;
    }

    return reeks;
  }

  function bereken(
    r,
    expOngesaldeerd,
    dagen
  ) {
    var imp = r.imp;
    var exp = r.exp;

    var onges =
      Math.min(
        getal(
          expOngesaldeerd
        ),
        exp
      );

    var ges =
      Math.max(
        0,
        exp -
        onges
      );

    var balansInk =
      -r.inkoop;

    var balansVerk =
      r.verkoop;

    var balansNetto =
      balansInk +
      balansVerk;

    // Match the priced portion used by Actueel, while retaining all measured kWh.
    var ebImp = r.voorlopig && Number.isFinite(r.geprijsdeImportKwh) ? r.geprijsdeImportKwh : imp;
    var ebExp = r.voorlopig && Number.isFinite(r.geprijsdeExportKwh) ? r.geprijsdeExportKwh : exp;
    var ebTarief = Number.isFinite(r.ebTarief) ? r.ebTarief : ebVoor(r.key);
    var ebInk = -ebImp * ebTarief;
    var ebVerk = Math.max(0, ebExp - onges) * ebTarief;

    var eb =
      ebInk +
      ebVerk;

    var stroom =
      balansNetto +
      eb;

    var vast =
      getal(dagen) *
      vastDag(r.key);

    var allinInk =
      balansInk +
      ebInk;

    var allinVerk =
      balansVerk +
      ebVerk;

    return {
      key:
        r.key,

      imp:
        imp,

      exp:
        exp,

      balansInk:
        balansInk,

      balansVerk:
        balansVerk,

      balansNetto:
        balansNetto,

      eb:
        eb,

      ebInk:
        ebInk,

      ebVerk:
        ebVerk,

      ongesaldeerd:
        onges,

      gesaldeerd:
        ges,

      allinInk:
        allinInk,

      allinVerk:
        allinVerk,

      stroom:
        stroom,

      vast:
        vast,

      voorschot:
        voorschotVoor(
          r.key,
          getal(dagen),
          false
        ),

      totaal:
        stroom +
        vast,

      saldo:
        stroom +
        vast +
        voorschotVoor(
          r.key,
          getal(dagen),
          false
        ),

      dagen:
        getal(dagen),

      prijsInk:
        imp > 0
          ? Math.abs(
              allinInk
            ) / imp
          : 0,

      prijsVerk:
        exp > 0
          ? allinVerk / exp
          : 0,

      prijsInkBalans:
        imp > 0
          ? r.inkoop / imp
          : 0,

      prijsVerkBalans:
        exp > 0
          ? r.verkoop / exp
          : 0,

      laden:
        r.laden,

      ontladen:
        r.ontladen,

      pv:
        r.pv,

      afrrImp:
        r.afrrImp,

      afrrExp:
        r.afrrExp,

      afrrVergoeding:
        r.afrrVergoeding,

      dealsAantal:
        r.dealsAantal,

      geschat:
        !!r.leeg
    };
  }

  function fpr(rijen) {
    if (
      !rijen ||
      !rijen.length
    ) {
      return null;
    }

    var laad = 0;
    var ont = 0;
    var laadKwh = 0;
    var ontKwh = 0;
    var meegeteld = 0;

    rijen.forEach(
      function (a) {
        if (
          !a.laden &&
          !a.ontladen
        ) {
          return;
        }

        if (
          !a.prijsInk &&
          !a.prijsVerk
        ) {
          return;
        }

        var viaNet =
          Math.min(
            a.exp,
            a.ontladen
          );

        var viaHuis =
          Math.max(
            0,
            a.ontladen -
            viaNet
          );

        laad +=
          a.laden *
          a.prijsInk;

        ont +=
          viaNet *
          a.prijsVerk +
          viaHuis *
          a.prijsInk;

        laadKwh +=
          a.laden;

        ontKwh +=
          a.ontladen;

        meegeteld++;
      }
    );

    if (laad <= 0) {
      return null;
    }

    return {
      ratio:
        ont / laad,

      laadKwh:
        laadKwh,

      ontlaadKwh:
        ontKwh,

      gemLaad:
        laadKwh > 0
          ? laad / laadKwh
          : 0,

      gemOntlaad:
        ontKwh > 0
          ? ont / ontKwh
          : 0,

      netto:
        ont - laad,

      retour:
        laadKwh > 0
          ? ontKwh / laadKwh
          : 0,

      perioden:
        meegeteld
    };
  }

  function regel(
    label,
    waarde,
    o
  ) {
    o = o || {};

    var kl =
      o.neutraal
        ? D.inkt
        : kleur(
            waarde
          );

    var fs =
      o.groot
        ? '15.5px'
        : '12.5px';

    var streep =
      o.streep
        ? (
            'border-top:1px solid ' +
            D.rand +
            ';margin-top:8px;' +
            'padding-top:9px;'
          )
        : '';

    var sub =
      o.sub
        ? (
            '<div style="' +
            'font-size:10.5px;' +
            'color:' +
            D.grijs +
            ';margin-top:2px;' +
            'line-height:1.4;' +
            '">' +
            o.sub +
            '</div>'
          )
        : '';

    return (
      '<div style="' +
      'display:flex;' +
      'justify-content:space-between;' +
      'align-items:baseline;' +
      'gap:16px;' +
      'padding:4px 0;' +
      streep +
      '">' +

        '<div style="' +
        'font-size:' +
        fs +
        ';font-weight:' +
        (
          o.dik
            ? '600'
            : '400'
        ) +
        ';color:' +
        (
          o.dik
            ? D.inkt
            : '#4a4453'
        ) +
        ';">' +
        label +
        sub +
        '</div>' +

        '<div style="' +
        'font-size:' +
        fs +
        ';font-weight:' +
        (
          o.dik
            ? '700'
            : '500'
        ) +
        ';color:' +
        kl +
        ';white-space:nowrap;' +
        'font-variant-numeric:tabular-nums;' +
        '">' +
        eurT(waarde) +
        '</div>' +

      '</div>'
    );
  }

  function vakje(
    kop,
    groot,
    klein,
    kl
  ) {
    return (
      '<div style="' +
      'padding:10px 12px;' +
      'border:1px solid ' +
      D.rand +
      ';border-radius:8px;' +
      '">' +

        '<div style="' +
        'font-size:10px;' +
        'text-transform:uppercase;' +
        'letter-spacing:.06em;' +
        'color:' +
        D.grijs +
        ';">' +
        kop +
        '</div>' +

        '<div style="' +
        'font-size:17px;' +
        'font-weight:700;' +
        'margin-top:2px;' +
        'color:' +
        (kl || D.inkt) +
        ';font-variant-numeric:tabular-nums;' +
        '">' +
        groot +
        '</div>' +

        '<div style="' +
        'font-size:10.5px;' +
        'color:' +
        D.grijs +
        ';margin-top:2px;' +
        '">' +
        klein +
        '</div>' +

      '</div>'
    );
  }

  function bouwHoofdkaart(
    a,
    ctx
  ) {
    var c =
      kaart(
        'be-hoofd',
        null
      );

    var perMaand =
      ctx.interval ===
      'month';

    var contractPeriode =
      ctx.interval ===
        'rolling_year' &&
      Number.isFinite(
        ctx.contractSaldo
      );

    var volDagen =
      perMaand &&
      a.key
        ? dagenInMaand(
            a.key
          )
        : 0;

    var deelPeriode =
      perMaand &&
      volDagen > 0 &&
      a.dagen > 0 &&
      a.dagen < volDagen;

    var stroomKosten =
      a.allinInk +
      a.allinVerk +
      (perMaand ? (ctx.voorlopigStroom || 0) : 0);

    function rij(
      label,
      detail,
      bedrag,
      o
    ) {
      o = o || {};

      var streep =
        o.streep
          ? (
              'border-top:1px solid ' +
              D.rand +
              ';'
            )
          : '';

      var gew =
        o.dik
          ? '600'
          : '400';

      return (
        '<tr>' +

          '<td style="' +
          'padding:8px 0;' +
          streep +
          'font-size:13.5px;' +
          'font-weight:' +
          gew +
          ';color:' +
          D.inkt +
          ';">' +
          label +
          '</td>' +

          '<td style="' +
          'padding:8px 0;' +
          streep +
          'font-size:12px;' +
          'color:' +
          D.grijs +
          ';white-space:nowrap;' +
          '">' +
          (detail || '') +
          '</td>' +

          '<td style="' +
          'padding:8px 0;' +
          streep +
          'text-align:right;' +
          'font-size:13.5px;' +
          'font-weight:' +
          (
            o.dik
              ? '700'
              : '500'
          ) +
          ';white-space:nowrap;' +
          'font-variant-numeric:tabular-nums;' +
          'color:' +
          (
            o.neutraal
              ? D.inkt
              : kleur(
                  bedrag
                )
          ) +
          ';">' +
          eurT(bedrag) +
          '</td>' +

        '</tr>'
      );
    }

    var tabel =
      '<table style="' +
      'width:100%;' +
      'border-collapse:collapse;' +
      'table-layout:fixed;' +
      '">' +

        '<colgroup>' +
          '<col style="width:40%">' +
          '<col style="width:30%">' +
          '<col style="width:30%">' +
        '</colgroup>' +

        rij(
          'Afname van het net',
          kwh(a.imp) +
          ' \u00e0 ' +
          eur(
            a.prijsInk,
            3
          ),
          a.allinInk
        ) +

        rij(
          'Teruglevering',
          kwh(a.exp) +
          ' \u00e0 ' +
          eur(
            a.prijsVerk,
            3
          ),
          a.allinVerk
        ) +

        (
          perMaand && ctx.voorlopigAantal > 0
            ? rij(
                'Voorlopige kosten / opbrengsten',
                ctx.voorlopigAantal + ' dag(en) · nog niet definitief',
                ctx.voorlopigStroom
              )
            : ''
        ) +

        (
          perMaand
            ? ''
            : rij(
                'Netbeheer',
                num(
                  a.dagen,
                  0
                ) +
                ' dagen',
                a.vast,
                {
                  streep: true
                }
              )
        ) +

        (
          contractPeriode &&
          Math.abs(
            ctx.contractWerkelijk -
            a.totaal
          ) > 0.005
            ? rij(
                'Voorlopige aanvulling',
                'nog niet definitief bij Balans',
                ctx.contractWerkelijk -
                  a.totaal
              )
            : ''
        ) +

        (
          contractPeriode
            ? rij(
                'Betaald voorschot',
                'Volgens ingangsdata · naar rato van dagen',
                ctx.contractBetaald,
                {
                  neutraal:
                    true
                }
              )
            : ''
        ) +

        rij(
          perMaand
            ? 'Stroomkosten'
            : (
                contractPeriode
                  ? 'Huidig contractsaldo'
                  : 'Totaal'
              ),
          '',
          perMaand
            ? stroomKosten
            : (
                contractPeriode
                  ? ctx.contractSaldo
                  : a.totaal
              ),
          {
            dik: true,
            streep: true
          }
        ) +

      '</table>';

    var eindbedrag =
      perMaand
        ? stroomKosten
        : (
            contractPeriode
              ? ctx.contractSaldo
              : a.totaal
          );

    var kop =
      '<div style="' +
      'display:flex;' +
      'justify-content:space-between;' +
      'align-items:baseline;' +
      'gap:16px;' +
      'flex-wrap:wrap;' +
      'margin-bottom:14px;' +
      '">' +

        '<div>' +

          '<div style="' +
          'font-size:17px;' +
          'font-weight:600;' +
          'color:' +
          D.inkt +
          ';">' +
          ctx.naam +
          '</div>' +

          '<div style="' +
          'font-size:12px;' +
          'color:' +
          D.grijs +
          ';margin-top:2px;' +
          '">' +

          (
            perMaand
              ? (
                  num(
                    a.dagen,
                    0
                  ) +
                  (
                    deelPeriode
                      ? ' van ' +
                        volDagen
                      : ''
                  ) +
                  ' dagen \u00b7 alleen afname en teruglevering'
                )
              : (
                  (
                    a.dagen
                      ? (
                          num(
                            a.dagen,
                            0
                          ) +
                          ' dagen \u00b7 '
                        )
                      : ''
                  ) +
                  (
                    contractPeriode
                      ? 'contractstand incl. voorschotten'
                      : 'alles inbegrepen'
                  )
                )
          ) +

          '</div>' +

        '</div>' +

        '<div style="text-align:right;">' +

          '<div style="' +
          'font-size:27px;' +
          'font-weight:700;' +
          'line-height:1.1;' +
          'color:' +
          kleur(
            eindbedrag
          ) +
          ';font-variant-numeric:tabular-nums;' +
          '">' +
          eurT(
            eindbedrag
          ) +
          '</div>' +

          '<div style="' +
          'font-size:12px;' +
          'color:' +
          D.grijs +
          ';">' +

          (
            perMaand
              ? 'stroomkosten'
              : contractPeriode
              ? (
                  eindbedrag < 0
                    ? 'nog te betalen'
                    : 'te ontvangen'
                )
              : (
                  eindbedrag < 0
                    ? 'kosten'
                    : 'opbrengst'
                )
          ) +

          '</div>' +

        '</div>' +

      '</div>';

    c.innerHTML =
      kop +
      tabel;

    if (deelPeriode) {
      c.appendChild(
        el(
          'div',
          'margin-top:10px;' +
          'font-size:11px;' +
          'color:' +
          D.grijs +
          ';line-height:1.5;',
          'Balans heeft ' +
          a.dagen +
          ' van de ' +
          volDagen +
          ' dagen verwerkt. ' +
          'Dit stroomkostenblok bevat alleen afname en teruglevering. ' +
          'Netbeheer, voorschotten en de vaste belastingvermindering ' +
          'zijn hier niet meegerekend.'
        )
      );
    }

    return c;
  }

  function bouwPrijsopbouw(a) {
    var c =
      sectie(
        'be-prijs',
        'Prijsopbouw per kWh'
      );

    if (a.zonderBelastingen) {
      c.appendChild(el('div', 'display:flex;gap:24px;flex-wrap:wrap;line-height:1.6',
        kolom('Afname', eur(a.prijsInk,3) + ' / kWh', 'kaal + € 0,02/kWh opslag', D.rood) +
        kolom('Teruglevering', eur(a.prijsVerk,3) + ' / kWh', 'kaal − € 0,02/kWh opslag', D.groen)));
      c.appendChild(el('div','font-size:11px;margin-top:10px;color:'+D.grijs,
        'EB en btw uitgeschakeld voor deze stroomkostenweergave. Het contractoverzicht hieronder behoudt zijn volledige berekening.'));
      return c;
    }
    function kolomPrijs(
      titel,
      balansPrijs,
      ebDeel,
      allinPrijs,
      kl,
      voet
    ) {
      return (
        '<div style="' +
        'padding:12px 14px;' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:9px;' +
        '">' +

          '<div style="' +
          'font-size:11px;' +
          'text-transform:uppercase;' +
          'letter-spacing:.06em;' +
          'color:' +
          D.grijs +
          ';margin-bottom:9px;' +
          '">' +
          titel +
          '</div>' +

          '<div style="' +
          'display:flex;' +
          'justify-content:space-between;' +
          'font-size:12.5px;' +
          'padding:3px 0;' +
          '">' +

            '<span style="color:#4a4453;">' +
            'Volgens Balans' +
            '</span>' +

            '<span style="' +
            'font-variant-numeric:tabular-nums;' +
            '">' +
            eur(
              balansPrijs,
              3
            ) +
            '</span>' +

          '</div>' +

          '<div style="' +
          'display:flex;' +
          'justify-content:space-between;' +
          'font-size:12.5px;' +
          'padding:3px 0;' +
          '">' +

            '<span style="color:#4a4453;">' +
            'Energiebelasting' +
            '</span>' +

            '<span style="' +
            'font-variant-numeric:tabular-nums;' +
            'color:' +
            kl +
            ';">' +

            (
              ebDeel < 0
                ? '\u2212'
                : '+'
            ) +
            ' ' +
            eur(
              Math.abs(
                ebDeel
              ),
              3
            ) +

            '</span>' +

          '</div>' +

          '<div style="' +
          'display:flex;' +
          'justify-content:space-between;' +
          'font-size:14px;' +
          'font-weight:700;' +
          'padding:7px 0 0;' +
          'margin-top:5px;' +
          'border-top:1px solid ' +
          D.rand +
          ';">' +

            '<span>' +
            'All-in' +
            '</span>' +

            '<span style="' +
            'font-variant-numeric:tabular-nums;' +
            'color:' +
            kl +
            ';">' +
            eur(
              allinPrijs,
              3
            ) +
            '</span>' +

          '</div>' +

          '<div style="' +
          'font-size:11px;' +
          'color:' +
          D.grijs +
          ';margin-top:6px;' +
          'line-height:1.45;' +
          '">' +
          voet +
          '</div>' +

        '</div>'
      );
    }

    var ebVerkPerKwh =
      a.exp > 0
        ? (
            a.ebVerk /
            a.exp
          )
        : 0;

    c.appendChild(
      el(
        'div',
        'display:grid;' +
        'grid-template-columns:repeat(auto-fit,minmax(230px,1fr));' +
        'gap:12px;',

        kolomPrijs(
          'Afname',
          a.prijsInkBalans,
          EB,
          a.prijsInk,
          D.rood,
          'Het cijfer van Balans is inclusief BTW en de 2 ct leverkosten. ' +
          'Daar komt ' +
          eur(
            EB_BASIS,
            3
          ) +
          ' energiebelasting plus 21% BTW bij, dus ' +
          eur(
            EB,
            5
          ) +
          '.'
        ) +

        kolomPrijs(
          'Teruglevering',
          a.prijsVerkBalans,
          ebVerkPerKwh,
          a.prijsVerk,
          D.groen,

          a.ongesaldeerd > 0.5
            ? (
                kwh(
                  a.gesaldeerd
                ) +
                ' van de ' +
                kwh(
                  a.exp
                ) +
                ' valt binnen de saldering en krijgt EB terug; ' +
                kwh(
                  a.ongesaldeerd
                ) +
                ' niet. Gemiddeld dus minder dan ' +
                eur(
                  EB,
                  5
                ) +
                '.'
              )
            : (
                'Alle teruglevering valt binnen de saldeerruimte, ' +
                'dus over elke kWh komt ' +
                eur(
                  EB,
                  5
                ) +
                ' energiebelasting terug.'
              )
        )
      )
    );

    c.appendChild(
      el(
        'div',
        'margin-top:12px;' +
        'padding-top:12px;' +
        'border-top:1px solid ' +
        D.rand +
        ';display:flex;' +
        'gap:24px;' +
        'flex-wrap:wrap;' +
        'row-gap:12px;',

        kolom(
          'Spread all-in',
          ct(
            a.prijsVerk -
            a.prijsInk
          ) +
          ' / kWh',
          'verkoop \u2212 inkoop',
          D.paars
        ) +

        kolom(
          'Energiebelasting',
          eurT(
            a.eb
          ),
          kwh(
            a.imp
          ) +
          ' af, ' +
          kwh(
            a.gesaldeerd
          ) +
          ' terug',
          kleur(
            a.eb
          )
        ) +

        kolom(
          'Netbeheer',
          eurT(
            a.vast
          ),
          'levering ' +
          eur(
            LEV_DAG,
            4
          ) +
          ' + transport ' +
          eur(
            TRA_DAG,
            4
          ) +
          ' \u2212 vermindering ' +
          eur(
            VER_DAG,
            4
          ) +
          ' per dag',
          kleur(
            a.vast
          )
        )
      )
    );

    return c;
  }

  function fprKleur(r) {
    if (r >= 1.6) {
      return D.groen;
    }

    if (r >= 1.05) {
      return D.paars;
    }

    if (r >= 1.0) {
      return D.oranje;
    }

    return D.rood;
  }

  function fprWoord(r) {
    if (r >= 1.8) {
      return 'Uitstekend';
    }

    if (r >= 1.6) {
      return 'Zeer goed';
    }

    if (r >= 1.4) {
      return 'Goed';
    }

    if (r >= 1.2) {
      return 'Redelijk';
    }

    if (r >= 1.05) {
      return 'Matig';
    }

    if (r >= 1.0) {
      return 'Break-even';
    }

    return 'Verlies';
  }

  function kolom(
    kop,
    groot,
    klein,
    kl
  ) {
    return (
      '<div style="min-width:96px;">' +

        '<div style="' +
        'font-size:10px;' +
        'text-transform:uppercase;' +
        'letter-spacing:.05em;' +
        'color:' +
        D.grijs +
        ';">' +
        kop +
        '</div>' +

        '<div style="' +
        'font-size:13.5px;' +
        'font-weight:600;' +
        'margin-top:2px;' +
        'color:' +
        D.inkt +
        ';font-variant-numeric:tabular-nums;' +
        '">' +
        groot +
        '</div>' +

        '<div style="' +
        'font-size:11px;' +
        'font-weight:700;' +
        'color:' +
        kl +
        ';">' +
        klein +
        '</div>' +

      '</div>'
    );
  }

  function bouwFpr(
    f,
    periodeWoord
  ) {
    if (!f) {
      return null;
    }

    var c =
      sectie(
        'be-fpr',
        'Accu \u00b7 financial performance ratio'
      );

    var kl =
      fprKleur(
        f.ratio
      );

    var pct =
      Math.min(
        100,
        Math.max(
          0,
          (
            f.ratio /
            2
          ) *
          100
        )
      );

    c.appendChild(
      el(
        'div',
        'display:flex;' +
        'gap:28px;' +
        'flex-wrap:wrap;' +
        'align-items:center;' +
        'row-gap:18px;',

        '<div style="' +
        'display:flex;' +
        'align-items:center;' +
        'gap:13px;' +
        '">' +

          '<div style="' +
          'font-size:40px;' +
          'font-weight:700;' +
          'line-height:1;' +
          'color:' +
          kl +
          ';font-variant-numeric:tabular-nums;' +
          '">' +
          num(
            f.ratio,
            2
          ) +
          '</div>' +

          '<div>' +

            '<div style="' +
            'font-size:13px;' +
            'font-weight:700;' +
            'color:' +
            kl +
            ';">' +

            (
              f.ratio >= 1
                ? '+'
                : ''
            ) +

            num(
              (
                f.ratio -
                1
              ) *
              100,
              0
            ) +

            '% rendement' +

            '</div>' +

            '<div style="' +
            'font-size:11px;' +
            'font-weight:600;' +
            'color:' +
            kl +
            ';opacity:.85;' +
            '">' +
            fprWoord(
              f.ratio
            ) +
            '</div>' +

            '<div style="' +
            'font-size:10px;' +
            'color:' +
            D.grijs +
            ';">' +
            'waarde ontladen \u00f7 waarde laden' +
            '</div>' +

          '</div>' +

        '</div>' +

        '<div style="' +
        'width:1px;' +
        'align-self:stretch;' +
        'background:' +
        D.rand +
        ';">' +
        '</div>' +

        '<div style="' +
        'display:flex;' +
        'gap:26px;' +
        'flex-wrap:wrap;' +
        'flex:1;' +
        'row-gap:12px;' +
        '">' +

          kolom(
            'Laden',
            kwh(
              f.laadKwh
            ),
            ct(
              f.gemLaad
            ) +
            '/kWh',
            D.rood
          ) +

          kolom(
            'Ontladen',
            kwh(
              f.ontlaadKwh
            ),
            ct(
              f.gemOntlaad
            ) +
            '/kWh',
            D.groen
          ) +

          kolom(
            'Netto',
            eurT(
              f.netto
            ),
            num(
              f.retour *
              100,
              0
            ) +
            '% retour',
            kleur(
              f.netto
            )
          ) +

          kolom(
            'Spread',
            ct(
              f.gemOntlaad -
              f.gemLaad
            ),
            'per kWh all-in',
            D.paars
          ) +

        '</div>' +

        '<div style="' +
        'min-width:180px;' +
        'flex:1;' +
        '">' +

          '<div style="' +
          'height:8px;' +
          'border-radius:4px;' +
          'position:relative;' +
          'background:linear-gradient(to right,' +
          D.rood +
          ',' +
          D.oranje +
          ' 25%,' +
          D.paars +
          ' 50%,' +
          D.groen +
          ');">' +

            '<div style="' +
            'position:absolute;' +
            'top:-3px;' +
            'left:' +
            pct +
            '%;' +
            'transform:translateX(-50%);' +
            'width:14px;' +
            'height:14px;' +
            'border-radius:50%;' +
            'background:#fff;' +
            'border:2.5px solid ' +
            kl +
            ';box-shadow:0 1px 4px rgba(0,0,0,.15);' +
            '">' +
            '</div>' +

          '</div>' +

          '<div style="' +
          'display:flex;' +
          'justify-content:space-between;' +
          'font-size:9px;' +
          'color:' +
          D.grijs +
          ';margin-top:4px;' +
          '">' +

            '<span>0</span>' +
            '<span>1,0</span>' +
            '<span>2,0+</span>' +

          '</div>' +

        '</div>'
      )
    );

    return c;
  }

  var KOL1 =
    '92px';

  var STAAT_GRID =
    'grid-template-columns:' +
    KOL1 +
    ' minmax(60px,1fr) 104px 84px 84px 96px;min-width:650px;' +
    'gap:12px;';

  function staatKop() {
    return (
      '<div style="' +
      'display:grid;' +
      STAAT_GRID +
      'padding:0 6px 7px;' +
      'margin-bottom:5px;' +
      'border-bottom:1px solid ' +
      D.rand +
      ';font-size:9.5px;' +
      'text-transform:uppercase;' +
      'letter-spacing:.05em;' +
      'color:' +
      D.grijs +
      ';white-space:nowrap;' +
      '">' +

        '<div>Maand</div>' +
        '<div></div>' +

        '<div style="text-align:right;">' +
        'All-in' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Vschot' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Vaste k.' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Saldo' +
        '</div>' +

      '</div>'
    );
  }

  function staatRij(o) {
    var bg =
      o.even
        ? 'rgba(107,63,160,.02)'
        : 'transparent';

    var dim =
      o.geschat
        ? 'opacity:.6;'
        : '';

    var cur =
      o.geschat
        ? 'font-style:italic;'
        : '';

    var t =
      o.geschat
        ? '~'
        : '';

    var balk =
      Math.min(
        100,
        Math.abs(
          o.stroom
        ) /
        4
      );

    var balkEcht =
      balk;

    var balkVoorlopig = 0;

    if (
      Number.isFinite(
        o.voorlopigStroom
      ) &&
      Math.abs(
        o.voorlopigStroom
      ) > 0.000001 &&
      Number.isFinite(
        o.stroomEcht
      )
    ) {
      var zelfdeRichting =
        o.stroomEcht === 0 ||
        o.stroom === 0 ||
        (
          o.stroomEcht > 0 &&
          o.stroom > 0
        ) ||
        (
          o.stroomEcht < 0 &&
          o.stroom < 0
        );

      if (
        zelfdeRichting &&
        Math.abs(
          o.stroom
        ) >=
        Math.abs(
          o.stroomEcht
        )
      ) {
        balkEcht =
          Math.min(
            balk,
            Math.abs(
              o.stroomEcht
            ) /
            4
          );

        balkVoorlopig =
          Math.max(
            0,
            balk - balkEcht
          );

      } else {
        balkVoorlopig =
          Math.min(
            balk,
            Math.abs(
              o.voorlopigStroom
            ) /
            4
          );

        balkEcht =
          Math.max(
            0,
            balk - balkVoorlopig
          );
      }
    }

    var balkRest = 0;

    if (o.naast) {
      var balkProg =
        Math.min(
          100,
          Math.abs(
            o.naast
          ) /
          4
        );

      balkRest =
        Math.max(
          0,
          balkProg -
          balk
        );
    }

    var vastWeergave =
      -o.vast;

    var sub =
      o.sub
        ? (
            '<div style="' +
            'font-size:10px;' +
            'font-weight:600;' +
            'margin-top:4px;' +
            'white-space:nowrap;' +
            'color:' +
            (
              o.subKleur ||
              D.paars
            ) +
            ';">' +
            o.sub +
            '</div>'
          )
        : '';

    return (
      '<div style="' +
      'display:grid;' +
      STAAT_GRID +
      'align-items:start;' +
      'padding:8px 6px;' +
      'border-radius:5px;' +
      'background:' +
      bg +
      ';' +
      dim +
      'font-variant-numeric:tabular-nums;' +
      '">' +

        '<div style="' +
        'font-size:12px;' +
        'padding-top:1px;' +
        cur +
        'color:' +
        (
          o.geschat
            ? D.paarsLicht
            : D.inkt
        ) +
        ';font-weight:' +
        (
          o.nu
            ? '600'
            : '400'
        ) +
        ';">' +
        '<span style="display:inline-block;position:relative;white-space:nowrap;">' +
        maandLabel(
          o.key
        ) +
        (o.contractLabel ? '<span style="position:absolute;left:0;top:100%;font-size:8px;font-weight:400;font-style:normal;line-height:1;margin-top:1px;white-space:nowrap;color:' +
          D.grijs + ';">' + o.contractLabel + '</span>' : '') +
        '</span></div>' +

        '<div>' +

          '<div style="' +
          'height:7px;' +
          'border-radius:4px;' +
          'background:#eeebf4;' +
          'overflow:hidden;' +
          'margin-top:4px;' +
          'display:flex;' +
          '">' +

            '<div style="' +
            'height:100%;' +
            'width:' +
            balkEcht +
            '%;' +
            'flex-shrink:0;' +
            'border-radius:' +
            (
              balkVoorlopig > 0
                ? '4px 0 0 4px'
                : '4px'
            ) +
            ';background:' +
            (
              o.geschat
                ? kleurZacht(
                    o.stroom
                  )
                : kleur(
                    o.stroom
                  )
            ) +
            ';">' +
            '</div>' +

            (
              balkVoorlopig > 0
                ? (
                    '<div style="' +
                    'height:100%;' +
                    'width:' +
                    balkVoorlopig +
                    '%;' +
                    'flex-shrink:0;' +
                    'background-color:' +
                    kleur(
                      o.stroom
                    ) +
                    ';background-image:' +
                    'repeating-linear-gradient(' +
                    '135deg,' +
                    'rgba(255,255,255,.82) 0,' +
                    'rgba(255,255,255,.82) 2px,' +
                    'rgba(255,255,255,0) 2px,' +
                    'rgba(255,255,255,0) 5px' +
                    ');' +
                    'border-radius:0 4px 4px 0;' +
                    '">' +
                    '</div>'
                  )
                : ''
            ) +

            (
              balkRest > 0
                ? (
                    '<div style="' +
                    'height:100%;' +
                    'width:' +
                    balkRest +
                    '%;' +
                    'flex-shrink:0;' +
                    'background:' +
                    kleurZacht(
                      o.naast
                    ) +
                    ';">' +
                    '</div>'
                  )
                : ''
            ) +

          '</div>' +

          sub +

        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'font-weight:600;' +
        'padding-top:1px;' +
        cur +
        'color:' +
        (
          o.geschat
            ? kleurZacht(
                o.stroom
              )
            : kleur(
                o.stroom
              )
        ) +
        ';">' +

        t +
        eurCent(
          o.stroom
        ) +

        (
          o.naast
            ? (
                '<span style="' +
                'color:' +
                D.paarsLicht +
                ';font-weight:400;' +
                '">' +
                ' / ~' +
                eurKort(
                  o.naast
                ) +
                '</span>'
              )
            : ''
        ) +

        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'padding-top:1px;' +
        'color:' +
        D.grijs +
        ';">' +
        '+\u20ac' +
        num(
          o.voorschot,
          2
        ) +
        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'padding-top:1px;' +
        cur +
        'color:' +
        (
          o.geschat
            ? kleurZacht(
                vastWeergave
              )
            : kleur(
                vastWeergave
              )
        ) +
        ';">' +
        eurCent(
          vastWeergave
        ) +
        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'font-weight:600;' +
        'padding-top:1px;' +
        cur +
        'color:' +
        (
          o.geschat
            ? kleurZacht(
                o.cum
              )
            : kleur(
                o.cum
              )
        ) +
        ';">' +
        t +
        eurKort(
          o.cum
        ) +
        '</div>' +

      '</div>'
    );
  }

  function bouwMaandstaat(rijen, sald, saldProg, huidigeKey, voorlopigeRijen, voorlopigeKey) {
    var c = sectie('be-staat', 'Voorschot &amp; verrekening');
    var periode = huidigContract(), vandaag = iso(new Date());
    var contractStart = periode.begin;
    // Voeg uitsluitend nog niet definitief verwerkte dagen binnen dit contractjaar toe.
    var echt = rijen.map(function(r){
      var copy = Object.assign({},r), deel=r.contractDeel;
      var keys=new Set(r.contractDagKeys||[]), extra=[];
      (voorlopigeRijen||[]).forEach(function(d){
        if(d && d.voorlopig && d.key>=deel.van && d.key<=deel.tot && d.key<=vandaag &&
          !keys.has(d.key) && !(r.contractBekendeDagen===deel.dagen)) {keys.add(d.key);extra.push(d);}
      });
      var velden=['imp','exp','inkoop','verkoop','laden','ontladen','pv','afrrImp','afrrExp','afrrVergoeding','dealsAantal'];
      extra.forEach(function(d){velden.forEach(function(k){copy[k]=getal(copy[k])+getal(d[k]);});});
      copy.contractVoorlopig=extra; copy.contractBekendeDagen=(r.contractBekendeDagen||0)+extra.length;
      copy.leeg=!(copy.contractBekendeDagen>0);
      if(extra.length){
        copy.voorlopig=true;
        copy.geprijsdeImportKwh=getal(r.imp)+extra.reduce(function(n,d){return n+(Number.isFinite(d.geprijsdeImportKwh)?d.geprijsdeImportKwh:d.imp);},0);
        copy.geprijsdeExportKwh=getal(r.exp)+extra.reduce(function(n,d){return n+(Number.isFinite(d.geprijsdeExportKwh)?d.geprijsdeExportKwh:d.exp);},0);
      }
      return copy;
    });
    var saldEcht=salderingReeks(echt,false), saldDefinitief=salderingReeks(rijen,false), bekendBedrag={}, werkelijkPer={};
    echt.forEach(function(r,i){
      if(r.leeg)return;
      var a=bereken(r,saldEcht[i].ongesaldeerd,r.contractBekendeDagen);
      var origineel=rijen[i];
      a.stroomEcht=origineel.leeg?0:bereken(origineel,saldDefinitief[i].ongesaldeerd,origineel.contractBekendeDagen||0).stroom;
      a.voorlopigStroom=a.stroom-a.stroomEcht;
      werkelijkPer[r.key]=a;
      if(r.contractBekendeDagen===dagenInMaand(r.key) && r.key<vandaag.slice(0,7))bekendBedrag[r.key]=a.stroom;
    });
    var ank=ankers(bekendBedrag), aantalVolledig=Object.keys(bekendBedrag).length;
    var cum=0,betaald=0,werkelijk=0,vastTot=0,maandenBekend=0,jaarStroom=0,jaarVast=0;
    var html=staatKop();
    echt.forEach(function(r,i){
      var deel=r.contractDeel,a=werkelijkPer[r.key];
      var verwacht=contractPrognose(r,contractHistorie,ank,aantalVolledig);
      var nog=Math.max(0,deel.dagen-r.contractBekendeDagen);
      var prog=a ? a.stroom+verwacht*nog/deel.dagen : verwacht;
      var verstreken=Math.max(0,Math.min(deel.dagen,datumDagNummer(new Date(vandaag+'T12:00:00'))-datumDagNummer(new Date(deel.van+'T12:00:00'))+1));
      var betaaldMaand=contractVoorschot(deel,verstreken);
      var vs=contractVoorschot(deel,deel.van>vandaag?deel.dagen:verstreken);
      betaald+=betaaldMaand;
      if(verstreken>0)maandenBekend++;
      var vastWerkelijk=vastBereik(deel.van,verstreken),vastDeel=vastBereik(deel.van,deel.dagen);
      werkelijk+=a?a.stroom:0; vastTot+=vastWerkelijk;
      jaarStroom+=prog; jaarVast+=vastDeel;
      var stroom=a?a.stroom:prog;
      var vast=a?vastWerkelijk:vastDeel;
      cum+=stroom+vast+vs;
      var sub=null;
      if(r.key===vandaag.slice(0,7)) {
        var definitieveKeys=(rijen[i].contractDagKeys||[]).slice().sort();
        var laatsteDefinitief=definitieveKeys.length?definitieveKeys[definitieveKeys.length-1]:null;
        if(!laatsteDefinitief && rijen[i].contractBekendeDagen===deel.dagen)laatsteDefinitief=deel.tot;
        sub=laatsteDefinitief?'berekend t/m '+parseInt(laatsteDefinitief.slice(8),10)+' '+maandNaam(r.key):'nog geen definitieve dagen';
      }
      var voorlopigTekst=voorlopigeDagenTekst(r.contractVoorlopig,r.key);
      if(voorlopigTekst)sub=(sub?sub+' · ':'')+voorlopigTekst;
      if(verstreken>r.contractBekendeDagen)sub=(sub?sub+' · ':'')+(verstreken-r.contractBekendeDagen)+' dagen zonder resultaat';
      html+=staatRij({key:r.key,nu:r.key===vandaag.slice(0,7),even:i%2===0,geschat:!a,
        stroom:stroom,stroomEcht:a?a.stroomEcht:stroom,voorlopigStroom:a?a.voorlopigStroom:0,vast:vast,voorschot:vs,cum:cum,
        sub:sub,subKleur:verstreken>r.contractBekendeDagen?D.oranje:null,naast:a&&nog>0?prog:null,
        contractLabel:deel.eerste?'Start '+contractDatumTekst(deel.van):deel.laatste?'Einde '+contractDatumTekst(deel.tot):null,
        contractLaatste:deel.laatste});
    });
    var jaarVoorschot = periode.delen.reduce(function(totaal, deel) {
      return totaal + contractVoorschot(deel, deel.dagen);
    }, 0);

    var jaarSaldo =
      jaarStroom +
      jaarVast +
      jaarVoorschot;

    html +=
      '<div style="' +
      'display:grid;' +
      STAAT_GRID +
      'align-items:center;' +
      'padding:11px 6px 3px;' +
      'margin-top:6px;' +
      'border-top:1.5px solid ' +
      D.rand +
      ';font-variant-numeric:tabular-nums;' +
      '">' +

        '<div style="' +
        'font-size:9.5px;' +
        'font-weight:700;' +
        'text-transform:uppercase;' +
        'letter-spacing:.05em;' +
        'color:' +
        D.label +
        ';">' +
        'Prognose jaar' +
        '</div>' +

        '<div></div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'font-weight:700;' +
        'color:' +
        kleur(
          jaarStroom
        ) +
        ';">' +
        eurKort(
          jaarStroom
        ) +
        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'font-weight:700;' +
        'color:' +
        D.inkt +
        ';">' +
        '+\u20ac' +
        num(
          jaarVoorschot,
          0
        ) +
        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'font-weight:700;' +
        'color:' +
        kleur(
          -jaarVast
        ) +
        ';">' +
        eurKort(
          -jaarVast
        ) +
        '</div>' +

        '<div style="' +
        'text-align:right;' +
        'font-size:12px;' +
        'font-weight:700;' +
        'color:' +
        kleur(
          jaarSaldo
        ) +
        ';">' +
        eurKort(
          jaarSaldo
        ) +
        '</div>' +

      '</div>';

    var werkelijkTot =
      werkelijk +
      vastTot;

    var saldoNu =
      werkelijkTot +
      betaald;

    var voortgang =
      contractVoortgang(
        contractStart,
        new Date()
      );

    var pct =
      Math.max(
        0,
        Math.min(
          100,
          voortgang.pctExact
        )
      );

    var pctTekst =
      (
        Math.round(
          pct * 10
        ) /
        10
      )
        .toFixed(1)
        .replace('.', ',');

    var eind =
      new Date(
        voortgang.grens.getTime()
      );

    eind.setDate(
      eind.getDate() - 1
    );

    var duurTekst =
      !voortgang.gestart
        ? 'nog niet gestart'
        : voortgang.voltooid
          ? '12 mnd · voltooid'
          : voortgang.maanden +
            ' mnd' +
            (
              voortgang.restDagen > 0
                ? ' + ' +
                  voortgang.restDagen +
                  (
                    voortgang.restDagen === 1
                      ? ' dag'
                      : ' dgn'
                  )
                : ''
            );

    c.appendChild(
      el(
        'div',
        'display:grid;' +
        'grid-template-columns:repeat(auto-fit,minmax(170px,1fr));' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:9px;' +
        'overflow:hidden;' +
        'margin-bottom:14px;',

        cel(
          'Voorschotten t/m nu',
          '+' +
          eur(
            betaald
          ),
          'Volgens ingangsdata · naar rato van dagen',
          D.inkt
        ) +

        cel(
          'Werkelijk t/m nu',
          eurT(
            werkelijkTot
          ),
          'stroom + netbeheer + belastingen',
          kleur(
            werkelijkTot
          )
        ) +

        cel(
          'Huidig saldo',
          eurT(
            saldoNu
          ),
          saldoNu < 0
            ? 'nog te betalen'
            : 'te ontvangen',
          kleur(
            saldoNu
          )
        )
      )
    );

    c.appendChild(
      el(
        'div',
        'margin-bottom:14px;',

        '<div style="' +
        'display:flex;' +
        'justify-content:space-between;' +
        'font-size:10px;' +
        'color:' +
        D.grijs +
        ';margin-bottom:4px;' +
        '">' +

          '<span>' +
          contractStart.getDate() +
          ' ' +
          MND_LANG[
            contractStart.getMonth()
          ] +
          ' ' +
          contractStart.getFullYear() +
          '</span>' +

          '<span>' +
          eind.getDate() +
          ' ' +
          MND_LANG[
            eind.getMonth()
          ] +
          ' ' +
          eind.getFullYear() +
          '</span>' +

        '</div>' +

        '<div style="' +
        'height:16px;' +
        'position:relative;' +
        'font-size:10px;' +
        'color:' +
        D.paars +
        ';font-weight:600;' +
        '">' +

          '<span style="' +
          'position:absolute;' +
          'left:clamp(64px,' +
          pct +
          '%,calc(100% - 64px));' +
          'transform:translateX(-50%);' +
          'white-space:nowrap;' +
          '">' +
          '\u25cf nu (' +
          duurTekst +
          ')' +
          '</span>' +

        '</div>' +

        '<div style="' +
        'height:8px;' +
        'background:#ede8f5;' +
        'border-radius:4px;' +
        'position:relative;' +
        '">' +

          '<div style="' +
          'height:100%;' +
          'width:' +
          pct +
          '%;' +
          'background:' +
          D.paars +
          ';border-radius:4px;' +
          '">' +
          '</div>' +

          '<div style="' +
          'position:absolute;' +
          'top:-3px;' +
          'left:' +
          pct +
          '%;' +
          'transform:translateX(-50%);' +
          'width:14px;' +
          'height:14px;' +
          'border-radius:50%;' +
          'background:#fff;' +
          'border:2.5px solid ' +
          D.paars +
          ';box-shadow:0 1px 3px rgba(0,0,0,.15);' +
          '">' +
          '</div>' +

        '</div>' +

        '<div style="' +
        'font-size:10px;' +
        'color:' +
        D.grijs +
        ';margin-top:4px;' +
        '">' +
        'Contractdag ' +
        voortgang.contractDag +
        ' van ' +
        voortgang.totaalDagen +
        ' \u00b7 ' +
        pctTekst +
        '% van contractjaar' +
        '</div>'
      )
    );

    var det =
      el(
        'details',
        ''
      );

    det.open =
      true;

    det.innerHTML =
      '<summary style="' +
      'cursor:pointer;' +
      'font-size:11.5px;' +
      'color:' +
      D.grijs +
      ';list-style:none;' +
      '">' +
      '\u25bc Maanddetails verbergen' +
      '</summary>' +

      '<div style="margin-top:11px;overflow-x:auto;">' +
      html +
      '</div>';

    det.addEventListener(
      'toggle',
      function () {
        var sum =
          det.querySelector(
            'summary'
          );

        if (sum) {
          sum.textContent =
            det.open
              ? '\u25bc Maanddetails verbergen'
              : '\u25b6 Maanddetails tonen';
        }
      }
    );

    c.appendChild(
      det
    );

    c.dataset.beBetaald =
      String(betaald);

    c.dataset.beWerkelijk =
      String(werkelijkTot);

    c.dataset.beSaldoNu =
      String(saldoNu);

    c.dataset.beMaandenBekend =
      String(maandenBekend);

    return c;
  }

  function cel(
    kop,
    groot,
    klein,
    kl
  ) {
    return (
      '<div style="' +
      'padding:11px 14px;' +
      'border-right:1px solid ' +
      D.rand +
      ';">' +

        '<div style="' +
        'font-size:10px;' +
        'text-transform:uppercase;' +
        'letter-spacing:.05em;' +
        'color:' +
        D.grijs +
        ';">' +
        kop +
        '</div>' +

        '<div style="' +
        'font-size:20px;' +
        'font-weight:700;' +
        'margin-top:2px;' +
        'color:' +
        kl +
        ';font-variant-numeric:tabular-nums;' +
        '">' +
        groot +
        '</div>' +

        '<div style="' +
        'font-size:10.5px;' +
        'color:' +
        D.grijs +
        ';margin-top:2px;' +
        '">' +
        klein +
        '</div>' +

      '</div>'
    );
  }

  var SALD_GRID =
    'grid-template-columns:' +
    KOL1 +
    ' 1fr 1fr 1fr 1fr 1.1fr;' +
    'gap:12px;';

  function bouwSaldering(sald) {
    if (!cfg.saldering) {
      return null;
    }

    var gevuld =
      sald.filter(
        function (s) {
          return (
            !s.overgeslagen &&
            (
              s.imp > 0 ||
              s.exp > 0
            )
          );
        }
      );

    if (!gevuld.length) {
      return null;
    }

    var laatsteRij =
      gevuld[
        gevuld.length - 1
      ];

    var totImp =
      laatsteRij.cumImp;

    var totExp =
      laatsteRij.cumExp;

    var over =
      Math.max(
        0,
        totExp -
        totImp
      );

    var ruimte =
      Math.max(
        0,
        totImp -
        totExp
      );

    var naald =
      Math.min(
        98,
        Math.max(
          2,
          (
            totImp > 0
              ? totExp /
                totImp
              : 0
          ) *
          50
        )
      );

    var kl =
      over > 0
        ? D.rood
        : D.groen;

    var schakelaar =
      '<label id="be-sald-prog" style="' +
      'display:flex;' +
      'align-items:center;' +
      'gap:7px;' +
      'cursor:pointer;' +
      'flex-shrink:0;' +
      '">' +

        '<span style="' +
        'font-size:10px;' +
        'font-weight:500;' +
        'color:' +
        (
          salderingPrognose
            ? D.paars
            : D.grijs
        ) +
        ';">' +
        'incl. prognose' +
        '</span>' +

        '<span style="' +
        'position:relative;' +
        'display:block;' +
        'width:36px;' +
        'height:20px;' +
        'border-radius:10px;' +
        'background:' +
        (
          salderingPrognose
            ? D.paars
            : D.rand
        ) +
        ';transition:background .2s;' +
        '">' +

          '<span style="' +
          'position:absolute;' +
          'top:3px;' +
          'left:' +
          (
            salderingPrognose
              ? '18px'
              : '3px'
          ) +
          ';width:14px;' +
          'height:14px;' +
          'border-radius:7px;' +
          'background:#fff;' +
          'transition:left .2s;' +
          'box-shadow:0 1px 3px rgba(0,0,0,.2);' +
          '">' +
          '</span>' +

        '</span>' +

      '</label>';

    var c =
      sectie(
        'be-sald',
        'Salderingsbalans contractjaar',
        schakelaar
      );

    var tabel =
      '<div style="' +
      'display:grid;' +
      SALD_GRID +
      'padding:0 6px 7px;' +
      'margin-bottom:5px;' +
      'border-bottom:1px solid ' +
      D.rand +
      ';font-size:9.5px;' +
      'text-transform:uppercase;' +
      'letter-spacing:.05em;' +
      'color:' +
      D.grijs +
      ';white-space:nowrap;' +
      '">' +

        '<div>Maand</div>' +

        '<div style="text-align:right;">' +
        'Import' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Export' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Cum. imp' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Cum. exp' +
        '</div>' +

        '<div style="text-align:right;">' +
        'Ongesaldeerd' +
        '</div>' +

      '</div>';

    sald.forEach(
      function (s, i) {
        if (s.overgeslagen) {
          tabel +=
            '<div style="' +
            'display:grid;' +
            SALD_GRID +
            'padding:6px;' +
            'font-size:11px;' +
            'opacity:.3;' +
            '">' +

              '<div style="' +
              'font-style:italic;' +
              'color:' +
              D.paarsLicht +
              ';">' +
              maandLabel(
                s.key
              ) +
              '</div>' +

              '<div style="text-align:right;">\u2013</div>' +
              '<div style="text-align:right;">\u2013</div>' +
              '<div style="text-align:right;">\u2013</div>' +
              '<div style="text-align:right;">\u2013</div>' +
              '<div style="text-align:right;">\u2013</div>' +

            '</div>';

          return;
        }

        var kantel =
          !s.naSaldering &&
          s.ongesaldeerd > 0 &&
          (
            s.cumExp -
            s.exp
          ) <=
          (
            s.cumImp -
            s.imp
          );

        var bg =
          s.naSaldering
            ? 'rgba(220,53,69,.05)'
            : (
                kantel
                  ? 'rgba(220,53,69,.07)'
                  : (
                      s.geschat
                        ? 'rgba(107,63,160,.03)'
                        : (
                            i % 2 === 0
                              ? 'rgba(107,63,160,.02)'
                              : 'transparent'
                          )
                    )
              );

        var stijl =
          s.geschat
            ? 'opacity:.65;font-style:italic;'
            : '';

        tabel +=
          '<div style="' +
          'display:grid;' +
          SALD_GRID +
          'padding:6px;' +
          'border-radius:5px;' +
          'font-size:11.5px;' +
          'background:' +
          bg +
          ';' +
          stijl +
          'font-variant-numeric:tabular-nums;' +
          '">' +

            '<div style="color:' +
            D.inkt +
            ';">' +

            maandLabel(
              s.key
            ) +

            (
              kantel
                ? (
                    ' <span style="' +
                    'color:' +
                    D.rood +
                    ';font-size:9px;' +
                    '">' +
                    '\u25c0' +
                    '</span>'
                  )
                : ''
            ) +

            (
              s.naSaldering
                ? (
                    ' <span style="' +
                    'color:' +
                    D.rood +
                    ';font-size:9px;' +
                    '">' +
                    '\u26a0' +
                    '</span>'
                  )
                : ''
            ) +

            '</div>' +

            '<div style="' +
            'text-align:right;' +
            'color:' +
            D.grijs +
            ';">' +
            num(
              s.imp,
              0
            ) +
            '</div>' +

            '<div style="' +
            'text-align:right;' +
            'color:' +
            D.grijs +
            ';">' +
            num(
              s.exp,
              0
            ) +
            '</div>' +

            '<div style="text-align:right;">' +
            num(
              s.cumImp,
              0
            ) +
            '</div>' +

            '<div style="' +
            'text-align:right;' +
            'color:' +
            (
              s.cumExp >
              s.cumImp
                ? D.rood
                : D.inkt
            ) +
            ';">' +
            num(
              s.cumExp,
              0
            ) +
            '</div>' +

            '<div style="' +
            'text-align:right;' +
            'font-weight:' +
            (
              s.ongesaldeerd > 0
                ? '700'
                : '400'
            ) +
            ';color:' +
            (
              s.ongesaldeerd > 0
                ? D.rood
                : D.grijs
            ) +
            ';">' +

            (
              s.ongesaldeerd > 0
                ? (
                    num(
                      s.ongesaldeerd,
                      0
                    ) +
                    ' kWh'
                  )
                : '\u2013'
            ) +

            '</div>' +

          '</div>';
      }
    );

    c.appendChild(
      el(
        'div',
        'display:grid;' +
        'grid-template-columns:repeat(auto-fit,minmax(150px,1fr));' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:9px;' +
        'overflow:hidden;' +
        'margin-bottom:13px;',

        cel(
          'Import',
          kwh(
            totImp
          ),
          'contractjaar',
          D.inkt
        ) +

        cel(
          'Export',
          kwh(
            totExp
          ),
          'contractjaar',
          kl
        ) +

        cel(
          over > 0
            ? 'Buiten saldering'
            : 'Saldeerruimte over',
          kwh(
            over > 0
              ? over
              : ruimte
          ),
          over > 0
            ? 'geen EB-teruggave hierop'
            : 'nog te benutten',
          kl
        )
      )
    );

    c.appendChild(
      el(
        'div',
        'margin-bottom:13px;',

        '<div style="' +
        'display:flex;' +
        'justify-content:space-between;' +
        'font-size:10px;' +
        'color:' +
        D.grijs +
        ';margin-bottom:5px;' +
        '">' +

          '<span>\u2190 import overheerst</span>' +
          '<span>break-even</span>' +
          '<span>export overschot \u2192</span>' +

        '</div>' +

        '<div style="' +
        'height:8px;' +
        'border-radius:4px;' +
        'border:1px solid ' +
        D.rand +
        ';position:relative;' +
        'background:linear-gradient(to right,' +
        D.groen +
        ' 0%,#a8d5b5 45%,#f0edf7 50%,#f5c0c0 55%,' +
        D.rood +
        ' 100%);">' +

          '<div style="' +
          'position:absolute;' +
          'top:0;' +
          'left:50%;' +
          'width:2px;' +
          'height:100%;' +
          'background:' +
          D.paars +
          ';opacity:.3;' +
          '">' +
          '</div>' +

          '<div style="' +
          'position:absolute;' +
          'top:-3px;' +
          'left:' +
          naald +
          '%;' +
          'transform:translateX(-50%);' +
          'width:14px;' +
          'height:14px;' +
          'border-radius:50%;' +
          'background:#fff;' +
          'border:2.5px solid ' +
          kl +
          ';box-shadow:0 1px 4px rgba(0,0,0,.15);' +
          '">' +
          '</div>' +

        '</div>'
      )
    );

    if (over > 0) {
      c.appendChild(
        el(
          'div',
          'margin-bottom:12px;' +
          'padding:7px 10px;' +
          'border-radius:7px;' +
          'font-size:11px;' +
          'background:rgba(220,53,69,.06);' +
          'color:' +
          D.rood +
          ';',

          kwh(
            over
          ) +
          ' export valt buiten de saldering \u2014 daarover komt geen ' +
          eur(
            EB,
            5
          ) +
          '/kWh energiebelasting terug, dus ' +
          eur(
            over *
            EB
          ) +
          ' minder dan wanneer er ruimte was.'
        )
      );
    }

    var det =
      el(
        'details',
        ''
      );

    det.innerHTML =
      '<summary style="' +
      'cursor:pointer;' +
      'font-size:11.5px;' +
      'color:' +
      D.grijs +
      ';list-style:none;' +
      '">' +
      '\u25b6 Maand voor maand' +
      '</summary>' +

      '<div style="margin-top:11px;">' +
      tabel +
      '</div>' +

      '<div style="' +
      'margin-top:10px;' +
      'font-size:10.5px;' +
      'color:' +
      D.grijs +
      ';line-height:1.5;' +
      '">' +

      (
        salderingPrognose
          ? 'Cursief = prognose \u00b7 '
          : 'Alleen maanden met echte cijfers \u00b7 '
      ) +

      '\u25c0 kantelpunt saldering \u00b7 ' +
      '\u26a0 na 31 december 2026, geen saldering meer' +

      '</div>';

    det.addEventListener(
      'toggle',
      function () {
        var s =
          det.querySelector(
            'summary'
          );

        if (s) {
          s.textContent =
            det.open
              ? '\u25bc Maand voor maand verbergen'
              : '\u25b6 Maand voor maand';
        }
      }
    );

    c.appendChild(det);

    return c;
  }


  /*
   * ============================================================
   * RESULTATEN — Balans-kaarten en grafiek
   * ============================================================
   */

  function zetKaartTekst(
    id,
    tekst,
    kl
  ) {
    var e =
      document.getElementById(
        id
      );

    if (!e) {
      return null;
    }

    e.textContent =
      tekst;

    if (kl) {
      e.style.setProperty(
        'color',
        kl,
        'important'
      );

    } else {
      e.style.removeProperty(
        'color'
      );
    }

    return e;
  }

  function zetSubInfo(
    id,
    html
  ) {
    var e =
      document.getElementById(
        id
      );

    if (!e) {
      return;
    }

    var houder =
      e.parentElement;

    var oud =
      houder.querySelector(
        '.be-sub'
      );

    if (oud) {
      oud.remove();
    }

    if (!html) {
      return;
    }

    houder.appendChild(
      el(
        'div',
        'margin-top:6px;' +
        'font-size:11px;' +
        'color:' +
        D.grijs +
        ';',
        html
      )
    );

    houder.lastElementChild
      .className =
        'be-sub';
  }

  function zetPopover(
    id,
    titel,
    inhoud
  ) {
    var e =
      document.getElementById(
        id
      );

    var m =
      e &&
      e.closest(
        '.summary-compact-metric'
      );

    var b =
      m &&
      m.querySelector(
        'button.help-popover'
      );

    if (!b) {
      return;
    }

    if (
      !b.getAttribute(
        'data-be-orig-titel'
      )
    ) {
      b.setAttribute(
        'data-be-orig-titel',
        b.getAttribute(
          'data-bs-title'
        ) || ''
      );

      b.setAttribute(
        'data-be-orig-inhoud',
        b.getAttribute(
          'data-bs-content'
        ) || ''
      );
    }

    var t =
      titel === null
        ? b.getAttribute(
            'data-be-orig-titel'
          )
        : titel;

    var c =
      inhoud === null
        ? b.getAttribute(
            'data-be-orig-inhoud'
          )
        : inhoud;

    if (
      b.getAttribute(
        'data-bs-title'
      ) === t &&
      b.getAttribute(
        'data-bs-content'
      ) === c
    ) {
      return;
    }

    b.setAttribute(
      'data-bs-title',
      t
    );

    b.setAttribute(
      'data-bs-content',
      c
    );

    b.setAttribute(
      'aria-label',
      t
    );

    try {
      var BS =
        window.bootstrap;

      var inst =
        (
          BS &&
          BS.Popover
        )
          ? BS.Popover.getInstance(
              b
            )
          : null;

      if (
        inst &&
        typeof inst.setContent ===
          'function'
      ) {
        inst.setContent({
          '.popover-header':
            t,

          '.popover-body':
            c
        });
      }

    } catch (err) {}
  }

  function pasPopoversAan(
    a,
    aan
  ) {
    if (!aan) {
      [
        'summary-stroom-voordeel',
        'summary-deal-result',
        'summary-buy-price',
        'summary-sell-price'
      ].forEach(
        function (id) {
          zetPopover(
            id,
            null,
            null
          );
        }
      );

      return;
    }

    if (a.zonderBelastingen) {
      ['summary-stroom-voordeel','summary-deal-result','summary-buy-price','summary-sell-price'].forEach(function(id) {
        zetPopover(id, 'Zonder EB en btw', 'Kale stroomprijs, met € 0,02/kWh opslag bij inkoop en € 0,02/kWh aftrek bij verkoop. Energiebelasting en btw zijn uit deze weergave gelaten.');
      });
      return;
    }
    var ebPerKwhVerk =
      a.exp > 0
        ? (
            a.ebVerk /
            a.exp
          )
        : 0;

    var buiten =
      a.ongesaldeerd > 0.5
        ? (
            ' Van de ' +
            kwh(
              a.exp
            ) +
            ' valt ' +
            kwh(
              a.ongesaldeerd
            ) +
            ' buiten de saldeerruimte; ' +
            'daarover komt geen energiebelasting terug.'
          )
        : (
            ' Alle teruglevering valt binnen de saldeerruimte, ' +
            'dus over elke kWh komt de volle ' +
            eur(
              EB,
              5
            ) +
            ' terug.'
          );

    zetPopover(
      'summary-stroom-voordeel',
      'Kosten stroomafname all-in',

      eur(
        Math.abs(
          a.balansInk
        )
      ) +
      ' volgens Balans, inclusief btw en \u20ac 0,02 leverkosten per kWh. ' +
      'Daar hoort ' +
      eur(
        Math.abs(
          a.ebInk
        )
      ) +
      ' energiebelasting bij: ' +
      kwh(
        a.imp
      ) +
      ' \u00d7 ' +
      eur(
        EB,
        5
      ) +
      ' per kWh. Samen ' +
      eur(
        Math.abs(
          a.allinInk
        )
      ) +
      '. Balans laat die belasting weg, terwijl je hem wel betaalt.'
    );

    zetPopover(
      'summary-deal-result',
      'Opbrengst teruglevering all-in',

      eur(
        a.balansVerk
      ) +
      ' volgens Balans, inclusief btw en minus \u20ac 0,02 leverkosten per kWh. ' +
      'Door saldering krijg je daarnaast ' +
      eur(
        a.ebVerk
      ) +
      ' energiebelasting terug over ' +
      kwh(
        a.gesaldeerd
      ) +
      '. Samen ' +
      eur(
        a.allinVerk
      ) +
      '.' +
      buiten
    );

    zetPopover(
      'summary-buy-price',
      'Gem. inkoopprijs all-in',

      ct(
        a.prijsInkBalans
      ) +
      ' per kWh volgens Balans, plus ' +
      ct(
        EB
      ) +
      ' energiebelasting inclusief btw, is ' +
      ct(
        a.prijsInk
      ) +
      ' per kWh. ' +
      'Dit is het bedrag dat je werkelijk kwijt bent voor een kilowattuur van het net.'
    );

    zetPopover(
      'summary-sell-price',
      'Gem. verkoopprijs all-in',

      ct(
        a.prijsVerkBalans
      ) +
      ' per kWh volgens Balans, plus ' +
      ct(
        ebPerKwhVerk
      ) +
      ' energiebelasting die je via saldering terugkrijgt, is ' +
      ct(
        a.prijsVerk
      ) +
      ' per kWh. ' +
      'Het verschil met de inkoopprijs is ' +
      ct(
        a.prijsVerk -
        a.prijsInk
      ) +
      ' per kWh.'
    );
  }

  function zetKaartLabel(aan) {
    var e =
      document.getElementById(
        'summary-stroom-voordeel'
      );

    if (!e) {
      return;
    }

    var kaartEl =
      e.closest(
        '.summary-compact-metric'
      );

    var lbl =
      kaartEl
        ? kaartEl.querySelector(
            '.summary-compact-label'
          )
        : null;

    if (!lbl) {
      return;
    }

    var tekstNode =
      Array.prototype
        .filter.call(
          lbl.childNodes,
          function (n) {
            return (
              n.nodeType === 3
            );
          }
        )[0];

    if (tekstNode) {
      tekstNode.nodeValue =
        aan
          ? 'Kosten stroomafname all-in'
          : 'Kosten stroomafname';
    }
  }

  function pasBalansKaartenAan(
    a,
    ruw,
    aan
  ) {
    if (!aan) {
      zetKaartTekst(
        'summary-stroom-voordeel',
        eur(
          ruw.inkoop
        )
      );

      zetKaartTekst(
        'summary-deal-result',
        eur(
          ruw.verkoop
        )
      );

      zetKaartTekst(
        'summary-buy-price',
        prijs(
          ruw.prijsInk
        )
      );

      zetKaartTekst(
        'summary-sell-price',
        prijs(
          ruw.prijsVerk
        )
      );

      zetSubInfo(
        'summary-stroom-voordeel',
        null
      );

      zetSubInfo(
        'summary-deal-result',
        null
      );

      zetKaartLabel(
        false
      );

      pasPopoversAan(
        a,
        false
      );

      return;
    }

    zetKaartTekst(
      'summary-stroom-voordeel',
      eur(
        Math.abs(
          a.allinInk
        )
      ),
      D.rood
    );

    zetKaartTekst(
      'summary-deal-result',
      eur(
        a.allinVerk
      ),
      D.groen
    );

    zetKaartTekst(
      'summary-buy-price',
      prijs(
        a.prijsInk
      )
    );

    zetKaartTekst(
      'summary-sell-price',
      prijs(
        a.prijsVerk
      )
    );

    zetSubInfo(
      'summary-stroom-voordeel',

      kwh(
        a.imp
      ) +
      ' \u00b7 waarvan ' +
      '<span style="' +
      'color:' +
      D.rood +
      ';font-weight:600;' +
      '">' +
      eur(
        Math.abs(
          a.ebInk
        )
      ) +
      '</span> energiebelasting'
    );

    zetSubInfo(
      'summary-deal-result',

      kwh(
        a.exp
      ) +
      ' \u00b7 waarvan ' +
      '<span style="' +
      'color:' +
      D.groen +
      ';font-weight:600;' +
      '">' +
      eur(
        a.ebVerk
      ) +
      '</span> energiebelasting terug'
    );

    zetKaartLabel(
      true
    );

    if (a.zonderBelastingen) {
      zetSubInfo('summary-stroom-voordeel', kwh(a.imp) + ' · zonder EB en btw · + € 0,02/kWh opslag');
      zetSubInfo('summary-deal-result', kwh(a.exp) + ' · zonder EB en btw · − € 0,02/kWh opslag');
    }
    pasPopoversAan(
      a,
      true
    );
  }

  var chartOrig = null;
  var chartHerstelTimer = null;
  var chartWachtFrame = null;
  var chartWachtStatus = null;
  var chartRenderId = 0;

  function grafiekSleutel(chart) {
    return JSON.stringify([
      laatste ? laatste.interval : '',
      laatste ? laatste.periode : '',
      chart.data.labels
    ]);
  }

  function grafiekRenderVingerafdruk(chart) {
    if (!chart) {
      return '';
    }

    function r(v) {
      return Number.isFinite(v)
        ? Math.round(v * 1000) / 1000
        : null;
    }

    var uit = [
      chart.width,
      chart.height,
      chart.data &&
      chart.data.labels
        ? chart.data.labels.length
        : 0
    ];

    if (chart.chartArea) {
      uit.push(
        r(chart.chartArea.left),
        r(chart.chartArea.top),
        r(chart.chartArea.right),
        r(chart.chartArea.bottom)
      );
    }

    Object.keys(
      chart.scales || {}
    )
      .sort()
      .forEach(
        function (k) {
          var s =
            chart.scales[k];

          uit.push(
            k,
            r(s.min),
            r(s.max),
            r(s.left),
            r(s.top),
            r(s.right),
            r(s.bottom)
          );
        }
      );

    (chart.data.datasets || [])
      .forEach(
        function (ds, i) {
          var meta =
            chart.getDatasetMeta
              ? chart.getDatasetMeta(i)
              : null;

          uit.push(
            ds.label || '',
            Array.isArray(ds.data)
              ? ds.data.length
              : 0,
            meta && meta.hidden
              ? 1
              : 0
          );

          (
            meta &&
            Array.isArray(meta.data)
              ? meta.data
              : []
          ).forEach(
            function (e) {
              uit.push(
                r(e.x),
                r(e.y),
                r(e.base),
                r(e.width),
                r(e.height)
              );
            }
          );
        }
      );

    return JSON.stringify(
      uit
    );
  }

  // BE noemt de vergelijkingsreeks sinds 15 oktober anders. Alleen All-in
  // vervangt deze reeks door het eigen stroomresultaat; UIT herstelt de bron.
  // Presentatiefilter voor grafiek en geselecteerde stroomkostenperiode.
  // Het contractoverzicht en de opgeslagen bronresultaten blijven bruto.
  function beResultaatWeergave(a) {
    if (!a || cfg.resultaatBelastingen !== false || a.zonderBelastingen) return a;
    var b = Object.assign({}, a);
    b.zonderBelastingen = true;
    // De bron is inclusief btw en de bestaande 2 ct opslag. Eerst die
    // opslag terugdraaien, dan de btw, dan exact 2 ct per kant toepassen.
    b.allinInk = (a.balansInk + a.imp * OPSLAG) / BTW - a.imp * OPSLAG;
    b.allinVerk = (a.balansVerk + a.exp * OPSLAG) / BTW - a.exp * OPSLAG;
    b.balansInk = b.allinInk;
    b.balansVerk = b.allinVerk;
    b.eb = b.ebInk = b.ebVerk = 0;
    b.stroom = b.balansNetto = b.allinInk + b.allinVerk;
    b.prijsInk = b.prijsInkBalans = a.imp ? -b.allinInk / a.imp : 0;
    b.prijsVerk = b.prijsVerkBalans = a.exp ? b.allinVerk / a.exp : 0;
    return b;
  }

  function beCsvCel(v) {
    if (v === null || v === undefined) return '';
    if (typeof v === 'number') return Number.isFinite(v) ? String(v).replace('.', ',') : '';
    var s = typeof v === 'object' ? JSON.stringify(v) : String(v);
    if (/^[=+@\-\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  }
  function beCsvMaak(rijen) {
    var keys = Array.from(new Set(rijen.flatMap(function(r) { return Object.keys(r); })));
    return '\ufeff' + [keys.map(beCsvCel).join(';')].concat(rijen.map(function(r) {
      return keys.map(function(k) { return beCsvCel(r[k]); }).join(';');
    })).join('\r\n');
  }
  function beCsvDatums(van, tot) {
    if (![van,tot].every(function(d) {return /^\d{4}-\d{2}-\d{2}$/.test(d) &&
      Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0,10) === d;}) || van > tot)
      throw Error('Kies een geldige begin- en einddatum.');
    var dagen=[];
    for(var t=Date.parse(van); t<=Date.parse(tot); t+=86400000) dagen.push(new Date(t).toISOString().slice(0,10));
    return dagen;
  }
  function beCsvRijen(j, dag) {
    var lijst = j && j.day_detail && j.day_detail.intervals;
    if (!j || j.period !== dag || j.interval !== 'day' || !j.pricing ||
        j.pricing.include_vat !== false || j.pricing.include_delivery_cost !== false)
      throw Error('Bron bevestigt de gevraagde dag en kale prijzen niet.');
    if (!Array.isArray(lijst) || !lijst.length) return [{datum:dag,export_status:'geen kwartierdata beschikbaar'}];
    var seen=new Set();
    return lijst.map(function(r) {
      if (!r.timestamp || !Number.isFinite(Date.parse(r.timestamp)) || seen.has(r.timestamp))
        throw Error('Ontbrekende of dubbele kwartiertijd in de bron.');
      seen.add(r.timestamp);
      return Object.assign({datum:dag,tijdzone:'Europe/Amsterdam',
        lokale_start:new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam',dateStyle:'short',timeStyle:'long'}).format(new Date(r.timestamp)),
        export_status:'brondata',include_vat:false,include_delivery_cost:false,
        bron_status:j.data_quality && j.data_quality.status || ''},r);
    });
  }
  function beCsvSlaOp(naam, rijen) {
    var a=document.createElement('a'),u=URL.createObjectURL(new Blob([beCsvMaak(rijen)],{type:'text/csv;charset=utf-8'}));
    a.href=u;a.download=naam;a.click();setTimeout(function(){URL.revokeObjectURL(u);},60000);
  }
  var beCsvBezig = false;
  function beResultaatExtraBediening(wrap) {
    wrap.style.flexWrap='wrap';
    var belastingKnop=document.createElement('button');
    belastingKnop.type='button';belastingKnop.id='be-resultaat-belastingen';
    belastingKnop.setAttribute('role','switch');
    belastingKnop.setAttribute('aria-label','EB & btw');
    belastingKnop.style.cssText='display:flex;align-items:center;gap:9px;border:0;padding:0;background:transparent;color:'+D.paars+';font:600 13px system-ui;letter-spacing:.03em;cursor:pointer';
    var belastingLabel=document.createElement('span');belastingLabel.textContent='EB & btw';
    var belastingTrack=document.createElement('span');belastingTrack.setAttribute('aria-hidden','true');
    belastingTrack.style.cssText='position:relative;display:inline-block;box-sizing:border-box;width:44px;height:24px;border-radius:12px;flex-shrink:0;border:1.5px solid '+D.paarsLicht+';transition:background .25s';
    var belastingThumb=document.createElement('span');
    belastingThumb.style.cssText='position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);transition:transform .25s';
    belastingTrack.appendChild(belastingThumb);belastingKnop.append(belastingLabel,belastingTrack);
    function update(){
      belastingKnop.hidden=!cfg.allin;
      belastingKnop.style.display=cfg.allin?'flex':'none';
      belastingKnop.setAttribute('aria-checked',String(cfg.resultaatBelastingen));
      belastingLabel.style.color=cfg.resultaatBelastingen?D.paars:D.paarsLicht;
      belastingTrack.style.background=cfg.resultaatBelastingen?D.paars:D.rand;
      belastingThumb.style.transform=cfg.resultaatBelastingen?'translateX(20px)':'translateX(0)';
      belastingKnop.title='Grafiek en stroomkosten: energiebelasting en btw. De opslag van € 0,02 per kWh blijft aan beide kanten staan.';
    }
    belastingKnop.addEventListener('click',function(){
      cfg.resultaatBelastingen=!cfg.resultaatBelastingen;
      localStorage.setItem('be_cfg_resultaat_belastingen',cfg.resultaatBelastingen?'aan':'uit');
      update();herteken();
    });
    wrap.appendChild(belastingKnop);
    wrap.querySelector('label').addEventListener('click',function(){update();});
    update();
  }
  var beCsvPaneel;
  function beKwartierExportBediening(wrap) {
    if(beCsvPaneel){wrap.appendChild(beCsvPaneel);return;}
    var det=document.createElement('details');beCsvPaneel=det;det.open=true;det.style.cssText='font-size:12px;max-width:100%;color:'+D.paars;
    var sum=document.createElement('summary');sum.textContent='Download kwartierdata';sum.style.cursor='pointer';det.appendChild(sum);
    var box=document.createElement('div');box.style.cssText='display:flex;gap:8px;align-items:end;flex-wrap:wrap;padding:10px 0';
    var vandaag=new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Amsterdam'}).format(new Date());
    function datum(naam,waarde){var l=document.createElement('label');l.textContent=naam+' ';var i=document.createElement('input');i.type='date';i.value=waarde;i.max=vandaag;i.style.cssText='max-width:150px;padding:5px;border:1px solid '+D.rand+';border-radius:6px;font:inherit';l.appendChild(i);box.appendChild(l);return i;}
    var van=datum('Vanaf',iso(cfg.start)),tot=datum('Tot en met',vandaag);
    var start=document.createElement('button'),stop=document.createElement('button'),status=document.createElement('div');
    start.type=stop.type='button';start.textContent='Download CSV';stop.textContent='Stoppen';stop.hidden=true;
    [start,stop].forEach(function(b){b.style.cssText='border:1px solid '+D.paarsLicht+';border-radius:8px;padding:8px 12px;background:transparent;color:'+D.paars+';font:inherit;cursor:pointer';box.appendChild(b);});
    var voortgang=document.createElement('progress');voortgang.max=1;voortgang.value=0;voortgang.hidden=true;voortgang.style.cssText='width:100%;height:10px;accent-color:'+D.paars;voortgang.setAttribute('aria-label','Voortgang kwartierexport');box.appendChild(voortgang);
    status.setAttribute('role','status');status.style.cssText='flex-basis:100%;line-height:1.5';
    status.textContent='Alle bronvelden per kwartier. Prijzen zonder btw, energiebelasting en opslag; lege bronwaarden blijven leeg. UTC-tijden blijven behouden.';
    box.appendChild(status);det.appendChild(box);wrap.appendChild(det);
    var afgebroken=false,controller;
    stop.onclick=function(){afgebroken=true;if(controller)controller.abort();};
    start.onclick=async function(){
      if(beCsvBezig)return;
      var dagen;
      try{dagen=beCsvDatums(van.value,tot.value);if(tot.value>vandaag)throw Error('De einddatum mag niet in de toekomst liggen.');}
      catch(e){status.textContent=e.message;return;}
      var begin=van.value,eind=tot.value,rijen=[],fouten=0,leeg=0,klaar=0;
      afgebroken=false;beCsvBezig=true;status.textContent='Export voorbereiden · 0/'+dagen.length+' dagen';voortgang.hidden=false;voortgang.max=dagen.length;voortgang.value=0;start.disabled=van.disabled=tot.disabled=true;stop.hidden=false;
      function wacht(ms){return new Promise(function(resolve){var t=Date.now();function tick(){if(afgebroken||Date.now()-t>=ms)resolve();else setTimeout(tick,200);}tick();});}
      try {
        for(var dag of dagen){
          if(afgebroken)break;
          var gelukt=false;
          for(var poging=0;poging<4&&!afgebroken;poging++){
            await wacht(1250);if(afgebroken)break;
            status.textContent='Ophalen '+dag+' · '+klaar+'/'+dagen.length+' dagen';
            controller=new AbortController();var timeout=setTimeout(function(){controller.abort();},45000);
            try {
              var u=new URL('/customer/'+encodeURIComponent(KLANT)+'/results-v2-api/',location.origin);
              u.search=new URLSearchParams({interval:'day',period:dag,include_vat:'0',include_delivery_cost:'0'});
              var r=await origFetch(u.href,{credentials:'same-origin',cache:'no-store',signal:controller.signal});
              if(r.status===429&&poging<3){
                clearTimeout(timeout);var delay=Math.max(60000,(Number(r.headers.get('Retry-After'))||0)*1000);
                var hervat=Date.now()+delay;
                while(!afgebroken&&Date.now()<hervat){
                  status.textContent=klaar+'/'+dagen.length+' dagen · BE vraagt om een pauze · verder over '+Math.ceil((hervat-Date.now())/1000)+' s';
                  await wacht(Math.min(1000,hervat-Date.now()));
                }
                continue;
              }
              if(!r.ok)throw Error('HTTP '+r.status);
              var jr=beCsvRijen(await r.json(),dag);rijen.push.apply(rijen,jr);
              if(jr.length===1&&jr[0].export_status!=='brondata')leeg++;
              gelukt=true;break;
            } catch(e) {
              if(afgebroken)break;
              if(poging===3){rijen.push({datum:dag,export_status:'ophalen mislukt',fout:e.message});fouten++;}
            } finally {clearTimeout(timeout);controller=null;}
          }
          if(!afgebroken){klaar++;voortgang.value=klaar;}
        }
        if(rijen.length)beCsvSlaOp('BE-kwartierdata-'+begin+'-tot-'+eind+(afgebroken||fouten?'-gedeeltelijk':'')+'.csv',rijen);
        status.textContent=(afgebroken?'Gestopt. Deelbestand gedownload. ':'CSV gedownload. ')+klaar+'/'+dagen.length+' dagen; '+fouten+' mislukt; '+leeg+' zonder kwartierdata.';
      } catch(e){status.textContent='Export onderbroken: '+e.message;if(rijen.length)beCsvSlaOp('BE-kwartierdata-'+begin+'-gedeeltelijk.csv',rijen);}
      finally {beCsvBezig=false;start.disabled=van.disabled=tot.disabled=false;stop.hidden=true;}
    };
  }

  function beGrafiekRol(label) {
    return label === 'Totaal voordeel t.o.v. vast' ? 'Totaal' : label;
  }

  function beGrafiekDataSignatuur(chart) {
    return JSON.stringify([chart.data.labels, chart.data.datasets.map(function (d) {
      return [d.label, d.data];
    })]);
  }

  var CHART_SETS = [
    'Inkoop kosten',
    'Verkoop opbrengsten',
    'Totaal'
  ];

  var voorlopigChartPluginGeregistreerd = false;

  function zorgVoorlopigChartPlugin() {
    if (
      voorlopigChartPluginGeregistreerd ||
      !window.Chart ||
      typeof Chart.register !==
        'function'
    ) {
      return;
    }

    try {
      Chart.register({
        id:
          'beVoorlopigArcering',

        beforeDatasetsDraw: function (chart) {
          // Alleen bijgetekende staven: 70% van hun oorspronkelijke dekking.
          if (!chart.$beVoorlopigIndices || !chart.$beVoorlopigIndices.length) return;
          chart.data.datasets.forEach(function (ds, di) {
            var meta = chart.getDatasetMeta(di);
            (meta.data || []).forEach(function (bar, index) {
              if (bar.$beOrigineleDraw || typeof bar.draw !== 'function') return;
              var origineel = bar.draw;
              bar.$beOrigineleDraw = origineel;
              bar.draw = function (ctx) {
                ctx.save();
                try {
                  if ((chart.$beVoorlopigIndices || []).indexOf(index) !== -1) ctx.globalAlpha *= 0.7;
                  return origineel.apply(this, arguments);
                } finally { ctx.restore(); }
              };
            });
          });
        },

        afterDatasetsDraw:
          function (chart) {
            var indices =
              chart.$beVoorlopigIndices || [];

            if (!indices.length) {
              return;
            }

            var ctx =
              chart.ctx;

            indices.forEach(
              function (idx) {
                chart.data.datasets
                  .forEach(
                    function (ds, datasetIndex) {
                      if (
                        !Array.isArray(
                          ds.data
                        ) ||
                        ds.data[idx] == null ||
                        !Number.isFinite(
                          Number(
                            ds.data[idx]
                          )
                        )
                      ) {
                        return;
                      }

                      var meta =
                        chart.getDatasetMeta(
                          datasetIndex
                        );

                      var staaf =
                        meta &&
                        meta.data &&
                        meta.data[idx];

                      if (
                        !staaf ||
                        !Number.isFinite(
                          staaf.x
                        ) ||
                        !Number.isFinite(
                          staaf.y
                        ) ||
                        !Number.isFinite(
                          staaf.base
                        ) ||
                        !Number.isFinite(
                          staaf.width
                        ) ||
                        staaf.width <= 0
                      ) {
                        return;
                      }

                      var links =
                        staaf.x -
                        staaf.width / 2;

                      var rechts =
                        staaf.x +
                        staaf.width / 2;

                      var boven =
                        Math.min(
                          staaf.y,
                          staaf.base
                        );

                      var onder =
                        Math.max(
                          staaf.y,
                          staaf.base
                        );

                      if (
                        onder - boven < 1
                      ) {
                        return;
                      }

                      ctx.save();

                      ctx.beginPath();
                      ctx.rect(
                        links,
                        boven,
                        rechts - links,
                        onder - boven
                      );
                      ctx.clip();

                      ctx.fillStyle =
                        'rgba(107,63,160,.035)';

                      ctx.fillRect(
                        links,
                        boven,
                        rechts - links,
                        onder - boven
                      );

                      ctx.strokeStyle =
                        'rgba(107,63,160,.28)';

                      ctx.lineWidth =
                        1;

                      var hoogte =
                        onder - boven;

                      for (
                        var p =
                          links - hoogte;
                        p < rechts;
                        p += 7
                      ) {
                        ctx.beginPath();
                        ctx.moveTo(
                          p,
                          onder
                        );
                        ctx.lineTo(
                          p + hoogte,
                          boven
                        );
                        ctx.stroke();
                      }

                      ctx.restore();
                    }
                  );
              }
            );
          }
      });

      voorlopigChartPluginGeregistreerd =
        true;

    } catch (e) {
      /*
       * Chart kan de plugin al kennen na een SPA-herbouw.
       */
      voorlopigChartPluginGeregistreerd =
        true;
    }
  }

  function herstelVoorlopigeGrafiek(chart) {
    var v = chart && chart.$beVoorlopig;
    if (!v) return;
    if (JSON.stringify(chart.data.labels) === JSON.stringify(v.projectedLabels)) {
      chart.data.labels = v.basisLabels.slice();
      v.datasets.forEach(function (o) {
        if (chart.data.datasets.indexOf(o.ref) !== -1) o.ref.data = o.data.slice();
      });
    }
    chart.$beVoorlopig = null;
    chart.$beVoorlopigIndices = [];
  }

  function pasVoorlopigeMaandGrafiekAan(chart, rijen, allin) {
    if (laatste && laatste.interval === 'all_time') { pasAllTimeGrafiekAan(chart, rijen && rijen.beAllTime, allin); return; }
    if (!chart || !laatste || laatste.interval !== 'month') return;
    var mk = laatste.periode;
    if (!/^\d{4}-\d{2}$/.test(String(mk))) return;
    var echt = laatste.rijen || [];
    var labelsBron = chart.data.labels || [];
    function labelKey(lbl) {
      if (typeof lbl === 'number' && lbl >= 1 && lbl <= 31) return mk + '-' + n2(lbl);
      var t = String(lbl).trim().toLowerCase().replace(/^~/, '');
      if (/^\d{4}-\d{2}-\d{2}$/.test(t)) return t.slice(0, 7) === mk ? t : null;
      var m = t.match(/^(\d{1,2})(?:\s+([a-z]+)\.?)?$/);
      if (!m || +m[1] < 1 || +m[1] > dagenInMaand(mk)) return null;
      if (m[2] && m[2].slice(0, 3) !== MND_KORT[+mk.slice(5) - 1].toLowerCase().slice(0, 3)) return null;
      return mk + '-' + n2(+m[1]);
    }
    var indices = {};
    labelsBron.forEach(function (lbl, i) {
      var k = labelKey(lbl);
      if (k) indices[k] = indices[k] === undefined ? i : -1;
    });
    var perDag = {}, dubbel = false;
    echt.forEach(function (r, i) {
      if (!r || r.bronAanwezig === false) return;
      if (!voorlopigeDagGrenzen(r.key) || r.key.slice(0, 7) !== mk || perDag[r.key]) {
        dubbel = true; return;
      }
      var idx = indices[r.key];
      if (idx === undefined && echt.length === labelsBron.length) idx = i;
      if (idx === undefined || idx < 0) { dubbel = true; return; }
      perDag[r.key] = { index: idx };
    });
    if (dubbel) return;
    var opslag = leesVoorlopigeDagen();
    (rijen || []).forEach(function (r) {
      if (r && r.key && r.key.slice(0, 7) === mk && opslag[r.key] && !perDag[r.key]) {
        perDag[r.key] = { rij: opslag[r.key] };
      }
    });
    var basisLabels = chart.data.labels.slice();
    var datasets = chart.data.datasets.map(function (ds) {
      return { ref: ds, data: Array.isArray(ds.data) ? ds.data.slice() : [] };
    });
    var vandaag = iso(new Date());
    var einde = mk === vandaag.slice(0, 7) ? +vandaag.slice(8) : dagenInMaand(mk);
    if (mk > vandaag.slice(0, 7)) return;
    var labels = [], indices = [];
    var nieuw = datasets.map(function () { return []; });
    for (var dag = 1; dag <= einde; dag++) {
      var key = mk + '-' + n2(dag), item = perDag[key];
      labels.push(item && item.index !== undefined
        ? basisLabels[item.index]
        : item && item.rij
          ? voorlopigDagLabel(key)
          : key);
      var a = item && item.rij ? beResultaatWeergave(bereken(item.rij, naSaldering(key) ? item.rij.exp : 0, 1)) : null;
      if (a) indices.push(dag - 1);
      datasets.forEach(function (o, di) {
        var value = null;
        if (item && item.index !== undefined) {
          value = o.data[item.index] == null ? null : o.data[item.index];
        } else if (a) {
          if (o.ref.label === 'Inkoop kosten') value = allin ? -a.allinInk : item.rij.inkoop;
          if (o.ref.label === 'Verkoop opbrengsten') value = allin ? a.allinVerk : item.rij.verkoop;
          if (o.ref.label === 'Totaal') value = allin ? a.stroom : -item.rij.inkoop + item.rij.verkoop;
          if (o.ref.label === 'Energiebelasting') value = allin ? a.eb : null;
        }
        nieuw[di].push(value);
      });
    }
    chart.data.labels = labels;
    datasets.forEach(function (o, i) { o.ref.data = nieuw[i]; });
    chart.$beVoorlopig = { basisLabels: basisLabels, datasets: datasets, projectedLabels: labels.slice() };
    chart.$beVoorlopigIndices = indices;
    zorgVoorlopigChartPlugin();
  }

  function pasGrafiekAan(perPeriode, aan, poging, renderId, bron, voorlopigeRijen) {
    poging = poging || 0;

    if (
      renderId !== chartRenderId ||
      laatste !== bron ||
      !pastBijActievePeriode(bron, actievePeriode())
    ) {
      return;
    }

    var chart =
      window.Chart &&
      Chart.getChart
        ? Chart.getChart(
            'summary-chart'
          )
        : null;

    /*
     * Alleen de Resultaten-chart wordt hier gevolgd.
     * Actueel en andere Chart.js-instanties worden nergens aangeraakt.
     */
    if (!chart) {
      if (poging < 30) {
        chartHerstelTimer =
          setTimeout(
            function () {
              pasGrafiekAan(
                perPeriode,
                aan,
                poging + 1,
                renderId,
                bron,
                voorlopigeRijen
              );
            },
            75
          );
      }

      return;
    }

    /*
     * Een eventuele vorige maandprojectie één keer terugzetten naar
     * de basislabels/data voordat we op de native Balans-render wachten.
     *
     * Geen chart.update() hier: Balans mag eerst zijn eigen render en
     * animatie volledig afmaken.
     */
    if (
      chart.$beHerstelRenderId !==
      renderId
    ) {
      // Een nieuwe native render kan ook dezelfde maand opnieuw aanleveren.
      // Bewaar die actuele bron, nooit de vorige All-in-projectie als origineel.
      var externGewijzigd = chart.$beAllinSignatuur &&
        chart.$beAllinSignatuur !== beGrafiekDataSignatuur(chart);
      if (externGewijzigd) {
        chart.$beVoorlopig = null;
        chart.$beVoorlopigIndices = [];
        chartOrig = null;
      }
      herstelVoorlopigeGrafiek(chart);
      if (!externGewijzigd && chartOrig && chartOrig.chart === chart) {
        chart.data.datasets = chart.data.datasets.filter(function (d) {
          return d.label !== 'Energiebelasting';
        });
        chartOrig.sets.forEach(function (o) {
          var d = chart.data.datasets.find(function (v) {
            return beGrafiekRol(v.label) === beGrafiekRol(o.label);
          });
          if (d) { d.label = o.label; d.data = o.data.slice(); }
        });
      }

      chart.$beHerstelRenderId =
        renderId;
    }

    var n =
      chart.data &&
      chart.data.labels
        ? chart.data.labels.length
        : 0;

    var origineleSets =
      chart.data &&
      chart.data.datasets
        ? chart.data.datasets.filter(
            function (d) {
              return (
                CHART_SETS.indexOf(
                  beGrafiekRol(d.label)
                ) !== -1
              );
            }
          )
        : [];

    var klaar =
      n > 0 &&
      origineleSets.length ===
        CHART_SETS.length &&
      origineleSets.every(
        function (d) {
          return (
            Array.isArray(
              d.data
            ) &&
            d.data.length === n
          );
        }
      );

    if (!klaar) {
      if (poging < 30) {
        chartHerstelTimer =
          setTimeout(
            function () {
              pasGrafiekAan(
                perPeriode,
                aan,
                poging + 1,
                renderId,
                bron,
                voorlopigeRijen
              );
            },
            75
          );
      }

      return;
    }

    var nu =
      (
        window.performance &&
        typeof performance.now ===
          'function'
      )
        ? performance.now()
        : Date.now();

    var vinger =
      grafiekRenderVingerafdruk(
        chart
      );

    if (
      !chartWachtStatus ||
      chartWachtStatus.renderId !==
        renderId ||
      chartWachtStatus.chart !==
        chart
    ) {
      chartWachtStatus = {
        renderId:
          renderId,

        chart:
          chart,

        gestart:
          nu,

        vorige:
          vinger,

        stabiel:
          0
      };

    } else if (
      chartWachtStatus.vorige ===
      vinger
    ) {
      chartWachtStatus.stabiel++;

    } else {
      chartWachtStatus.vorige =
        vinger;

      chartWachtStatus.stabiel =
        0;
    }

    /*
     * Dit is bewust géén vaste "180 ms en hopen"-render meer.
     *
     * We kijken uitsluitend naar summary-chart en wachten:
     * - minimaal 450 ms nadat de native chart bruikbaar werd;
     * - én minstens 5 opeenvolgende animation frames zonder
     *   verandering in schaal/chartArea/staaf- of puntgeometrie.
     *
     * Daardoor kan de originele Balans-animatie volledig aflopen.
     * Na maximaal 3 s gaan we toch door om een vastloper te voorkomen.
     */
    var langGenoeg =
      nu -
      chartWachtStatus.gestart >=
      450;

    var stabielGenoeg =
      chartWachtStatus.stabiel >=
      5;

    var timeout =
      nu -
      chartWachtStatus.gestart >=
      3000;

    if (
      (
        !langGenoeg ||
        !stabielGenoeg
      ) &&
      !timeout
    ) {
      chartWachtFrame =
        requestAnimationFrame(
          function () {
            pasGrafiekAan(
              perPeriode,
              aan,
              poging,
              renderId,
              bron,
              voorlopigeRijen
            );
          }
        );

      return;
    }

    chartWachtFrame =
      null;

    chartWachtStatus =
      null;

    delete chart.$beHerstelRenderId;

    /*
     * Pas NU — nadat Balans klaar is — nemen we de native reeks als
     * basis en zetten we de All-in/provisional projectie erop.
     */
    var sleutel =
      grafiekSleutel(
        chart
      );

    if (
      !chartOrig ||
      chartOrig.sleutel !==
        sleutel ||
      chartOrig.chart !==
        chart
    ) {
      chartOrig = {
        chart:
          chart,

        sleutel:
          sleutel,

        n:
          n,

        sets:
          origineleSets.map(
            function (d) {
              return {
                label:
                  d.label,

                data:
                  d.data.slice()
              };
            }
          )
      };
    }

    chart.data.datasets =
      chart.data.datasets
        .filter(
          function (d) {
            return (
              d.label !==
              'Energiebelasting'
            );
          }
        );

    if (
      !aan ||
      !perPeriode ||
      perPeriode.length !== n
    ) {
      chartOrig.sets
        .forEach(
          function (o) {
            var ds =
              chart.data.datasets
                .find(
                  function (d) {
                    return (
                      d.label ===
                      o.label
                    );
                  }
                );

            if (ds) {
              ds.data =
                o.data.slice();
            }
          }
        );

    } else {
      chart.data.datasets
        .forEach(
          function (ds) {
            if (
              ds.label ===
              'Inkoop kosten'
            ) {
              ds.data =
                perPeriode.map(
                  function (a) {
                    return -a.allinInk;
                  }
                );
            }

            if (
              ds.label ===
              'Verkoop opbrengsten'
            ) {
              ds.data =
                perPeriode.map(
                  function (a) {
                    return a.allinVerk;
                  }
                );
            }

            if (
              beGrafiekRol(ds.label) ===
              'Totaal'
            ) {
              ds.label = 'Totaal';
              ds.data =
                perPeriode.map(
                  function (a) {
                    return a.stroom;
                  }
                );
            }
          }
        );

      if (cfg.resultaatBelastingen !== false) chart.data.datasets.push({
        label:
          'Energiebelasting',

        data:
          perPeriode.map(
            function (a) {
              return a.eb;
            }
          ),

        backgroundColor:
          '#1D9E75',

        borderRadius:
          0,

        order:
          2
      });
    }

    /*
     * Provisional dagen veranderen bij Maand ook het aantal X-categorieën.
     * Dat gebeurt vóór onderstaande normale Chart.js-update, zodat breedte
     * en schaal in dezelfde layoutpass opnieuw worden berekend.
     */
    if (aan && perPeriode && perPeriode.length === n) {
      pasVoorlopigeMaandGrafiekAan(chart, voorlopigeRijen || [], true);
    }
    // De toelichting hoort bij de weergegeven berekening, niet bij BE's vergelijking.
    var toelichting = document.querySelector('.results-summary-card .card-header small');
    if (toelichting) {
      if (toelichting.$beOrigineel === undefined) toelichting.$beOrigineel = toelichting.textContent;
      toelichting.textContent = aan && perPeriode && perPeriode.length === n
        ? (cfg.resultaatBelastingen !== false
          ? 'Totaal: verkoopopbrengst min inkoopkosten, inclusief all-in-correcties. Zonder besparingen ten opzichte van een vast contract.'
          : 'Totaal: verkoop min inkoop, zonder EB en btw. Met € 0,02/kWh opslag bij inkoop en € 0,02/kWh aftrek bij verkoop.')
        : toelichting.$beOrigineel;
    }
    chart.$beAllinSignatuur = beGrafiekDataSignatuur(chart);

    if (
      chart.options.scales &&
      chart.options.scales.y
    ) {
      chart.options.scales.y.min =
        undefined;

      chart.options.scales.y.max =
        undefined;
    }

    /*
     * Geen update('none'): de normale Chart.js-animatie blijft behouden.
     * Omdat de native animatie hierboven al klaar was, vechten twee renders
     * niet meer om dezelfde schaal/bar-geometrie.
     */
    chart.update();
  }


  /*
   * ============================================================
   * RESULTATEN — API onderscheppen
   * ============================================================
   */

  var laatste = null;
  var periodeCache = {};
  var timer = null;

  // All time spans the installation's first recorded day through today.
  // Confirmed data wins; recent missing days may be supplemented by measured
  // provisional records. Missing measurements are never replaced by forecasts.
  function maakAllTime(bron, opslag, g, nu) {
    var vandaag = iso(nu), begin = g && g.min_day;
    var verwerkt = g && g.max_day;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(begin || '') || !/^\d{4}-\d{2}-\d{2}$/.test(verwerkt || '')) return null;
    var dagen = Math.max(0, datumDagNummer(nu) - datumDagNummer(new Date(begin + 'T12:00:00')) + 1);
    var velden = ['imp','exp','inkoop','verkoop','laden','ontladen','pv','afrrImp','afrrExp','afrrVergoeding','dealsAantal'];
    var maanden = {}, extra = [], ontbreekt = [], onvolledig = [];
    (bron.rijen || []).forEach(function(r) {
      var m = Object.assign({}, r, {geprijsdeImportKwh:r.imp,geprijsdeExportKwh:r.exp});
      maanden[r.key] = m;
    });
    Object.keys(opslag).sort().forEach(function(key) {
      var r = opslag[key];
      if (key <= verwerkt || key < begin || key > vandaag || !r || r.prijsHerberekenen || !r.voorlopig ||
          !['imp','exp','inkoop','verkoop'].every(function(k){return Number.isFinite(r[k]);})) return;
      extra.push(r);
      if (r.deelresultaat || r.prijsOnvolledig) onvolledig.push(key);
      var mk = key.slice(0,7), m = maanden[mk];
      if (!m) { m = {key:mk,bronAanwezig:true,geprijsdeImportKwh:0,geprijsdeExportKwh:0}; velden.forEach(function(k){m[k]=0;}); maanden[mk]=m; }
      velden.forEach(function(k){m[k]=getal(m[k])+getal(r[k]);});
      m.voorlopig = true;
      m.geprijsdeImportKwh += Number.isFinite(r.geprijsdeImportKwh) ? r.geprijsdeImportKwh : r.imp;
      m.geprijsdeExportKwh += Number.isFinite(r.geprijsdeExportKwh) ? r.geprijsdeExportKwh : r.exp;
    });
    var heeft = new Set(extra.map(function(r){return r.key;}));
    var cursor = new Date(verwerkt+'T12:00:00'); cursor.setDate(cursor.getDate()+1);
    while (iso(cursor) <= vandaag) { if (!heeft.has(iso(cursor))) ontbreekt.push(iso(cursor)); cursor.setDate(cursor.getDate()+1); }
    var rijen = Object.keys(maanden).sort().map(function(k){return maanden[k];});
    // Preserve annual settlement boundaries instead of netting separate years.
    var groepen = {}, saldMap = {};
    rijen.forEach(function(r){
      var y=+r.key.slice(0,4), m=+r.key.slice(5,7);
      var groep=y-(m<cfg.start.getMonth()+1?1:0);
      (groepen[groep]||(groepen[groep]=[])).push(r);
    });
    Object.keys(groepen).forEach(function(k){salderingReeks(groepen[k],false).forEach(function(r){saldMap[r.key]=r.ongesaldeerd;});});
    var totaal=Object.assign({},bron.totaal), geprijsdImp=bron.totaal.imp, geprijsdExp=bron.totaal.exp;
    extra.forEach(function(r){
      velden.forEach(function(k){totaal[k]=getal(totaal[k])+getal(r[k]);});
      geprijsdImp+=Number.isFinite(r.geprijsdeImportKwh)?r.geprijsdeImportKwh:r.imp;
      geprijsdExp+=Number.isFinite(r.geprijsdeExportKwh)?r.geprijsdeExportKwh:r.exp;
    });
    if(extra.length){totaal.voorlopig=true;totaal.geprijsdeImportKwh=geprijsdImp;totaal.geprijsdeExportKwh=geprijsdExp;}
    var onges=rijen.reduce(function(n,r){return n+(saldMap[r.key]||0);},0);
    var berekend=rijen.map(function(r){return bereken(r,saldMap[r.key]||0,0);});
    return {a:bereken(totaal,onges,dagen), rijen:rijen, berekend:berekend, extra:extra,
      begin:begin, einde:vandaag, verwerkt:verwerkt, ontbreekt:ontbreekt, onvolledig:onvolledig,
      ruw:{inkoop:totaal.inkoop,verkoop:totaal.verkoop,prijsInk:totaal.imp?totaal.inkoop/totaal.imp:0,prijsVerk:totaal.exp?totaal.verkoop/totaal.exp:0}};
  }

  function pasAllTimeGrafiekAan(chart, info, aan) {
    if (!chart || !info || !aan) return;
    var labels=chart.data.labels.slice(),sets=chart.data.datasets.map(function(d){return {ref:d,data:d.data.slice()};});
    var nativeKeys=laatste.rijen.map(function(r){return r.key;});
    chart.data.labels=info.rijen.map(function(r){var i=nativeKeys.indexOf(r.key);return i>=0?labels[i]:'~'+maandLabel(r.key);});
    chart.data.datasets.forEach(function(d){
      var field={'Inkoop kosten':'allinInk','Verkoop opbrengsten':'allinVerk','Totaal':'stroom','Energiebelasting':'eb'}[d.label];
      if(field)d.data=info.berekend.map(function(a){a=beResultaatWeergave(a);return field==='allinInk'?-a[field]:a[field];});
    });
    chart.$beVoorlopig={basisLabels:labels,datasets:sets,projectedLabels:chart.data.labels.slice()};
    chart.$beVoorlopigIndices=info.rijen.map(function(r,i){return r.voorlopig?i:-1;}).filter(function(i){return i>=0;});
  }

  function isJaarInterval(interval) {
    return interval === 'year' || interval === 'rolling_year';
  }

  function actievePeriode() {
    var knop = document.querySelector('.summary-granularity.active');
    var g = knop ? knop.textContent.trim().toLowerCase() : 'maand';

    // All time has its own API period; never fall back to the hidden month picker.
    if ((knop && knop.getAttribute('data-granularity') === 'all_time') || g === 'all time') {
      return { interval: 'all_time', periode: 'all' };
    }

    if (g === 'dag') {
      var dagPicker = document.getElementById('dayPicker');
      return {
        interval: 'day',
        periode: dagPicker ? dagPicker.value : null
      };
    }

    if (g === 'jaar') {
      var jaarPicker = document.getElementById('summary-year-picker');
      var jaarKeuze = jaarPicker ? String(jaarPicker.value || '') : '';
      var jaarTekst =
        jaarPicker &&
        jaarPicker.options &&
        jaarPicker.selectedIndex >= 0
          ? String(
              jaarPicker.options[
                jaarPicker.selectedIndex
              ].textContent || ''
            ).trim()
          : (
              jaarPicker
                ? String(
                    jaarPicker.textContent ||
                    jaarPicker.getAttribute('value') ||
                    jaarPicker.getAttribute('aria-valuetext') ||
                    ''
                  ).trim()
                : ''
            );

      /*
       * Balans gebruikt voor "12 maanden" sinds de dashboardwijziging:
       * interval=rolling_year&period=de huidige jjjj-mm.
       */
      if (
        jaarKeuze === 'rolling_year' ||
        /12\s*maanden/i.test(jaarTekst)
      ) {
        return {
          interval: 'rolling_year',
          periode: iso(new Date()).slice(0, 7)
        };
      }

      return {
        interval: 'year',
        periode: jaarKeuze || String(new Date().getFullYear())
      };
    }

    var maandPicker = document.getElementById('summary-month-picker');
    return {
      interval: 'month',
      periode: maandPicker ? maandPicker.value : null
    };
  }

  function periodeSleutel(
    interval,
    periode
  ) {
    return (
      String(interval || '') +
      '|' +
      String(periode || '')
    );
  }

  function pastBijActievePeriode(
    data,
    actief
  ) {
    if (!data || !actief) {
      return false;
    }

    return (
      data.interval === actief.interval &&
      (
        !actief.periode ||
        String(data.periode || '') === String(actief.periode)
      )
    );
  }

  function kiesActieveCache() {
    var actief = actievePeriode();
    var opgeslagen = periodeCache[
      periodeSleutel(
        actief.interval,
        actief.periode
      )
    ];

    if (opgeslagen) {
      laatste = opgeslagen;
      return true;
    }

    return pastBijActievePeriode(
      laatste,
      actief
    );
  }

  function onthoud(
    j,
    valInterval,
    valPeriode
  ) {
    if (
      !j ||
      !Array.isArray(
        j.series
      )
    ) {
      return false;
    }

    var actief =
      actievePeriode();

    var isAangevraagdeRolling =
      actief.interval === 'rolling_year' &&
      valInterval === 'rolling_year';

    var interval =
      isAangevraagdeRolling
        ? 'rolling_year'
        : (
            j.interval ||
            valInterval ||
            'month'
          );

    var pv =
      j.pricing || {};

    var tot =
      j.totals || {};

    var snapshot = {
      rijen:
        j.series.map(
          function (s) {
            return naarIncl(
              s,
              pv
            );
          }
        ),

      totaal:
        naarIncl(
          tot,
          pv
        ),

      ruw: {
        inkoop:
          getal(
            tot.total_buy_eur
          ),

        verkoop:
          getal(
            tot.total_sell_eur
          ),

        prijsInk:
          getal(
            tot.avg_buy_price_eur_per_kwh
          ),

        prijsVerk:
          getal(
            tot.avg_sell_price_eur_per_kwh
          )
      },

      interval:
        interval,

      periode:
        isAangevraagdeRolling
          ? (
              valPeriode ||
              actief.periode
            )
          : (
              j.period ||
              valPeriode ||
              actief.periode
            )
    };

    periodeCache[
      periodeSleutel(
        snapshot.interval,
        snapshot.periode
      )
    ] = snapshot;

    /*
     * Balans kan tijdens de opbouw van Resultaten nog een antwoord van
     * de vorige granulariteit afronden. Bewaar dat antwoord wel, maar laat
     * het de nu gekozen Dag/Maand/Jaar-periode nooit overschrijven.
     */
    if (!pastBijActievePeriode(snapshot, actief)) {
      return false;
    }

    laatste = snapshot;

    return true;
  }

  if (
    KLANT &&
    KLANT !== 'account'
  ) {
    window.fetch =
      function (
        input,
        init
      ) {
        var url =
          typeof input === 'string'
            ? input
            : (
                input &&
                typeof input.url ===
                  'string'
                  ? input.url
                  : ''
              );

        var p =
          origFetch(
            input,
            init
          );

        // Observe dashboard price refreshes immediately, without changing its response.
        if (url.indexOf('/customer/current-prices/api/') !== -1) {
          p.then(function (resp) {
            if (!resp.ok) return;
            return resp.clone().json().then(function (j) {
              window.BECurrentTariffCache.remember(KLANT,j);
              if (isActueelPagina()) beOntvangLivePrijzen(j);
              beBewaarPrijzenLater(j);
            });
          }).catch(function () {});
        }

        if (
          url.indexOf(
            'results-v2-api'
          ) === -1
        ) {
          return p;
        }

        return p.then(
          function (resp) {
            if (!resp.ok) {
              return resp;
            }

            var requestUrl;

            try {
              requestUrl =
                new URL(
                  url,
                  location.origin
                );
            } catch (e) {
              requestUrl = null;
            }

            resp.clone()
              .json()
              .then(
                function (j) {
                  if (
                    onthoud(
                      j,
                      requestUrl
                        ? requestUrl.searchParams.get('interval')
                        : null,
                      requestUrl
                        ? requestUrl.searchParams.get('period')
                        : null
                    )
                  ) {
                    plan();
                  }
                }
              )
              .catch(
                function () {}
              );

            return resp;
          }
        );
      };
  }

  function plan() {
    return; // v6: Resultaten blijft native; het eigen overzicht leest zijn eigen data.
    clearTimeout(
      timer
    );

    timer =
      setTimeout(
        function () {
          if (kiesActieveCache()) {
            herteken();

          } else {
            zelfHalen()
              .then(
                function (ok) {
                  if (ok) {
                    herteken();
                  }
                }
              );
          }
        },
        90
      );
  }

  var bezig = false;

  function zelfHalen() {
    if (
      bezig ||
      !KLANT
    ) {
      return Promise.resolve(
        false
      );
    }

    var actief =
      actievePeriode();

    if (!actief.periode) {
      return Promise.resolve(
        false
      );
    }

    bezig = true;

    var u =
      new URL(
        location.origin +
        '/customer/' +
        KLANT +
        '/results-v2-api/'
      );

    u.searchParams.set(
      'interval',
      actief.interval
    );

    u.searchParams.set(
      'period',
      actief.periode
    );

    u.searchParams.set(
      'include_vat',
      '1'
    );

    u.searchParams.set(
      'include_delivery_cost',
      '1'
    );

    return origFetch(
      u,
      {
        credentials:
          'same-origin'
      }
    )

      .then(
        function (r) {
          return r.ok
            ? r.json()
            : null;
        }
      )

      .then(
        function (j) {
          bezig = false;

          return onthoud(
            j,
            actief.interval,
            actief.periode
          );
        }
      )

      .catch(
        function () {
          bezig = false;
          return false;
        }
      );
  }


  /*
   * ============================================================
   * RESULTATEN — pagina bouwen
   * ============================================================
   */

  function anker() {
    var k =
      document.querySelector(
        '.results-summary-card'
      );

    return k
      ? k.closest(
          '.row'
        )
      : null;
  }

  function houder() {
    var h =
      document.getElementById(
        'be-panelen'
      );

    if (h) {
      return h;
    }

    var a =
      anker();

    if (
      !a ||
      !a.parentElement
    ) {
      return null;
    }

    h =
      el(
        'div',
        ''
      );

    h.id =
      'be-panelen';

    a.parentElement
      .insertBefore(
        h,
        a.nextSibling
      );

    return h;
  }

  function regelBalansBlok() {
    var b =
      document.querySelector(
        '.results-trade-savings-card'
      );

    /*
     * De nieuwe dashboardopbouw deelt layout-rijen met andere onderdelen.
     * Verberg daarom alleen de kaart zelf en nooit meer closest('.row').
     */
    if (b) {
      b.style.display =
        cfg.balansBlok
          ? ''
          : 'none';
    }

    /* De originele kop/intro blijft staan; die hoort bij de pagina. */
  }

  function periodeNaam() {
    if (laatste && laatste.interval === 'all_time') return 'All time';
    var t =
      document.getElementById(
        'summary-title'
      );

    return t
      ? t.textContent.trim()
      : (
          laatste
            ? laatste.periode
            : ''
        );
  }

  // Bewaar de oorspronkelijke BE-cellen per DOM-rij; herladen maakt nieuwe rijen.
  var beTabelOrigineel = new WeakMap();
  function beResultatenTabel(perPeriode, bron) {
    var wrapper=document.getElementById('summary-table-wrapper');
    var heading=document.getElementById('summary-table-heading');
    var panelen=document.getElementById('be-panelen');
    if(!wrapper||!panelen||!panelen.parentNode)return;
    var host=document.getElementById('be-resultatentabel');
    if(!host){
      host=document.createElement('div');host.id='be-resultatentabel';
      host.style.cssText='margin-top:18px;padding:18px;border:1px solid '+D.rand+';border-radius:12px;min-width:0';
      panelen.parentNode.insertBefore(host,panelen.nextSibling);
    }
    // Buiten be-panelen: hertekenen van onze kaarten mag de BE-rijen niet wissen.
    if(heading&&heading.parentNode!==host)host.appendChild(heading);
    if(wrapper.parentNode!==host)host.appendChild(wrapper);
    var body=document.getElementById('summary-table-body');
    if(!body)return;
    var rows=Array.from(body.rows),headers=Array.from(wrapper.querySelectorAll('thead th'));
    var aan=cfg.allin&&bron&&bron.interval!=='day';
    host.hidden=!bron||bron.interval==='day'||!rows.length;
    var note=document.getElementById('be-resultatentabel-uitleg');
    if(!note){note=document.createElement('p');note.id='be-resultatentabel-uitleg';note.style.cssText='font-size:12px;color:'+D.grijs+';margin:10px 0';host.insertBefore(note,wrapper);}
    var uitleg=aan?'Totaal = verkoopopbrengsten − inkoopkosten. '+(cfg.resultaatBelastingen?'Inclusief btw en energiebelasting na saldering.':'Zonder btw en energiebelasting.')+' Opslag aan beide kanten inbegrepen. Beschikbare bronperioden; prognoses en losse voorlopige aanvullingen staan in het overzicht erboven.':'';
    if(note.textContent!==uitleg)note.textContent=uitleg;
    note.hidden=!aan;
    function herstel(node){
      var oud=beTabelOrigineel.get(node);
      if(oud&&node.innerHTML!==oud)node.innerHTML=oud;
    }
    headers.forEach(function(th,i){
      if(!beTabelOrigineel.has(th))beTabelOrigineel.set(th,th.innerHTML);
      th.hidden=aan&&(i===5||i===6);
      if(i===1){
        if(!th.dataset.beOrigTitle)th.dataset.beOrigTitle=th.title||' ';
        th.title=aan?'Verkoopopbrengsten min inkoopkosten, volgens de gekozen belastingstand.':th.dataset.beOrigTitle.trim();
      }
    });
    rows.forEach(function(row,index){
      if(!beTabelOrigineel.has(row))beTabelOrigineel.set(row,row.innerHTML);
      if(!aan){herstel(row);return;}
      var a=perPeriode&&perPeriode[index],r=bron.rijen&&bron.rijen[index];
      // Nooit resultaten op een andere bronperiode plakken.
      var geldig=rows.length===bron.rijen.length&&a&&r&&a.key===r.key&&r.bronAanwezig!==false;
      var cells=Array.from(row.cells);if(cells.length<9)return;
      [5,6].forEach(function(i){cells[i].hidden=true;});
      function zet(i,value,decimalen){
        var tekst=Number.isFinite(value)?new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR',minimumFractionDigits:decimalen,maximumFractionDigits:decimalen}).format(value):'—';
        if(cells[i].textContent!==tekst)cells[i].textContent=tekst;
        cells[i].removeAttribute('title');
      }
      zet(1,geldig?a.stroom:NaN,2);zet(2,geldig?-a.allinInk:NaN,2);zet(3,geldig?a.allinVerk:NaN,2);
      cells[1].classList.remove('text-success','text-danger');
      cells[1].style.color=geldig?(a.stroom<0?D.rood:D.groen):D.grijs;
      var prijs=function(n){return Number.isFinite(n)?new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR',minimumFractionDigits:3,maximumFractionDigits:3}).format(n)+' / kWh':'—';};
      var prijzen=prijs(geldig&&a.imp>0?-a.allinInk/a.imp:NaN)+'<br>'+prijs(geldig&&a.exp>0?a.allinVerk/a.exp:NaN);
      if(cells[4].innerHTML!==prijzen)cells[4].innerHTML=prijzen;
    });
  }

  function herteken() {
    if (!kiesActieveCache()) {
      zelfHalen()
        .then(
          function (ok) {
            if (ok) {
              herteken();
            }
          }
        );

      return;
    }

    var h =
      houder();

    if (!h) {
      return;
    }

    regelBalansBlok();
    var renderBron = laatste;

    var extraMaandKey =
      null;

    if (
      laatste.interval ===
        'day' &&
      laatste.periode
    ) {
      extraMaandKey =
        String(
          laatste.periode
        ).slice(
          0,
          7
        );

    } else if (
      isJaarInterval(laatste.interval) &&
      (
        laatste.interval === 'rolling_year' ||
        String(laatste.periode) === String(new Date().getFullYear())
      )
    ) {
      extraMaandKey =
        iso(
          new Date()
        ).slice(
          0,
          7
        );
    }

    var extraMaand =
      extraMaandKey
        ? haalMaandDagen(
            extraMaandKey
          )
        : Promise.resolve(
            []
          );

    /*
     * Voorschot & verrekening beslaat het contractjaar, onafhankelijk
     * van de hierboven geselecteerde grafiekperiode. Valideer de
     * voorlopige dagen daarom altijd tegen de echte dagen van de
     * lopende maand, ook wanneer de gebruiker 2025 bekijkt.
     */
    var contractVoorlopigeKey =
      iso(new Date()).slice(0, 7);

    var contractMaand =
      laatste.interval === 'month' &&
      laatste.periode === contractVoorlopigeKey
        ? Promise.resolve(laatste.rijen)
        : extraMaandKey === contractVoorlopigeKey
          ? extraMaand
          : haalMaandDagen(contractVoorlopigeKey);

    Promise.all([
      haalContractjaar(),
      haalLopendeDagen(),
      extraMaand,
      contractMaand
    ]).then(
      function (res) {
        if (laatste !== renderBron || !pastBijActievePeriode(renderBron, actievePeriode())) return;
        var jaar =
          res[0];

        var sald =
          salderingReeks(
            jaar,
            false
          );

        var saldProg =
          salderingReeks(
            jaar,
            true
          );

        var tot =
          laatste.totaal;

        var huidigeKey = null;
        var ongesaldeerd;
        var dagen;
        var periodeWoord;

        if (
          laatste.interval ===
            'month' &&
          laatste.periode
        ) {
          huidigeKey =
            laatste.periode;

          tot.key =
            huidigeKey;

          var s =
            sald.find(
              function (x) {
                return (
                  x.key ===
                  huidigeKey
                );
              }
            );

          ongesaldeerd =
            s
              ? s.ongesaldeerd
              : Math.max(
                  0,
                  tot.exp -
                  tot.imp
                );

          dagen =
            dagenVerstreken(
              huidigeKey
            );

          periodeWoord =
            'deze maand';

        } else if (
          laatste.interval ===
          'day'
        ) {
          huidigeKey =
            laatste.periode
              ? String(
                  laatste.periode
                ).slice(
                  0,
                  7
                )
              : null;

          var sm =
            sald.find(
              function (x) {
                return (
                  x.key ===
                  huidigeKey
                );
              }
            );

          var maandExp =
            res[2].reduce(
              function (
                a,
                r
              ) {
                return (
                  a +
                  r.exp
                );
              },
              0
            );

          var fractieDagOnges =
            (
              sm &&
              maandExp > 0
            )
              ? (
                  sm.ongesaldeerd /
                  maandExp
                )
              : 0;

          ongesaldeerd =
            tot.exp *
            Math.min(
              1,
              Math.max(
                0,
                fractieDagOnges
              )
            );

          dagen = 1;

          periodeWoord =
            'deze dag';

        } else {
          if (
            isJaarInterval(laatste.interval) &&
            (
              laatste.interval === 'rolling_year' ||
              String(laatste.periode) === String(new Date().getFullYear())
            )
          ) {
            huidigeKey =
              iso(
                new Date()
              ).slice(
                0,
                7
              );
          }

          var eigenKeys = {};

          laatste.rijen
            .forEach(
              function (r) {
                if (r.key) {
                  eigenKeys[
                    r.key
                  ] = true;
                }
              }
            );

          dagen =
            laatste.rijen
              .reduce(
                function (
                  a,
                  r
                ) {
                  return (
                    a +
                    (
                      r.key
                        ? dagenVerstreken(
                            r.key
                          )
                        : 0
                    )
                  );
                },
                0
              );

          ongesaldeerd =
            sald.reduce(
              function (
                a,
                x
              ) {
                return (
                  a +
                  (
                    x.overgeslagen ||
                    !eigenKeys[
                      x.key
                    ]
                      ? 0
                      : x.ongesaldeerd
                  )
                );
              },
              0
            );

          periodeWoord =
            laatste.interval === 'all_time' ? 'de gehele beschikbare periode' : 'deze periode';
        }

        var a =
          bereken(
            tot,
            ongesaldeerd,
            dagen
          );

        var fractieOnges =
          tot.exp > 0
            ? (
                ongesaldeerd /
                tot.exp
              )
            : 0;

        var perPeriode =
          laatste.rijen.map(
            function (r) {
              return bereken(
                r,
                r.exp *
                fractieOnges,
                1
              );
            }
          );

        var voorlopigeRijen =
          (
            laatste.interval ===
              'month' ||
            laatste.interval ===
              'day'
          )
            ? voorlopigeDagenVoorMaand(
                huidigeKey,
                laatste.interval ===
                  'day'
                    ? res[2]
                    : laatste.rijen
              )
            : (
                isJaarInterval(laatste.interval) &&
                huidigeKey
                  ? voorlopigeDagenVoorMaand(
                      huidigeKey,
                      res[2]
                    )
                  : []
              );

        var contractVoorlopigeRijen =
          voorlopigeDagenVoorMaand(
            contractVoorlopigeKey,
            res[3]
          );

        var allTimeInfo = laatste.interval === 'all_time'
          ? maakAllTime(laatste, leesVoorlopigeDagen(), grenzen(), new Date()) : null;
        if (allTimeInfo) {
          a = allTimeInfo.a;
          voorlopigeRijen = allTimeInfo.extra.slice();
          voorlopigeRijen.beAllTime = allTimeInfo;
          perPeriode = laatste.rijen.map(function(r){return allTimeInfo.berekend.find(function(x){return x.key===r.key;});});
        }
        a = beResultaatWeergave(a);
        perPeriode = perPeriode.map(beResultaatWeergave);
        beResultatenTabel(perPeriode, laatste);
        pasBalansKaartenAan(
          a,
          allTimeInfo ? allTimeInfo.ruw : laatste.ruw,
          cfg.allin
        );

        clearTimeout(
          chartHerstelTimer
        );

        if (chartWachtFrame) {
          cancelAnimationFrame(
            chartWachtFrame
          );

          chartWachtFrame =
            null;
        }

        chartWachtStatus =
          null;

        var renderId =
          ++chartRenderId;

        var bron =
          laatste;

        var grafiekAan =
          cfg.allin &&
          laatste.interval !==
            'day';

        chartHerstelTimer =
          setTimeout(
            function () {
              pasGrafiekAan(
                perPeriode,
                grafiekAan,
                0,
                renderId,
                bron,
                voorlopigeRijen
              );
            },
            30
          );

        h.innerHTML = '';

        if (!cfg.allin) {
          h.appendChild(
            el(
              'div',
              'margin-top:14px;' +
              'padding:11px 14px;' +
              'border:1px dashed ' +
              D.rand +
              ';border-radius:9px;' +
              'font-size:12px;' +
              'color:' +
              D.grijs +
              ';',

              'All-in staat uit \u2014 dit zijn de cijfers van Balans zelf, ' +
              'zonder energiebelasting. Zet de schakelaar ' +
              '<b style="color:' +
              D.paars +
              ';">All-in</b> in de kaartkop aan.'
            )
          );

          return;
        }

        var maandStaat =
          bouwMaandstaat(
            jaar,
            sald,
            saldProg,
            huidigeKey,
            contractVoorlopigeRijen,
            contractVoorlopigeKey
          );

        var kaartCtx = {
          naam:
            periodeNaam(),

          interval:
            laatste.interval,

          periodeWoord:
            periodeWoord
        };

        if (
          laatste.interval ===
            'rolling_year'
        ) {
          kaartCtx.contractBetaald =
            parseFloat(
              maandStaat.dataset.beBetaald
            );

          kaartCtx.contractWerkelijk =
            parseFloat(
              maandStaat.dataset.beWerkelijk
            );

          kaartCtx.contractSaldo =
            parseFloat(
              maandStaat.dataset.beSaldoNu
            );

          kaartCtx.contractMaanden =
            parseInt(
              maandStaat.dataset.beMaandenBekend,
              10
            ) || 0;
        }

        if (laatste.interval === 'month') {
          kaartCtx.voorlopigStroom = 0;
          kaartCtx.voorlopigAantal = voorlopigeRijen.length;
          voorlopigeRijen.forEach(function (r) {
            kaartCtx.voorlopigStroom += beResultaatWeergave(bereken(
              r, naSaldering(r.key) ? r.exp : 0, 1
            )).stroom;
          });
        }

        var kaartEl =
          bouwHoofdkaart(
            a,
            kaartCtx
          );

        if (allTimeInfo) {
          var fmt = function(key) { var p=key.split('-');return p[2]+'-'+p[1]+'-'+p[0]; };
          var melding = document.createElement('div');
          melding.id='be-all-time-bereik';
          melding.style.cssText='font-size:12px;color:'+D.grijs+';margin-bottom:12px;line-height:1.6';
          melding.textContent='Vanaf aansluiting '+fmt(allTimeInfo.begin)+' t/m vandaag '+fmt(allTimeInfo.einde)+
            '. Verwerkt t/m '+fmt(allTimeInfo.verwerkt)+'.'+
            (allTimeInfo.extra.length ? ' '+allTimeInfo.extra.length+' voorlopige dag(en) meegerekend.' : '')+
            (allTimeInfo.onvolledig.length ? ' Voorlopige metingen/prijzen deels onvolledig: '+allTimeInfo.onvolledig.map(fmt).join(', ')+'.' : '')+
            (allTimeInfo.ontbreekt.length ? ' Nog geen resultaat voor: '+allTimeInfo.ontbreekt.map(fmt).join(', ')+'.' : '');
          kaartEl.insertBefore(melding,kaartEl.firstChild.nextSibling);
        }
        kaartEl.appendChild(
          bouwPrijsopbouw(
            a
          )
        );

        if (laatste.interval !== 'day') {
          var f = fpr(perPeriode);
          var fprSectie = bouwFpr(f, periodeWoord);

          if (fprSectie) {
            kaartEl.appendChild(fprSectie);
          }
        }

        kaartEl.appendChild(
          maandStaat
        );

        var saldSectie =
          bouwSaldering(
            salderingPrognose
              ? saldProg
              : sald
          );

        if (saldSectie) {
          kaartEl.appendChild(
            saldSectie
          );
        }

        h.appendChild(
          kaartEl
        );

        var knop =
          document.getElementById(
            'be-sald-prog'
          );

        if (knop) {
          knop.addEventListener(
            'click',
            function (e) {
              e.preventDefault();

              salderingPrognose =
                !salderingPrognose;

              herteken();
            }
          );
        }

        var g =
          grenzen();

        if (
          g &&
          g.max_day
        ) {
          h.appendChild(
            bouwVerwerkt(
              g
            )
          );
        }
      }
    );
  }

  function bouwVerwerkt(g) {
    var laatsteDag =
      new Date(
        g.max_day +
        'T12:00:00'
      );

    var achter =
      Math.round(
        (
          new Date(
            iso(
              new Date()
            ) +
            'T12:00:00'
          ) -
          laatsteDag
        ) /
        86400000
      );

    var laat =
      achter > 3;

    var c =
      el(
        'div',
        'margin-top:14px;' +
        'padding:9px 13px;' +
        'border-radius:8px;' +
        'font-size:11.5px;' +
        'line-height:1.55;' +
        'background:' +
        (
          laat
            ? 'rgba(224,123,0,.08)'
            : '#f6f4fa'
        ) +
        ';border:1px solid ' +
        (
          laat
            ? 'rgba(224,123,0,.35)'
            : D.rand
        ) +
        ';color:' +
        (
          laat
            ? '#5a4a33'
            : D.grijs
        ) +
        ';',

        'Balans heeft verwerkt tot en met <b>' +
        laatsteDag.getDate() +
        ' ' +
        MND_LANG[
          laatsteDag.getMonth()
        ] +
        '</b> \u2014 ' +
        achter +
        ' dag' +
        (
          achter === 1
            ? ''
            : 'en'
        ) +
        ' achterstand. ' +
        (
          laat
            ? 'Dat is meer dan de gebruikelijke twee dagen.'
            : 'Dat is normaal.'
        )
      );

    c.id =
      'be-verwerkt';

    return c;
  }


  /*
   * ============================================================
   * RESULTATEN — toggle + instellingen
   * ============================================================
   */

  function injecteerKop() {
    if (
      document.getElementById(
        'be-kop'
      )
    ) {
      return;
    }

    var k =
      document.querySelector(
        '.results-summary-card'
      );

    var hdr =
      k
        ? k.querySelector(
            '.card-header'
          )
        : null;

    if (!hdr) {
      return;
    }

    var cs =
      getComputedStyle(
        hdr
      );

    if (
      cs.display !==
      'flex'
    ) {
      hdr.style.display =
        'flex';

      hdr.style.alignItems =
        'center';

      hdr.style.flexWrap =
        'wrap';

      hdr.style.gap =
        '12px';
    }

    var wrap =
      el(
        'div',
        'display:flex;' +
        'align-items:center;' +
        'gap:11px;' +
        'margin-left:auto;' +
        'user-select:none;'
      );

    wrap.id =
      'be-kop';

    var lbl =
      el(
        'span',
        'font-size:13px;' +
        'font-weight:600;' +
        'letter-spacing:.03em;' +
        'transition:color .2s;' +
        'color:' +
        (
          cfg.allin
            ? D.paars
            : D.paarsLicht
        ) +
        ';',
        'All-in'
      );

    var track =
      el(
        'div',
        'position:relative;' +
        'width:44px;' +
        'height:24px;' +
        'border-radius:12px;' +
        'flex-shrink:0;' +
        'border:1.5px solid ' +
        D.paarsLicht +
        ';transition:background .25s;' +
        'background:' +
        (
          cfg.allin
            ? D.paars
            : D.rand
        ) +
        ';'
      );

    var thumb =
      el(
        'div',
        'position:absolute;' +
        'top:2px;' +
        'left:2px;' +
        'width:16px;' +
        'height:16px;' +
        'border-radius:50%;' +
        'background:#fff;' +
        'box-shadow:0 1px 4px rgba(0,0,0,.25);' +
        'transition:transform .25s;' +
        'transform:translateX(' +
        (
          cfg.allin
            ? '20px'
            : '0'
        ) +
        ');'
      );

    track.appendChild(
      thumb
    );

    var schakel =
      el(
        'label',
        'display:flex;' +
        'align-items:center;' +
        'gap:9px;' +
        'cursor:pointer;'
      );

    schakel.appendChild(
      lbl
    );

    schakel.appendChild(
      track
    );

    schakel.addEventListener(
      'click',
      function (e) {
        e.preventDefault();

        cfg.allin =
          !cfg.allin;
        localStorage.setItem(LS.allin, cfg.allin ? 'aan' : 'uit');

        lbl.style.color =
          cfg.allin
            ? D.paars
            : D.paarsLicht;

        track.style.background =
          cfg.allin
            ? D.paars
            : D.rand;

        thumb.style.transform =
          cfg.allin
            ? 'translateX(20px)'
            : 'translateX(0)';

        herteken();
      }
    );

    wrap.appendChild(
      schakel
    );
    beResultaatExtraBediening(wrap);

    var gear =
      el(
        'div',
        'width:18px;' +
        'height:18px;' +
        'cursor:pointer;' +
        'opacity:.6;' +
        'flex-shrink:0;' +
        'transition:opacity .2s;'
      );

    gear.innerHTML =
      '<svg viewBox="0 0 24 24" ' +
      'fill="none" ' +
      'stroke="' +
      D.paars +
      '" ' +
      'stroke-width="2" ' +
      'stroke-linecap="round" ' +
      'stroke-linejoin="round" ' +
      'style="width:100%;height:100%;">' +

        '<circle cx="12" cy="12" r="3"/>' +

        '<path d="' +
        'M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06' +
        'a2 2 0 0 1-2.83 2.83l-.06-.06' +
        'a1.65 1.65 0 0 0-1.82-.33 ' +
        '1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09' +
        'A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33' +
        'l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06' +
        'A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1' +
        'H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9' +
        'a1.65 1.65 0 0 0-.33-1.82l-.06-.06' +
        'a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68' +
        'a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09' +
        'a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33' +
        'l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06' +
        'A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1' +
        'H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z' +
        '"/>' +

      '</svg>';

    gear.addEventListener(
      'mouseenter',
      function () {
        gear.style.opacity =
          '1';
      }
    );

    gear.addEventListener(
      'mouseleave',
      function () {
        gear.style.opacity =
          '.6';
      }
    );

    gear.addEventListener(
      'click',
      function (e) {
        e.stopPropagation();

        var p =
          document.getElementById(
            'be-paneel'
          );

        if (p) {
          p.remove();
          return;
        }

        openInstellingen(
          hdr
        );
      }
    );

    wrap.appendChild(
      gear
    );

    hdr.appendChild(
      wrap
    );
  }

  function veld(
    id,
    label,
    waarde,
    type
  ) {
    return (
      '<div style="margin-bottom:13px;">' +

        '<label style="' +
        'font-size:10.5px;' +
        'color:#555;' +
        'display:block;' +
        'margin-bottom:5px;' +
        'text-transform:uppercase;' +
        'letter-spacing:.04em;' +
        '">' +
        label +
        '</label>' +

        '<input id="' +
        id +
        '" type="' +
        type +
        '" step="any" value="' +
        waarde +
        '" style="' +
        'width:100%;' +
        'box-sizing:border-box;' +
        'padding:8px 10px;' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:6px;' +
        'font-size:13px;' +
        '">' +

      '</div>'
    );
  }

  function knopje(
    id,
    titel,
    uitleg,
    aan
  ) {
    return (
      '<div style="' +
      'margin-bottom:11px;' +
      'padding:10px 12px;' +
      'background:#faf9fd;' +
      'border:1px solid ' +
      D.rand +
      ';border-radius:8px;' +
      'display:flex;' +
      'align-items:center;' +
      'justify-content:space-between;' +
      'gap:12px;' +
      '">' +

        '<div>' +

          '<div style="' +
          'font-size:11px;' +
          'color:#555;' +
          'font-weight:600;' +
          '">' +
          titel +
          '</div>' +

          '<div style="' +
          'font-size:10px;' +
          'color:' +
          D.paarsLicht +
          ';margin-top:3px;' +
          'line-height:1.4;' +
          '">' +
          uitleg +
          '</div>' +

        '</div>' +

        '<div id="' +
        id +
        '" style="' +
        'position:relative;' +
        'width:36px;' +
        'height:20px;' +
        'border-radius:10px;' +
        'cursor:pointer;' +
        'flex-shrink:0;' +
        'transition:background .2s;' +
        'background:' +
        (
          aan
            ? D.paars
            : D.rand
        ) +
        ';">' +

          '<div style="' +
          'position:absolute;' +
          'top:3px;' +
          'left:' +
          (
            aan
              ? '18px'
              : '3px'
          ) +
          ';width:14px;' +
          'height:14px;' +
          'border-radius:7px;' +
          'background:#fff;' +
          'transition:left .2s;' +
          'box-shadow:0 1px 3px rgba(0,0,0,.2);' +
          '">' +
          '</div>' +

        '</div>' +

      '</div>'
    );
  }

  function hangKnopje(
    id,
    staat,
    sleutel
  ) {
    var e =
      document.getElementById(
        id
      );

    if (!e) {
      return;
    }

    e.addEventListener(
      'click',
      function () {
        staat[sleutel] =
          !staat[sleutel];

        e.style.background =
          staat[sleutel]
            ? D.paars
            : D.rand;

        e.firstElementChild
          .style.left =
            staat[sleutel]
              ? '18px'
              : '3px';
      }
    );
  }

  function openInstellingen(hdr) {
    var p =
      el(
        'div',
        'position:absolute;' +
        'z-index:9999;' +
        'background:#fff;' +
        'border:1px solid ' +
        D.rand +
        ';border-radius:10px;' +
        'padding:17px 19px;' +
        'width:min(430px, calc(100vw - 24px));' +
        'box-sizing:border-box;' +
        'max-height:min(82vh, 760px);' +
        'overflow:auto;' +
        'box-shadow:0 6px 22px rgba(107,63,160,.16);'
      );

    p.id =
      'be-paneel';

    var r =
      hdr.getBoundingClientRect();

    p.style.top =
      (
        window.scrollY +
        r.bottom +
        6
      ) +
      'px';

    p.style.left =
      Math.max(
        12,
        window.scrollX +
        r.right -
        340
      ) +
      'px';

    p.innerHTML =
      '<div style="' +
      'display:flex;' +
      'justify-content:space-between;' +
      'align-items:center;' +
      'margin-bottom:15px;' +
      '">' +

        '<div style="' +
        'font-size:12px;' +
        'font-weight:700;' +
        'letter-spacing:.05em;' +
        'text-transform:uppercase;' +
        'color:' +
        D.paars +
        ';">' +
        'Instellingen v7.1' +
        '</div>' +

        '<span id="be-p-sluit" style="' +
        'cursor:pointer;' +
        'font-size:19px;' +
        'color:#aaa;' +
        'line-height:1;' +
        '">' +
        '\u00d7' +
        '</span>' +

      '</div>' +

      '<div style="display:flex;gap:6px;margin-bottom:13px;">' +
        '<button id="be-tabknop-alg" data-tab="alg" class="be-tabknop" style="flex:1;padding:7px;border-radius:6px;border:1px solid ' + D.paars + ';background:' + D.paars + ';color:#fff;font-size:11px;font-weight:600;cursor:pointer;">Algemeen</button>' +
        '<button id="be-tabknop-download" data-tab="download" class="be-tabknop" style="flex:1;padding:7px;border-radius:6px;border:1px solid ' + D.rand + ';background:#fff;color:' + D.paars + ';font-size:11px;font-weight:600;cursor:pointer;">Downloads</button>' +
      '</div>' +

      '<div id="be-tab-alg">' +

      veld(
        'be-p-voorschot',
        'Basisvoorschot per maand (\u20ac)',
        cfg.voorschot.toFixed(2),
        'number'
      ) +

      '<div id="be-voorschot-historie"></div>' +

      veld(
        'be-p-start',
        'Startdatum contract (dd-mm-jjjj)',
        n2(
          cfg.start.getDate()
        ) +
        '-' +
        n2(
          cfg.start.getMonth() + 1
        ) +
        '-' +
        cfg.start.getFullYear(),
        'text'
      ) +

      knopje('be-p-dark', 'Donkere modus', 'Op alle pagina’s, met behoud van de bestaande indeling', beDarkOn) +
      '<label for="be-p-dark-style" style="display:grid;gap:6px;margin:10px 0 14px;font-size:12px;">Dark mode stijl' +
      '<select id="be-p-dark-style" style="width:100%;min-height:44px;padding:8px;border:1px solid #e8e2f0;border-radius:6px;background:#fff;color:#292633;font:inherit;">' +
      '<option value="bruingrijs"'+(window.BETheme.style()==='bruingrijs'?' selected':'')+'>Bruingrijs</option>' +
      '<option value="grafiet"'+(window.BETheme.style()==='grafiet'?' selected':'')+'>Grafiet</option></select></label>' +

      '<label for="be-p-afrr" style="display:grid;gap:6px;margin:10px 0 14px;font-size:12px;">Regelvermogen &amp; biedingen' +
      '<select id="be-p-afrr" style="width:100%;min-height:44px;padding:8px;border:1px solid #e8e2f0;border-radius:6px;background:#fff;color:#292633;font:inherit;"><option value="aan">Aan</option><option value="uit">Uit</option></select>' +
      '<small>Direct opgeslagen. Uit verbergt het hele TenneT-paneel en stopt nieuwe API-aanvragen; je sleutel blijft bewaard.</small></label>' +

      knopje(
        'be-p-sald',
        'Salderingsbalans tonen',
        'Import tegen export over het contractjaar',
        cfg.saldering
      ) +

      knopje(
        'be-p-balans',
        'Blok "Balans Systeem resultaat" tonen',
        'Besparing tegenover een vast contract, exclusief energiebelasting',
        cfg.balansBlok
      ) +

      '<div style="' +
      'display:flex;' +
      'gap:8px;' +
      'margin-top:4px;' +
      '">' +

        '<button id="be-p-op" style="' +
        'flex:1;' +
        'padding:9px;' +
        'background:' +
        D.paars +
        ';color:#fff;' +
        'border:none;' +
        'border-radius:6px;' +
        'font-size:12px;' +
        'font-weight:600;' +
        'cursor:pointer;' +
        '">' +
        'Opslaan' +
        '</button>' +

        '<button id="be-p-wis" ' +
        'title="Wis restanten van eerdere versies uit localStorage" ' +
        'style="' +
        'padding:9px 12px;' +
        'background:#fff;' +
        'color:' +
        D.rood +
        ';border:1px solid ' +
        D.rood +
        ';border-radius:6px;' +
        'font-size:12px;' +
        'cursor:pointer;' +
        '">' +
        'Wis data' +
        '</button>' +

      '</div>' +

      '</div>' +

      '<div id="be-tab-download" style="display:none;">' +
      '</div>' +

      '<div id="be-p-melding" style="' +
      'margin-top:11px;' +
      'font-size:11px;' +
      'display:none;' +
      '">' +
      '</div>';

    document.body.appendChild(
      p
    );

    // De 340 hieronder hoorde bij het oude paneel van 330 breed. Nu het
    // paneel breder is en per scherm kan verschillen, plaatsen we hem na het
    // toevoegen opnieuw op zijn werkelijke breedte en klemmen we hem binnen
    // beeld, zodat hij er aan de rechterkant niet meer afloopt.
    (function plaatsPaneel() {
      function zet() {
        var rr = hdr.getBoundingClientRect();
        var breedte = p.offsetWidth || 430;
        var rand = 12;
        var zichtbaar = document.documentElement.clientWidth;
        var wens = window.scrollX + rr.right - breedte;
        var meest = window.scrollX + zichtbaar - breedte - rand;
        var minst = window.scrollX + rand;
        p.style.left = Math.round(Math.max(minst, Math.min(wens, meest))) + 'px';
        p.style.top = Math.round(window.scrollY + rr.bottom + 6) + 'px';
      }
      zet();
      window.addEventListener('resize', zet);
      var weg = new MutationObserver(function () {
        if (!document.getElementById('be-paneel')) {
          window.removeEventListener('resize', zet);
          weg.disconnect();
        }
      });
      weg.observe(document.body, { childList: true });
    })();

    document.getElementById(
      'be-p-sluit'
    ).addEventListener(
      'click',
      function () {
        p.remove();
      }
    );

    // Instellingen en downloads hebben ieder een eigen sectie.
    Array.prototype.forEach.call(p.querySelectorAll('.be-tabknop'), function (knop) {
      knop.addEventListener('click', function () {
        var welke = knop.getAttribute('data-tab');
        Array.prototype.forEach.call(p.querySelectorAll('.be-tabknop'), function (k) {
          var aan = k === knop;
          k.style.background = aan ? D.paars : '#fff';
          k.style.color = aan ? '#fff' : D.paars;
          k.style.borderColor = aan ? D.paars : D.rand;
        });
        var alg = document.getElementById('be-tab-alg');
        var downloads = document.getElementById('be-tab-download');
        if (alg) alg.style.display = welke === 'alg' ? '' : 'none';
        if (downloads) downloads.style.display = welke === 'download' ? '' : 'none';
      });
    });

    beKwartierExportBediening(document.getElementById('be-tab-download'));
    beVoorschotInstellingen(document.getElementById('be-voorschot-historie'));

    var staat = {
      dark: beDarkOn,
      sald:
        cfg.saldering,

      balans:
        cfg.balansBlok
    };

    hangKnopje('be-p-dark', staat, 'dark');
    var afrrSelect=document.getElementById('be-p-afrr');
    afrrSelect.value=beAfrrMarketEnabled()?'aan':'uit';
    afrrSelect.addEventListener('change',function(){beAfrrMarketSet(afrrSelect.value==='aan');});


    hangKnopje(
      'be-p-sald',
      staat,
      'sald'
    );

    hangKnopje(
      'be-p-balans',
      staat,
      'balans'
    );

    document.getElementById(
      'be-p-wis'
    ).addEventListener(
      'click',
      function () {
        var m =
          document.getElementById(
            'be-p-melding'
          );

        if (
          !confirm(
            'Restanten van eerdere versies uit localStorage wissen? De instellingen blijven staan.'
          )
        ) {
          return;
        }

        var n =
          wisOpslag();

        m.style.color =
          n > 0
            ? D.oranje
            : D.grijs;

        m.textContent =
          n > 0
            ? (
                n +
                ' oude sleutel' +
                (
                  n === 1
                    ? ''
                    : 's'
                ) +
                ' gewist.'
              )
            : (
                'Niets te wissen \u2014 er stond niets ouds meer in.'
              );

        m.style.display =
          'block';

        herteken();
      }
    );

    document.getElementById(
      'be-p-op'
    ).addEventListener(
      'click',
      function () {
        var m =
          document.getElementById(
            'be-p-melding'
          );

        function fout(t) {
          m.style.color =
            D.rood;

          m.textContent =
            t;

          m.style.display =
            'block';
        }

        var v =
          parseFloat(
            document.getElementById(
              'be-p-voorschot'
            ).value
          );

        var s =
          document.getElementById(
            'be-p-start'
          )
            .value
            .trim()
            .split('-');

        if (
          isNaN(v) ||
          v < 0
        ) {
          return fout(
            'Ongeldig voorschotbedrag.'
          );
        }

        if (
          s.length !== 3
        ) {
          return fout(
            'Datum moet dd-mm-jjjj zijn.'
          );
        }

        var d =
          new Date(
            parseInt(
              s[2],
              10
            ),
            parseInt(
              s[1],
              10
            ) - 1,
            parseInt(
              s[0],
              10
            )
          );

        if (
          isNaN(
            d.getTime()
          )
        ) {
          return fout(
            'Ongeldige datum.'
          );
        }

        var historie;
        try {
          historie=beVoorschotValideer(Array.from(document.querySelectorAll('#be-voorschot-historie .be-vs-rijen > div')).map(function(r){return {datum:r.children[0].value,bedrag:r.children[1].value};}));
        }catch(e){return fout(e.message);}
        cfg.voorschotHistorie=historie;
        localStorage.setItem('be_cfg_voorschot_historie',JSON.stringify(historie));
        beDarkApply(staat.dark,document.getElementById('be-p-dark-style').value);

        cfg.voorschot =
          v;

        cfg.start =
          d;

        cfg.saldering =
          staat.sald;

        cfg.balansBlok =
          staat.balans;

        localStorage.setItem(
          LS.voorschot,
          v.toFixed(2)
        );

        localStorage.setItem(
          LS.startdatum,
          iso(d)
        );

        localStorage.setItem(
          LS.saldering,
          staat.sald
            ? 'aan'
            : 'uit'
        );

        localStorage.setItem(
          LS.balansBlok,
          staat.balans
            ? 'aan'
            : 'uit'
        );

        contractCache =
          null;

        dagenLopend =
          null;

        m.style.color =
          D.groen;

        m.textContent =
          'Opgeslagen.';

        m.style.display =
          'block';

        herteken();
      }
    );
  }

  function wisOpslag() {
    var weg = [];

    try {
      Object.keys(
        localStorage
      ).forEach(
        function (k) {
          if (
            k.indexOf('be_') === 0 &&
            k.indexOf(
              'be_cfg_'
            ) !== 0
          ) {
            weg.push(k);
          }
        }
      );

      weg.forEach(
        function (k) {
          localStorage.removeItem(
            k
          );
        }
      );

    } catch (e) {}

    contractCache =
      null;

    dagenLopend =
      null;

    cacheJaar = {};

    return weg.length;
  }


  /*
   * ============================================================
   * START
   * ============================================================
   */

  /* Financieel v6.8. Eigen scherm; geen herschrijving van Balans-kaarten.
   * De API-bedragen zijn volgens dezelfde prijsmetadata genormaliseerd als v5.
   * Saldering/EB zijn expliciete ramingen per contractjaar, geen maandafrekening.
   */
  var beOvDefault = {
    vat: true, tax: true, salderen: true, eligible: 100, schema: 2,
    paymentMode: 'schema', payments: {}, taxAllocation: 'tijd', eligibleConfirmed: false,
    supplier: LEV_DAG, network: TRA_DAG,
    rates: Object.assign({}, EB_JAAR),
    credit: Object.assign({}, VER_JAAR),
    networkRates: Object.assign({}, NET_JAAR)
  };
  var beOvSettings = (function () {
    try {
      var s = JSON.parse(localStorage.getItem('be_overzicht_settings_v1') || '{}');
      // be_cfg_saldering uit v5 bepaalde alleen de zichtbaarheid van de kaart.
      // De eerste testversie las dat ten onrechte als uitschakeling van EB-verrekening.
      // Lege jaarvelden (null) overschrijven de standaardtarieven niet.
      function gevuld(o) { var r = {}; Object.keys(o || {}).forEach(function (k) { if (typeof o[k] === 'number' && isFinite(o[k]) && o[k] >= 0) r[k] = o[k]; }); return r; }
      // 6.7: oude standaarddagbedragen uit eerdere versies vervangen door de gefactureerde.
      if (s.network === 1.3861) delete s.network;
      if (s.supplier === 0.2184) delete s.supplier;
      return Object.assign({}, beOvDefault, s, {
        schema: 2, salderen: s.schema === 2 ? s.salderen !== false : true,
        rates: Object.assign({}, beOvDefault.rates, gevuld(s.rates)),
        credit: Object.assign({}, beOvDefault.credit, gevuld(s.credit)),
        networkRates: Object.assign({}, beOvDefault.networkRates, gevuld(s.networkRates))
      });
    } catch (_) { return Object.assign({}, beOvDefault); }
  })();
  function beOvDate(key) { return new Date(key + 'T12:00:00Z'); }
  function beOvISO(d) { return d.toISOString().slice(0, 10); }
  function beOvAdd(key, n) { var d = beOvDate(key); d.setUTCDate(d.getUTCDate() + n); return beOvISO(d); }
  function beOvDays(a, b) { return Math.max(0, Math.round((beOvDate(b) - beOvDate(a)) / 86400000) + 1); }
  function beOvAnniversary(start, n) {
    var d = beOvDate(start), y = d.getUTCFullYear() + n, m = d.getUTCMonth();
    return beOvISO(new Date(Date.UTC(y, m, Math.min(d.getUTCDate(), new Date(Date.UTC(y, m + 1, 0)).getUTCDate()), 12)));
  }
  function beOvContract(key) {
    var start = iso(cfg.start), n = Math.max(0, +key.slice(0, 4) - +start.slice(0, 4));
    if (n && beOvAnniversary(start, n) > key) n--;
    var begin = beOvAnniversary(start, n), end = beOvAdd(beOvAnniversary(start, n + 1), -1);
    return {begin: begin, end: end, index: n};
  }
  function beOvMonths(a, b) {
    if (a > b) return [];
    var out = [], d = beOvDate(a.slice(0, 7) + '-01');
    while (beOvISO(d).slice(0, 7) <= b.slice(0, 7) && out.length < 61) {
      out.push(beOvISO(d).slice(0, 7)); d.setUTCMonth(d.getUTCMonth() + 1);
    }
    return out;
  }
  function beOvFinite(v) { return typeof v === 'number' && Number.isFinite(v); }
  function beOvNormalize(j, month) {
    if (!j || !Array.isArray(j.series) || !j.pricing) throw Error('Onbekend antwoordformaat voor ' + month + '.');
    var flags = j.pricing;
    ['include_vat', 'include_delivery_cost'].forEach(function (k) {
      if (![true, false, 0, 1, '0', '1'].includes(flags[k])) throw Error('Prijsbasis ontbreekt: ' + k + ' (' + month + ').');
    });
    var vat = flags.include_vat === true || flags.include_vat === 1 || flags.include_vat === '1';
    var fee = flags.include_delivery_cost === true || flags.include_delivery_cost === 1 || flags.include_delivery_cost === '1';
    var seen = new Set();
    return j.series.map(function (s) {
      var key = s.date || s.day;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(key || '') || key.slice(0, 7) !== month || beOvISO(beOvDate(key)) !== key)
        throw Error('Onverwachte dagdatum in ' + month + '.');
      if (seen.has(key)) throw Error('Dubbele dagdatum: ' + key + '.');
      seen.add(key);
      if (!['import_kwh', 'export_kwh', 'total_buy_eur', 'total_sell_eur'].every(function (k) { return beOvFinite(s[k]); }) || s.import_kwh < 0 || s.export_kwh < 0)
        return null; // Een ontbrekend bronbedrag is nooit een nulbedrag.
      var r = naarIncl(s, {include_vat: vat, include_delivery_cost: fee});
      r.key = key; r.voorlopig = /provisional|preliminary|pending|voorlopig/i.test(String(s.status || ''));
      return r;
    }).filter(Boolean);
  }
  function beOvSum(rows, key) { return rows.reduce(function (n, r) { return n + (beOvFinite(r[key]) ? r[key] : 0); }, 0); }

  // De eigen cache is een gedateerd deelresultaat, ook na een herlaadactie.
  // Definitieve Balansdagen winnen; dezelfde dag wordt nooit tweemaal opgeteld.
  function beOvMergeRows(source, stored, id, from, to, now) {
    var today=iso(new Date(now)), map=new Map();
    source.forEach(function(r){if(r.key>=from&&r.key<=to&&r.key<=today)map.set(r.key,Object.assign({},r));});
    Object.keys(stored).forEach(function(key){
      var p=stored[key],g=voorlopigeDagGrenzen(key);
      if(map.has(key)||key<from||key>to||key>today||!g||!p||p.prijsHerberekenen||p.key!==key||p.klant!==id||p.archiefVersie!==1||p.voorlopig!==true)return;
      if(!['imp','exp','inkoop','verkoop','gemetenVanaf','gemetenTot','gedektMs','bijgewerkt'].every(function(k){return beOvFinite(p[k]);})||p.imp<0||p.exp<0)return;
      if(p.gemetenVanaf!==g.start||p.gemetenTot<=g.start||p.gemetenTot>g.eind||p.gemetenTot>now||p.bijgewerkt>now||p.gedektMs<=0||p.gedektMs>p.gemetenTot-g.start)return;
      var r=Object.assign({},p,{eigenCache:true});
      if(p.prijsOnvolledig){
        if(!['geprijsdeImportKwh','geprijsdeExportKwh'].every(function(k){return beOvFinite(p[k])&&p[k]>=0;}))return;
        if(p.geprijsdeImportKwh>p.imp+1e-6||p.geprijsdeExportKwh>p.exp+1e-6)return;
        r.gemetenImportKwh=p.imp;r.gemetenExportKwh=p.exp;
        r.imp=p.geprijsdeImportKwh;r.exp=p.geprijsdeExportKwh;
      }
      r.deelresultaat=!!p.prijsOnvolledig||p.gedektMs<(g.eind-g.start)*.995;
      map.set(key,r);
    });
    return Array.from(map.values()).sort(function(a,b){return a.key.localeCompare(b.key);});
  }

  function beOvForecast(all, range, settings, today) {
    var complete=all.filter(function(d){return d.key<today&&!d.voorlopig&&!d.deelresultaat;}),
        base=complete.filter(function(d){return d.key>=beOvAdd(today,-28);});
    if(range.b<today)return {rows:null,reason:'afgelopen',base:base.length};
    if(base.length<7)return {rows:null,reason:'weinig',base:base.length};
    // Dezelfde maandfactoren als de kWh-prognose in 5.0. Reken kWh en
    // bronbedragen apart, zodat de prognose controleerbaar blijft met huidige EB.
    var factors={imp:[1,.62,.25,.09,.02,.01,.02,.03,.10,.32,.57,.87],exp:[.10,.18,.45,1,1.30,1.32,1.18,.96,.74,.28,.12,.08]};
    var plans={},scenario=all.filter(function(d){return d.key<today;}),usedHistory=false;
    beOvMonths(today,range.b).forEach(function(month){
      var prior=String(+month.slice(0,4)-1)+month.slice(4),old=complete.filter(function(d){return d.key.slice(0,7)===prior;}),plan={};
      ['imp','exp'].forEach(function(k){
        var factor=factors[k],target=factor[+month.slice(5,7)-1];
        var normalized=base.reduce(function(sum,d){return sum+d[k]/factor[+d.key.slice(5,7)-1];},0)/base.length;
        plan[k]=normalized*target;
        var priceKey=k==='imp'?'inkoop':'verkoop',volume=beOvSum(base,k);
        plan[priceKey]=volume>0?plan[k]*beOvSum(base,priceKey)/volume:0;
        // Vorig jaar weegt 60%, de recente seizoensraming 40%, zoals de
        // combinatie in 5.0. Alleen een volledige bronmaand mag meetellen.
        var next=beOvDate(prior+'-01');next.setUTCMonth(next.getUTCMonth()+1);
        if(old.length===beOvDays(prior+'-01',beOvAdd(beOvISO(next),-1))){
          plan[k]=.6*beOvSum(old,k)/old.length+.4*plan[k];
          plan[priceKey]=.6*beOvSum(old,priceKey)/old.length+.4*plan[priceKey];usedHistory=true;
        }
      });plans[month]=plan;
    });
    for(var key=today;key<=range.b;key=beOvAdd(key,1))scenario.push(Object.assign({key:key,forecast:true},plans[key.slice(0,7)]));
    return {rows:beOvCalculate(scenario,settings),reason:'',base:base.length,history:usedHistory};
  }

  function beOvApplyMonthResult(target,result){
    target.errors=(target.errors||[]).filter(function(e){return e.month!==result.month;});
    target.unavailableMonths=(target.unavailableMonths||[]).filter(function(month){return month!==result.month;});
    if(result.error)target.errors.push({month:result.month,message:result.error});
    else if(result.unavailable)target.unavailableMonths.push(result.month);
    else target.sourceRows=target.sourceRows.filter(function(r){return r.key.slice(0,7)!==result.month;}).concat(result.rows);
  }
  function beOvUnavailableNotice(months,cacheDays){
    return (months||[]).slice().sort().map(function(month){
      var name=new Intl.DateTimeFormat('nl-NL',{month:'long',year:'numeric',timeZone:'UTC'}).format(beOvDate(month+'-01'));
      return name.charAt(0).toUpperCase()+name.slice(1)+' nog niet verwerkt'+
        (cacheDays.some(function(day){return day.slice(0,7)===month;})?' · voorlopige eigen cache':'');
    }).join(' · ');
  }

  // Het contract bepaalt de salderingsgrens. De EB-last staat op de afnamedag;
  // de EB-teruggaaf op de terugleverdag. Zo blijft het seizoenseffect per maand
  // zichtbaar. Voor de teruggaaf wordt het naar afname gewogen EB-tarief gebruikt.
  // De jaargrens gebruikt de gekozen, expliciet benoemde tariefverdelingsraming.
  function beOvCalculate(rows, settings) {
    var out = rows.map(function (r) { return Object.assign({}, r); }), groups = {};
    out.forEach(function (r) {
      var contract = beOvContract(r.key), group = contract.begin;
      (groups[group] || (groups[group] = [])).push(r);
      r.contract = group;
    });
    Object.keys(groups).forEach(function (key) {
      var pre = groups[key].filter(function (r) { return r.key < '2027-01-01'; });
      var imp = beOvSum(pre, 'imp'), eligibleBase = beOvSum(pre, 'exp') * settings.eligible / 100;
      // 6.8.4: art. 50 lid 2 Wbm met art. 2.31 Energiewet. Duurzame invoeding telt volledig mee
      // (tot de afname); andere invoeding (bijv. netstroom via de batterij) tot 5.000 kWh.
      // Duurzaam per dag = min(teruglevering, geschatte pv-opwek uit de Balans-bron). Dagen zonder
      // pv-gegeven krijgen het duurzame aandeel van de bekende dagen in hetzelfde contract.
      var knownExp=0,knownRen=0;
      pre.forEach(function(r){if(r.pvBekend===true){knownExp+=r.exp;knownRen+=Math.min(r.exp,Math.max(0,r.pv));}});
      var share=knownExp>0?knownRen/knownExp:(pre.some(function(r){return r.pvBekend===true;})?1:0);
      pre.forEach(function(r){r.expRen=r.pvBekend===true?Math.min(r.exp,Math.max(0,r.pv)):r.exp*share;r.expNon=Math.max(0,r.exp-r.expRen);});
      var renBase=beOvSum(pre,'expRen')*settings.eligible/100,nonBase=beOvSum(pre,'expNon')*settings.eligible/100;
      var nonEligible=settings.eligibleConfirmed?nonBase:Math.min(5000,nonBase);
      var nonFactor=nonBase>0?nonEligible/nonBase:1;
      var eligible=renBase+nonEligible;
      var creditKwh = settings.salderen ? Math.min(imp, eligible) : 0;
      // Teruglevering die door de 5.000 kWh-grens buiten de verrekening valt.
      var cappedKwh = settings.salderen ? Math.max(0, Math.min(imp, eligibleBase) - creditKwh) : 0;
      var herkomst={duurzaam:renBase,overig:nonBase,overigMee:nonEligible,pvOnbekendeDagen:pre.filter(function(r){return r.exp>0&&r.pvBekend!==true;}).length};
      var grossTax = 0, unknownRate = false;
      pre.forEach(function(r){var rate=settings.rates[r.key.slice(0,4)];if(r.imp>0&&!(beOvFinite(rate)&&rate>=0))unknownRate=true;else if(r.imp>0)grossTax+=r.imp*rate;});
      var refundEx = !creditKwh ? 0 : unknownRate ? null : grossTax * creditKwh / imp;
      var grossTaxForCap = grossTax;
      if(creditKwh>0&&settings.taxAllocation==='werkelijk'&&!unknownRate){
        // 7.0: werkelijk netto verbruik per tariefperiode (kalenderjaar) volgens de meterdata,
        // zoals Balans factureert. Het belastbare saldo over het hele contract blijft gelijk.
        var perJaar={};
        pre.forEach(function(r){var y=r.key.slice(0,4),j=perJaar[y]||(perJaar[y]={imp:0,exp:0});j.imp+=r.imp;j.exp+=((r.expRen||0)+(r.expNon||0)*nonFactor)*settings.eligible/100;});
        var jaren=Object.keys(perJaar),gewicht=0;
        jaren.forEach(function(y){perJaar[y].w=Math.max(0,perJaar[y].imp-perJaar[y].exp);gewicht+=perJaar[y].w;});
        var belastbaar=imp-creditKwh,ebNetto=0;
        jaren.forEach(function(y){var deel=gewicht>0?perJaar[y].w/gewicht:(imp>0?perJaar[y].imp/imp:0);ebNetto+=belastbaar*deel*settings.rates[y];});
        refundEx=grossTax-ebNetto;
      } else if(creditKwh>0&&settings.taxAllocation!=='afname'&&!unknownRate){
        var through=pre.reduce(function(last,r){return r.key>last?r.key:last;},key),sumRates=0,countDays=0;
        for(var dateKey=key;dateKey<=through;dateKey=beOvAdd(dateKey,1)){
          var dayRate=settings.rates[dateKey.slice(0,4)];
          if(!beOvFinite(dayRate)||dayRate<0){unknownRate=true;break;}
          sumRates+=dayRate;countDays++;
        }
        refundEx=unknownRate?null:grossTax-(imp-creditKwh)*(countDays?sumRates/countDays:0);
      }
      var higherContract=imp-creditKwh+beOvSum(groups[key].filter(function(r){return r.key>='2027-01-01';}),'imp')>10000+1e-8;
      groups[key].forEach(function (r) {
        var eligibleRow=r.key<'2027-01-01'?((r.expRen||0)+(r.expNon||0)*nonFactor)*settings.eligible/100:0;
        var fraction=eligible>0?eligibleRow/eligible:0;r.herkomst=herkomst;
        r.saldKwh=creditKwh*fraction;
        r.salderingPlafondKwh=cappedKwh;r.salderingPlafondRate=imp>0?grossTaxForCap/imp:0;
        r.taxable=r.imp-(imp>0&&r.key<'2027-01-01'?r.imp*creditKwh/imp:0);
        var rate = settings.rates[r.key.slice(0, 4)];
        r.ebGrossEx=r.imp<1e-9?0:beOvFinite(rate)&&rate>=0?r.imp*rate:null;
        r.ebCreditEx=!fraction?0:refundEx===null?null:refundEx*fraction;
        r.ebEx=r.ebGrossEx===null||r.ebCreditEx===null?null:r.ebGrossEx-r.ebCreditEx;
        if(higherContract)r.ebEx=null;
        r.buyEx = r.inkoop / BTW; r.sellEx = r.verkoop / BTW;
        r.buyShown = settings.vat ? r.inkoop : r.buyEx;
        r.sellShown = settings.vat ? r.verkoop : r.sellEx;
        r.ebShown = !settings.tax ? 0 : r.ebEx === null ? null : r.ebEx * (settings.vat ? BTW : 1);
        r.ebGrossShown=!settings.tax?0:r.ebGrossEx===null?null:r.ebGrossEx*(settings.vat?BTW:1);
        r.ebCreditShown=!settings.tax?0:r.ebCreditEx===null?null:r.ebCreditEx*(settings.vat?BTW:1);
        r.trade = r.sellShown - r.buyShown;
        r.result = r.ebShown === null ? null : r.trade - r.ebShown;
      });
    });
    return out.sort(function (a, b) { return a.key.localeCompare(b.key); });
  }
  function beOvTotal(rows) {
    var total = {};
    ['imp', 'exp', 'inkoop', 'verkoop', 'buyEx', 'sellEx', 'buyShown', 'sellShown', 'trade', 'taxable', 'saldKwh', 'pv', 'laden', 'ontladen'].forEach(function (k) { total[k] = beOvSum(rows, k); });
    total.ebShown = rows.some(function (r) { return r.ebShown === null; }) ? null : beOvSum(rows, 'ebShown');
    total.ebGrossShown=rows.some(function(r){return r.ebGrossShown===null;})?null:beOvSum(rows,'ebGrossShown');
    total.ebCreditShown=rows.some(function(r){return r.ebCreditShown===null;})?null:beOvSum(rows,'ebCreditShown');
    total.result = total.ebShown === null ? null : total.trade - total.ebShown;
    total.vatTrade = (total.verkoop - total.inkoop) - (total.sellEx - total.buyEx);
    return total;
  }
  function beOvNetwork(settings, y) {
    var v = settings.networkRates ? settings.networkRates[y] : undefined;
    return beOvFinite(v) && v >= 0 ? v : settings.network;
  }
  function beOvFixed(a, b, settings) {
    var n = beOvDays(a, b), credit = 0, network = 0, unknown = false;
    for (var k = a; k <= b; k = beOvAdd(k, 1)) {
      var y = k.slice(0, 4), amount = settings.credit[y];
      var yearDays = beOvDays(y + '-01-01', y + '-12-31');
      network += beOvNetwork(settings, y);
      if (!beOvFinite(amount)) unknown = true;
      else credit += amount / yearDays * (settings.vat ? BTW : 1);
    }
    var factor = settings.vat ? 1 : 1 / BTW;
    return {days: n, supplier: n * settings.supplier * factor, network: network * factor,
      credit: unknown ? null : credit, net: unknown ? null : credit - (n * settings.supplier + network) * factor,
      advance: settings.paymentMode==='actual' ? ((settings.payments||{})[KLANT]||[]).filter(function(p){return p.datum>=a&&p.datum<=b;}).reduce(function(sum,p){return sum+p.bedrag;},0) : n ? beVoorschotSom(a, n) : 0};
  }
  function beOvStatementData(all,r,settings,through) {
    function cents(n){return n===null?null:Math.round((n+Math.sign(n)*1e-10)*100);}
    var cumulative=0,unknown=false,stroom=0,vast=0,advance=0,hasRows=false;
    var months=beOvMonths(r.a,r.b).map(function(m){
      var a=m+'-01';if(a<r.a)a=r.a;
      var next=beOvDate(m+'-01');next.setUTCMonth(next.getUTCMonth()+1);
      var b=beOvAdd(beOvISO(next),-1);if(b>r.b)b=r.b;if(b>through)b=through;
      var n=beOvDays(a,b),rows=all.filter(function(d){return d.key>=a&&d.key<=b;}),t=beOvTotal(rows),f=beOvFixed(a,b,settings);
      var sc=rows.length?cents(t.result):null,fc=cents(f.net),ac=cents(f.advance);
      if(rows.length)hasRows=true;
      if(n){vast+=fc||0;advance+=ac;if(sc===null||fc===null)unknown=true;else {stroom+=sc;cumulative+=sc+fc+ac;}}
      return {month:m,from:a,to:b,total:t,fixed:f,days:n,count:rows.length,provisional:rows.filter(function(d){return d.voorlopig;}).length,
        provisionalRows:rows.filter(function(d){return d.voorlopig&&!d.forecast;}),lastKnown:rows.length?rows[rows.length-1].key:null,
        stroom:sc===null?null:sc/100,vast:fc===null?null:fc/100,advance:ac/100,saldo:unknown?null:cumulative/100};
    });
    return {months:months,stroom:unknown||!hasRows?null:stroom/100,vast:unknown?null:vast/100,advance:advance/100,
      full:unknown||!hasRows?null:(stroom+vast)/100,saldo:unknown||!hasRows?null:cumulative/100};
  }

  function beOvForecastLines(known,expected,today){
    function cents(v){return v===null?null:Math.round(v*100);}
    function diff(a,b){return a===null||b===null?null:cents(a)-cents(b);}
    var month=today.slice(0,7),previous={},correction=0;
    known.months.forEach(function(m){previous[m.month]=m;});
    expected.months.filter(function(m){return m.month<month;}).forEach(function(m){
      var old=previous[m.month],delta=diff(m.stroom,old?old.stroom:0);
      correction=correction===null||delta===null?null:correction+delta;
    });
    var balance=known.months.some(function(m){return m.days;})?cents(known.saldo):0;
    return expected.months.filter(function(m){return m.month>=month;}).map(function(m,i){
      var old=previous[m.month],stroom=diff(m.stroom,old&&old.days?old.stroom:0),advance=diff(m.advance,old&&old.days?old.advance:0),vast=diff(m.vast,old&&old.days?old.vast:0);
      if(i===0)stroom=stroom===null||correction===null?null:stroom+correction;
      balance=balance===null||stroom===null||vast===null?null:balance+stroom+advance+vast;
      return {month:m.month,stroom:stroom===null?null:stroom/100,advance:advance/100,vast:vast===null?null:vast/100,saldo:balance===null?null:balance/100};
    });
  }

  function beOverzichtStart() {
    var HASH = '#be-energieoverzicht', root, shadow, navAnchor, fallback, state, latest, cache = new Map(), serial = 0, opened = false;
    var layoutTimer, monthNow = iso(new Date()).slice(0, 7), inertNodes = [], oldHash = '', previousFocus;
    var ownRefreshPromise=null, ownRefreshAt=0, expandedMonth=null, chartUnit='eur', chartPoints=[], tooltipPinned=false, tooltipIndex=-1;
    var monthAnimation=null,monthToggleSerial=0,menuActiveBefore=[],navLinks=[],menuSerial=0;
    var mobileChrome=[],mobileHeader=null,mobileSidebar=null,pageScrollBefore=null;
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function fmt(v, decimals) { return Number(v).toLocaleString('nl-NL', {minimumFractionDigits: decimals || 0, maximumFractionDigits: decimals == null ? 1 : decimals}); }
    function money(v) { return v === null || !Number.isFinite(v) ? 'Nog onbekend' : new Intl.NumberFormat('nl-NL', {style:'currency', currency:'EUR'}).format(Math.abs(v) < 0.005 ? 0 : v); }
    function date(s) { return new Intl.DateTimeFormat('nl-NL', {day:'numeric',month:'short',year:'numeric', timeZone:'UTC'}).format(beOvDate(s)); }
    function signedClass(v) { return v === null ? '' : v >= 0 ? 'positive' : 'negative'; }
    function save() {
      try {
        localStorage.setItem('be_overzicht_settings_v1', JSON.stringify(beOvSettings));
        document.dispatchEvent(new Event('be-financial-settings-update'));
      } catch (_) {}
    }
    function $(id) { return shadow.getElementById(id); }
    function status(text, error) { $('status').textContent = text; $('status').className = error ? 'notice warning' : 'notice'; }
    function button(label, attr) { return '<button type="button" ' + (attr || '') + '>' + label + '</button>'; }
    function contractOptions() {
      var max = beOvContract(iso(new Date())).index + 1, html = '';
      for (var i = 0; i <= max; i++) {
        var begin = beOvAnniversary(iso(cfg.start), i), end = beOvAdd(beOvAnniversary(iso(cfg.start), i + 1), -1);
        html += '<option value="' + i + '">' + date(begin) + ' – ' + date(end) + '</option>';
      }
      return html;
    }
    function mount() {
      root=document.createElement('section');root.id='be-energieoverzicht';root.hidden=true;
      root.style.cssText='position:fixed;left:0;right:0;top:0;bottom:0;z-index:1040;background:#f6f7fb;overflow:auto;overscroll-behavior:contain';
      shadow=root.attachShadow({mode:'open'});
      shadow.innerHTML=`<style>
        :host{--bg:#f6f7fb;--paper:#fff;--ink:#292633;--muted:#74717e;--line:#e7e4ec;--purple:#714291;--soft:#f1edf6;--green:#208557;--red:#c64151;--blue:#2f7996;color-scheme:light;font:14px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink)}
        :host([data-dark]){--bg:#282723;--paper:#36342f;--ink:#eee8df;--muted:#c0b8ab;--line:#575148;--purple:#cfb3f0;--soft:#44384f;--green:#62d0ad;--red:#ff96a8;--blue:#99b9ff;color-scheme:dark}
        :host{--button:#714291;--button-ink:#fff}
        :host([data-dark]){--button:#8057a4;--ink:#f5f0e8}
        :host([data-dark][data-dark-style="grafiet"]){--bg:#111316;--paper:#1c1f26;--ink:#f5f7fa;--muted:#b6c0cf;--line:#3c4351;--purple:#a879ff;--soft:#262a34;--green:#23d9a0;--red:#ff6079;--blue:#4398ff;--button:#7340b5}
        :host([data-dark][data-dark-style="grafiet"]) .chart-bar:not([stroke]){fill-opacity:1}
        :host([data-dark]) button,:host([data-dark]) input,:host([data-dark]) select,:host([data-dark]) option{color:var(--ink)}
        #title:focus{outline:none;box-shadow:none}
        *{box-sizing:border-box}[hidden]{display:none!important}h1,h2,h3,p{margin:0}h1{font-size:23px}h2{font-size:16px}h3{font-size:14px}small,.help,.muted{color:var(--muted)}a{color:var(--purple)}button,input,select{font:inherit;color:inherit}button,select,input[type=date],input[type=month],input[type=number]{border:1px solid var(--line);border-radius:6px;background:var(--paper);padding:7px 10px;min-height:34px}button,summary{cursor:pointer}button:hover{border-color:var(--purple)}button:disabled{opacity:.5}button:focus-visible,input:focus-visible,select:focus-visible,a:focus-visible,summary:focus-visible{outline:2px solid var(--purple);outline-offset:3px}input[type=checkbox]{accent-color:var(--purple)}
        .page{padding:24px 28px 36px;background:var(--bg);min-height:100%}.wrap{max-width:1380px;margin:auto}.top,.actions,.fields,.toggles,.section-head,.legend{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.top,.section-head{justify-content:space-between}.fields label{display:grid;gap:3px;font-size:11px;color:var(--muted)}.fields input,.fields select{font-size:13px;color:var(--ink)}.filters{margin-top:18px}.toggles{margin-top:12px;font-size:12px}.toggles label{display:flex;align-items:center;gap:5px}.toggles small{margin-left:auto}.panel{background:var(--paper);border:1px solid var(--line);border-radius:9px;padding:18px;margin-top:14px}.notice{font-size:12px;color:var(--muted);margin-top:12px}.notice.warning{color:var(--red)}.help{font-size:11px;line-height:1.5;margin-top:8px}.positive{color:var(--green)}.negative{color:var(--red)}
        .summary{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--line);border-radius:7px;margin-bottom:16px}.summary>div{padding:10px 14px}.summary>div+div{border-left:1px solid var(--line)}.summary small{display:block;font-size:11px}.summary strong{font-size:23px;font-variant-numeric:tabular-nums}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px;white-space:nowrap}th,td{text-align:right;padding:9px 10px;border-bottom:1px solid var(--line);font-variant-numeric:tabular-nums}th:first-child,td:first-child{text-align:left}th{font-size:10px;text-transform:uppercase;letter-spacing:.4px;color:var(--muted);font-weight:600}th:first-child{width:auto}tbody tr:nth-child(odd){background:color-mix(in srgb,var(--soft) 30%,var(--paper))}.month-cell{display:flex;align-items:center;gap:12px}.month-name{width:104px;flex-shrink:0}.month-link{border:0;padding:0;min-height:0;background:none;font-weight:500}.month-name small{display:block;font-size:10px}.month-meter{flex:1;min-width:190px;height:24px;position:relative;background:var(--soft);border-radius:9px;overflow:hidden}.month-meter>span{height:10px;display:block;min-width:1px;border-radius:9px}.current-month{font-weight:650}.current-month .month-link{font-weight:650}.future{color:var(--muted);font-style:italic}.forecast-row{border-top:1px dashed var(--line);color:var(--muted)}.end-row{background:var(--soft);font-weight:700}tfoot td{padding-top:10px;padding-bottom:10px}tfoot .known-row{font-weight:700;border-top:2px solid var(--line)}.legend{font-size:11px;color:var(--muted);gap:18px}.dot{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:5px}.chart{margin-top:8px}.chart svg{width:100%;height:auto;display:block}.purchase-summary{display:flex;flex-wrap:wrap;gap:6px 28px;margin-top:9px;font-size:13px}.purchase-summary strong{font-variant-numeric:tabular-nums}.purchase-summary small{color:var(--muted);font-size:.9em;white-space:nowrap}.row{display:flex;gap:16px;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--line);font-size:13px}.row strong{white-space:nowrap}.row.total{font-weight:650;border-top:1px solid var(--line)}.grid{display:grid;gap:12px}.settings-grid{grid-template-columns:repeat(3,1fr);margin:12px 0}.settings-grid label{display:grid;gap:5px;font-size:12px}.settings-grid input{min-width:0;width:100%}.note-list{display:grid;gap:9px;margin-top:12px;font-size:12px}.bar{height:7px;background:var(--soft);margin-top:8px}.bar span{display:block;height:100%;background:var(--purple)}summary{font-size:13px;font-weight:600}.empty{padding:24px;text-align:center;color:var(--muted)}.narrative{font-size:13px;margin-top:12px}.badge{font-size:11px;color:var(--muted)}
        .projected-meter{opacity:.38;margin-top:4px}.forecast-value{display:block;color:var(--muted);font-size:11px;margin-top:5px}.month-detail{white-space:normal;text-align:left;padding:14px;background:var(--paper);border-left:3px solid var(--purple)}.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px 30px}.detail-grid h3{font-size:13px;margin:6px 0}.detail-period{font-size:12px;color:var(--muted);margin-bottom:10px}.detail-row td{padding:0 0 12px}.month-link:hover{text-decoration:underline}@media(max-width:750px){.page{padding:16px 12px}.panel{padding:12px}.summary strong{font-size:18px}.summary>div{padding:8px}.month-meter{min-width:190px}.detail-grid{grid-template-columns:1fr}th:first-child{width:auto}.settings-grid{grid-template-columns:1fr 1fr}.purchase-summary{gap:12px;font-size:12px}td,th{padding:8px}.toggles small{margin-left:0}.actions{gap:6px}}@media(max-width:450px){.settings-grid{grid-template-columns:1fr}.summary strong{font-size:16px}.summary small{font-size:10px}}

        .month-statement{table-layout:fixed;min-width:900px;font-size:12px}.month-plot-col{width:auto}.amount-col{width:110px}.month-statement td,.month-statement th{padding-left:7px;padding-right:7px}.month-statement th{font-size:9px;letter-spacing:.15px;white-space:normal}.month-statement td:first-child{padding-right:18px}.month-statement .detail-row td{padding:0}.month-meter{border-radius:3px;background:repeating-linear-gradient(to right,var(--soft),var(--soft) calc(25% - 1px),var(--line) calc(25% - 1px),var(--line) 25%)}.month-meter>span{border-radius:2px}.month-cell{gap:12px}.month-meter>span:only-child{height:14px;margin-top:5px}.period-switch,.unit-switch{display:inline-flex;border:1px solid var(--line);padding:3px;border-radius:8px;gap:3px;background:var(--paper)}.period-switch button,.unit-switch button{border:0;background:transparent;white-space:nowrap;font-size:13px;padding:7px 14px}.period-switch button[aria-pressed=true],.unit-switch button[aria-pressed=true]{background:var(--button);color:var(--button-ink);font-weight:600}.period-bar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.period-navigation{display:flex;align-items:end;gap:6px}.period-navigation label{min-width:160px}.period-navigation input,.period-navigation select{width:100%}.period-switch button:focus-visible,.unit-switch button:focus-visible{outline-offset:0}.chart-stage{position:relative;isolation:isolate}.chart-stage svg{width:100%;height:auto;min-height:210px;display:block}.chart-hit{fill:transparent;cursor:crosshair}.chart-hit:hover,.chart-hit:focus{fill:var(--purple);fill-opacity:.08;outline:none}.chart-hit:focus{stroke:var(--purple);stroke-width:1}.chart-tooltip{position:absolute;z-index:2;width:300px;max-width:calc(100% - 12px);padding:12px 14px;background:var(--paper);border:1px solid var(--line);box-shadow:0 5px 24px #0002;border-radius:8px;pointer-events:none;font-size:12px}.chart-tooltip h3{font-size:13px;margin-bottom:3px}.tip-state{color:var(--muted);font-size:11px;margin-bottom:8px}.tip-grid{display:grid;grid-template-columns:1fr auto auto;gap:5px 12px;align-items:baseline;font-variant-numeric:tabular-nums}.tip-grid strong{text-align:right;white-space:nowrap}.tip-grid small{text-align:right}.tip-foot{font-size:10px;color:var(--muted);border-top:1px solid var(--line);padding-top:7px;margin-top:8px}.chart-legend{display:flex;flex-wrap:wrap;gap:14px;font-size:11px;align-items:center;color:var(--muted);margin-top:6px}.legend-outline{display:inline-block;width:12px;height:9px;border:1.5px dashed currentColor;margin-right:4px}.legend-solid{display:inline-block;width:12px;height:9px;background:currentColor;opacity:.7;margin-right:4px}.chart-hint{margin-left:auto}.chart-stage [data-chart-hit]{touch-action:pan-y}.chart-stage svg{overflow:visible}.chart-title-note{font-size:11px;color:var(--muted)}
        .chart-tooltip{position:static;width:auto;max-width:none;padding:0;border:0;box-shadow:none;border-radius:0;background:transparent;pointer-events:none}.chart-readout{min-height:70px;margin-top:6px;padding:10px 12px;border-radius:6px;background:var(--soft);display:grid;align-content:center}.tip-values{display:flex;align-items:baseline;gap:10px 22px;flex-wrap:wrap;font-size:12px}.tip-values>strong{color:var(--purple);min-width:100px}.tip-values span{color:var(--muted);white-space:nowrap}.tip-values span strong{color:var(--ink);margin-left:4px;font-variant-numeric:tabular-nums}.chart-readout .tip-foot{border:0;margin-top:5px;padding:0}.chart-readout .help{margin:0}.month-name{width:132px}.month-meter{display:flex;align-items:stretch;height:12px;background:var(--soft);border-radius:4px;min-width:190px}.month-meter>span,.month-meter>span:only-child{height:100%;margin:0;flex-shrink:0;min-width:0;border-radius:0}.month-meter .forecast-tail{opacity:.35}.month-meter>span:first-child{border-radius:3px 0 0 3px}.month-dates{font-weight:400}.contract-edge{font-weight:600;color:var(--purple)}
        .month-summary{cursor:pointer}.month-summary:hover{background:var(--soft)}.month-summary:focus-visible{outline:2px solid var(--purple);outline-offset:-2px}.toggles select{font-size:12px;margin-left:4px}.ledger-dates{font-size:12px;color:var(--muted);margin-top:3px;margin-bottom:12px}
        .chart-column{transition:opacity .14s ease}.chart-stage[data-active] .chart-column{opacity:.4}.chart-stage[data-active] .chart-column[data-selected]{opacity:1}.chart-backlight{opacity:0;pointer-events:none;transition:opacity .14s ease}.chart-column[data-selected] .chart-backlight{opacity:.85}.chart-column[data-selected] .chart-bar{fill-opacity:1;filter:drop-shadow(0 2px 2px #0002)}.chart-hit:hover,.chart-hit:focus{fill:transparent;stroke:none}.chart-hit:focus-visible{stroke:var(--purple);stroke-width:.8;stroke-dasharray:3 3}.chart-readout{border-left:3px solid var(--purple)}.tip-values span{display:inline-flex;align-items:center;gap:5px;background:var(--paper);border-radius:5px;padding:4px 7px}.tip-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--series-color);flex:none}.tip-values span strong{color:var(--series-color)}.tip-values .has-rate{display:inline-grid;grid-template-columns:7px auto auto;column-gap:5px;row-gap:2px;align-items:center}.tip-values .tip-rate{grid-column:2/-1;font-size:10px;font-weight:400;line-height:1.15;color:var(--muted);white-space:nowrap}@media(prefers-reduced-motion:reduce){.chart-column,.chart-backlight{transition:none}}
        .detail-reveal{overflow:hidden}.cache-detail{margin-top:18px;padding:14px;background:var(--soft);border:1px solid var(--line);border-radius:8px}.cache-detail h3{margin:0 0 4px}.cache-table{width:100%;font-size:12px}.month-statement .cache-table td,.month-statement .cache-table th{padding:8px;white-space:nowrap}.cache-table td:first-child,.cache-table th:first-child{text-align:left;width:auto}.cache-table small{display:block;color:var(--muted);font-size:10px}.cache-table td:last-child{font-weight:700;font-size:14px}.tip-balance{display:flex;align-items:baseline;gap:10px 22px;flex-wrap:wrap;margin-top:10px;padding-top:8px;border-top:1px solid var(--line)}.tip-balance>strong{font-size:16px}.tip-balance>span{color:var(--muted);font-size:11px}.month-summary .month-link{transition:color .2s ease}
        .stream-result{display:flex;align-items:baseline;gap:8px 20px;flex-wrap:wrap;margin-top:10px;padding-top:8px;border-top:1px solid var(--line)}.stream-result>span:first-child{font-weight:650;font-size:13px}.stream-result>strong{font-size:24px;font-variant-numeric:tabular-nums}.stream-result strong small{font-size:13px;font-weight:600}.stream-result>span:last-child{font-size:11px;color:var(--muted)}.cache-table .net-stream{font-size:15px;font-weight:750;background:var(--paper)}.day-result-label{pointer-events:none}.month-progress{display:block;font-size:10px;font-weight:400;line-height:1.5;white-space:normal;margin-top:4px;color:var(--muted)}

        @media(max-width:767px){
          .top{position:static;background:var(--bg);padding:8px 0 12px}.mobile-menu{font-weight:600}
          .page{padding:max(12px,env(safe-area-inset-top)) max(10px,env(safe-area-inset-right)) max(24px,env(safe-area-inset-bottom)) max(10px,env(safe-area-inset-left));overflow-x:clip}
          .wrap,.panel,.fields,.filters{min-width:0;max-width:100%}.top h1{font-size:21px}.top .actions{display:grid;grid-template-columns:minmax(0,1fr) 44px;width:100%}
          button,select,input[type=date],input[type=month],input[type=number]{min-height:44px}.fields select,.fields input,.toggles select,.settings-grid input,.settings-grid select{font-size:16px;min-width:0;max-width:100%}
          .period-switch{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));width:100%}.period-switch button{font-size:12px;padding:6px 2px}
          .period-navigation{display:grid;grid-template-columns:44px minmax(0,1fr) 44px 44px;gap:4px;width:100%}.period-navigation label{min-width:0}.period-navigation:has(#from-field:not([hidden])){grid-template-columns:minmax(0,1fr) minmax(0,1fr)}
          .toggles{align-items:flex-start}.toggles label{display:grid;gap:4px;width:100%}.toggles select{width:100%;margin-left:0}.toggles small{margin-left:0;white-space:normal}
          .purchase-summary{flex-wrap:wrap;gap:6px 16px}.summary{grid-template-columns:1fr}.summary>div+div{border-left:0;border-top:1px solid var(--line)}.summary strong{font-size:21px}
          .table-wrap{width:100%;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch}.month-statement{min-width:720px}.settings-grid{grid-template-columns:minmax(0,1fr)}
          .chart-stage{max-width:100%;overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch}.chart-stage svg{width:max(600px,100%);min-height:0}.chart-stage [data-chart-hit]{touch-action:pan-x pan-y}
          .chart-readout{max-width:100%;padding:9px}.tip-values{gap:6px;align-items:center}.tip-values>strong{flex-basis:100%;min-width:0}.tip-values span{font-size:11px}.stream-result{gap:6px}.stream-result>strong{font-size:21px}.stream-result>span:first-child{flex-basis:100%}
          .row{gap:8px;font-size:12px}.row>span{min-width:0;overflow-wrap:anywhere}.chart-hint{margin-left:0}.section-head{gap:8px}.top .actions button{padding:7px 8px;font-size:12px}
        }
.filters label,.settings-grid label{min-width:0;gap:6px;font-size:12px;font-weight:550;line-height:1.4}
.fields input,.fields select,.toggles select,.settings-grid input,.settings-grid select,.payment-row input,#advance-history input{min-width:0;max-width:100%;height:40px;box-sizing:border-box;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:var(--paper);color:var(--ink);font:inherit;font-size:14px;font-variant-numeric:tabular-nums}
.fields input,.fields select,.settings-grid input,.settings-grid select{width:100%}
.fields input:focus-visible,.fields select:focus-visible,.toggles select:focus-visible,.settings-grid input:focus-visible,.settings-grid select:focus-visible{outline:2px solid var(--purple);outline-offset:2px}
.toggles label{display:grid;align-items:start;gap:6px}.toggles{align-items:end;gap:12px}
.appearance-settings{display:flex;align-items:center;justify-content:space-between;gap:16px}.appearance-settings h2{margin:0 0 4px}.appearance-settings .help{margin:0}
.appearance-settings label{display:grid;gap:6px;min-width:150px;font-size:12px;font-weight:550}.appearance-settings select{height:40px;border-radius:8px;font-size:14px}
@media(max-width:560px){.fields input,.fields select,.toggles select,.settings-grid input,.settings-grid select,.payment-row input,#advance-history input,.appearance-settings select{font-size:16px;min-height:44px;height:44px}.toggles label{width:100%}.toggles select{width:100%}.appearance-settings{align-items:stretch;flex-direction:column;gap:12px}.appearance-settings label{min-width:0;width:100%}.settings-grid{gap:14px}.period-navigation{max-width:100%}}

      </style><div class="page"><div class="wrap">
        <header class="top">${button('☰ Menu','id="mobile-menu" class="mobile-menu" hidden aria-label="Dashboardmenu openen"')}<h1 id="title" tabindex="-1">Financieel <small style="font-size:11px;font-weight:500">7.1</small></h1><div class="actions">${button('Instellingen & uitleg','id="options" aria-expanded="false" aria-controls="settings"')}${button('↻','id="refresh" aria-label="Vernieuwen"')}</div></header>
        <div class="filters"><select id="period" aria-label="Periode" hidden><option value="month">Maand</option><option value="year">Jaar</option><option value="contract">Contractjaar</option><option value="custom">Eigen periode</option></select><div class="period-bar"><div class="period-switch" role="group" aria-label="Periode kiezen">${button('Maand','data-preset="month" aria-pressed="false"')}${button('Jaar','data-preset="year" aria-pressed="false"')}${button('Contract','data-preset="contract" aria-pressed="true"')}${button('Zelf kiezen','data-preset="custom" aria-pressed="false"')}</div><div class="fields period-navigation">${button('←','id="prev" aria-label="Vorige periode"')}<label id="month-field">Maand<input id="month" type="month" value="${monthNow}"></label><label id="year-field" hidden>Jaar<select id="year"></select></label><label id="contract-field" hidden>Contract<select id="contract"></select></label><label id="from-field" hidden>Van<input id="from" type="date"></label><label id="to-field" hidden>Tot en met<input id="to" type="date"></label>${button('→','id="next" aria-label="Volgende periode"')}${button('Nu','id="current-period" title="Ga naar de huidige maand, het huidige jaar of contract"')}</div></div><div class="toggles"><label>Prijsweergave<select id="price-mode"><option value="allin">All-in + opslag (EB en btw)</option><option value="bare">Kaal + opslag (zonder EB/btw)</option></select></label><span id="basis" class="badge"></span><small id="filter-dates"></small></div></div>

        <div id="status" role="status" aria-live="polite" class="notice"></div>
        <div id="content"></div>
        <div id="settings" hidden><section class="panel appearance-settings"><div><h2>Weergave</h2><p class="help">Donkere modus voor het hele dashboard.</p></div><label for="cfg-dark">Donkere modus<select id="cfg-dark"><option value="uit">Uit</option><option value="aan">Aan</option></select></label><label for="cfg-dark-style">Dark mode stijl<select id="cfg-dark-style"><option value="bruingrijs">Bruingrijs</option><option value="grafiet">Grafiet</option></select></label><label for="cfg-afrr-market">Regelvermogen &amp; biedingen<select id="cfg-afrr-market"><option value="aan">Aan</option><option value="uit">Uit · geen API-aanvragen</option></select></label></section><section class="panel"><h2>Voorschotten en contract</h2><div id="settings-body"></div></section><section class="panel"><h2>Berekening van deze selectie</h2><div id="calculation"></div></section><details class="panel"><summary>Rekenregels en bronnen</summary><div id="rules" class="note-list"></div></details><div class="actions" style="margin-top:12px">${button('CSV downloaden','id="csv"')}</div></div>
      </div></div>`;
      theme();document.body.appendChild(root);
      var year = +monthNow.slice(0, 4), startYear = cfg.start.getFullYear();
      for (var y = startYear; y <= year + 1; y++) $('year').add(new Option(String(y), String(y)));
      $('year').value = String(year); $('contract').innerHTML = contractOptions(); $('contract').value = String(beOvContract(iso(new Date())).index);
      $('from').value = monthNow + '-01'; $('to').value = iso(new Date());
      var allin=beOvSettings.tax&&beOvSettings.vat;beOvSettings.tax=beOvSettings.vat=allin;$('price-mode').value=allin?'allin':'bare';
      state = {type:'contract'}; $('period').value='contract';
      ['period','month','year','contract','from','to'].forEach(function (id) { $(id).addEventListener('change', function () { updateFilters(); load(); }); });
      $('cfg-dark').value=beDarkOn?'aan':'uit';
      $('cfg-dark').onchange=function(){beDarkApply($('cfg-dark').value==='aan');};
      $('cfg-dark-style').value=window.BETheme.style();
      $('cfg-dark-style').onchange=function(){window.BETheme.setStyle($('cfg-dark-style').value);};
      $('cfg-afrr-market').value=beAfrrMarketEnabled()?'aan':'uit';
      $('cfg-afrr-market').onchange=function(){beAfrrMarketSet($('cfg-afrr-market').value==='aan');};

      $('price-mode').addEventListener('change',function(){var allin=$('price-mode').value==='allin';beOvSettings.tax=beOvSettings.vat=allin;save();updateFilters();if(latest)render();});
      shadow.querySelectorAll('[data-preset]').forEach(function(b){b.onclick=function(){
        $('period').value=b.dataset.preset;updateFilters();load();
      };});
      $('current-period').onclick=function(){
        $('month').value=iso(new Date()).slice(0,7);$('year').value=String(new Date().getFullYear());$('contract').value=String(beOvContract(iso(new Date())).index);
        updateFilters();load();
      };
      $('prev').onclick = function () { shift(-1); }; $('next').onclick = function () { shift(1); };
      $('options').onclick=function(){var open=$('settings').hidden;$('settings').hidden=!open;$('content').hidden=open;$('options').textContent=open?'Terug naar overzicht':'Instellingen & uitleg';$('options').setAttribute('aria-expanded',String(open));};
      $('rules').innerHTML=''+
        '<p>Stroom = verkoop − inkoop − energiebelasting na saldering. Vaste kosten = belastingvermindering − levering − netbeheer. Plus voorschotten geeft het saldo. Alle bedragen zijn voorlopig; maandbedragen worden op centen afgerond.</p>'+
        '<p>Voorschotten volgen je bedragen en ingangsdatums, verdeeld over kalenderdagen. Dit is geen bankafschrift. Je kunt ook werkelijke betalingen invullen. Vaste dagkosten en voorschotten lopen tot en met vandaag; de gemeten stroom van vandaag kan nog onvolledig zijn.</p>'+
        '<p>Balansdagen krijgen voorrang op de eigen cache. Een cachedag blijft voorlopig; bij ontbrekende prijzen telt uitsluitend het geprijsde deel mee. Vandaag wordt in de prognose vervangen door één geschatte hele dag. De bekende stand gebruikt het gemeten dagdeel. Daardoor tellen ze nooit dubbel.</p>'+
        '<p>De prognose gebruikt de seizoensfactoren voor afname en teruglevering uit 5.0, met maximaal 28 complete recente brondagen (minimaal 7). Een beschikbare volledige vergelijkbare maand van vorig jaar weegt 60% mee. Bronbedragen en kWh worden geraamd vóór toepassing van EB. Dit is geen weers- of prijsvoorspelling. De resterende stroompost bevat ook het verwachte effect op saldering. Bij ontbrekende historische dagen tonen we geen totaalprognose.</p>'+
        '<p>Tot 1 januari 2027 wordt EB per contractjaar verrekend (art. 50 lid 2 Wbm), maximaal de afname. Duurzame teruglevering telt volledig; overige teruglevering tot 5.000 kWh (art. 2.31 Energiewet). Duurzaam = per dag maximaal de geschatte pv-opwek uit de Balans-gegevens. Bij jaarwisseling geldt de gekozen tijdsevenredige of afnamegewogen raming; je leveranciersnota kan een andere toegestane verdeling hanteren. Maandbedragen zijn een toerekening en kunnen veranderen.</p>'+
        '<p>Btw of EB uit is een vergelijking, geen factuurbedrag. Netto niet terugleveren maakt btw niet automatisch nul. De opslag van 2 cent inclusief btw is al verwerkt in de bron; we tellen hem niet nogmaals op. Ontbrekende jaartarieven of hogere verbruiksschijven geven geen verzonnen bedrag.</p>'+
        '<p><a href="https://consument.acm.nl/elektriciteit-en-gas/duurzame-energie/wat-is-salderen" target="_blank" rel="noopener noreferrer">ACM: salderen</a> · <a href="https://download.belastingdienst.nl/belastingdienst/docs/handboek_milieubelast_2026_ml0301z61fd.pdf" target="_blank" rel="noopener noreferrer">Belastingdienst: Handboek 2026, 7.4.2 en 7.8.14</a></p>';
      $('refresh').onclick = function () { cache.clear(); load(); };
      $('csv').onclick = exportCSV;
      $('mobile-menu').onclick=function(){
        var toggle=document.querySelector('[data-bs-target="#mobileSidebar"]');
        if(toggle&&toggle.getAttribute('aria-expanded')!=='true')toggle.click();
      };
      ['pointerover','pointermove','focusin'].forEach(function(event){$('content').addEventListener(event,function(e){
        var hit=e.target.closest('[data-chart-hit]');if(hit&&!tooltipPinned)showChartTip(+hit.dataset.chartHit,e);
      });});
      $('content').addEventListener('pointerout',function(e){if(!tooltipPinned&&e.target.closest('[data-chart-hit]')&&!(e.relatedTarget&&e.relatedTarget.closest('[data-chart-hit]')))hideChartTip();});
      $('content').addEventListener('focusout',function(e){if(!tooltipPinned&&e.target.closest('[data-chart-hit]'))hideChartTip();});
      $('content').addEventListener('keydown',function(e){var month=e.target.closest('[data-month]');if(month&&(e.key==='Enter'||e.key===' ')){e.preventDefault();e.stopPropagation();toggleMonth(month.dataset.month);return;}var hit=e.target.closest('[data-chart-hit]');if(!hit)return;
        if(e.key==='Escape'){e.preventDefault();e.stopPropagation();tooltipPinned=false;hideChartTip();}
        else if(e.key==='Enter'||e.key===' '){e.preventDefault();tooltipPinned=!tooltipPinned;showChartTip(+hit.dataset.chartHit,e);}
        else if(e.key==='ArrowRight'||e.key==='ArrowLeft'){e.preventDefault();var i=Math.max(0,Math.min(chartPoints.length-1,+hit.dataset.chartHit+(e.key==='ArrowRight'?1:-1)));tooltipPinned=false;var next=$('chart-point-'+i);if(next)next.focus();}
      });
      $('content').addEventListener('click', function (e) {
        var unit=e.target.closest('[data-chart-unit]');if(unit){chartUnit=unit.dataset.chartUnit;render();return;}
        var hit=e.target.closest('[data-chart-hit]');if(hit){tooltipPinned=!(tooltipPinned&&tooltipIndex===+hit.dataset.chartHit);showChartTip(+hit.dataset.chartHit,e);return;}
        tooltipPinned=false;hideChartTip();
        var month=e.target.closest('[data-month]');if(month){toggleMonth(month.dataset.month);return;}
        var b = e.target.closest('[data-contract-link]'); if (!b) return;
        $('period').value = 'contract'; $('contract').value = b.dataset.contractLink; updateFilters(); load();
      });
      settingsUI(); updateFilters(); theme();
    }
    function toggleMonth(key){
      var scroll=innerWidth<768?window.scrollY:root.scrollTop,closing=expandedMonth===key,token=++monthToggleSerial;
      expandedMonth=closing?null:key;
      if(monthAnimation){monthAnimation.cancel();monthAnimation=null;}
      function redraw(){render();var row=$('month-row-'+key);if(row)row.focus({preventScroll:true});if(innerWidth<768)window.scrollTo(window.scrollX,scroll);else root.scrollTop=scroll;}
      if(!closing)redraw();
      var detail=$('reveal-'+key),reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      if(!detail||!detail.animate||reduce){if(closing)redraw();return;}
      var height=detail.getBoundingClientRect().height;
      var animation=detail.animate(closing?[{height:height+'px',opacity:1},{height:'0px',opacity:0}]:[{height:'0px',opacity:0},{height:height+'px',opacity:1}],{duration:closing?180:260,easing:'cubic-bezier(.22,.7,.24,1)',fill:'both'});
      monthAnimation=animation;
      animation.finished.then(function(){if(token!==monthToggleSerial)return;monthAnimation=null;if(closing)redraw();animation.cancel();}).catch(function(){});
    }
    function statementRange(r){
      if($('period').value!=='month')return r;
      var today=iso(new Date()),anchor=today>=r.a&&today<=r.b?today:r.a,c=beOvContract(anchor);
      return {a:c.begin,b:c.end};
    }
    function theme() { if (root) {
      var dark=window.BETheme.isDark(),style=window.BETheme.style();
      root.toggleAttribute('data-dark',dark);root.setAttribute('data-dark-style',style);
      root.style.background=dark?(style==='grafiet'?'#111316':'#282723'):'#f6f7fb';
      if($('cfg-dark'))$('cfg-dark').value=dark?'aan':'uit';
      if($('cfg-dark-style'))$('cfg-dark-style').value=style;
    } }
    function shift(n) {
      var type = $('period').value;
      if (type === 'month') { var d = beOvDate($('month').value + '-01'); d.setUTCMonth(d.getUTCMonth() + n); $('month').value = beOvISO(d).slice(0, 7); }
      else { var select = $(type); if (select.selectedIndex + n < 0 || select.selectedIndex + n >= select.options.length) return; select.selectedIndex += n; }
      updateFilters(); load();
    }
    function range() {
      var type = $('period').value, a, b;
      if (type === 'month') { a = $('month').value + '-01'; var d = beOvDate(a); d.setUTCMonth(d.getUTCMonth() + 1); b = beOvAdd(beOvISO(d), -1); }
      if (type === 'year') { a = $('year').value + '-01-01'; b = $('year').value + '-12-31'; }
      if (type === 'contract') { a = beOvAnniversary(iso(cfg.start), +$('contract').value); b = beOvAdd(beOvAnniversary(iso(cfg.start), +$('contract').value + 1), -1); }
      if (type === 'custom') { a = $('from').value; b = $('to').value; }
      if (![a,b].every(function (k) { return /^\d{4}-\d{2}-\d{2}$/.test(k || '') && Number.isFinite(+beOvDate(k)) && beOvISO(beOvDate(k)) === k; })) throw Error('Kies twee geldige datums.');
      if (a > b) throw Error('De einddatum moet op of na de begindatum liggen.');
      if (beOvDays(a, b) > 1096) throw Error('Kies maximaal drie jaar tegelijk.');
      if (b < iso(cfg.start)) throw Error('Deze periode ligt vóór de ingestelde contractstart. Kies een latere periode.');
      if (a < iso(cfg.start)) a = iso(cfg.start);
      return {a:a, b:b};
    }
    function updateFilters() {
      var type = $('period').value; state.type = type;
      shadow.querySelectorAll('[data-preset]').forEach(function(b){b.setAttribute('aria-pressed',String(b.dataset.preset===type));});
      $('prev').hidden=$('next').hidden=$('current-period').hidden=type==='custom';
      ['month','year','contract','from','to'].forEach(function (id) { $(id + '-field').hidden = type === 'custom' ? !['from','to'].includes(id) : id !== type; });
      $('prev').disabled = $('next').disabled = type === 'custom';
      $('basis').textContent=beOvSettings.tax?'All-in · met EB en btw':'Kaal · zonder EB en btw';
      try { var r = range(); $('filter-dates').textContent = date(r.a) + ' t/m ' + date(r.b); } catch (_) { $('filter-dates').textContent = ''; }
    }
    async function fetchMonth(id, month) {
      var key = id + ':' + month, saved = cache.get(key), now = Date.now();
      if (saved && now - saved.time < 60000) return {rows:saved.rows,unavailable:!!saved.unavailable};
      var url = new URL('/customer/' + encodeURIComponent(id) + '/results-v2-api/', location.origin);
      url.searchParams.set('interval','month'); url.searchParams.set('period',month);
      url.searchParams.set('include_vat','1'); url.searchParams.set('include_delivery_cost','1');
      var res = await origFetch(url.href, {credentials:'same-origin'});
      if(res.status===400){
        var failure=null;try{failure=await res.json();}catch(_){}
        if(failure?.error?.code==='period_not_available'){
          var unavailable={rows:[],unavailable:true};
          cache.set(key,{time:now,rows:[],unavailable:true});return unavailable;
        }
      }
      if (!res.ok) throw Error(res.status === 429 ? 'Balans vraagt om even te wachten (429). Probeer over een minuut opnieuw.' : res.status === 401 || res.status === 403 ? 'Log opnieuw in bij Balans om je resultaten te lezen.' : 'Resultaten ' + month + ' konden niet worden geladen (HTTP ' + res.status + ').');
      var rows = beOvNormalize(await res.json(), month);
      cache.set(key, {time:now, rows:rows,unavailable:false}); return {rows:rows,unavailable:false};
    }
    async function load() {
      var ticket = ++serial, r, id;
      try { r = range(); id = verversKlantUitPad(); if (!geldigeKlant(id)) throw Error('Het installatie-id is nog niet bekend. Open eerst Actueel of Resultaten en daarna dit overzicht.'); }
      catch (e) { status(e.message, true); latest = null; $('content').innerHTML = ''; $('csv').disabled = true; return; }
      latest = null; $('csv').disabled = true; $('refresh').disabled = true;
      $('content').innerHTML = '<div class="panel empty"><span class="spinner"></span> Je brongegevens worden gelezen…</div>';
      var today = iso(new Date()), last = r.b < today ? r.b : today;
      var from = r.a <= last ? beOvContract(r.a).begin : beOvContract(today).begin;
      var end = r.a <= last ? beOvContract(last).end : today;
      if (end > today) end = today;
      if (from > beOvAdd(today, -28)) from = beOvAdd(today, -28);
      if (from < iso(cfg.start)) from = iso(cfg.start);
      var months = beOvMonths(from, end), sets = [], cursor = 0, done = 0;
      status('Historie en salderingscontext ophalen: 0 / ' + months.length + ' maanden.');
      async function worker() {
        while (cursor < months.length) {
          if (ticket !== serial) return;
          var month = months[cursor++];
          try { sets.push(Object.assign({month:month},await fetchMonth(id,month))); }
          catch (e) { sets.push({month:month,error:e.message||'Resultaten '+month+' konden niet worden geladen.'}); }
          done++; if (ticket === serial) status('Historie en salderingscontext ophalen: ' + done + ' / ' + months.length + ' maanden.');
        }
      }
      await Promise.all([worker(), worker()]);
      if (ticket !== serial) return;
      if (id !== verversKlantUitPad()) { $('refresh').disabled = false; load(); return; }
      latest = {id:id, range:r, sourceRows:[], rows:[], errors:[], unavailableMonths:[], at:new Date(), from:from, to:end, day:today};
      sets.forEach(function(set){beOvApplyMonthResult(latest,set);});
      mergeOwnCache();
      $('refresh').disabled = false; $('csv').disabled = false; render();
      refreshOwnCache();
    }
    function mergeOwnCache(){
      if(!latest)return;
      latest.rows=beOvMergeRows(latest.sourceRows,leesVoorlopigeDagen(),latest.id,latest.from,latest.to,Date.now());
      var yesterday=beOvAdd(iso(new Date()),-1),end=latest.to<yesterday?latest.to:yesterday;
      latest.contextMissing=Math.max(0,beOvDays(latest.from,end)-latest.rows.filter(function(d){return d.key<=end;}).length);
      latest.contextPartial=latest.rows.some(function(d){return d.key<=end&&d.deelresultaat;});
    }
    function refreshOwnCache(){
      if(ownRefreshPromise||!opened||document.hidden||!latest)return;
      var target=latest,id=target.id,before=JSON.stringify([target.rows,target.errors,target.unavailableMonths]);
      ownRefreshAt=Date.now();
      ownRefreshPromise=Promise.resolve().then(function(){return resultatenHaalVoorlopigeDagen(true);}).catch(function(){return false;}).then(async function(){
        if(!opened||latest!==target||id!==verversKlantUitPad())return;
        // De bestaande cachecontrole ruimt een voorlopige dag op zodra Balans
        // hem heeft verwerkt. Lees daarom ook de bijbehorende echte dag opnieuw.
        var today=iso(new Date()),recent=beOvMonths(beOvAdd(today,-4),today);
        var sets=await Promise.all(recent.map(async function(month){
          try{cache.delete(id+':'+month);return Object.assign({month:month},await fetchMonth(id,month));}
          catch(e){return {month:month,error:e.message||'Resultaten '+month+' konden niet worden geladen.'};}
        }));
        if(!opened||latest!==target||id!==verversKlantUitPad())return;
        sets.forEach(function(set){beOvApplyMonthResult(target,set);});
      }).then(function(){
        ownRefreshPromise=null;
        if(!opened||latest!==target||latest.id!==verversKlantUitPad())return;
        mergeOwnCache();
        if(before!==JSON.stringify([target.rows,target.errors,target.unavailableMonths]))render();
      });
    }
    function selected(all, r) { return all.filter(function (d) { return d.key >= r.a && d.key <= r.b; }); }
    function aggregates(rows, monthly) {
      var groups = new Map(); rows.forEach(function (r) { var key = monthly ? r.key.slice(0, 7) : r.key; if (!groups.has(key)) groups.set(key, []); groups.get(key).push(r); });
      return Array.from(groups.entries()).map(function (pair) { return Object.assign({key:pair[0], count:pair[1].length, provisional:pair[1].filter(function (r) { return r.voorlopig; }).length}, beOvTotal(pair[1])); });
    }
    function signedMoney(v){return v===null||!Number.isFinite(v)?'Nog onbekend':(v>.004?'+':'')+money(v);}
    function row(label,value,cls){return '<div class="row '+(cls||'')+'"><span>'+label+'</span><strong>'+value+'</strong></div>';}
    function streamMoney(v){return v===null||!Number.isFinite(v)?'Nog onbekend':(Math.abs(v)<.005?'':v>0?'+ ':'− ')+money(Math.abs(v));}
    function chartAmounts(t){return t?[t.ebGrossShown===null?null:t.buyShown+t.ebGrossShown,t.ebCreditShown===null?null:t.sellShown+t.ebCreditShown,t.result]:[null,null,null];}
    function averagePrice(amount,kwh){return Number.isFinite(amount)&&Number.isFinite(kwh)&&kwh>0?'€ '+(amount/kwh).toLocaleString('nl-NL',{minimumFractionDigits:2,maximumFractionDigits:3})+' / kWh':'—';}
    function showChartTip(index,event){
      var point=chartPoints[index],tip=$('chart-tooltip');if(!point||!tip||!point.known)return;
      var known=point.known,name=point.key.length===7?new Intl.DateTimeFormat('nl-NL',{month:'long',year:'numeric',timeZone:'UTC'}).format(beOvDate(point.key+'-01')):date(point.key);
      var amounts=chartAmounts(known),html='<div class="tip-values"><strong>'+esc(name)+'</strong>';
      function item(label,value,color,rate){color=color||(label==='Inkoop'||label==='Afname'?'var(--blue)':label==='Verkoop'||label==='Export'?'var(--green)':'var(--purple)');var rateLabel=label==='Inkoop'||label==='Afname'?'Gem. importprijs':'Gem. exportprijs';return '<span'+(rate!==undefined?' class="has-rate"':'')+' style="--series-color:'+color+'"><i class="tip-dot"></i>'+label+' <strong>'+value+'</strong>'+(rate!==undefined?'<small class="tip-rate" title="'+rateLabel+'">gem. '+rate+'</small>':'')+'</span>';}
      html+=item('Afname',fmt(known.imp,2)+' kWh','var(--blue)',chartUnit==='kwh'?averagePrice(amounts[0],known.imp):undefined);
      if(chartUnit==='eur')html+=item('Inkoop',money(amounts[0]),'var(--blue)',averagePrice(amounts[0],known.imp));
      html+=item('Export',fmt(known.exp,2)+' kWh','var(--green)',chartUnit==='kwh'?averagePrice(amounts[1],known.exp):undefined);
      if(chartUnit==='eur')html+=item('Verkoop',money(amounts[1]),'var(--green)',averagePrice(amounts[1],known.exp));
      if(chartUnit==='eur')html+=item('Resultaat',streamMoney(amounts[2]));
      html+='</div>';
      if(chartUnit==='eur'){
        var result=amounts[2],daily=point.key.length===10,kind=result===null?'Nog onbekend':Math.abs(result)<.005?'Geen kosten of opbrengst':result<0?'Stroomkosten':'Stroomopbrengst';
        html+='<div class="stream-result"><span>Netto stroomresultaat '+(daily?'van deze dag':'van deze maand')+'</span><strong class="'+signedClass(result)+'">'+streamMoney(result)+' <small>'+kind.toLowerCase()+'</small></strong><span>Verkoop − inkoop</span></div>';
      }
      html+='<p class="tip-foot">'+(known.provisional?'Inclusief eigen cache · voorlopig. ':'')+'2 cent opslag inbegrepen · '+(beOvSettings.tax?'met EB na saldering':'zonder EB')+' · '+(beOvSettings.vat?'incl. btw':'excl. btw')+' · '+(tooltipPinned?'Vastgezet · klik opnieuw om los te maken.':'Klik om vast te zetten; ← → voor vorige/volgende.')+'</p>';
      tip.innerHTML=html;tip.hidden=false;tooltipIndex=index;var stage=$('chart-stage');if(stage){stage.setAttribute('data-active','true');stage.querySelectorAll('[data-chart-column]').forEach(function(g){g.toggleAttribute('data-selected',+g.dataset.chartColumn===index);});}var hint=$('chart-tip-hint');if(hint)hint.hidden=true;
    }
    function hideChartTip(){var stage=$('chart-stage');if(stage){stage.removeAttribute('data-active');stage.querySelectorAll('[data-chart-column]').forEach(function(g){g.removeAttribute('data-selected');});}var tip=$('chart-tooltip'),hint=$('chart-tip-hint');if(tip)tip.hidden=true;if(hint)hint.hidden=false;tooltipIndex=-1;}
    function barChart(points){
      chartPoints=points;tooltipPinned=false;tooltipIndex=-1;
      if(!points.length)return '<p class="empty">Nog geen brongegevens in deze periode.</p>';
      var w=1040,h=240,left=58,bottom=204,top=16,plot=w-left-12;
      function values(t){return chartUnit==='kwh'?(t?[t.imp,t.exp]:[null,null]):chartAmounts(t);}
      var numbers=[0];points.forEach(function(p){[p.known].forEach(function(t){values(t).forEach(function(v){if(v!==null)numbers.push(v);});});});
      var min=Math.min.apply(null,numbers),max=Math.max.apply(null,numbers);if(min===max)max=min+1;
      var padding=(max-min)*.06;max+=padding;if(min<0)min-=padding;
      var y=function(v){return top+(max-v)/(max-min)*(bottom-top);},zero=y(0),slot=plot/points.length,count=chartUnit==='kwh'?2:3,bar=Math.min(19,slot*.7/count),colors=['var(--blue)','var(--green)','var(--purple)'];
      var svg='<div class="chart-stage" id="chart-stage"><svg viewBox="0 0 '+w+' '+h+'" role="group" aria-label="'+(chartUnit==='kwh'?'Afname en teruglevering in kWh':'Inkoop, verkoop en stroomresultaat in euro')+'; beweeg over de grafiek voor details"><defs><pattern id="cache-hatch" width="5" height="5" patternUnits="userSpaceOnUse"><path d="M-1 1L1-1 M0 5L5 0 M4 6L6 4" stroke="var(--paper)" opacity=".65" stroke-width="1.5"/></pattern></defs>';
      for(var i=0;i<5;i++){var v=min+(max-min)*i/4,py=y(v);svg+='<line x1="'+left+'" y1="'+py+'" x2="'+(w-12)+'" y2="'+py+'" stroke="var(--line)"/><text x="'+(left-8)+'" y="'+(py+3)+'" text-anchor="end" fill="var(--muted)" font-size="10">'+(chartUnit==='eur'?'€ ':'')+esc(fmt(v,0))+'</text>';}
      svg+='<line x1="'+left+'" y1="'+zero+'" x2="'+(w-12)+'" y2="'+zero+'" stroke="var(--muted)" opacity=".65"/>';
      points.forEach(function(p,i){
        var x=left+slot*(i+.5),label=p.key.length===7?p.key.slice(5)+'/'+p.key.slice(2,4):p.key.slice(8)+'/'+p.key.slice(5,7);p.x=x;
        svg+='<g class="chart-column" data-chart-column="'+i+'"><rect class="chart-backlight" x="'+(left+slot*i+2)+'" y="'+top+'" width="'+Math.max(1,slot-4)+'" height="'+(bottom-top)+'" rx="5" fill="var(--soft)"/>';
        [p.known].forEach(function(t){if(!t)return;var future=false;
          values(t).forEach(function(v,j){if(v===null)return;var py=y(v),rx=x+(j-(count-1)/2)*(bar+2)-bar/2,height=Math.max(.8,Math.abs(zero-py));
            var attrs=' x="'+rx+'" y="'+Math.min(zero,py)+'" width="'+bar+'" height="'+height+'" rx="2"';
            svg+='<rect class="chart-bar"'+attrs+' fill="'+colors[j]+'" fill-opacity="'+(future?'.10':'.8')+'"'+(future?' stroke="'+colors[j]+'" stroke-width="1.3" stroke-dasharray="3 2"':'')+'/>';
            if(chartUnit==='eur'&&j===2&&p.key.length===10&&points.length<=31)svg+='<text class="day-result-label" x="'+(rx+bar/2)+'" y="'+(v>=0?Math.max(10,py-5):Math.min(218,zero+height+12))+'" text-anchor="middle" font-size="9" font-weight="650" fill="'+(v<0?'var(--red)':'var(--green)')+'">'+esc((v>0?'+':'')+fmt(v,2))+'</text>';
            if(!future&&t.provisional&&p.key.length===10)svg+='<rect'+attrs+' fill="url(#cache-hatch)" pointer-events="none"/>';
          });
        });
        if(i%Math.max(1,Math.ceil(points.length/16))===0||i===points.length-1)svg+='<text x="'+x+'" y="228" text-anchor="middle" font-size="10" fill="var(--muted)">'+label+'</text>';
        var desc=(p.key.length===7?p.key:p.key)+' · '+(p.known?'bekend':'prognose')+' · '+(chartUnit==='eur'?'inkoop '+money(chartAmounts(p.known)[0])+', verkoop '+money(chartAmounts(p.known)[1]):'afname '+(p.known?fmt(p.known.imp,2):'—')+' kWh');
        svg+='<rect id="chart-point-'+i+'" class="chart-hit" data-chart-hit="'+i+'" x="'+(left+slot*i)+'" y="'+top+'" width="'+slot+'" height="'+(bottom-top)+'" tabindex="0" role="button" aria-label="'+esc(desc)+'" aria-describedby="chart-tooltip"/></g>';
      });
      return svg+'</svg></div><div class="chart-readout"><p class="help" id="chart-tip-hint">Tik of beweeg over een dag of maand voor de bedragen.</p><div class="chart-tooltip" id="chart-tooltip" role="tooltip" hidden></div></div>';
    }
    function chartData(rows,r){
      var monthly=$('period').value!=='month'&&beOvDays(r.a,r.b)>62;
      // Deze grafiek bevat uitsluitend gemeten/voorlopige bronresultaten.
      return aggregates(rows,monthly).map(function(t){return {key:t.key,known:t};});
    }
    function balanceParts(t,a,b){
      function round(v){return v===null?null:Math.round((v+Math.sign(v)*1e-10)*100)/100;}
      var f=beOvFixed(a,b,beOvSettings),buy=t.ebGrossShown===null?null:round(t.buyShown+t.ebGrossShown),sell=t.ebCreditShown===null?null:round(t.sellShown+t.ebCreditShown),fixed=round(f.net),advance=round(f.advance);
      return {buy:buy,sell:sell,stroom:buy===null||sell===null?null:round(sell-buy),fixed:fixed,advance:advance,saldo:buy===null||sell===null||fixed===null?null:round(sell-buy+fixed+advance)};
    }
    function provisionalDetail(m){
      var rows=m.provisionalRows||[];if(!rows.length)return '';
      var sum={buy:0,sell:0,stroom:0,fixed:0,advance:0,saldo:0};
      var h='<section class="cache-detail"><h3>Voorlopige dagen · eigen cache</h3><p class="help">Al opgenomen in de maandstand. Dagsaldo = verkoop − inkoop + vaste posten + voorschot.</p><div class="table-wrap"><table class="cache-table"><thead><tr><th>Datum</th><th>Inkoop −</th><th>Verkoop +</th><th>Netto stroom</th><th>Vaste posten</th><th>Voorschot +</th><th>Dagsaldo incl. voorschot</th></tr></thead><tbody>';
      rows.forEach(function(d){var v=balanceParts(beOvTotal([d]),d.key,d.key),label=date(d.key)+(d.deelresultaat?' · dagdeel':'');
        Object.keys(sum).forEach(function(k){sum[k]=sum[k]===null||v[k]===null?null:Math.round((sum[k]+v[k])*100)/100;});
        h+='<tr><td>'+esc(label)+(d.bijgewerkt?'<small>Bijgewerkt '+new Intl.DateTimeFormat('nl-NL',{hour:'2-digit',minute:'2-digit',timeZone:'Europe/Amsterdam'}).format(new Date(d.bijgewerkt))+'</small>':'')+'</td>'+['buy','sell','stroom','fixed','advance','saldo'].map(function(k){var amount=k==='buy'?(v[k]===null?null:-v[k]):v[k];return '<td class="'+signedClass(amount)+(k==='stroom'?' net-stream':'')+'">'+signedMoney(amount)+'</td>';}).join('')+'</tr>';
      });
      h+='</tbody><tfoot><tr><td>Voorlopige dagen samen</td>'+['buy','sell','stroom','fixed','advance','saldo'].map(function(k){return '<td>'+signedMoney(k==='buy'?(sum[k]===null?null:-sum[k]):sum[k])+'</td>';}).join('')+'</tr></tfoot></table></div><p class="help">Positief dagsaldo = erbij op je te ontvangen saldo; negatief = eraf. Opslag en gekozen EB/btw inbegrepen. EB is een contractraming. Vandaag: stroom tot het cachetijdstip, vaste posten en voorschot voor de hele dag. Dagafronding kan 1 cent afwijken van de maandafronding.'+(rows.some(function(d){return d.prijsOnvolledig;})?' Alleen het geprijsde deel telt mee.':'')+'</p></section>';
      return h;
    }
    function monthDetail(m, projection){
      if(!m||!m.days)return '<p class="help">Voor deze maand zijn nog geen gemeten bedragen beschikbaar.</p>';
      var t=m.total,f=m.fixed,s=beOvSettings,factor=s.vat?1:1/BTW,fi=t.imp*.02*factor,fe=t.exp*.02*factor;
      var buy=t.ebGrossShown===null?null:t.buyShown+t.ebGrossShown,sell=t.ebCreditShown===null?null:t.sellShown+t.ebCreditShown;
      var h='<div class="month-detail"><p class="detail-period">'+date(m.from)+' t/m '+date(m.to)+' · '+(m.forecast?'prognose':m.provisional?'inclusief voorlopige eigen cache':'bekende brongegevens')+'</p><div class="detail-grid"><div><h3>1. Inkoop · '+fmt(t.imp,2)+' kWh</h3>'+
        row('Stroom zonder opslag',signedMoney(-t.buyShown+fi))+row('Opslag · '+(s.vat?'2 cent incl. btw':'1,65289 cent excl. btw')+' / kWh',signedMoney(-fi))+row('Energiebelasting afname',signedMoney(t.ebGrossShown===null?null:-t.ebGrossShown))+row('Totaal inkoop',signedMoney(buy===null?null:-buy),'total')+'<p class="help">Gemiddeld '+(buy===null||!t.imp?'—':'€ '+fmt(buy/t.imp,5))+' / kWh, inclusief gekozen EB/btw.</p></div><div><h3>2. Verkoop · '+fmt(t.exp,2)+' kWh</h3>'+
        row('Opbrengst vóór opslag',signedMoney(t.sellShown+fe))+row('Opslag · '+(s.vat?'2 cent incl. btw':'1,65289 cent excl. btw')+' / kWh',signedMoney(-fe))+row('EB terug door salderen / tariefverdeling',signedMoney(t.ebCreditShown))+row('Totaal verkoop',signedMoney(sell),'total')+'<p class="help">Gemiddeld '+(sell===null||!t.exp?'—':'€ '+fmt(sell/t.exp,5))+' / kWh. Saldering wordt over het contract berekend.</p></div><div><h3>3. Vaste posten en voorschot</h3>'+
        row('Vaste levering',signedMoney(-f.supplier))+row('Netbeheer',signedMoney(-f.network))+row('Vermindering energiebelasting',signedMoney(f.credit))+row('Vaste posten samen',signedMoney(m.vast),'total')+row(s.paymentMode==='actual'?'Ingevoerde betalingen':'Voorschot volgens ingangsdatums',signedMoney(m.advance))+'</div><div><h3>4. Effect op jouw saldo</h3>'+
        row('Stroom: verkoop − inkoop',signedMoney(m.stroom))+row('Vaste posten',signedMoney(m.vast))+row('Voorschot',signedMoney(m.advance))+row('Deze maand erbij / eraf',signedMoney(m.stroom===null||m.vast===null?null:Math.round((m.stroom+m.vast+m.advance)*100)/100),'total')+row('Opgeteld saldo',signedMoney(m.saldo),'total');
      if(projection)h+=row('Verwacht saldo na deze maand','~ '+signedMoney(projection.saldo));
      if(m.contractCorrection)h+='<p class="help">De geraamde EB-teruggaaf bevat '+signedMoney(m.contractCorrection)+' contractcorrectie voor eerdere maanden.</p>';
      if(projection&&projection.contractCorrection)h+='<p class="help">De maandprognose bevat '+signedMoney(projection.contractCorrection)+' verwachte EB-contractcorrectie voor eerdere maanden.</p>';
      h+='</div></div>'+provisionalDetail(m)+'<p class="help">'+(s.vat?'Alle bovenstaande bedragen zijn inclusief btw; btw over de bronbedragen en opslag wordt niet nogmaals opgeteld.':'Vergelijking zonder btw; dit is geen factuurbedrag.')+' De 2 cent opslag zit al in de bron. Maandtotalen zijn op centen afgerond.</p></div>';
      return h;
    }
    function projectedMonths(statement,forecast){
      var today=iso(new Date()),known={},projected={};
      statement.months.forEach(function(m){known[m.month]=m;});
      if(forecast)beOvForecastLines(statement,forecast,today).forEach(function(delta){
        var old=known[delta.month],target=forecast.months.find(function(m){return m.month===delta.month;}),p=Object.assign({},target);
        ['stroom','vast','advance'].forEach(function(k){p[k]=delta[k]===null?null:Math.round((delta[k]+(old&&old.days?old[k]:0))*100)/100;});
        p.saldo=delta.saldo;p.forecast=true;p.total=Object.assign({},target.total);
        p.contractCorrection=p.stroom===null||target.stroom===null?null:Math.round((p.stroom-target.stroom)*100)/100;
        if(p.total.ebCreditShown!==null&&p.contractCorrection!==null)p.total.ebCreditShown+=p.contractCorrection;
        projected[p.month]=p;
      });
      return projected;
    }
    function monthStatement(statement,forecast,r){
      var today=iso(new Date()),current=today.slice(0,7),projected=projectedMonths(statement,forecast),max=1;
      statement.months.concat(Object.values(projected)).forEach(function(m){if(m.stroom!==null)max=Math.max(max,Math.abs(m.stroom));});
      function entries(m){var t=m.total,b=t.ebGrossShown===null?null:-(t.buyShown+t.ebGrossShown),v=t.ebCreditShown===null?null:t.sellShown+t.ebCreditShown;return [m.stroom,m.advance,m.vast,m.saldo];}
      function cells(m,p,future){var vals=entries(m),pv=p?entries(p):null;return vals.map(function(v,i){
        return '<td class="'+signedClass(v)+'">'+(future?'~ ':'')+signedMoney(v)+(pv?'<small class="forecast-value" title="Verwacht aan het einde van deze maand">~ '+signedMoney(pv[i])+'</small>':'')+'</td>';
      }).join('');}
      var html='<p class="help">Klik op een maandregel voor de uitsplitsing. Donker = bekend, licht = nog verwacht, ~ = prognose.</p><div class="table-wrap"><table class="month-statement"><colgroup><col class="month-plot-col"><col span="4" class="amount-col"></colgroup><thead><tr><th>Maand / stroomresultaat</th><th>Stroom</th><th>Voorschot</th><th>Vaste posten</th><th>Saldo opgeteld</th></tr></thead><tbody>';
      statement.months.forEach(function(m){
        var p=projected[m.month],future=!m.days;if(future&&!p)return;
        var shown=future?p:m,name=new Intl.DateTimeFormat('nl-NL',{month:'short',year:'numeric',timeZone:'UTC'}).format(beOvDate(m.month+'-01'));
        var fill=shown.stroom===null?0:Math.abs(shown.stroom)/max*100;
        var meter='<span style="width:'+fill+'%;background:'+(shown.stroom>=0?'var(--green)':'var(--red)')+';opacity:'+(future?'.35':'1')+'"></span>';
        if(p&&!future&&m.stroom!==null&&p.stroom!==null&&m.stroom*p.stroom>=0){var rest=Math.max(0,Math.abs(p.stroom)/max*100-fill);if(rest)meter+='<span class="forecast-tail" style="width:'+rest+'%;background:'+(p.stroom>=0?'var(--green)':'var(--red)')+'"></span>';}
        var notes=future?'verwachting':m.month===current?'Berekend t/m '+date(m.lastKnown||m.to):'';
        if(m.days&&m.count<m.days)notes+=(notes?' · ':'')+m.count+'/'+m.days+' dagen beschikbaar';
        if(m.provisional)notes+=(notes?' · ':'')+'Voorlopig: '+m.provisionalRows.map(function(d){return date(d.key);}).join(', ');
        var nextMonth=beOvDate(m.month+'-01');nextMonth.setUTCMonth(nextMonth.getUTCMonth()+1);
        var monthFrom=m.month+'-01';if(monthFrom<r.a)monthFrom=r.a;
        var monthTo=beOvAdd(beOvISO(nextMonth),-1);if(monthTo>r.b)monthTo=r.b;
        function shortDay(k){return k.slice(8)+'-'+k.slice(5,7);}
        var periodLabel=shortDay(monthFrom)+' t/m '+shortDay(monthTo);
        var contract=beOvContract(monthFrom),edge=monthFrom===contract.begin?'Start '+monthFrom.split('-').reverse().join('-'):monthTo===contract.end?'Einde '+monthTo.split('-').reverse().join('-'):'';
        html+='<tr id="month-row-'+m.month+'" data-month="'+m.month+'" tabindex="0" aria-expanded="'+(expandedMonth===m.month)+'" aria-controls="detail-'+m.month+'" class="month-summary '+(future?'forecast-row':m.month===current?'current-month':'')+'"><td><div class="month-cell"><div class="month-name">'+('<button class="month-link" type="button" tabindex="-1" data-month="'+m.month+'" aria-expanded="'+(expandedMonth===m.month)+'" aria-controls="detail-'+m.month+'">'+(expandedMonth===m.month?'▾ ':'▸ ')+esc(name)+'</button>')+'<small class="month-dates">'+esc(periodLabel)+'</small>'+(edge?'<small class="contract-edge">'+esc(edge)+'</small>':'')+'</div><div class="month-meter" aria-hidden="true">'+meter+'</div></div>'+(notes?'<small class="month-progress">'+esc(notes)+'</small>':'')+'</td>'+cells(shown,future?null:p,future)+'</tr>';
        if(expandedMonth===m.month)html+='<tr id="detail-'+m.month+'" class="detail-row"><td colspan="5"><div id="reveal-'+m.month+'" class="detail-reveal">'+monthDetail(shown,future?null:p)+'</div></td></tr>';
      });
      function footer(label,data,approx){return '<tr class="'+(approx?'end-row':'known-row')+'"><td>'+label+'</td>'+['stroom','advance','vast','saldo'].map(function(k){return '<td class="'+signedClass(data[k])+'">'+(approx?'~ ':'')+signedMoney(data[k])+'</td>';}).join('')+'</tr>';}
      html+='</tbody><tfoot>'+footer('Stand t/m nu',statement,false);
      if(forecast)html+=footer('Prognose einde periode',forecast,true);
      return html+'</tfoot></table></div>';
    }
    function render(){
      if(!latest)return;
      if(latest.id!==verversKlantUitPad()){load();return;}
      var s=beOvSettings,all=beOvCalculate(latest.rows,s),r=latest.range,rows=selected(all,r),t=beOvTotal(rows);
      var today=iso(new Date()),yesterday=beOvAdd(today,-1),end=r.b<today?r.b:today,n=beOvDays(r.a,end);
      var historicEnd=r.b<yesterday?r.b:yesterday,historic=rows.filter(function(d){return d.key<=historicEnd;});
      var missing=Math.max(0,beOvDays(r.a,historicEnd)-historic.length),provisional=rows.filter(function(d){return d.voorlopig;});
      var partial=rows.some(function(d){return d.key<today&&d.deelresultaat;});
      var statement=beOvStatementData(all,r,s,end),f=beOvFixed(r.a,end,s),comparison=!s.tax||!s.vat;
      var ledgerRange=statementRange(r),ledgerEnd=ledgerRange.b<today?ledgerRange.b:today,ledgerStatement=beOvStatementData(all,ledgerRange,s,ledgerEnd);
      var forecast=beOvForecast(all,ledgerRange,s,today),prediction=null;
      var blocked=missing||latest.contextMissing||partial||latest.contextPartial||latest.errors.length;
      if(forecast.rows&&!blocked)prediction=beOvStatementData(forecast.rows,ledgerRange,s,ledgerRange.b);
      var cacheDays=provisional.filter(function(d){return d.eigenCache;}).map(function(d){return d.key;});
      var cacheText=cacheDays.length?' · '+(cacheDays.length>3?cacheDays.length+' dagen':cacheDays.map(function(key){return key.slice(8)+'/'+key.slice(5,7);}).join(', '))+' uit eigen cache (voorlopig)':'';
      var todayRow=rows.find(function(d){return d.key===today;}),timeText='';
      if(todayRow&&todayRow.eigenCache)timeText=' · vandaag gedeeltelijk, cache bijgewerkt '+new Intl.DateTimeFormat('nl-NL',{hour:'2-digit',minute:'2-digit',timeZone:'Europe/Amsterdam'}).format(new Date(todayRow.bijgewerkt));
      var unavailableText=beOvUnavailableNotice(latest.unavailableMonths,cacheDays);
      status((latest.errors.length?latest.errors.map(function(e){return e.message;}).join(' ')+' ':'')+(unavailableText?unavailableText+' · ':'')+rows.length+' van '+n+' verstreken dagen bekend'+cacheText+timeText+(missing?' · '+missing+' '+(missing===1?'dag ontbreekt':'dagen ontbreken'):'')+(partial?' · onvolledig dagdeel':''),!!(missing||latest.errors.length||partial));
      var summary='<div class="summary"><div><small>'+esc(s.paymentMode==='actual'?'Betaalde voorschotten':'Voorschotten t/m nu')+'</small><strong>'+signedMoney(ledgerStatement.advance)+'</strong></div><div><small>Stroom + vaste kosten</small><strong class="'+signedClass(ledgerStatement.full)+'">'+signedMoney(ledgerStatement.full)+'</strong></div><div><small>'+esc(comparison?'Vergelijkingssaldo':ledgerStatement.saldo===null?'Saldo nog onbekend':missing||partial||latest.errors.length?'Voorlopig deelsaldo':ledgerStatement.saldo>=0?'Te ontvangen t/m nu':'Te betalen t/m nu')+'</small><strong class="'+signedClass(ledgerStatement.saldo)+'">'+signedMoney(ledgerStatement.saldo)+'</strong></div></div>';
      var chartRows=chartData(rows,r);
      var amounts=chartAmounts(t),buy=amounts[0],sell=amounts[1];
      var buyRate=averagePrice(buy,t.imp),sellRate=averagePrice(sell,t.exp);
      var purchaseSummary='<div class="purchase-summary">'+
        '<span>Inkoop <strong>'+money(buy)+'</strong>'+(buyRate==='—'?'':' <small>· '+buyRate+'</small>')+'</span>'+
        '<span>Verkoop <strong>'+money(sell)+'</strong>'+(sellRate==='—'?'':' <small>· '+sellRate+'</small>')+'</span>'+
        '<span>Stroom <strong class="'+signedClass(t.result)+'">'+signedMoney(rows.length?t.result:null)+'</strong></span></div>';
      var html='<section class="panel"><div class="section-head"><h2>Inkoop en verkoop</h2><div class="unit-switch" role="group" aria-label="Grafiekeenheid"><button type="button" data-chart-unit="eur" aria-pressed="'+(chartUnit==='eur')+'">Euro</button><button type="button" data-chart-unit="kwh" aria-pressed="'+(chartUnit==='kwh')+'">kWh</button></div><span class="badge">'+esc((s.tax?'Met EB':'Zonder EB')+' · '+(s.vat?'met btw':'zonder btw'))+'</span></div>'+purchaseSummary+'<div class="chart">'+barChart(chartRows)+'</div><div class="legend"><span><i class="dot" style="background:var(--blue)"></i>'+(chartUnit==='eur'?'Inkoop':'Afname')+'</span><span><i class="dot" style="background:var(--green)"></i>'+(chartUnit==='eur'?'Verkoop':'Teruglevering')+'</span>'+(chartUnit==='eur'?'<span><i class="dot" style="background:var(--purple)"></i>Stroomresultaat</span>':'')+'</div><div class="chart-legend"><span class="chart-hint">Tik op een balk · klik voor vastzetten</span></div><p class="help">2 cent opslag incl. btw per kWh is inbegrepen bij inkoop én verkoop. '+(provisional.length?(chartRows.some(function(p){return p.key.length===10;})?'Arcering = eigen cache / voorlopig. ':'Inclusief voorlopige cachedagen. '):'')+'EB na saldering volgens de gekozen contractinstellingen.</p></section>';
      html+='<section class="panel"><h2>'+($('period').value==='month'?'Jouw contractmaandstaat':'Jouw maandstaat')+'</h2><p class="ledger-dates">'+date(ledgerRange.a)+' t/m '+date(ledgerRange.b)+'</p>'+summary+monthStatement(ledgerStatement,prediction,ledgerRange)+'<p class="help">Stroom = verkoop − inkoop (inclusief gekozen EB/btw). Vaste k. = belastingvermindering − levering − netbeheer. Saldo = opgeteld vanaf het begin van deze selectie. '+(s.paymentMode==='actual'?'Voorschotten zijn je ingevoerde betalingen.':'Voorschotten volgen je ingangsdatums, naar rato van dagen; geen bevestigde bankbetalingen.')+'</p>';
      if(prediction)html+='<p class="help">~ Seizoensraming met de maandfactoren uit 5.0 en '+forecast.base+' recente complete dagen.'+(forecast.history?' Beschikbare volledige maanden van vorig jaar wegen 60% mee.':' Geen volledige vergelijkbare maand van vorig jaar beschikbaar.')+' De eerste prognosemaand verwerkt ook de verwachte contractcorrectie voor saldering; het eindsaldo sluit daarop aan. Geen weers- of prijsvoorspelling.</p>';
      else if(forecast.reason!=='afgelopen')html+='<p class="help">'+(blocked?'Geen totaalprognose: ontbrekende of onvolledige historie. Een totaalprognose zou ontbrekende historie verbergen.':'Prognose beschikbaar vanaf 7 complete brondagen in de laatste 28 dagen.')+'</p>';
      if(comparison)html+='<p class="help">Zonder EB of btw is het saldo een vergelijking, geen factuurbedrag.</p>';
      var plafond={};all.forEach(function(d){if(d.salderingPlafondKwh>0.5&&d.key>=ledgerRange.a&&d.key<=ledgerRange.b)plafond[d.contract]=d;});
      Object.keys(plafond).forEach(function(c){var d=plafond[c],eur=d.salderingPlafondKwh*d.salderingPlafondRate*BTW;
        html+='<p class="notice warning">Saldeerplafond actief (contract vanaf '+date(c)+'): '+fmt(d.salderingPlafondKwh)+' kWh teruglevering telt niet mee voor EB-verrekening, ongeveer '+money(eur)+' incl. btw. Dit is niet-duurzame teruglevering boven de wettelijke 5.000 kWh (teruglevering hoger dan de geschatte pv-opwek). Verrekent je leverancier dit toch, zet dan onder Geavanceerd “alles salderen” aan.</p>';});
      if(todayRow&&(todayRow.deelresultaat||todayRow.voorlopig))html+='<p class="help">Vandaag is nog onvolledig. Vaste dagkosten en voorschot lopen t/m vandaag.'+(todayRow.prijsOnvolledig?' Niet alle gemeten stroom heeft al een prijs; alleen het geprijsde deel telt mee.':'')+'</p>';
      html+='</section>';
      $('content').innerHTML=html;
      if(chartUnit==='eur'&&chartRows.length&&chartRows[0].key.length===10)showChartTip(chartRows.length-1);
      var feeFactor=s.vat?1:1/BTW,feeImport=t.imp*.02*feeFactor,feeExport=t.exp*.02*feeFactor;
      var detail=row('Inkoop stroom zonder opslag',signedMoney(-(t.buyShown-feeImport)))+row('Opslag inkoop · '+fmt(t.imp)+' kWh × '+(s.vat?'€ 0,02000':'€ 0,0165289'),signedMoney(-feeImport))+row('EB over afname',signedMoney(t.ebGrossShown===null?null:-t.ebGrossShown))+row('Totaal inkoop inclusief gekozen EB',signedMoney(buy===null?null:-buy),'total')+
        row('Verkoop stroom vóór opslag',signedMoney(t.sellShown+feeExport))+row('Opslag verkoop · '+fmt(t.exp)+' kWh × '+(s.vat?'€ 0,02000':'€ 0,0165289'),signedMoney(-feeExport))+row('EB-verrekening saldering / tariefverdeling',signedMoney(t.ebCreditShown))+row('Netto verkoop inclusief gekozen EB',signedMoney(sell),'total')+
        row('Stroomresultaat',signedMoney(rows.length?t.result:null),'total')+row('Vaste levering',signedMoney(-f.supplier))+row('Netbeheer',signedMoney(-f.network))+row('Belastingvermindering',signedMoney(f.credit))+row('Maandafronding',signedMoney(statement.full===null||t.result===null||f.net===null?null:statement.full-t.result-f.net))+row('Voorschotten',signedMoney(statement.advance))+row($('period').value==='month'?'Deze maand erbij / eraf':'Saldo van deze selectie',signedMoney(statement.saldo),'total');
      detail+='<p class="help">De opslag is al verwerkt: € 0,02 incl. btw, of € 0,02 / 1,21 excl. btw. Saldering: '+(s.salderen?'aan':'uit')+(function(){var h=null;rows.forEach(function(r){if(r.herkomst)h=r.herkomst;});return h?' · duurzaam '+fmt(h.duurzaam)+' kWh volledig, overig '+fmt(h.overig)+' kWh waarvan '+fmt(h.overigMee)+' meegeteld (max 5.000)'+(h.pvOnbekendeDagen?' · '+h.pvOnbekendeDagen+' dagen zonder pv-gegeven geschat':''):'';})()+' · EB-tariefverdeling '+(s.taxAllocation==='afname'?'afnamegewogen':s.taxAllocation==='werkelijk'?'werkelijk verbruik per tariefperiode':'tijdsevenredig')+'. Deze verrekening is een raming; de leveranciersnota is bepalend.</p>';
      $('calculation').innerHTML=detail;
    }
    function settingsUI() {
      var years=new Set([2025,2026,new Date().getFullYear(),new Date().getFullYear()+1]);
      var html='<form id="settings-form"><div class="grid settings-grid"><label>Aansluit-/contractstart<input id="cfg-start" type="date" value="'+iso(cfg.start)+'" required></label><label>Basisvoorschot per maand (€)<input id="cfg-advance" type="number" min="0" step="any" value="'+cfg.voorschot+'" required></label><label>Saldering volgens jouw contract<select id="cfg-salderen"><option value="aan">Tot 2027 salderen (contractvoorwaarden)</option><option value="uit">Niet verrekenen</option></select></label><label>Teruglevering die mag meetellen (%)<input id="cfg-eligible" type="number" min="0" max="100" step="1" value="'+beOvSettings.eligible+'" required></label><label>Vaste levering per dag, incl. btw (€)<input id="cfg-supplier" type="number" min="0" step="any" value="'+beOvSettings.supplier+'" required></label><label>Netbeheer per dag, incl. btw (€)<input id="cfg-network" type="number" min="0" step="any" value="'+beOvSettings.network+'" required></label></div>'+
        '<p class="help">De contractstart en voorschotten komen uit je bestaande instellingen. De dagbedragen zijn overgenomen uit de huidige plugin; controleer ze met je contract. Salderingsinstellingen en jaartarieven hieronder gelden alleen voor dit nieuwe overzicht. De bron splitst batterij- en zonneteruglevering niet uit.</p>'+
        '<label style="display:flex;gap:8px;align-items:center;margin:12px 0"><input id="cfg-eligible-confirmed" type="checkbox">Geavanceerd: alles salderen, ook niet-duurzame teruglevering boven 5.000 kWh</label><p class="help">Standaard volgt Financieel de wet: duurzame teruglevering (tot de geschatte pv-opwek per dag) telt volledig mee, overige teruglevering tot 5.000 kWh per contractjaar, en nooit meer dan de afname. Zet dit alleen aan als je nota laat zien dat je leverancier ook het meerdere verrekent.</p>'+
        '<div id="advance-history"></div><div class="grid settings-grid"><label>Voorschotten in het saldo<select id="cfg-payment-mode"><option value="schema">Maandbedragen naar rato van dagen</option><option value="actual">Mijn ingevoerde werkelijke betalingen</option></select></label><label>EB-verdeling bij jaarwisseling<select id="cfg-tax-allocation"><option value="tijd">Tijdsevenredig (gebruikelijk bij stroom)</option><option value="werkelijk">Werkelijk verbruik per tariefperiode (zoals Balans)</option><option value="afname">Afnamegewogen raming</option></select></label></div>'+
        '<details><summary>Werkelijke voorschotbetalingen invoeren</summary><p class="help">Vul ontvangen betaalbewijzen over. Deze lokale lijst verandert geen incasso of bedrag bij de leverancier. Kies hierboven werkelijke betalingen om ze in het saldo te gebruiken.</p><div id="actual-payments"></div><button type="button" id="add-payment">+ Betaling toevoegen</button></details>'+
        '<h3 style="margin-top:18px">Jaartarieven voor het rekenmodel</h3><div class="table-wrap"><table><thead><tr><th>Jaar</th><th>EB excl. btw, €/kWh</th><th>Vaste belastingvermindering excl. btw, €/jaar</th><th>Netbeheer incl. btw, €/dag</th></tr></thead><tbody>';
      Array.from(years).sort().forEach(function(y){html+='<tr><td>'+y+'</td><td><input aria-label="EB '+y+'" data-rate="'+y+'" type="number" min="0" max="10" step="any" placeholder="Nog invullen" value="'+(beOvFinite(beOvSettings.rates[y])?beOvSettings.rates[y]:'')+'"></td><td><input aria-label="Belastingvermindering '+y+'" data-credit="'+y+'" type="number" min="0" step="any" placeholder="Nog invullen" value="'+(beOvFinite(beOvSettings.credit[y])?beOvSettings.credit[y]:'')+'"></td><td><input aria-label="Netbeheer '+y+'" data-network="'+y+'" type="number" min="0" step="any" placeholder="Standaard" value="'+(beOvFinite((beOvSettings.networkRates||{})[y])?beOvSettings.networkRates[y]:'')+'"></td></tr>';});
      html+='</tbody></table></div><p class="help">2025: EB 0,10154 en vermindering 524,95; 2026: EB 0,09161 en vermindering 519,80; 2027 (Belastingplan, voorlopig): EB 0,08802 en vermindering 519,58 (excl. btw). De jaartarieven en de grens op 1 januari 2027 worden gescheiden. Hogere verbruiksschijven geven “Nog onbekend” in plaats van een onjuist bedrag. Kies de tariefverdeling die op je contract/nota staat; standaard is de raming tijdsevenredig. Netbeheer per jaar staat op je jaarafrekening (Enexis t/m 3×25 A zoals Balans factureert: 1,30390 in 2025 en 1,30365 in 2026, standaard ingevuld); leeg = het algemene netbeheerbedrag hierboven. Andere netbeheerder of grotere aansluiting: neem het bedrag van je eigen nota over. Deze jaartarieven gelden sinds 6.7 ook voor de andere kaarten.</p><div class="actions" style="margin-top:16px"><button class="primary" type="submit">Instellingen opslaan</button><span id="save-status" role="status"></span></div></form>';
      $('settings-body').innerHTML=html; $('cfg-salderen').value=beOvSettings.salderen?'aan':'uit';
      $('cfg-eligible-confirmed').checked=!!beOvSettings.eligibleConfirmed;
      beVoorschotInstellingen($('advance-history'));
      $('cfg-payment-mode').value=beOvSettings.paymentMode||'schema';$('cfg-tax-allocation').value=beOvSettings.taxAllocation||'tijd';
      function paymentRow(p){
        var div=document.createElement('div');div.className='payment-row';div.style.cssText='display:flex;gap:8px;margin:8px 0;align-items:center';
        var day=document.createElement('input'),amount=document.createElement('input'),remove=document.createElement('button');
        day.type='date';day.value=p.datum;day.max=iso(new Date());day.setAttribute('aria-label','Betaaldatum voorschot');
        amount.type='number';amount.min='0';amount.step='.01';amount.value=p.bedrag;amount.setAttribute('aria-label','Betaald voorschot in euro');
        remove.type='button';remove.textContent='×';remove.setAttribute('aria-label','Betaling verwijderen');remove.onclick=function(){div.remove();};
        day.style.minWidth=amount.style.minWidth='0';day.style.width=amount.style.width='42%';div.append(day,amount,remove);$('actual-payments').appendChild(div);
      }
      (((beOvSettings.payments||{})[KLANT])||[]).forEach(paymentRow);
      $('add-payment').onclick=function(){paymentRow({datum:iso(new Date()),bedrag:cfg.voorschot});};
      $('settings-form').onsubmit=function(e){e.preventDefault();
        try {
          var start=$('cfg-start').value,advance=+$('cfg-advance').value,eligible=+$('cfg-eligible').value,supplier=+$('cfg-supplier').value,network=+$('cfg-network').value;
          if(!/^\d{4}-\d{2}-\d{2}$/.test(start)||beOvISO(beOvDate(start))!==start||start>iso(new Date()))throw Error('Vul een geldige contractstart op of vóór vandaag in.');
          if(![advance,eligible,supplier,network].every(beOvFinite)||advance<0||eligible<0||eligible>100||supplier<0||network<0)throw Error('Controleer de ingevulde bedragen en het percentage.');
          var history=beVoorschotValideer(Array.from($('advance-history').querySelectorAll('.be-vs-rijen>div')).map(function(d){var inputs=d.querySelectorAll('input');return {datum:inputs[0].value,bedrag:inputs[1].value};}));
          var payments=Object.assign({},beOvSettings.payments||{});
          payments[KLANT]=Array.from($('actual-payments').querySelectorAll('.payment-row')).map(function(div){var inputs=div.querySelectorAll('input'),day=inputs[0].value,value=inputs[1].value,amount=Number(value);
            if(!/^\d{4}-\d{2}-\d{2}$/.test(day)||beOvISO(beOvDate(day))!==day||day>iso(new Date())||value===''||!beOvFinite(amount)||amount<0)throw Error('Controleer de betaaldatums en bedragen van de werkelijke betalingen.');return {datum:day,bedrag:amount};});
          var rates=Object.assign({},beOvSettings.rates),credits=Object.assign({},beOvSettings.credit),networks=Object.assign({},beOvSettings.networkRates||{});
          shadow.querySelectorAll('[data-rate],[data-credit],[data-network]').forEach(function(input){var map=input.hasAttribute('data-rate')?rates:input.hasAttribute('data-credit')?credits:networks,year=input.dataset.rate||input.dataset.credit||input.dataset.network;
            if(input.value===''){map[year]=null;return;}var value=+input.value;if(!beOvFinite(value)||value<0)throw Error('Een jaartarief moet nul of positief zijn.');map[year]=value;});
          cfg.start=new Date(start+'T00:00:00');cfg.voorschot=advance;cfg.voorschotHistorie=history;
          localStorage.setItem(LS.startdatum,start);localStorage.setItem(LS.voorschot,String(advance));localStorage.setItem('be_cfg_voorschot_historie',JSON.stringify(history));
          Object.assign(beOvSettings,{schema:2,eligible:eligible,eligibleConfirmed:$('cfg-eligible-confirmed').checked,supplier:supplier,network:network,salderen:$('cfg-salderen').value==='aan',rates:rates,credit:credits,networkRates:networks,payments:payments,paymentMode:$('cfg-payment-mode').value,taxAllocation:$('cfg-tax-allocation').value});save();
          $('save-status').textContent='Opgeslagen.';
          var selectedYear=$('year').value;$('year').innerHTML='';for(var y=cfg.start.getFullYear();y<=new Date().getFullYear()+1;y++)$('year').add(new Option(String(y),String(y)));$('year').value=selectedYear;
          if(!$('year').value)$('year').value=String(new Date().getFullYear());
          $('contract').innerHTML=contractOptions();$('contract').value=String(beOvContract(iso(new Date())).index);updateFilters();cache.clear();load();
        } catch(err){$('save-status').textContent=err.message;}
      };
    }
    function exportCSV() {
      if(!latest)return;
      var rows=selected(beOvCalculate(latest.rows,beOvSettings),latest.range),basis=(beOvSettings.tax?'met EB':'zonder EB')+'; '+(beOvSettings.vat?'met btw':'zonder btw');
      var out=[];
      rows.forEach(function(r){out.push({'Datum':r.key,'Afname kWh':r.imp,'Teruglevering kWh':r.exp,'Inkoop EUR':r.buyShown,'Verkoop EUR':r.sellShown,'EB model EUR':r.ebShown,'Variabel resultaat EUR':r.result,'Salderingscontract vanaf':r.contract,'Voorlopig':r.voorlopig?'ja':'nee','Eigen cache':r.eigenCache?'ja':'nee','Onvolledig dagdeel':r.deelresultaat?'ja':'nee','Prijzen onvolledig':r.prijsOnvolledig?'ja':'nee','Cache bijgewerkt':r.bijgewerkt?new Date(r.bijgewerkt).toISOString():'','Weergave':basis});});
      beCsvSlaOp('Balans-Energieoverzicht-'+latest.range.a+'-tot-'+latest.range.b+'.csv',out);
    }
    function restoreMobileNavigation(){
      mobileChrome.forEach(function(pair){var node=pair[0];pair[1].forEach(function(p){if(p[1])node.style.setProperty(p[0],p[1],p[2]);else node.style.removeProperty(p[0]);});});
      mobileChrome=[];mobileHeader=null;mobileSidebar=null;
    }
    function showBackground(show){
      inertNodes.forEach(function(pair){
        var style=pair[0].style;
        if(!show){
          if(!pair[2])pair[2]=[style.getPropertyValue('display'),style.getPropertyPriority('display')];
          style.setProperty('display','none','important');
        }else if(pair[2]){
          if(pair[2][0])style.setProperty('display',pair[2][0],pair[2][1]);else style.removeProperty('display');
          pair.pop();
        }
      });
    }
    function preserveMobileNavigation(){
      var toggle=innerWidth<768&&document.querySelector('[data-bs-target="#mobileSidebar"]');
      var header=toggle&&toggle.closest('header,nav,.navbar'),menu=toggle&&document.querySelector('#mobileSidebar');
      if(!header){restoreMobileNavigation();return false;}
      if(header!==mobileHeader||menu!==mobileSidebar){
        restoreMobileNavigation();mobileHeader=header;mobileSidebar=menu;
        [[header,['position','top','left','right','z-index']],[menu,['position','top','left','z-index','min-height','max-height','overflow-y']]].forEach(function(pair){
          if(pair[0])mobileChrome.push([pair[0],pair[1].map(function(key){return [key,pair[0].style.getPropertyValue(key),pair[0].style.getPropertyPriority(key)];})]);
        });
      }
      function set(node,key,value){if(node.style.getPropertyValue(key)!==value||node.style.getPropertyPriority(key)!=='important')node.style.setProperty(key,value,'important');}
      set(header,'position','static');set(header,'top','auto');set(header,'left','auto');set(header,'right','auto');set(header,'z-index','1042');
      if(menu){set(menu,'position','static');set(menu,'top','auto');set(menu,'left','auto');set(menu,'z-index','1043');set(menu,'min-height','0px');set(menu,'max-height','none');set(menu,'overflow-y','visible');}
      return true;
    }
    function makeBackgroundInert(node){
      var toggle=document.querySelector('[data-bs-target="#mobileSidebar"]');
      var protectedNodes=[root,mobileHeader,mobileSidebar,fallback,document.querySelector('#mobileSidebar'),toggle&&toggle.closest('header,nav,.navbar')].concat(navLinks.map(function(a){return a.closest('nav,aside,.sidebar,.sidenav,#sidebar,#mobileSidebar,.nav')||a;})).filter(Boolean);
      if(protectedNodes.includes(node)||inertNodes.some(function(pair){return pair[0]===node;}))return;
      if(protectedNodes.some(function(p){return node.contains(p);}))Array.from(node.children).forEach(makeBackgroundInert);
      else{inertNodes.push([node,node.inert]);node.inert=true;}
    }
    function layout() {
      if(!root||!opened)return;
      var anchor=navLinks.find(function(a){var r=a.getBoundingClientRect();return r.width>0&&r.height>0&&r.right>0&&r.left<innerWidth;})||(navAnchor&&navAnchor.isConnected?navAnchor:null), container=anchor&&anchor.closest('nav,aside,.sidebar,.sidenav,#sidebar,.offcanvas,.nav');
      var left=0;
      while(innerWidth>=768&&container&&container!==document.body){var rect=container.getBoundingClientRect();if(rect.width>80&&rect.width<440&&rect.height>180&&rect.left<120&&rect.right<innerWidth*.6){left=Math.max(left,rect.right);}container=container.parentElement;}
      root.style.left=Math.round(left)+'px';
      var nativeMenu=preserveMobileNavigation();
      // Mobile uses the document's scroll so the real menu and our title leave together.
      var mobile=innerWidth<768,height=mobileHeader?Math.ceil(mobileHeader.getBoundingClientRect().height):0;
      root.style.position=mobile?'relative':'fixed';root.style.top=mobile?'auto':'0px';root.style.bottom=mobile?'auto':'0px';
      root.style.overflow=mobile?'visible':'auto';root.style.minHeight=mobile?'calc(100dvh - '+height+'px)':'0px';
      root.style.overscrollBehavior=mobile?'auto':'contain';
      showBackground(!mobile);
      $('mobile-menu').hidden=nativeMenu||innerWidth>=768||!document.querySelector('[data-bs-target="#mobileSidebar"]');
      if(fallback)fallback.style.display=opened?'none':'';
    }
    function open(push,source) {
      if(source)navAnchor=source;
      if(!root)mount();
      var mobileToggle=document.querySelector('[data-bs-target="#mobileSidebar"][aria-expanded="true"]');
      if(innerWidth<768&&mobileToggle)mobileToggle.click();
      if(opened){layout();return;}
      previousFocus=document.activeElement;pageScrollBefore=[window.scrollX,window.scrollY];oldHash=location.hash===HASH?'':location.hash;
      if(push&&location.hash!==HASH)history.pushState({beEnergyOverview:true},'',location.pathname+location.search+HASH);
      root.hidden=false;opened=true;theme();layout();
      document.querySelectorAll('main,[role="main"],.main-content,.content-wrapper').forEach(makeBackgroundInert);
      var nativeCard=document.querySelector('.results-summary-card,.energy-chart-legend');
      if(nativeCard&&!nativeCard.contains(root)&&!nativeCard.contains(navAnchor)){
        var nativeContent=nativeCard;
        while(nativeContent.parentElement&&nativeContent.parentElement!==document.body&&!nativeContent.parentElement.contains(root)&&!nativeContent.parentElement.contains(navAnchor))nativeContent=nativeContent.parentElement;
        makeBackgroundInert(nativeContent);
      }
      if(navAnchor){
        menuActiveBefore=Array.from(document.querySelectorAll('a.active')).filter(function(a){return !navLinks.includes(a)&&a.closest('nav,aside,.sidebar,.sidenav,#sidebar,.nav');}).map(function(a){var old=a.className;a.className=old.replace(/\bactive\b/g,'').trim();return [a,old];});
        navLinks.forEach(function(a){a.className=a.className.replace(/\bactive\b/g,'').trim()+' active';a.setAttribute('aria-current','page');});
      }
      showBackground(innerWidth>=768);
      if(innerWidth<768){$('title').focus({preventScroll:true});window.scrollTo(0,0);}else $('title').focus();
      load();
    }
    function close() {
      if(!opened)return;
      serial++;opened=false;root.hidden=true;
      restoreMobileNavigation();
      showBackground(true);
      inertNodes.forEach(function(pair){pair[0].inert=pair[1];});inertNodes=[];
      if(location.hash===HASH)history.replaceState(history.state,'',location.pathname+location.search+oldHash);
      navLinks.forEach(function(a){a.removeAttribute('aria-current');a.className=a.className.replace(/\bactive\b/g,'').trim();});
      menuActiveBefore.forEach(function(pair){if(pair[0].isConnected)pair[0].className=pair[1];});menuActiveBefore=[];
      if(fallback)fallback.style.display='';
      var mobileToggle=innerWidth<768&&document.querySelector('[data-bs-target="#mobileSidebar"]');
      if(mobileToggle)mobileToggle.focus({preventScroll:true});else if(previousFocus&&previousFocus.isConnected)previousFocus.focus({preventScroll:true});
      if(pageScrollBefore){window.scrollTo(pageScrollBefore[0],pageScrollBefore[1]);pageScrollBefore=null;}
    }
    function addMenu() {
      var candidates=Array.from(document.querySelectorAll('a[href*="/results"]')).filter(function(a){return !a.closest('#be-energieoverzicht');});
      if(!geldigeKlant(KLANT))verversKlantUitPad();
      navLinks=navLinks.filter(function(a){return a.isConnected;});
      candidates.forEach(function(anchor){
        var list=anchor.closest('ul,ol,nav,aside,.sidebar,.sidenav,#sidebar,#mobileSidebar,.nav')||anchor.parentElement;
        if(navLinks.some(function(a){return list.contains(a);}))return;
        var link=document.createElement('a');link.id='be-energieoverzicht-link'+(menuSerial?'-'+menuSerial:'');menuSerial++;
        link.href=HASH;link.setAttribute('data-be-financial-link','');
        link.className=anchor.className.replace(/\bactive\b/g,'').trim();
        var icon=anchor.querySelector&&anchor.querySelector('svg');
        link.innerHTML='<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex:none"><path d="M17 6.5a6 6 0 1 0 0 11M4 10h9M4 14h8"/></svg><span>Financieel</span>';
        if(icon){var ownIcon=link.querySelector('svg');ownIcon.setAttribute('class',icon.getAttribute('class')||'');ownIcon.setAttribute('width',icon.getAttribute('width')||'24');ownIcon.setAttribute('height',icon.getAttribute('height')||'24');}
        link.title='Inkoop, verkoop, saldering en prognose in begrijpelijke taal';link.style.cssText='display:flex;align-items:center;gap:12px;white-space:normal';
        link.addEventListener('click',function(e){e.preventDefault();open(true,link);});
        if(anchor.parentElement.tagName==='LI'){var li=document.createElement('li');li.className=anchor.parentElement.className.replace(/\bactive\b/g,'').trim();li.appendChild(link);anchor.parentElement.insertAdjacentElement('afterend',li);}
        else anchor.insertAdjacentElement('afterend',link);
        navLinks.push(link);if(!navAnchor||!navAnchor.isConnected)navAnchor=link;
        if(opened){link.setAttribute('aria-current','page');link.className+=' active';}
      });
      if(navLinks.length&&fallback){fallback.remove();fallback=null;}layout();
    }
    function maintain() {
      addMenu();
      if(location.hash===HASH&&!opened)open(false);
      else if(location.hash!==HASH&&opened)close();
      if(opened){
        layout();
        if(latest&&(latest.id!==verversKlantUitPad()||latest.day!==iso(new Date())))load();
        else if(latest&&!document.hidden&&Date.now()-ownRefreshAt>=60000)refreshOwnCache();
      }
    }
    // Een link blijft beschikbaar wanneer de site een ander menu gebruikt.
    setTimeout(function(){
      addMenu();if(!navAnchor&&!fallback){fallback=document.createElement('a');fallback.href=HASH;fallback.textContent='€ Financieel';fallback.style.cssText='position:fixed;z-index:1041;left:12px;bottom:20px;padding:12px 16px;border-radius:10px;background:#65419d;color:#fff;font:600 14px system-ui;text-decoration:none;box-shadow:0 3px 12px #0003';fallback.onclick=function(e){e.preventDefault();open(true);};document.body.appendChild(fallback);}
    },1500);
    document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(opened&&a&&!navLinks.includes(a)&&a!==fallback&&!root.contains(a)&&a.getAttribute('href')!==HASH)close();},true);
    document.addEventListener('wheel',function(e){
      if(!opened||!root||e.ctrlKey||!e.deltaY||e.clientX>=root.getBoundingClientRect().left)return;
      var factor=e.deltaMode===1?18:e.deltaMode===2?(root.clientHeight||innerHeight):1;
      root.scrollTop+=e.deltaY*factor;e.preventDefault();
    },{passive:false});
    window.addEventListener('hashchange',maintain);window.addEventListener('popstate',maintain);
    window.addEventListener('resize',function(){clearTimeout(layoutTimer);layoutTimer=setTimeout(layout,50);});
    document.addEventListener('be-dark-change',theme);
    setInterval(maintain,1500);maintain();
  }


  var contractLaatsteDag = iso(new Date());
  function pols() {
    if (
      location.pathname.indexOf(
        '/results'
      ) === -1
    ) {
      return;
    }

    var contractVandaag = iso(new Date());
    if (contractVandaag !== contractLaatsteDag) {
      contractLaatsteDag = contractVandaag;
      contractCache = null;
      cacheJaar = {};
      cacheMaandDagen = {};
      plan();
    }

    injecteerKop();

    regelBalansBlok();

    resultatenHaalVoorlopigeDagen()
      .then(
        function (ok) {
          if (ok) {
            plan();
          }
        }
      );
  }

  function start() {
    startActueelAllin();
    beArchiefOnderhoud();
    setInterval(beArchiefOnderhoud, 300000);
    beOverzichtStart();
  }

  if (document.body) {
    start();

  } else {
    document.addEventListener(
      'DOMContentLoaded',
      start
    );
  }




})();


/* Stabiele live cijfers op Actueel, altijd actief. */
(function () {
  'use strict';

  if (window.top !== window.self) return;

  var RUSTAAGH_RUNTIME_GUARD = 'data-be-rustaagh-runtime';
  if (document.documentElement.getAttribute(RUSTAAGH_RUNTIME_GUARD) === '5.0') return;
  document.documentElement.setAttribute(RUSTAAGH_RUNTIME_GUARD, '5.0');

  var STYLE_ID = 'be-stabiele-cijfers-stijl';
  var MARKER = 'be-stabiel-getal';
  var scanGepland = false;
  var panelen = [null, null];
  var wachtPanelen = [null, null];
  var ontdekPanelen = true;

  function voegStijlToe() {
    if (document.getElementById(STYLE_ID)) return;

    var stijl = document.createElement('style');
    stijl.id = STYLE_ID;
    stijl.textContent =
      '.' + MARKER + '{' +
        'display:inline-block!important;' +
        'box-sizing:content-box!important;' +
        'max-width:100%!important;' +
        'white-space:nowrap!important;' +
        'font-variant-numeric:tabular-nums lining-nums!important;' +
        'font-feature-settings:"tnum" 1,"lnum" 1!important;' +
      '}' +
      '.' + MARKER + ',.' + MARKER + ' *{' +
        'font-variant-numeric:tabular-nums lining-nums!important;' +
        'font-feature-settings:"tnum" 1,"lnum" 1!important;' +
      '}' +
      '.' + MARKER + '[data-be-eenheid="w"]{width:8ch!important;}' +
      '.' + MARKER + '[data-be-eenheid="kw"]{width:7ch!important;}' +
      '.' + MARKER + '[data-be-eenheid="pct"]{width:5ch!important;}' +
      '.' + MARKER + '[data-be-eenheid="kwh"]{width:9ch!important;}' +
      '.' + MARKER + '[data-be-eenheid="eur"]{width:9ch!important;}' +
      '.' + MARKER + '[data-be-uitlijning="midden"]{text-align:center!important;}' +
      '.' + MARKER + '[data-be-uitlijning="rechts"]{text-align:right!important;}' +
      '.' + MARKER + '[data-be-uitlijning="links"]{text-align:left!important;}';

    (document.head || document.documentElement).appendChild(stijl);
  }

  function tekst(el) {
    return String(el && el.textContent || '')
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function eenheidVan(waarde) {
    if (/^[+\-−]?\s*€\s*\d[\d\s.,]*$/i.test(waarde)) return 'eur';
    if (/^[+\-−]?\s*\d[\d\s.,]*\s*kWh$/i.test(waarde)) return 'kwh';
    if (/^[+\-−]?\s*\d[\d\s.,]*\s*kW$/i.test(waarde)) return 'kw';
    if (/^[+\-−]?\s*\d[\d\s.,]*\s*W$/i.test(waarde)) return 'w';
    if (/^[+\-−]?\s*\d[\d\s.,]*\s*%$/i.test(waarde)) return 'pct';
    return null;
  }

  function vindTitelElement(titel) {
    var alles = document.querySelectorAll('h1,h2,h3,h4,h5,h6,div,span');

    for (var i = 0; i < alles.length; i++) {
      if (tekst(alles[i]) === titel) return alles[i];
    }

    return null;
  }

  function aantalMeetwaarden(wortel) {
    if (!wortel) return 0;

    var aantal = 0;
    var alles = wortel.querySelectorAll('*');

    for (var i = 0; i < alles.length; i++) {
      var waarde = tekst(alles[i]);
      if (!eenheidVan(waarde)) continue;

      /* Tel één DOM-laag per getal, ook wanneer React dezelfde tekst nestelt. */
      var dubbelKind = false;
      for (var j = 0; j < alles[i].children.length; j++) {
        if (tekst(alles[i].children[j]) === waarde) {
          dubbelKind = true;
          break;
        }
      }
      if (!dubbelKind) aantal++;
    }

    return aantal;
  }

  function vindPaneel(titel) {
    var titelElement = vindTitelElement(titel);
    var index = titel === 'Live Status' ? 0 : 1;
    wachtPanelen[index] = titelElement && (titelElement.closest('section,.card') ||
      (titelElement.parentElement && titelElement.parentElement.parentElement));
    if (!titelElement) return null;

    var minimaal = titel === 'Laatste meting' ? 4 : 3;
    var paneel = titelElement;

    while (paneel.parentElement && paneel !== document.body) {
      paneel = paneel.parentElement;

      /*
       * Zoek de eerste voorouder die titel én meetwaarden bevat. Dit gebruikt
       * de DOM-inhoud in plaats van browserafhankelijke pixelafmetingen.
       */
      if (aantalMeetwaarden(paneel) >= minimaal) return paneel;
    }

    return null;
  }

  function actueelPaneelNummer(el, panelen) {
    var rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height || rect.top < 0) return -1;

    for (var i = 0; i < panelen.length; i++) {
      if (panelen[i] && panelen[i].contains(el)) return i;
    }

    return -1;
  }

  function buitensteZelfdeWaarde(el, waarde) {
    var huidig = el;

    while (huidig.parentElement) {
      var ouder = huidig.parentElement;
      var r = ouder.getBoundingClientRect();

      if (tekst(ouder) !== waarde || r.width > 220 || r.height > 90) break;
      huidig = ouder;
    }

    return huidig;
  }

  function markeerActueleCijfers() {
    scanGepland = false;
    if (document.hidden) return;
    voegStijlToe();

    if (ontdekPanelen || panelen.some(function(p){return p && !p.isConnected;})) {
      panelen = [vindPaneel('Live Status'), vindPaneel('Laatste meting')];
      ontdekPanelen = false;
    }
    // Only live-value panels need numerical alignment; chart/status mutations
    // elsewhere must not trigger layout reads across the whole dashboard.
    var elementen = [], gezien = new Set();
    panelen.forEach(function(paneel){
      if (!paneel || !paneel.isConnected) return;
      paneel.querySelectorAll('*').forEach(function(el){
        if (!gezien.has(el)) { gezien.add(el); elementen.push(el); }
      });
    });

    for (var i = 0; i < elementen.length; i++) {
      var el = elementen[i];
      var waarde = tekst(el);
      var eenheid = eenheidVan(waarde);
      if (!eenheid) continue;
      var paneelNummer = actueelPaneelNummer(el, panelen);

      if (paneelNummer < 0) continue;

      /*
       * Het SOC-bolletje ligt ín de batterijtekening. Een geforceerde
       * breedte op dat element vervormt daarom het volledige pictogram.
       * De losse SOC-regel rechts krijgt wel gewoon een vaste breedte.
       */
      if (paneelNummer === 0 && eenheid === 'pct') continue;

      var doel = buitensteZelfdeWaarde(el, waarde);
      doel.classList.add(MARKER);
      doel.setAttribute('data-be-eenheid', eenheid);
      doel.setAttribute(
        'data-be-uitlijning',
        paneelNummer === 0 ? 'midden' : 'rechts'
      );
    }
  }

  function planScan() {
    if (scanGepland || document.hidden) return;
    scanGepland = true;
    requestAnimationFrame(markeerActueleCijfers);
  }

  function herontdek() {
    ontdekPanelen = true;
    planScan();
  }

  function mogelijkNieuwPaneel(node) {
    var el = node.nodeType === 1 ? node : node.parentElement;
    if (!el || el.closest('script,style,canvas,noscript')) return false;
    var inhoud = tekst(node);
    return inhoud.indexOf('Live Status') !== -1 || inhoud.indexOf('Laatste meting') !== -1 ||
      (panelen.some(function(p,i){return !p && wachtPanelen[i] && wachtPanelen[i].contains(el);}) && !!eenheidVan(inhoud));
  }

  function volgMeetwaarden(records) {
    var geraakt = false;
    if (panelen.some(function(p){return p && !p.isConnected;})) ontdekPanelen = true;
    records.forEach(function(r){
      var el = r.target.nodeType === 1 ? r.target : r.target.parentElement;
      var binnenPaneel = panelen.some(function(p){return p && el && p.contains(el);});
      if (binnenPaneel) geraakt = true;
      if (r.type === 'characterData') {
        if (!binnenPaneel && mogelijkNieuwPaneel(r.target)) ontdekPanelen = true;
      } else {
        r.addedNodes.forEach(function(node){
          if (mogelijkNieuwPaneel(node)) ontdekPanelen = true;
        });
      }
    });
    if (geraakt || ontdekPanelen) planScan();
  }

  voegStijlToe();
  planScan();

  new MutationObserver(volgMeetwaarden).observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });

  window.addEventListener('resize', planScan, { passive: true });
  window.addEventListener('popstate', herontdek, { passive: true });
  window.addEventListener('hashchange', herontdek, { passive: true });
  document.addEventListener('visibilitychange', function(){if(!document.hidden)herontdek();});
}());


// Break-evenmarkeringen van het cumulatieve dagresultaat.
(function () {
    const GUARD = '__beDagBreakeven01';
    if (window[GUARD]) return;
    window[GUARD] = true;
    const ZONE = 'Europe/Amsterdam';
    const clock = new Intl.DateTimeFormat('en-GB', {
      timeZone: ZONE, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
    });
    function parts(t) {
      const p = Object.fromEntries(clock.formatToParts(new Date(t)).map(x => [x.type, x.value]));
      return {day: p.year + '-' + p.month + '-' + p.day, midnight: p.hour === '00' && p.minute === '00'};
    }
    // Use the main plugin's quarter results: same tariffs, all-in switch and energy integration.
    // No new network calls, no EPEX substitution for the actual settlement price.
    function crossings(rows, now) {
      const today = parts(now).day;
      const day = rows.filter(r => Number.isFinite(r.start) && parts(r.start).day === today && r.start < now)
        .slice().sort((a, b) => a.start - b.start);
      if (!day.length || !parts(day[0].start).midnight || day[0].start % 900000 !== 0) return [];
      let sum = 0, previousEnd = day[0].start, lastSign = 0, zeroTime = null, estimated = false;
      const out = [], EPS = 1e-9;
      for (const r of day) {
        // Require continuous metering. A missing tariff is already omitted from
        // the displayed daily subtotal; follow that subtotal with an explicit caveat.
        if (r.start !== previousEnd || r.end - r.start !== 900000 || r.carried) break;
        const info = r.breakEven;
        const end = info ? info.tot : r.end;
        if (!Number.isFinite(end) || end <= r.start || end > Math.min(r.end, now)) break;
        const amount = info ? info.bedrag : r.res;
        if (!Number.isFinite(amount)) break;
        if (info) {
          if (!Number.isFinite(info.gemetenMs) || info.gemetenMs < (end - r.start) * 0.97) break;
          estimated = estimated || info.prijsOnvolledig || end < r.end;
        } else if (r.deel || r.wacht || r.end > now) break;
        const before = sum;
        sum += amount;
        const sign = sum > EPS ? 1 : sum < -EPS ? -1 : 0;
        if (!sign) {
          if (lastSign && zeroTime === null) zeroTime = end;
        } else {
          if (lastSign && sign !== lastSign) {
            // Approximate within a completed quarter; quarter totals cannot locate sub-quarter reversals.
            const t = zeroTime !== null ? zeroTime : r.start + (end - r.start) * (-before / amount);
            out.push({t, from: lastSign, to: sign, estimated: !!estimated});
          }
          lastSign = sign;
          zeroTime = null;
        }
        previousEnd = r.end;
      }
      return out;
    }
    let data = null, chartLibrary = null, pending = false, sourceText = null, drawnChart = null;
    let marksData = null, marksQuarter = null, cachedMarks = [];
    function read() {
      const source = document.getElementById('be-tarief-data')?.textContent || 'null';
      if (source === sourceText) return false;
      sourceText = source;
      try { data = JSON.parse(source); }
      catch (_) { data = null; }
      return true;
    }
    function currentMarks() {
      const now = Date.now(), quarter = Math.floor(now / 900000);
      if (marksData !== data || marksQuarter !== quarter) {
        marksData = data; marksQuarter = quarter;
        cachedMarks = data?.aan && Array.isArray(data.rijen) ? crossings(data.rijen, now) : [];
      }
      return cachedMarks;
    }
    const plugin = {
      id: 'beDagBreakevenTest',
      afterDatasetsDraw(chart) {
        if (chart.canvas?.id !== 'be-tarief-chart' || !data?.aan || !Array.isArray(data.rijen)) return;
        const a = chart.chartArea, x = chart.scales.x, ctx = chart.ctx;
        if (!a || !x) return;
        const marks = currentMarks();
        ctx.save();
        ctx.beginPath(); ctx.rect(a.left, a.top, a.right - a.left, a.bottom - a.top); ctx.clip();
        let lastLabelX = -Infinity, lane = 0;
        marks.forEach(m => {
          const px = x.getPixelForValue(m.t);
          if (px < a.left || px > a.right) return;
          lane = px - lastLabelX < 100 ? (lane + 1) % 3 : 0;
          const y = a.bottom - 15 - lane * 24;
          ctx.strokeStyle = '#9274bb'; ctx.lineWidth = 1;
          ctx.setLineDash([3, 4]);ctx.beginPath();ctx.moveTo(px, a.top);ctx.lineTo(px, a.bottom);ctx.stroke();ctx.setLineDash([]);
          // Signs stay on their respective sides of the time marker.
          ctx.font = '700 14px system-ui, sans-serif';ctx.textBaseline = 'middle';
          ctx.textAlign = 'right';ctx.fillStyle = m.from > 0 ? '#198754' : '#dc3545';
          if (px - 7 > a.left + 8) ctx.fillText(m.from > 0 ? '+' : '−', px - 7, y);
          ctx.textAlign = 'left';ctx.fillStyle = m.to > 0 ? '#198754' : '#dc3545';
          if (px + 7 < a.right - 8) ctx.fillText(m.to > 0 ? '+' : '−', px + 7, y);
          ctx.font = '600 10px system-ui, sans-serif';
          // Vertical caption beside the line, leaving the signs at the bottom clear.
          const label = m.estimated ? 'Break even ≈' : 'Break even';
          const labelWidth = ctx.measureText(label).width;
          const labelX = px + 17 < a.right ? px + 11 : px - 11;
          const labelBottom = y - 17;
          if (labelBottom - labelWidth >= a.top + 4) {
            ctx.save();
            ctx.translate(labelX, labelBottom);
            ctx.rotate(-Math.PI / 2);
            ctx.fillStyle = document.documentElement.getAttribute('data-be-dark') === 'aan' ? (window.BETheme.style()==='grafiet'?'#1c1f26':'#373229') : '#ffffff';
            ctx.fillRect(-3, -7, labelWidth + 6, 14);
            ctx.fillStyle = '#9274bb';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(label, 0, 0);
            ctx.restore();
          }
          lastLabelX = px;
        });
        ctx.restore();
      }
    };
    function update() {
      pending = false;
      if (document.hidden) return;
      const changed = read();
      const C = window.Chart;
      if (!C || typeof C.register !== 'function') return;
      if (chartLibrary !== C) { C.register(plugin); chartLibrary = C; }
      const chart = C.getChart('be-tarief-chart');
      if (chart && (changed || drawnChart !== chart)) {
        drawnChart = chart;
        if (window.BEChartRefresh) window.BEChartRefresh.request(chart, 'draw');
        else chart.draw();
      }
      let note = document.getElementById('be-break-even-note');
      const row = document.getElementById('be-tarief-row');
      if (!row) return;
      if (!note) {
        note = document.createElement('p'); note.id = 'be-break-even-note';
        note.className = 'charging-chart-note'; row.appendChild(note);
      }
      const marks = currentMarks();
      const indicative = marks.some(m => m.estimated);
      note.hidden = !indicative;
      const text = indicative ? '≈ Break even van het berekende dagresultaat; ontbrekende prijzen of het lopende kwartier maken dit voorlopig.' : '';
      if (note.textContent !== text) note.textContent = text;
    }
    function schedule() {
      if (pending) return;
      pending = true; setTimeout(update, 0);
    }
    document.addEventListener('be-tarief-update', schedule);
    document.addEventListener('be-dark-change', schedule);
    document.addEventListener('visibilitychange', schedule);
    // The main plugin and Chart may start after this separate userscript.
    setInterval(update, 3000);
    update();
})();

    // 7.0: Fact(uur)checker — Balans-nota (pdf) inlezen, per post en per maand naast de regels en het dashboard.
    // 7.1: elektriciteit en gas gescheiden; gas alleen getoond, het dashboard gaat over stroom.
    (function () {
// Minimale PDF-tekstlezer voor Balans-facturen (Type0/Identity-H + ToUnicode, Flate).
// Geeft per pagina regels terug: [{y, cellen:[{x, tekst}]}], van boven naar onder.
async function bePdfRegels(buf) {
  const u8 = new Uint8Array(buf);
  let src = '';
  for (let i = 0; i < u8.length; i += 65536) src += String.fromCharCode.apply(null, u8.subarray(i, i + 65536));
  const objs = new Map();
  const re = /(\d+)\s+(\d+)\s+obj\b/g;
  let m;
  while ((m = re.exec(src))) {
    const start = m.index + m[0].length;
    const end = src.indexOf('endobj', start);
    if (end < 0) break;
    objs.set(+m[1], {body: src.slice(start, end), off: start});
    re.lastIndex = end;
  }
  const dictVan = id => { const o = objs.get(id); return o ? o.body.split(/\bstream\r?\n/)[0] : ''; };
  const ref = (dict, key) => { const r = new RegExp('/' + key + '\\s+(\\d+)\\s+\\d+\\s+R').exec(dict); return r ? +r[1] : null; };
  async function inflate(bin) {
    const ds = new DecompressionStream('deflate');
    const w = ds.writable.getWriter(); w.write(bin); w.close();
    const out = new Uint8Array(await new Response(ds.readable).arrayBuffer());
    let s = ''; for (let i = 0; i < out.length; i += 65536) s += String.fromCharCode.apply(null, out.subarray(i, i + 65536));
    return s;
  }
  async function streamVan(id) {
    const o = objs.get(id); if (!o) return '';
    const sm = /\bstream\r?\n/.exec(o.body); if (!sm) return '';
    const dict = o.body.slice(0, sm.index);
    let len = /\/Length\s+(\d+)(\s+\d+\s+R)?/.exec(dict);
    let n = len ? +len[1] : 0;
    if (len && len[2]) { const lo = objs.get(n); n = lo ? parseInt(lo.body, 10) : 0; }
    const s = o.off + sm.index + sm[0].length;
    if (!n) n = src.indexOf('endstream', s) - s;
    const raw = u8.subarray(s, s + n);
    return /FlateDecode/.test(dict) ? inflate(raw) : src.slice(s, s + n);
  }
  function hexNaarStr(h) { h = h.replace(/\s+/g, ''); if (h.length % 2) h += '0'; let s = ''; for (let i = 0; i < h.length; i += 2) s += String.fromCharCode(parseInt(h.substr(i, 2), 16)); return s; }
  function utf16(bin) { let s = ''; for (let i = 0; i + 1 < bin.length; i += 2) s += String.fromCharCode(bin.charCodeAt(i) << 8 | bin.charCodeAt(i + 1)); return s; }
  const fontCache = new Map();
  async function font(id) {
    if (fontCache.has(id)) return fontCache.get(id);
    const d = dictVan(id), f = {map: new Map(), w: new Map(), dw: 1000, twee: /Type0/.test(d)};
    const tu = ref(d, 'ToUnicode');
    if (tu) {
      const cm = await streamVan(tu);
      for (const blok of cm.split('beginbfchar').slice(1)) {
        const b = blok.split('endbfchar')[0];
        for (const p of b.matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]*)>/g)) f.map.set(parseInt(p[1], 16), utf16(hexNaarStr(p[2])));
      }
      for (const blok of cm.split('beginbfrange').slice(1)) {
        const b = blok.split('endbfrange')[0];
        for (const p of b.matchAll(/<([0-9a-fA-F]+)>\s*<([0-9a-fA-F]+)>\s*(<[0-9a-fA-F]*>|\[[^\]]*\])/g)) {
          const a = parseInt(p[1], 16), z = parseInt(p[2], 16);
          if (p[3][0] === '[') { const arr = [...p[3].matchAll(/<([0-9a-fA-F]*)>/g)]; for (let c = a; c <= z && c - a < arr.length; c++) f.map.set(c, utf16(hexNaarStr(arr[c - a][1]))); }
          else { const basis = hexNaarStr(p[3].slice(1, -1)); for (let c = a; c <= z; c++) { const s = utf16(basis); f.map.set(c, s.slice(0, -1) + String.fromCharCode(s.charCodeAt(s.length - 1) + c - a)); } }
        }
      }
    }
    const df = /\/DescendantFonts\s*\[\s*(\d+)\s+\d+\s+R/.exec(d);
    if (df) {
      const dd = dictVan(+df[1]);
      const dw = /\/DW\s+(\d+)/.exec(dd); if (dw) f.dw = +dw[1];
      let wtxt = null; const wr = /\/W\s+(\d+)\s+\d+\s+R/.exec(dd);
      if (wr) wtxt = objs.get(+wr[1])?.body; else { const i = dd.indexOf('/W'); if (i >= 0) wtxt = dd.slice(i + 2); }
      if (wtxt) {
        const t = wtxt.match(/\[|\]|-?\d+(\.\d+)?/g) || []; let i = 0;
        if (t[i] === '[') i++;
        while (i < t.length && t[i] !== ']') {
          const c = +t[i++];
          if (t[i] === '[') { i++; let k = c; while (t[i] !== ']' && i < t.length) f.w.set(k++, +t[i++]); i++; }
          else { const c2 = +t[i++], w = +t[i++]; for (let k = c; k <= c2; k++) f.w.set(k, w); }
        }
      }
    } else {
      const fc = /\/FirstChar\s+(\d+)/.exec(d), wa = /\/Widths\s*\[([^\]]*)\]/.exec(d);
      if (fc && wa) wa[1].trim().split(/\s+/).forEach((w, i) => f.w.set(+fc[1] + i, +w));
    }
    fontCache.set(id, f); return f;
  }
  const mul = (a, b) => [a[0]*b[0]+a[1]*b[2], a[0]*b[1]+a[1]*b[3], a[2]*b[0]+a[3]*b[2], a[2]*b[1]+a[3]*b[3], a[4]*b[0]+a[5]*b[2]+b[4], a[4]*b[1]+a[5]*b[3]+b[5]];
  const paginas = [];
  for (const [id] of objs) {
    const d = dictVan(id);
    if (!/\/Type\s*\/Page\b/.test(d)) continue;
    paginas.push(id);
  }
  // Paginavolgorde via /Kids van de Pages-boom.
  const volgorde = [];
  (function boom(id) { const d = dictVan(id); const k = /\/Kids\s*\[([^\]]*)\]/.exec(d); if (k) [...k[1].matchAll(/(\d+)\s+\d+\s+R/g)].forEach(x => boom(+x[1])); else if (/\/Type\s*\/Page\b/.test(d)) volgorde.push(id); })(ref(dictVan(ref(/trailer[\s\S]*$/.exec(src)?.[0] || '', 'Root')), 'Pages'));
  const lijst = volgorde.length ? volgorde : paginas;
  const resultaat = [];
  for (const pid of lijst) {
    const pd = dictVan(pid);
    let res = ''; const rr = ref(pd, 'Resources');
    res = rr ? dictVan(rr) : (/\/Resources\s*<<([\s\S]*)/.exec(pd)?.[1] || '');
    let fdict = ''; const fr = ref(res, 'Font');
    fdict = fr ? dictVan(fr) : (/\/Font\s*<<([^>]*)>>/.exec(res)?.[1] || '');
    const fonts = {};
    for (const x of fdict.matchAll(/\/([^\s/<>\[\]()]+)\s+(\d+)\s+\d+\s+R/g)) fonts[x[1]] = await font(+x[2]);
    let inhoud = '';
    const ca = /\/Contents\s*\[([^\]]*)\]/.exec(pd);
    const ids = ca ? [...ca[1].matchAll(/(\d+)\s+\d+\s+R/g)].map(x => +x[1]) : [ref(pd, 'Contents')].filter(Boolean);
    for (const c of ids) inhoud += (await streamVan(c)) + '\n';
    const glyphs = [];
    let ctm = [1,0,0,1,0,0]; const stack = []; let tm = [1,0,0,1,0,0], tlm = tm, f = null, fs = 1, tl = 0, tc = 0, tw = 0, th = 1;
    const ops = []; const tokRe = /(<[0-9a-fA-F\s]*>)|(\((?:\\[\s\S]|[^\\)])*\))|(\[)|(\])|(\/[^\s/<>\[\]()]+)|(-?(?:\d+\.?\d*|\.\d+))|([A-Za-z'"*]+)|<<|>>/g;
    let stackArgs = [], t;
    function lit(s) { return s.slice(1, -1).replace(/\\([nrtbf()\\]|[0-7]{1,3})/g, (q, e) => ({n:'\n',r:'\r',t:'\t',b:'\b',f:'\f','(':'(',')':')','\\':'\\'})[e] ?? String.fromCharCode(parseInt(e, 8))); }
    function toon(bin) {
      if (!f) return;
      const stap = f.twee ? 2 : 1;
      for (let i = 0; i < bin.length; i += stap) {
        const code = stap === 2 ? (bin.charCodeAt(i) << 8 | bin.charCodeAt(i + 1)) : bin.charCodeAt(i);
        const ch = f.map.has(code) ? f.map.get(code) : (stap === 1 ? String.fromCharCode(code) : '');
        const trm = mul(tm, ctm);
        const w = (f.w.has(code) ? f.w.get(code) : f.dw) / 1000;
        const sx = Math.hypot(trm[0], trm[1]) * fs;
        glyphs.push({x: trm[4], y: trm[5], adv: w * sx, h: Math.hypot(trm[2], trm[3]) * fs, ch});
        const tx = (w * fs + tc + (ch === ' ' ? tw : 0)) * th;
        tm = mul([1,0,0,1,tx,0], tm);
      }
    }
    while ((t = tokRe.exec(inhoud))) {
      if (t[1]) stackArgs.push({hex: hexNaarStr(t[1].slice(1, -1))});
      else if (t[2]) stackArgs.push({hex: lit(t[2])});
      else if (t[3]) stackArgs.push('[');
      else if (t[4]) { const arr = []; while (stackArgs.length && stackArgs[stackArgs.length - 1] !== '[') arr.unshift(stackArgs.pop()); stackArgs.pop(); stackArgs.push({arr}); }
      else if (t[5]) stackArgs.push({name: t[5].slice(1)});
      else if (t[6]) stackArgs.push(+t[6]);
      else if (t[7]) {
        const op = t[7], a = stackArgs; stackArgs = [];
        switch (op) {
          case 'q': stack.push(ctm); break;
          case 'Q': ctm = stack.pop() || [1,0,0,1,0,0]; break;
          case 'cm': ctm = mul(a.slice(-6), ctm); break;
          case 'BT': tm = tlm = [1,0,0,1,0,0]; break;
          case 'Tf': f = fonts[a[0]?.name] || null; fs = a[1]; break;
          case 'Tm': tm = tlm = a.slice(-6); break;
          case 'Td': tm = tlm = mul([1,0,0,1,a[0],a[1]], tlm); break;
          case 'TD': tl = -a[1]; tm = tlm = mul([1,0,0,1,a[0],a[1]], tlm); break;
          case 'TL': tl = a[0]; break;
          case 'Tc': tc = a[0]; break;
          case 'Tw': tw = a[0]; break;
          case 'Tz': th = a[0] / 100; break;
          case 'T*': tm = tlm = mul([1,0,0,1,0,-tl], tlm); break;
          case 'Tj': if (a[0]?.hex !== undefined) toon(a[0].hex); break;
          case "'": tm = tlm = mul([1,0,0,1,0,-tl], tlm); if (a[0]?.hex !== undefined) toon(a[0].hex); break;
          case '"': tw = a[0]; tc = a[1]; tm = tlm = mul([1,0,0,1,0,-tl], tlm); if (a[2]?.hex !== undefined) toon(a[2].hex); break;
          case 'TJ': for (const e of (a[0]?.arr || [])) { if (typeof e === 'number') tm = mul([1,0,0,1,-e / 1000 * fs * th,0], tm); else if (e.hex !== undefined) toon(e.hex); } break;
        }
      }
    }
    // Regels: glyphs met (bijna) gelijke y; cellen splitsen op grote horizontale gaten.
    const zicht = glyphs.filter(g => g.ch && !/^[​‌‍﻿]+$/.test(g.ch));
    zicht.sort((p, q) => q.y - p.y || p.x - q.x);
    const regels = [];
    for (const g of zicht) {
      let r = regels.find(r => Math.abs(r.y - g.y) < Math.max(1.5, g.h * 0.3));
      if (!r) { r = {y: g.y, g: []}; regels.push(r); }
      r.g.push(g);
    }
    regels.sort((p, q) => q.y - p.y);
    resultaat.push(regels.map(r => {
      r.g.sort((p, q) => p.x - q.x);
      const cellen = []; let cel = null, eind = -1e9;
      for (const g of r.g) {
        const gat = g.x - eind;
        if (!cel || gat > g.h * 1.2) { cel = {x: g.x, tekst: ''}; cellen.push(cel); }
        else if (gat > g.h * 0.18 && !cel.tekst.endsWith(' ')) cel.tekst += ' ';
        cel.tekst += g.ch; eind = g.x + g.adv;
      }
      cellen.forEach(c => c.tekst = c.tekst.replace(/\s+/g, ' ').trim());
      return {y: r.y, cellen: cellen.filter(c => c.tekst)};
    }));
  }
  return resultaat;
}


// Zet de regels van bePdfRegels om in factuurgegevens. Alleen wat er staat; geen aannames over betekenis.
function beFactuurLees(paginas) {
  const num = s => { if (s == null) return NaN; s = String(s).replace(/[€*\s​]/g, ''); if (!/^-?[\d.]*,?\d+$/.test(s)) return NaN; return +s.replace(/\./g, '').replace(',', '.'); };
  const isNum = s => Number.isFinite(num(s));
  const dat = s => { const m = /^(\d{2})-(\d{2})-(\d{4})$/.exec(s || ''); return m ? m[3] + '-' + m[2] + '-' + m[1] : null; };
  const f = {type: '', nummer: '', datum: '', periode: null, secties: [], totalen: {}, totalenGas: {}, samenvatting: [], meters: [], termijnen: [], termijnTotaal: null};
  let sectie = null, kandidaat = null, domein = 'elek';
  const regels = [];
  paginas.forEach(p => p.forEach(r => regels.push(r.cellen.map(c => c.tekst))));
  for (let raw of regels) {
    // '€' als losse cel samenvoegen met de waarde erna.
    const t = [];
    for (let i = 0; i < raw.length; i++) { if (raw[i] === '€' && i + 1 < raw.length) { t.push('€' + raw[++i]); } else t.push(raw[i]); }
    const regel = t.join(' | ');
    if (t.length === 1 && /^(JAAR|EIND|TUSSEN|MAAND)[A-Z]*AFREKENING$|^[A-Z]{6,}$/.test(t[0]) && !f.type) { f.type = t[0]; continue; }
    const kv = (k) => { const i = t.indexOf(k); return i >= 0 ? t[i + 1] : null; };
    if (t.includes('Factuurnummer:')) f.nummer = kv('Factuurnummer:') || f.nummer;
    if (t.includes('Factuurdatum:')) f.datum = dat(kv('Factuurdatum:')) || f.datum;
    if (t.includes('Leveringsperiode:')) { const m = /(\d\d-\d\d-\d{4})\s*-\s*(\d\d-\d\d-\d{4})/.exec(kv('Leveringsperiode:') || ''); if (m) f.periode = {van: dat(m[1]), tot: dat(m[2])}; }
    // Totalen onderaan de specificatie.
    let m;
    // 7.1: een nota kan elektriciteit én gas bevatten; elk deel heeft eigen secties en totalen.
    if (t.length === 1 && /specificatie\s+gas/i.test(t[0])) { domein = 'gas'; kandidaat = null; sectie = null; continue; }
    if (t.length === 1 && /specificatie\s+elektriciteit/i.test(t[0])) { domein = 'elek'; kandidaat = null; sectie = null; continue; }
    const tot = domein === 'gas' ? f.totalenGas : f.totalen;
    if (t.length === 2 && /^Totaal .*exclusief btw$/i.test(t[0]) && isNum(t[1])) { (/\bgas\b/i.test(t[0]) ? f.totalenGas : /elektriciteit/i.test(t[0]) ? f.totalen : tot).excl = num(t[1]); continue; }
    if (t.length === 2 && /^btw$/i.test(t[0]) && isNum(t[1])) { tot.btw = num(t[1]); continue; }
    if (t.length === 2 && /^Totaal inclusief btw$/i.test(t[0]) && isNum(t[1])) { tot.incl = num(t[1]); continue; }
    // Samenvatting pagina 1: omschrijving + excl + btw + totaal.
    if (t.length === 4 && t.slice(1).every(isNum) && !/^Totaal te/i.test(t[0]) && !f.samenvatting.some(s => s.label === t[0])) {
      f.samenvatting.push({label: t[0], excl: num(t[1]), btw: num(t[2]), incl: num(t[3])}); continue;
    }
    // Meterstanden.
    if (t.length === 8 && dat(t[1]) && dat(t[3]) && isNum(t[5])) {
      f.meters.push({domein, label: t[0], van: dat(t[1]), standVan: +t[2], tot: dat(t[3]), standTot: +t[4], verschil: +t[5], factor: +t[6], verbruik: +t[7]}); continue;
    }
    // Termijnen.
    if ((m = /^(\d{4}-\d{2}-\d{2}) tot (\d{4}-\d{2}-\d{2})$/.exec(t[0])) && t.length >= 3 && isNum(t[1])) {
      f.termijnen.push({van: m[1], tot: m[2], gefactureerd: num(t[1]), teVerrekenen: num(t[2]), nummer: t[3] || ''}); continue;
    }
    if (t[0] === 'Totaal' && t.length === 3 && isNum(t[1]) && f.termijnen.length && f.termijnTotaal == null) { f.termijnTotaal = num(t[1]); continue; }
    // Specificatieregel: omschrijving | aantal | eenheid | tarief | subtotaal | van | tot
    if (t.length === 7 && isNum(t[1]) && isNum(t[3]) && isNum(t[4]) && dat(t[5]) && dat(t[6])) {
      if (!sectie || sectie.naam !== kandidaat) { sectie = {naam: kandidaat || '(zonder kop)', domein: /\bgas\b/i.test(kandidaat || '') ? 'gas' : domein, regels: [], totaal: null}; f.secties.push(sectie); }
      sectie.regels.push({label: t[0], aantal: num(t[1]), eenheid: t[2], tarief: num(t[3]), subtotaal: num(t[4]), van: dat(t[5]), tot: dat(t[6])});
      continue;
    }
    if (t.length === 2 && (m = /^Totaal (.+)$/.exec(t[0])) && isNum(t[1])) {
      const s = (sectie && sectie.naam === m[1] ? sectie : null) || [...f.secties].reverse().find(s => s.naam === m[1] && s.domein === domein) || sectie;
      if (s && s.totaal == null) s.totaal = num(t[1]);
      continue;
    }
    if (t.length === 1 && !isNum(t[0]) && !/^\*|^p( :|$)/.test(t[0]) && t[0].length < 80) kandidaat = t[0];
  }
  return f;
}

// Afleidingen die alleen optellen/vergelijken wat op de factuur staat.
function beFactuurAnalyse(f) {
  const r2 = x => Math.round(x * 100) / 100;
  const maandVan = (van, tot) => {
    const a = new Date(van + 'T00:00:00Z'), b = new Date(tot + 'T00:00:00Z');
    const volgende = new Date(Date.UTC(a.getUTCFullYear(), a.getUTCMonth() + 1, 1));
    return b <= volgende && b > a ? van.slice(0, 7) : null;
  };
  const energie = f.secties.filter(s => /^(Levering|Productie) Elektriciteit$/i.test(s.naam));
  const maanden = new Map(), jaarregels = [];
  f.secties.filter(s => s.domein !== 'gas').forEach(s => s.regels.forEach(r => {
    const mk = energie.includes(s) ? maandVan(r.van, r.tot) : null;
    if (!mk) { jaarregels.push(Object.assign({sectie: s.naam}, r)); return; }
    if (!maanden.has(mk)) maanden.set(mk, {maand: mk, van: r.van, tot: r.tot, afname: [], terug: []});
    const m = maanden.get(mk);
    if (r.van < m.van) m.van = r.van; if (r.tot > m.tot) m.tot = r.tot;
    (/^Levering/i.test(s.naam) ? m.afname : m.terug).push(r);
  }));
  const lijst = [...maanden.values()].sort((a, b) => a.maand < b.maand ? -1 : 1);
  const labels = {afname: [], terug: []};
  lijst.forEach(m => ['afname', 'terug'].forEach(k => m[k].forEach(r => { if (!labels[k].includes(r.label)) labels[k].push(r.label); })));
  lijst.forEach(m => {
    const kwh = rs => { const markt = rs.filter(r => /^marktprijs$/i.test(r.label)); return (markt.length ? markt : rs.slice(0, 1)).reduce((n, r) => n + Math.abs(r.aantal), 0); };
    m.afnameKwh = kwh(m.afname); m.terugKwh = kwh(m.terug);
    m.afnameEur = r2(m.afname.reduce((n, r) => n + r.subtotaal, 0));
    m.terugEur = r2(m.terug.reduce((n, r) => n + r.subtotaal, 0));
    m.saldo = r2(m.afnameEur + m.terugEur);
  });
  // Controles
  const c = [];
  // status: 'ok' (≤ 1 ct), 'afronding' (≤ 5 ct), 'fout'
  const st = d => !Number.isFinite(d) ? 'fout' : d <= 0.011 ? 'ok' : d <= 0.05 ? 'afronding' : 'fout';
  const ok = (naam, a, b, tol) => { const d = Math.abs(a - b); c.push({naam, a, b, status: tol < 0.011 || tol > 0.06 ? (Number.isFinite(d) && d <= tol ? 'ok' : 'fout') : st(d)}); };
  let regelsOk = 0, regelsTot = 0; const fout = [];
  f.secties.forEach(s => s.regels.forEach(r => { regelsTot++; const v = r.aantal * r.tarief, tol = Math.max(0.011, Math.abs(r.aantal) * 0.000006); if (Math.abs(v - r.subtotaal) <= tol) regelsOk++; else fout.push({sectie: s.naam, label: r.label, van: r.van, tot: r.tot, aantal: r.aantal, tarief: r.tarief, berekend: r2(v), factuur: r.subtotaal}); }));
  const maxD = fout.reduce((n, x) => Math.max(n, Math.abs(x.berekend - x.factuur)), 0);
  c.push({naam: 'Aantal × tarief = subtotaal', status: !fout.length ? 'ok' : maxD <= 0.05 ? 'afronding' : 'fout', tekst: regelsOk + ' van ' + regelsTot + ' regels exact', fouten: fout});
  f.secties.forEach(s => { if (s.totaal != null) ok('Som regels = totaal “' + s.naam + '”', r2(s.regels.reduce((n, r) => n + r.subtotaal, 0)), s.totaal, 0.011); });
  const somDomein = d => r2(f.secties.filter(s => (s.domein === 'gas') === (d === 'gas')).reduce((n, s) => n + (s.totaal != null ? s.totaal : s.regels.reduce((x, r) => x + r.subtotaal, 0)), 0));
  [['elek', f.totalen, 'elektriciteit'], ['gas', f.totalenGas, 'gas']].forEach(([d, T, nm]) => {
    if (!f.secties.some(s => (s.domein === 'gas') === (d === 'gas'))) return;
    if (T.incl != null) ok('Som secties ' + nm + ' = totaal incl. btw', somDomein(d), T.incl, 0.05);
    if (T.excl != null && T.btw != null && T.incl != null) ok('Excl. + btw = incl. btw (' + nm + ')', r2(T.excl + T.btw), T.incl, 0.011);
  });
  const meterSom = re => f.meters.filter(m => m.domein !== 'gas' && re.test(m.label)).reduce((n, m) => n + Math.abs(m.verbruik), 0);
  if (f.meters.length) {
    ok('Afname per maand = meterstanden', lijst.reduce((n, m) => n + m.afnameKwh, 0), meterSom(/^Elektriciteit/i), 0.5);
    ok('Teruglevering per maand = meterstanden', lijst.reduce((n, m) => n + m.terugKwh, 0), meterSom(/^Productie/i), 0.5);
    const eb = jaarregels.filter(r => /energie ?belasting/i.test(r.label) && /kwh/i.test(r.eenheid)).reduce((n, r) => n + r.aantal, 0);
    if (eb) ok('Energiebelasting kWh = afname − teruglevering (meter)', r2(eb), meterSom(/^Elektriciteit/i) - meterSom(/^Productie/i), 0.5);
  }
  const term = f.termijnen.reduce((n, t) => n + t.teVerrekenen, 0);
  const sTerm = f.samenvatting.find(s => /^Termijn/i.test(s.label));
  if (f.termijnen.length && sTerm) ok('Som termijnen = termijnfacturen', r2(term), -sTerm.incl, 0.011);
  const sJaar = f.samenvatting.find(s => /afrekening elektriciteit/i.test(s.label)), sRest = f.samenvatting.find(s => /^Restant/i.test(s.label));
  const sGas = f.samenvatting.find(s => /afrekening gas/i.test(s.label));
  if (sJaar && f.totalen.incl != null) ok('Samenvatting = totaal specificatie elektriciteit', sJaar.incl, f.totalen.incl, 0.011);
  if (sGas && f.totalenGas.incl != null) ok('Samenvatting = totaal specificatie gas', sGas.incl, f.totalenGas.incl, 0.011);
  if (sJaar && sTerm && sRest) { const x = r2(sJaar.incl + (sGas ? sGas.incl : 0) + sTerm.incl), d = Math.abs(x - sRest.incl); c.push({naam: 'Afrekening' + (sGas ? 'en' : '') + ' + termijnen = restant', a: x, b: sRest.incl, status: d <= 0.011 ? 'ok' : d <= 0.10 ? 'afronding' : 'fout'}); }
  return {maanden: lijst, labels, jaarregels, controles: c};
}


(function () {
  'use strict';
  if (window.__beFactuurchecker) return; window.__beFactuurchecker = true;
  const HASH = '#factuurchecker', OPSLAG = 0.019965, OPSLAG_EX = 0.0165, OPSLAG_KEY = 'be_factuurchecker_v1';
  const euro = (v, d) => Number.isFinite(v) ? (v < 0 ? '−' : '') + '€ ' + Math.abs(v).toLocaleString('nl-NL', {minimumFractionDigits: d ?? 2, maximumFractionDigits: d ?? 2}) : '—';
  const kwh = v => Number.isFinite(v) ? Math.round(v).toLocaleString('nl-NL') : '—';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'})[c]);
  const MND = ['jan', 'feb', 'mrt', 'apr', 'mei', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dec'];
  const dNL = iso => iso ? iso.slice(8, 10) + '-' + iso.slice(5, 7) + '-' + iso.slice(0, 4) : '';
  const dagVoor = iso => { const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() - 1); return d.toISOString().slice(0, 10); };
  const maandNaam = (m, van, tot) => { const n = MND[+m.slice(5, 7) - 1] + ' ' + m.slice(0, 4); const vol = van.slice(8) === '01' && tot.slice(8) === '01'; return vol ? n : n + ' <small>(' + +van.slice(8) + '–' + +dagVoor(tot).slice(8) + ')</small>'; };

  let facturen = [];
  try { facturen = JSON.parse(localStorage.getItem(OPSLAG_KEY) || '[]'); if (!Array.isArray(facturen)) facturen = []; } catch (_) { facturen = []; }
  const bewaar = () => { try { localStorage.setItem(OPSLAG_KEY, JSON.stringify(facturen)); } catch (_) {} };
  const dash = new Map(); // nummer → {bezig, fout, maanden: {maand:{imp,exp,buy,sell,dagen}}}

  function klant() {
    const ok = id => !!id && !/^(?:account|results|current-history|current-prices|undefined|null)$/i.test(id);
    const m = location.pathname.match(/^\/customer\/([^/]+)(?:\/|$)/);
    if (m && ok(m[1])) return m[1];
    try { const l = localStorage.getItem('be_laatste_installatie'); if (ok(l)) return l; } catch (_) {}
    return null;
  }

  let root, shadow, opened = false, link = null;
  function bouw() {
    root = document.createElement('div'); root.id = 'be-factuurchecker'; root.hidden = true;
    root.style.cssText = 'position:fixed;top:0;right:0;bottom:0;left:0;z-index:1040;overflow:auto;overscroll-behavior:contain';
    shadow = root.attachShadow({mode: 'open'});
    shadow.innerHTML = `<style>
      :host{--bg:#f6f5f9;--paper:#fff;--ink:#1f1d24;--muted:#6b6875;--line:#e4e1ea;--purple:#65419d;--ok:#1f8a4c;--warn:#b7791f;--bad:#c53030}
      :host([data-dark]){--bg:#15141a;--paper:#1f1d26;--ink:#ece9f3;--muted:#a19dac;--line:#34313d}
      *{box-sizing:border-box}
      .wrap{min-height:100%;background:var(--bg);color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;padding:24px 28px 60px}
      h1{font-size:22px;margin:0 0 4px} h2{font-size:16px;margin:0} h3{font-size:13px;margin:18px 0 6px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
      .sub{color:var(--muted);margin:0 0 18px}
      .drop{border:2px dashed var(--line);border-radius:12px;padding:22px;text-align:center;color:var(--muted);background:var(--paper);cursor:pointer}
      .drop.over{border-color:var(--purple);color:var(--purple)} .drop.klein{padding:10px}
      .kaart{background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-top:16px}
      .kop{display:flex;gap:12px;align-items:baseline;flex-wrap:wrap} .kop .meta{color:var(--muted)} .kop .acties{margin-left:auto;display:flex;gap:8px}
      button{font:inherit;border:1px solid var(--line);background:var(--paper);color:var(--ink);border-radius:8px;padding:5px 10px;cursor:pointer}
      button.prim{background:var(--purple);border-color:var(--purple);color:#fff} button:disabled{opacity:.5;cursor:default}
      .kern{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px} .kern div{border:1px solid var(--line);border-radius:10px;padding:8px 12px;min-width:170px}
      .kern small{display:block;color:var(--muted);font-size:12px} .kern b{font-size:17px}
      .tabel{overflow-x:auto} table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}
      th,td{padding:5px 8px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap;vertical-align:top}
      th:first-child,td:first-child{text-align:left} th{font-size:12px;color:var(--muted);font-weight:600}
      th.groep{text-align:center;border-bottom:2px solid var(--line)} td small,th small{color:var(--muted);font-weight:400}
      td .t{display:block;font-size:11px;color:var(--muted)} tr.som td{font-weight:700;border-top:2px solid var(--line)}
      .links{text-align:left!important}
      ul.ctl{list-style:none;padding:0;margin:0;columns:2 340px} ul.ctl li{padding:2px 0;break-inside:avoid}
      .s{display:inline-block;width:18px;font-weight:700} .s.ok{color:var(--ok)} .s.afronding{color:var(--warn)} .s.fout{color:var(--bad)}
      .d{color:var(--muted);font-size:12px} .neg{color:var(--bad)} .pos{color:var(--ok)}
      .noot{color:var(--muted);font-size:12px;margin-top:6px} .fout{color:var(--bad)}
      details summary{cursor:pointer;margin-top:4px} summary.ctlkop{font-weight:600} details ul{margin-top:8px}
      .af{color:var(--bad)!important} .balken{border:1px solid var(--line);border-radius:10px;overflow:hidden} .balk summary,.balk.tot,.balk.kopr{display:grid;grid-template-columns:minmax(140px,1fr) 1.4fr 100px 120px 90px 190px;gap:10px;align-items:center;padding:8px 12px;list-style:none;cursor:pointer;border-bottom:1px solid var(--line)} .balk summary::-webkit-details-marker{display:none} .balk.tot{font-weight:700;cursor:default;border-bottom:0} .bb{position:relative;height:12px;background:linear-gradient(var(--line),var(--line)) 50% 0/1px 100% no-repeat} .bb i{position:absolute;top:0;bottom:0;border-radius:3px} .kost{background:#d9534f;fill:#d9534f} .teg{background:#2f9e5b;fill:#2f9e5b} .bw{text-align:right;font-variant-numeric:tabular-nums} .balk.kopr{font-size:11px;color:var(--muted);font-weight:600;cursor:default;text-transform:uppercase;letter-spacing:.03em} .balk.kopr span:nth-child(n+3){text-align:right} .balk.kopr span:last-child{text-align:left} .bo{font-size:12.5px;white-space:nowrap} ul.regels{columns:1} ul.regels li{padding:3px 0;color:var(--muted);font-size:12.5px} .bb.mini{display:block;height:10px;width:130px} table.mnd td{vertical-align:middle} .balk.gasr{grid-template-columns:minmax(140px,1fr) 1.4fr 100px;cursor:default;border-bottom:1px solid var(--line)} .bd{padding:4px 12px 10px;color:var(--muted);font-size:12.5px;border-bottom:1px solid var(--line)} .bd p{margin:4px 0} svg.mnd{width:100%;max-width:760px;height:auto;color:var(--ink)} svg.mnd text{font-size:10px;fill:var(--muted)} .oordeel{margin:14px 0 4px;padding:10px 12px;border:1px solid var(--line);border-radius:10px} .okk{color:var(--ok)} .s.methode{color:var(--purple)} .s.onb{color:var(--muted)} table.posten td:first-child{white-space:normal;max-width:520px} table.opbouw td:nth-child(2){text-align:right} .kern b{font-size:20px}
    </style>
    <div class="wrap">
      <h1>Fact(uur)checker <small style="font-size:11px;font-weight:500">7.1</small></h1>
      <p class="sub">Voor de <b>jaar- of eindafrekening</b> van Balans (niet de maandelijkse termijnfactuur). Leest de nota uit, zet elke post naast de regels en elke maand naast je dashboard.</p>
      <div class="drop" id="drop">Sleep je jaar- of eindafrekening van Balans (pdf) hierheen of klik om te kiezen<input id="file" type="file" accept="application/pdf,.pdf" multiple hidden></div>
      <div id="fout" class="fout"></div>
      <div id="lijst"></div>
    </div>`;
    document.body.appendChild(root);
    const drop = shadow.getElementById('drop'), file = shadow.getElementById('file');
    drop.addEventListener('click', () => file.click());
    file.addEventListener('change', () => { lees([...file.files]); file.value = ''; });
    drop.addEventListener('dragover', e => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', e => { e.preventDefault(); drop.classList.remove('over'); lees([...e.dataTransfer.files]); });
    shadow.addEventListener('click', e => {
      const b = e.target.closest('button[data-act]'); if (!b) return;
      const nr = b.dataset.nr;
      if (b.dataset.act === 'net') {
        const f = facturen.find(x => x.nummer === nr); if (!f) return;
        let st = {}; try { st = JSON.parse(localStorage.getItem('be_overzicht_settings_v1') || '{}') || {}; } catch (_) {}
        st.networkRates = st.networkRates || {};
        f.secties.filter(s => s.domein !== 'gas' && /systeembeheer|netbeheer/i.test(s.naam)).forEach(s => s.regels.forEach(r => { if (/dag/i.test(r.eenheid)) st.networkRates[r.van.slice(0, 4)] = r.tarief; }));
        try { localStorage.setItem('be_overzicht_settings_v1', JSON.stringify(st)); b.textContent = 'Overgenomen — Financieel gebruikt nu deze tarieven'; b.disabled = true; } catch (_) {}
        dash.delete(nr); setTimeout(teken, 1200); return;
      }
      if (b.dataset.act === 'weg') { facturen = facturen.filter(f => f.nummer !== nr); dash.delete(nr); bewaar(); teken(); }
      if (b.dataset.act === 'dash') vergelijk(nr);
    });
    thema(); document.addEventListener('be-dark-change', thema);
  }
  function thema() { if (!root) return; const d = document.documentElement.getAttribute('data-be-dark') === 'aan'; root.toggleAttribute('data-dark', d); }

  async function lees(files) {
    const fout = shadow.getElementById('fout'); fout.textContent = '';
    for (const file of files) {
      try {
        if (!/pdf$/i.test(file.type) && !/\.pdf$/i.test(file.name)) throw Error('geen pdf');
        const f = beFactuurLees(await bePdfRegels(await file.arrayBuffer()));
        if (!f.nummer) throw Error('geen Balans-factuur herkend');
        if (!f.secties.length || !/AFREKENING/i.test(f.type || '')) throw Error('dit lijkt een termijnfactuur of andere nota zonder specificatie. Gebruik de jaar- of eindafrekening van Balans');
        f.bestand = file.name; f.ingelezen = new Date().toISOString();
        facturen = facturen.filter(x => x.nummer !== f.nummer).concat(f);
        facturen.sort((a, b) => (a.periode?.van || '') < (b.periode?.van || '') ? -1 : 1);
      } catch (e) { fout.textContent += file.name + ': ' + e.message + '. '; console.warn('[Fact(uur)checker]', e); }
    }
    bewaar(); teken();
  }

  async function haalMaand(id, maand) {
    const url = new URL('/customer/' + encodeURIComponent(id) + '/results-v2-api/', location.origin);
    url.searchParams.set('interval', 'month'); url.searchParams.set('period', maand);
    url.searchParams.set('include_vat', '1'); url.searchParams.set('include_delivery_cost', '1');
    for (let poging = 0; poging < 3; poging++) {
      const res = await fetch(url.href, {credentials: 'same-origin'});
      if (res.status === 429) { const w = Math.min(60, +(res.headers.get('Retry-After') || 10)); await new Promise(r => setTimeout(r, w * 1000)); continue; }
      if (res.status === 400) return null;
      if (!res.ok) throw Error('HTTP ' + res.status + ' voor ' + maand);
      return res.json();
    }
    throw Error('Balans blijft om wachten vragen (429)');
  }
  const bool = v => v === true || v === 1 || v === '1';
  async function vergelijk(nr) {
    const f = facturen.find(x => x.nummer === nr), id = klant(); if (!f) return;
    const st = {bezig: true, fout: '', maanden: {}, dagen: []}; dash.set(nr, st); teken();
    if (!id) { st.bezig = false; st.fout = 'Installatie-id onbekend: open eerst Actueel of Resultaten.'; teken(); return; }
    const a = beFactuurAnalyse(f);
    try {
      for (const m of a.maanden) {
        const j = await haalMaand(id, m.maand);
        const r = {imp: 0, exp: 0, buy: 0, sell: 0, dagen: 0, ontbreekt: 0};
        if (j && Array.isArray(j.series)) {
          const vat = bool(j.pricing?.include_vat), lev = bool(j.pricing?.include_delivery_cost);
          for (const s of j.series) {
            const d = s.date || s.day; if (!d || d < m.van || d >= m.tot) continue;
            if (![s.import_kwh, s.export_kwh, s.total_buy_eur, s.total_sell_eur].every(Number.isFinite)) { r.ontbreekt++; (r.leeg = r.leeg || []).push(d); continue; }
            let buy = s.total_buy_eur, sell = s.total_sell_eur;
            if (lev) { buy -= s.import_kwh * (vat ? OPSLAG : OPSLAG_EX); sell += s.export_kwh * (vat ? OPSLAG : OPSLAG_EX); }
            if (!vat) { buy *= 1.21; sell *= 1.21; }
            r.imp += s.import_kwh; r.exp += s.export_kwh; r.buy += buy; r.sell += sell; r.dagen++;
            st.dagen.push({d, buy, sell, imp: s.import_kwh, exp: s.export_kwh, pv: s.pv_estimated_kwh, pvBekend: Number.isFinite(s.pv_estimated_kwh)});
          }
        }
        const totDagen = Math.round((new Date(m.tot) - new Date(m.van)) / 864e5);
        r.verwacht = totDagen; st.maanden[m.maand] = r; teken();
        await new Promise(res => setTimeout(res, 350));
      }
    } catch (e) { st.fout = e.message; }
    st.bezig = false; teken();
  }

  // ---- Hoe het hoort: zelfde regels als Financieel 7.0 (wet + Balans-contract) ----
  function instellingen() {
    let s = {}; try { s = JSON.parse(localStorage.getItem('be_overzicht_settings_v1') || '{}') || {}; } catch (_) {}
    const num = (o, k, d) => (o && Number.isFinite(+o[k]) && +o[k] > 0) ? +o[k] : d;
    return {
      eb: y => num(s.rates, y, {2025: 0.10154, 2026: 0.09161, 2027: 0.08802}[y]) * 1.21,
      verm: y => num(s.credit, y, {2025: 524.95, 2026: 519.80, 2027: 519.58}[y]) * 1.21,
      net: y => num(s.networkRates, y, {2025: 1.30390, 2026: 1.30365}[y] || num(s, 'network', 1.30365)),
      lev: num(s, 'supplier', 0.21839), opslag: OPSLAG
    };
  }
  const jaarDagen = y => ((y % 4 === 0 && y % 100) || y % 400 === 0) ? 366 : 365;
  function dagenPerJaar(van, tot) { const o = {}; for (let d = new Date(van + 'T12:00:00Z'); d.toISOString().slice(0, 10) < tot; d.setUTCDate(d.getUTCDate() + 1)) { const y = d.getUTCFullYear(); o[y] = (o[y] || 0) + 1; } return o; }
  function model(f, ds) {
    if (!f.periode || !ds || ds.bezig || !ds.dagen.length) return null;
    const I = instellingen(), dpj = dagenPerJaar(f.periode.van, f.periode.tot), dagen = ds.dagen;
    const totDagen = Object.values(dpj).reduce((n, x) => n + x, 0);
    if (dagen.length < totDagen) return {onvolledig: totDagen - dagen.length};
    const sum = (k, fn) => dagen.reduce((n, x) => n + (fn ? fn(x) : x[k]), 0);
    const imp = sum('imp'), exp = sum('exp');
    // Saldering: duurzaam per dag = min(teruglevering, geschatte pv); overig max 5.000 kWh (art. 2.31 Energiewet).
    const bekend = dagen.filter(x => x.pvBekend), kE = bekend.reduce((n, x) => n + x.exp, 0), kR = bekend.reduce((n, x) => n + Math.min(x.exp, Math.max(0, x.pv)), 0), share = kE > 0 ? kR / kE : 0;
    dagen.forEach(x => { x.ren = x.pvBekend ? Math.min(x.exp, Math.max(0, x.pv)) : x.exp * share; x.non = x.exp - x.ren; });
    const ren = sum('ren'), non = sum('non'), nonMee = Math.min(5000, non), nonF = non > 0 ? nonMee / non : 1;
    const credit = Math.min(imp, ren + nonMee), belastbaar = imp - credit;
    // EB tijdsevenredig en per werkelijk verbruik per tariefperiode.
    const jaren = Object.keys(dpj);
    const ebTijd = belastbaar * jaren.reduce((n, y) => n + dpj[y] * I.eb(y), 0) / totDagen;
    const w = {}; let wt = 0; jaren.forEach(y => { const dy = dagen.filter(x => x.d.slice(0, 4) === y); w[y] = Math.max(0, dy.reduce((n, x) => n + x.imp - (x.ren + x.non * nonF), 0)); wt += w[y]; });
    const werkelijkKwh = {}; jaren.forEach(y => werkelijkKwh[y] = wt > 0 ? belastbaar * w[y] / wt : 0);
    const ebWerk = jaren.reduce((n, y) => n + werkelijkKwh[y] * I.eb(y), 0);
    return {
      imp, exp, ren, non, nonMee, credit, belastbaar, ebTijd, ebWerk, werkelijkKwh, dpj,
      buy: Object.values(ds.maanden).reduce((n, m) => n + m.buy, 0), sell: Object.values(ds.maanden).reduce((n, m) => n + m.sell, 0),
      opslagAf: imp * I.opslag, opslagTerug: exp * I.opslag,
      verm: jaren.reduce((n, y) => n + dpj[y] / jaarDagen(+y) * I.verm(y), 0),
      net: jaren.reduce((n, y) => n + dpj[y] * I.net(y), 0),
      lev: totDagen * I.lev, totDagen
    };
  }
  // Posten van de factuur, in gewone taal, naast hoe het hoort. + verschil = factuur ongunstiger voor jou.
  function posten(f, M) {
    const r2 = x => Math.round(x * 100) / 100;
    const sec = re => f.secties.filter(s => s.domein !== 'gas' && re.test(s.naam));
    const som = (secs, fn) => r2(secs.reduce((n, s) => n + s.regels.filter(r => !fn || fn(r)).reduce((x, r) => x + r.subtotaal, 0), 0));
    const kwhS = (secs, fn) => secs.reduce((n, s) => n + s.regels.filter(r => !fn || fn(r)).reduce((x, r) => x + Math.abs(r.aantal), 0), 0);
    const markt = r => /^marktprijs$/i.test(r.label);
    const lev = sec(/^Levering Elektriciteit$/i), prod = sec(/^Productie Elektriciteit$/i), heff = sec(/heffingen/i);
    const ebR = r => /belasting/i.test(r.label) && /kwh/i.test(r.eenheid);
    const P = [];
    const levE = som(lev), prodE = som(prod), levNc = som(lev, r => !markt(r)), prodNc = som(prod, r => !markt(r));
    P.push({naam: 'Energie (afname − teruglevering)', wat: 'Stroomprijs per maand. Afname ' + kwh(kwhS(lev, markt)) + ' kWh, teruglevering ' + kwh(kwhS(prod, markt)) + ' kWh.' + (levNc || prodNc ? ' Vanaf de maand met “Netcorrectie”-regels: marktprijs + netcorrectie samen is wat je dashboard als inkoop/verkoop toont.' : ''),
      factuur: r2(levE + prodE), hoort: M ? r2(M.buy - M.sell) : null, bron: 'dashboard Resultaten', soort: 'data'});
    const oa = sec(/^Opslag .*Levering$/i), op = sec(/^Opslag .*Productie$/i);
    if (oa.length || op.length) P.push({naam: 'Inkoopvergoeding Balans', wat: 'Vaste opslag per kWh op afname én teruglevering (contract: € 0,0165 excl. btw).', factuur: r2(som(oa) + som(op)), hoort: M ? r2(M.opslagAf + M.opslagTerug) : null, bron: 'contract × kWh'});
    const eb = heff.flatMap(s => s.regels.filter(ebR)), ebKwh = eb.reduce((n, r) => n + r.aantal, 0), ebEur = r2(eb.reduce((n, r) => n + r.subtotaal, 0));
    if (eb.length) {
      P.push({naam: 'Salderen (kWh waarover energiebelasting)', wat: 'Afname min teruglevering die mag meetellen: duurzaam onbeperkt, overig max 5.000 kWh, nooit meer dan de afname (art. 50 lid 2 Wbm, art. 2.31 Energiewet).' + (M && !M.onvolledig ? ' Duurzaam ' + kwh(M.ren) + ' kWh, overig ' + kwh(M.non) + ' kWh.' : ''), factuur: ebKwh, hoort: M && !M.onvolledig ? M.belastbaar : null, eenheid: 'kWh'});
      const p = {naam: 'Energiebelasting', wat: 'Over ' + kwh(ebKwh) + ' kWh. ' + eb.map(r => kwh(r.aantal) + ' kWh × ' + euro(r.tarief, 5) + ' (' + dNL(r.van) + '–' + dNL(dagVoor(r.tot)) + ')').join('; ') + '.', factuur: ebEur, hoort: M && !M.onvolledig ? r2(M.ebTijd) : null, bron: 'tijdsevenredig'};
      // 7.1: zelfde totaal aan belaste kWh, alleen een andere verdeling over de jaren = toegestane methode.
      if (M && !M.onvolledig && Math.abs(ebKwh - M.belastbaar) <= Math.max(10, M.belastbaar * 0.002) && Math.abs(ebEur - M.ebTijd) > 0.5) {
        const perJaar = {}; eb.forEach(r => { const y = r.van.slice(0, 4); perJaar[y] = (perJaar[y] || 0) + r.aantal; });
        const tijd = {}; Object.keys(M.dpj).forEach(y => tijd[y] = M.belastbaar * M.dpj[y] / M.totDagen);
        const werk = Object.keys(perJaar).every(y => Math.abs(perJaar[y] - (M.werkelijkKwh[y] || 0)) <= 15);
        p.methode = 'Balans verdeelt de belaste kWh anders over de jaren: ' + Object.keys(perJaar).map(y => y + ' ' + kwh(perJaar[y]) + ' kWh').join(', ') + ' (tijdsevenredig: ' + Object.keys(tijd).map(y => y + ' ' + kwh(tijd[y]) + ' kWh').join(', ') + ')' + (werk ? ', gelijk aan het werkelijke netto verbruik per jaar' : '') + '. Het Handboek Milieubelastingen staat verschillende verdelingen toe; tijdsevenredig is bij stroom gebruikelijk.';
      }
      P.push(p);
      const rest = heff.flatMap(s => s.regels.filter(r => !ebR(r)));
      if (rest.length) P.push({naam: 'Belastingvermindering (heffingskorting)', wat: 'Vast bedrag per jaar per aansluiting, naar dagen: ' + rest.map(r => r.aantal + ' dagen × ' + euro(r.tarief, 5)).join(' + ') + '.', factuur: r2(rest.reduce((n, r) => n + r.subtotaal, 0)), hoort: M && !M.onvolledig ? r2(-M.verm) : null, bron: 'wettelijk jaarbedrag'});
    }
    const nb = sec(/systeembeheer|netbeheer/i);
    if (nb.length) {
      const I = instellingen(), naam = nb.map(s => s.naam.replace(/^.*\(|\).*$/g, '')).join(', ');
      const nota = {}; nb.forEach(s => s.regels.forEach(r => { if (/dag/i.test(r.eenheid)) nota[r.van.slice(0, 4)] = r.tarief; }));
      const anders = Object.keys(nota).filter(y => Math.abs(nota[y] - I.net(y)) > 0.00005);
      const p = {naam: 'Netbeheer', wat: 'Doorberekend tarief van je netbeheerder (' + naam + '), per dag: ' + Object.keys(nota).map(y => y + ' ' + euro(nota[y], 5)).join(', ') + '.', factuur: som(nb), hoort: M && !M.onvolledig ? r2(M.net) : null, bron: 'netbeheer in Financieel'};
      if (anders.length) { p.instelling = 'Financieel rekent met ' + anders.map(y => y + ' ' + euro(I.net(y), 5)).join(', ') + ' per dag, de nota met het tarief van ' + naam + '. Neem de nota-tarieven over, dan kloppen Financieel en deze vergelijking.'; p.notaTarief = nota; }
      P.push(p);
    }
    const vk = sec(/vaste leveringskosten/i);
    if (vk.length) P.push({naam: 'Vaste leveringskosten', wat: 'Vast bedrag per dag van Balans.', factuur: som(vk), hoort: M && !M.onvolledig ? r2(M.lev) : null, bron: 'contract'});
    const bekend = new Set([...lev, ...prod, ...oa, ...op, ...heff, ...nb, ...vk]);
    f.secties.filter(s => s.domein !== 'gas' && !bekend.has(s)).forEach(s => P.push({naam: s.naam, wat: 'Niet herkende post.', factuur: som([s]), hoort: null}));
    P.forEach(p => {
      if (p.hoort == null) { p.oordeel = 'onbekend'; return; }
      const d = p.eenheid === 'kWh' ? p.factuur - p.hoort : r2(p.factuur - p.hoort); p.verschil = d;
      const tol = p.eenheid === 'kWh' ? 2 : 0.011, klein = p.eenheid === 'kWh' ? 10 : Math.max(0.5, Math.abs(p.factuur) * 0.002);
      if (Math.abs(d) <= tol) p.oordeel = 'ok';
      else if (p.instelling) p.oordeel = 'instelling';
      else if (p.methode) p.oordeel = 'methode';
      else if (Math.abs(d) <= klein) p.oordeel = 'afronding';
      else p.oordeel = d > 0 ? 'nadeel' : 'voordeel';
      if (p.eenheid === 'kWh' && p.oordeel === 'nadeel') p.nadeelEur = null;
    });
    return P;
  }

  function teken() {
    if (!shadow) return;
    shadow.getElementById('drop').classList.toggle('klein', facturen.length > 0);
    shadow.getElementById('lijst').innerHTML = facturen.map(kaart).join('');
  }
  function kaart(f) {
    const a = beFactuurAnalyse(f), sam = f.samenvatting, ds = dash.get(f.nummer);
    if (!ds && klant()) setTimeout(() => vergelijk(f.nummer), 0);
    const per = f.periode ? dNL(f.periode.van) + ' t/m ' + dNL(dagVoor(f.periode.tot)) : '';
    const sJaar = sam.find(x => /afrekening elektriciteit/i.test(x.label)), sTerm = sam.find(x => /^Termijn/i.test(x.label)), sRest = sam.find(x => /^Restant/i.test(x.label));
    let h = `<div class="kaart"><div class="kop"><h2>${esc(f.type ? f.type[0] + f.type.slice(1).toLowerCase() : 'Factuur')} ${esc(f.nummer)}</h2>
      <span class="meta">${per} · factuurdatum ${dNL(f.datum)}</span>
      <span class="acties"><button data-act="weg" data-nr="${esc(f.nummer)}" title="Factuur verwijderen">×</button></span></div>`;

    // 1. Uitkomst
    h += '<div class="kern">';
    const sGas = sam.find(x => /afrekening gas/i.test(x.label));
    if (sJaar) h += `<div><small>Stroom ${sJaar.incl < 0 ? '(tegoed voor jou)' : '(kosten)'}</small><b>${euro(Math.abs(sJaar.incl))}</b></div>`;
    if (sGas) h += `<div><small>Gas ${sGas.incl < 0 ? '(tegoed voor jou)' : '(kosten)'}</small><b>${euro(Math.abs(sGas.incl))}</b></div>`;
    if (sTerm) h += `<div><small>Al betaald aan termijnen${sGas ? ' (stroom + gas)' : ''}</small><b>${euro(-sTerm.incl)}</b></div>`;
    if (sRest) h += `<div><small>${sRest.incl < 0 ? 'Je krijgt terug' : 'Je moet bijbetalen'}</small><b>${euro(Math.abs(sRest.incl))}</b></div>`;
    h += '</div>';

    // 2. Posten: factuur naast hoe het hoort
    const M = model(f, ds), P = posten(f, M), DREMPEL = 5;
    const lbl = {ok: ['✓', 'klopt', 'ok'], afronding: ['≈', 'afronding', 'afronding'], methode: ['↔', 'toegestane andere methode', 'methode'], nadeel: ['✗', 'in je nadeel', 'fout'], voordeel: ['+', 'in je voordeel', 'ok'], onbekend: ['?', 'niet te controleren', 'onb']};
    const nadelig = P.filter(p => p.oordeel === 'nadeel' && (p.eenheid === 'kWh' || p.verschil >= DREMPEL));
    const methode = P.filter(p => p.oordeel === 'methode');
    if (ds && ds.bezig) h += '<p class="noot">Dashboardgegevens worden gelezen…</p>';
    else if (M && M.onvolledig) h += `<p class="fout">Dashboard mist ${M.onvolledig} dag(en) in deze periode; vergelijking is onvolledig.</p>`;
    else if (M) h += '<div class="oordeel">' + (nadelig.length ? `<b class="fout">✗ ${nadelig.length} afwijking(en) in je nadeel boven € ${DREMPEL}:</b> ` + nadelig.map(p => esc(p.naam) + ' ' + (p.eenheid === 'kWh' ? kwh(p.verschil) + ' kWh' : euro(p.verschil))).join(' · ') : `<b class="okk">✓ Geen afwijkingen in je nadeel boven € ${DREMPEL}.</b>`) +
      (methode.length ? `<br><span class="d">↔ ${methode.map(p => esc(p.naam) + ': andere toegestane methode, ' + (p.verschil > 0 ? euro(p.verschil) + ' duurder' : euro(-p.verschil) + ' goedkoper') + ' dan tijdsevenredig').join(' · ')}</span>` : '') + '</div>';
    // Opbouw als balken: één regel per post, details bij aanklikken.
    const sal = P.find(p => p.eenheid === 'kWh'), rijen = P.filter(p => p.eenheid !== 'kWh');
    const maxAbs = Math.max(1, ...rijen.map(p => Math.abs(p.factuur)));
    const ic = {ok: ['✓', 'ok', 'klopt'], afronding: ['✓', 'ok', 'klopt (afronding)'], methode: ['↔', 'methode', 'andere toegestane methode'], nadeel: ['✗', 'fout', 'in je nadeel'], voordeel: ['✓', 'ok', 'in je voordeel'], onbekend: ['?', 'onb', 'niet te controleren'], instelling: ['ⓘ', 'methode', 'tarief ≠ Financieel']};
    h += `<h3>Zo komt het bedrag tot stand</h3><div class="balken"><div class="balk kopr"><span>Post</span><span></span><span>Nota</span><span>Volgens de regels</span><span>Verschil</span><span>Oordeel</span></div>`;
    let tH = 0, alleH = true;
    rijen.forEach(p => {
      const v = p.factuur, w = Math.abs(v) / maxAbs * 50, I = ic[p.oordeel];
      const det = [p.wat, p.methode && '↔ ' + p.methode, p.instelling && 'ⓘ ' + p.instelling, p === rijen.find(x => x.naam === 'Energiebelasting') && sal ? 'Salderen: ' + sal.wat + ' Op de nota ' + kwh(sal.factuur) + ' kWh' + (sal.hoort != null ? ', volgens de regels ' + kwh(sal.hoort) + ' kWh.' : '.') : null,
        p.hoort != null ? 'Nota ' + euro(p.factuur) + ' · volgens de regels ' + euro(p.hoort) + ' (' + p.bron + ') · verschil ' + (p.verschil > 0 ? '+' : '') + euro(p.verschil) + '.' : null].filter(Boolean);
      if (p.instelling) tH += p.factuur; else if (p.hoort == null) alleH = false; else tH += p.hoort;
      h += `<details class="balk"><summary><span class="bn">${esc(p.naam.replace(/ \(.*\)$/, ''))}</span><span class="bb"><i style="${v >= 0 ? 'left:50%' : 'right:50%'};width:${w}%" class="${v >= 0 ? 'kost' : 'teg'}"></i></span><span class="bw">${euro(v)}</span><span class="bw d">${p.hoort == null ? '—' : euro(p.hoort)}</span><span class="bw d">${p.verschil == null ? '' : (p.verschil > 0 ? '+' : '') + euro(p.verschil)}</span><span class="bo"><span class="s ${I[1]}">${I[0]}</span>${I[2]}</span></summary><div class="bd">${det.map(t => `<p>${esc(t)}</p>`).join('')}${p.notaTarief ? `<p><button data-act="net" data-nr="${esc(f.nummer)}">Netbeheertarieven van de nota overnemen in Financieel</button></p>` : ''}</div></details>`;
    });
    h += `<div class="balk tot"><span class="bn">Uitkomst stroom</span><span class="bb"></span><span class="bw">${euro(f.totalen.incl)}</span><span class="bw">${alleH ? euro(tH) : '—'}</span><span class="bw">${alleH ? (f.totalen.incl - tH > 0 ? '+' : '') + euro(f.totalen.incl - tH) : ''}</span><span></span></div></div>`;
    h += `<p class="noot">Rood = kosten, groen = in je voordeel. Verschil + = nota ongunstiger voor jou. Klik op een post voor uitleg.</p>`;
    // 7.1: gas staat op dezelfde nota maar niet in het Balans-dashboard: alleen tonen wat er staat.
    const gas = f.secties.filter(s => s.domein === 'gas');
    if (gas.length) {
      const m3 = f.meters.filter(m => m.domein === 'gas').reduce((n, m) => n + Math.abs(m.verbruik || 0), 0);
      const r2g = x => Math.round(x * 100) / 100, rg = [];
      gas.forEach(s => {
        if (/levering gas/i.test(s.naam)) { const lb = {}; s.regels.forEach(r => lb[r.label] = (lb[r.label] || 0) + r.subtotaal); Object.keys(lb).forEach(k => rg.push([k.replace(/^marktprijs$/i, 'Gasprijs (marktprijs)').replace(/^Inkoopvergoeding$/i, 'Inkoopvergoeding gas'), r2g(lb[k])])); }
        else rg.push([s.naam.replace(/^Overheidsheffingen$/i, 'Energiebelasting gas').replace(/kosten \(/i, 'kosten gas (').replace(/\/Diversen$/i, ' gas'), r2g(s.regels.reduce((n, r) => n + r.subtotaal, 0))]);
      });
      const gOk = a.controles.filter(c => /gas/i.test(c.naam)).every(c => c.status !== 'fout');
      h += `<h3>Gas <span style="text-transform:none;font-weight:400">— staat op dezelfde nota, maar zit niet in je Balans-dashboard</span></h3><div class="balken">` +
        rg.map(([k, v]) => `<div class="balk tot gasr"><span class="bn" style="font-weight:400">${esc(k)}</span><span></span><span class="bw" style="font-weight:400">${euro(v)}</span></div>`).join('') +
        `<div class="balk tot gasr"><span class="bn">Uitkomst gas</span><span class="d">${m3 ? kwh(m3) + ' m³' : ''}</span><span class="bw">${euro(f.totalenGas.incl)}</span></div></div>` +
        `<p class="noot">${gOk ? '✓ Intern nagerekend: regels en totalen kloppen.' : '✗ Gas rekent intern niet sluitend, zie Verificatie.'} Gas wordt niet met de regels of het dashboard vergeleken.</p>`;
    }

    // Per maand: tabel met inline balk en afwijking t.o.v. dashboard (altijd zichtbaar).
    const mm = a.maanden, mx = Math.max(1, ...mm.map(m => Math.abs(m.saldo)));
    const dz = m => ds && ds.maanden[m.maand] && ds.maanden[m.maand].dagen ? ds.maanden[m.maand] : null;
    const dl = (v, tol, f) => !Number.isFinite(v) ? '' : Math.abs(v) <= tol ? '<span class="d">0</span>' : `<span class="${v > 0 ? 'af' : 'okk'}">${v > 0 ? '+' : '−'}${f(Math.abs(v))}</span>`;
    const onder = (dv, f) => dv == null ? '' : `<span class="t">dashboard ${f(dv)}</span>`;
    h += `<h3>Per maand</h3><div class="tabel"><table class="mnd"><thead><tr><th>Maand</th><th>Afgenomen</th><th>Teruggeleverd</th><th>Kosten afname</th><th>Opbrengst teruglevering</th><th>Netto stroom</th><th class="links" style="min-width:130px"></th><th>Afwijking</th></tr></thead><tbody>`;
    const T = {ak: 0, tk: 0, ae: 0, te: 0, dak: 0, dtk: 0, dae: 0, dte: 0, n: 0};
    mm.forEach(m => {
      const d = dz(m), kost = m.afnameEur, opb = -m.terugEur, net = kost - opb, w = Math.abs(net) / mx * 50;
      T.ak += m.afnameKwh; T.tk += m.terugKwh; T.ae += kost; T.te += opb;
      if (d) { T.dak += d.imp; T.dtk += d.exp; T.dae += d.buy; T.dte += d.sell; T.n++; }
      const afw = d ? net - (d.buy - d.sell) : null;
      h += `<tr><td>${maandNaam(m.maand, m.van, m.tot)}</td>
        <td>${kwh(m.afnameKwh)} kWh${onder(d && d.imp, v => kwh(v))}</td>
        <td>${kwh(m.terugKwh)} kWh${onder(d && d.exp, v => kwh(v))}</td>
        <td>${euro(kost)}${onder(d && d.buy, euro)}</td>
        <td>${euro(opb)}${onder(d && d.sell, euro)}</td>
        <td><b>${euro(net)}</b>${onder(d && d.buy - d.sell, euro)}</td>
        <td class="links"><span class="bb mini"><i style="${net >= 0 ? 'left:50%' : 'right:50%'};width:${w}%" class="${net >= 0 ? 'kost' : 'teg'}"></i></span></td>
        <td>${d ? dl(afw, 0.5, euro) + `<span class="t">kWh ${dl(m.afnameKwh - d.imp, 1.5, v => kwh(v))} / ${dl(m.terugKwh - d.exp, 1.5, v => kwh(v))}</span>` : (ds && ds.bezig ? '<span class="d">…</span>' : '—')}</td></tr>`;
    });
    const tok = T.n === mm.length;
    h += `<tr class="som"><td>Totaal</td><td>${kwh(T.ak)} kWh${tok ? onder(T.dak, v => kwh(v)) : ''}</td><td>${kwh(T.tk)} kWh${tok ? onder(T.dtk, v => kwh(v)) : ''}</td><td>${euro(T.ae)}${tok ? onder(T.dae, euro) : ''}</td><td>${euro(T.te)}${tok ? onder(T.dte, euro) : ''}</td><td>${euro(T.ae - T.te)}${tok ? onder(T.dae - T.dte, euro) : ''}</td><td></td><td>${tok ? dl((T.ae - T.te) - (T.dae - T.dte), 0.5, euro) : ''}</td></tr></tbody></table></div>`;
    h += `<p class="noot">Zwart = nota (marktprijs + netcorrectie, incl. btw, zonder inkoopvergoeding). Grijs = dashboard Resultaten op dezelfde basis. Afwijking = nota − dashboard op netto stroom: <span class="af">rood +</span> = nota ongunstiger, <span class="okk">groen −</span> = nota gunstiger; daaronder het kWh-verschil afname / teruglevering. Kleiner dan € 0,50 of 1,5 kWh = 0.</p>`;
    // 7.1: maanden met een verschil > € 5: welke dagen springen eruit in het dashboard?
    const opv = [];
    mm.forEach(m => {
      const d = dz(m); if (!d || !ds.dagen) return;
      const afw = (m.afnameEur + m.terugEur) - (d.buy - d.sell); if (Math.abs(afw) <= 5) return;
      const dg = ds.dagen.filter(x => x.d >= m.van && x.d < m.tot), lijst = [];
      const med = a => { const b = a.slice().sort((x, y) => x - y); return b.length ? b[Math.floor(b.length / 2)] : NaN; };
      [['exp', 'sell', 'teruglevering', 'opbrengst'], ['imp', 'buy', 'afname', 'kosten']].forEach(([k, e, naam, wat]) => {
        const pr = dg.filter(x => x[k] > 1).map(x => x[e] / x[k]), mdn = med(pr), mad = med(pr.map(p => Math.abs(p - mdn)));
        dg.forEach(x => {
          if (x[k] > 1 && Math.abs(x[e]) < 0.01) lijst.push({d: x.d, t: `${naam} ${kwh(x[k])} kWh maar ${wat} € 0,00`});
          else if (x[k] > 3 && Number.isFinite(mdn) && Math.abs(x[e] / x[k] - mdn) > Math.max(0.10, 4 * mad)) lijst.push({d: x.d, t: `${naam} ${kwh(x[k])} kWh tegen gem. ${euro(x[e] / x[k], 3)}/kWh (maand ${euro(mdn, 3)})`});
        });
      });
      (d.leeg || []).forEach(x => lijst.push({d: x, t: 'geen gegevens in het dashboard'}));
      lijst.sort((a, b) => a.d < b.d ? -1 : 1);
      opv.push(`<li><b>${MND[+m.maand.slice(5) - 1]} ${m.maand.slice(0, 4)}</b> <span class="${afw > 0 ? 'af' : 'okk'}">${afw > 0 ? '+' : '−'}${euro(Math.abs(afw))}</span>: ` +
        (lijst.length ? lijst.map(x => `${dNL(x.d).slice(0, 5)} ${esc(x.t)}`).join(' · ') : 'geen dag springt eruit; het verschil is over de maand gespreid (bijv. andere afrekenprijzen dan het dashboard toont).') + '</li>');
    });
    if (opv.length) h += `<h3>Opvallende dagen</h3><ul class="ctl regels">${opv.join('')}</ul><p class="noot">Alleen maanden met meer dan € 5 verschil tussen nota en dashboard. De nota geeft maandtotalen; deze dagen zijn de waarschijnlijke plek van het verschil, gezien vanuit het dashboard.</p>`;
    if (ds?.fout) h += `<p class="fout">Dashboard: ${esc(ds.fout)}</p>`;

    // 4. Controles, ingeklapt
    const symbool = {ok: '✓', afronding: '≈', fout: '✗'};
    const n = {ok: 0, afronding: 0, fout: 0}; a.controles.forEach(c => n[c.status]++);
    const kop = n.fout ? `<span class="s fout">✗</span>${n.fout} controle(s) kloppen niet` : `<span class="s ok">✓</span>De factuur rekent intern goed` + (n.afronding ? ` <span class="d">(${n.afronding}× afrondingsverschil van een paar cent)</span>` : '');
    const I2 = instellingen(), jr = f.periode ? Object.keys(dagenPerJaar(f.periode.van, f.periode.tot)) : [];
    h += `<h3>Verificatie</h3><p class="ctlkop">${kop}</p><ul class="ctl">` + a.controles.map(c => {
      const w = c.tekst ? c.tekst : (c.status === 'ok' ? '' : `${fmt(c.a)} vs ${fmt(c.b)}`);
      return `<li><span class="s ${c.status}">${symbool[c.status]}</span>${esc(c.naam)}${w ? ` <span class="d">${esc(w)}</span>` : ''}</li>`;
    }).join('') + '</ul>';
    const rf = a.controles.find(c => c.fouten && c.fouten.length);
    if (rf) h += '<div class="tabel"><table><thead><tr><th>Regel</th><th>Aantal × tarief</th><th>Berekend</th><th>Factuur</th><th>Verschil</th></tr></thead><tbody>' +
      rf.fouten.map(x => `<tr><td>${esc(x.label)} <small>${dNL(x.van)}</small></td><td>${x.aantal.toLocaleString('nl-NL')} × ${euro(x.tarief, 5)}</td><td>${euro(x.berekend)}</td><td>${euro(x.factuur)}</td><td>${euro(x.factuur - x.berekend)}</td></tr>`).join('') + '</tbody></table></div>';
    h += `<details><summary>Gebruikte regels voor “volgens de regels”</summary><ul class="ctl regels">
      <li>Salderen over de hele contractperiode, maximaal de afname; duurzaam onbeperkt, overig max 5.000 kWh (art. 50 lid 2 Wbm, art. 2.31 Energiewet). Duurzaam per dag = min(teruglevering, geschatte pv-opwek).</li>
      <li>Energiebelasting incl. btw: ${jr.map(y => y + ' ' + euro(I2.eb(y), 5) + '/kWh').join(', ')}; verdeling over jaren tijdsevenredig (Handboek Milieubelastingen 2026, tariefwijziging binnen een verbruiksperiode).</li>
      <li>Belastingvermindering incl. btw: ${jr.map(y => y + ' ' + euro(I2.verm(y)) + '/jaar').join(', ')}, naar dagen.</li>
      <li>Netbeheer: ${jr.map(y => y + ' ' + euro(I2.net(y), 5) + '/dag').join(', ')} (instelling Financieel).</li>
      <li>Vaste leveringskosten ${euro(I2.lev, 5)}/dag; inkoopvergoeding € 0,0165 excl. btw per kWh afname en teruglevering (contract).</li>
      <li>Energie per maand: dashboard Resultaten, incl. btw, zonder inkoopvergoeding, alleen de dagen binnen de factuurperiode.</li></ul></details>`;
    return h + '</div>';
  }
  const r2 = x => Math.round(x * 100) / 100;
  function fmt(v) { return Number.isFinite(v) ? (Math.abs(v) >= 100 && Number.isInteger(v) ? kwh(v) : euro(v)) : '—'; }

  // Menu en openen/sluiten
  function layout() {
    if (!opened) return;
    let left = 0;
    const anker = link && link.isConnected ? link : document.querySelector('a[href*="/results"]');
    let c = anker && anker.closest('nav,aside,.sidebar,.sidenav,#sidebar,.offcanvas,.nav');
    while (innerWidth >= 768 && c && c !== document.body) { const r = c.getBoundingClientRect(); if (r.width > 80 && r.width < 440 && r.height > 180 && r.left < 120 && r.right < innerWidth * .6) left = Math.max(left, r.right); c = c.parentElement; }
    root.style.left = Math.round(left) + 'px';
  }
  function open() {
    if (!root) bouw();
    opened = true; root.hidden = false; teken(); layout();
    if (location.hash !== HASH) history.pushState(history.state, '', location.pathname + location.search + HASH);
    if (link) { link.setAttribute('aria-current', 'page'); link.classList.add('active'); }
  }
  function close() {
    if (!opened) return; opened = false; root.hidden = true;
    if (link) { link.removeAttribute('aria-current'); link.classList.remove('active'); }
  }
  function menu() {
    if (link && link.isConnected) return;
    const fin = document.querySelector('a[data-be-financial-link]');
    const anker = fin || [...document.querySelectorAll('a[href*="/results"]')].find(a => !a.closest('#be-energieoverzicht'));
    if (!anker) return;
    link = document.createElement('a'); link.href = HASH; link.setAttribute('data-be-factuur-link', '');
    link.className = anker.className.replace(/\bactive\b/g, '').trim();
    link.style.cssText = 'display:flex;align-items:center;gap:12px;white-space:normal';
    link.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="flex:none"><path d="M6 3h9l3 3v15H6z"/><path d="M9 9h6M9 13h6M9 17h3"/><path d="m14 17 1.5 1.5L19 15"/></svg><span>Fact(uur)checker</span>';
    const ico = anker.querySelector('svg'); if (ico) { const s = link.querySelector('svg'); s.setAttribute('class', ico.getAttribute('class') || ''); }
    link.addEventListener('click', e => { e.preventDefault(); open(); });
    if (anker.parentElement.tagName === 'LI') { const li = document.createElement('li'); li.className = anker.parentElement.className.replace(/\bactive\b/g, '').trim(); li.appendChild(link); anker.parentElement.insertAdjacentElement('afterend', li); }
    else anker.insertAdjacentElement('afterend', link);
  }
  document.addEventListener('click', e => { const a = e.target.closest && e.target.closest('a[href]'); if (opened && a && a !== link && !root.contains(a) && a.getAttribute('href') !== HASH) close(); }, true);
  window.addEventListener('hashchange', () => { if (location.hash === HASH) open(); else close(); });
  window.addEventListener('popstate', () => { if (location.hash === HASH) open(); else close(); });
  window.addEventListener('resize', layout);
  function start() { menu(); if (location.hash === HASH) open(); setInterval(() => { menu(); layout(); }, 1500); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();

    })();
  }
  if (document.documentElement) beDashboardMain();
  else document.addEventListener('DOMContentLoaded', beDashboardMain, {once:true});
})();

// Persistent aFRR BID observations.
(function () {
  'use strict';
  function beBidMain() {
(async function () {
    if (window.__beAfrrBid01) return;
    const QUARTER = 900000, DAY = 86400000, ARCHIVE_DAYS = 7, RECOVERY_REACH = 26 * 3600000;
    const directions = ['import', 'export'];
    const colours = {import: '#b65c72', export: '#73b9a1'};
    function bidColour(direction) {
      return window.BETheme?.seriesColor('bid-'+direction) || colours[direction];
    }
    function beChartRefresh(){
     if(window.BEChartRefresh)return window.BEChartRefresh;
     var pending=new Map(),queued=false;
     function schedule(){
      if(queued||document.hidden||!pending.size)return;
      queued=true;
      (typeof requestAnimationFrame==='function'?requestAnimationFrame:function(f){setTimeout(f,0);})(flush);
     }
     function flush(){
      queued=false;if(document.hidden)return;
      var work=Array.from(pending);pending.clear();
      work.forEach(function(pair){
       var c=pair[0],job=pair[1];if(!c.canvas||c.canvas.isConnected===false)return;
       try{
        var update=job.update;
        job.prepare.forEach(function(prepare){if(prepare())update=true;});
        if(update&&typeof c.update==='function')c.update('none');
        else if(job.draw&&typeof c.draw==='function')c.draw();
       }catch(e){console.error('[BE grafiekupdate]',e);}
      });
     }
     var api={request:function(c,mode,prepare){
      if(!c)return;
      var job=pending.get(c);if(!job){job={update:false,draw:false,prepare:new Set()};pending.set(c,job);}
      if(mode==='update')job.update=true;else if(mode==='draw')job.draw=true;
      if(prepare)job.prepare.add(prepare);
      schedule();
     }};
     document.addEventListener('visibilitychange',schedule);
     window.BEChartRefresh=api;return api;
    }
    const bids = new Map();
    let bidRevision=0;
    function setBid(start,record){
      const previous=bids.get(start);
      if(directions.some(d=>previous?.[d]?.value!==record[d]?.value||previous?.[d]?.observedAt!==record[d]?.observedAt||!!previous?.[d]?.estimated!==!!record[d]?.estimated))bidRevision++;
      bids.set(start,record);
    }
    let library, timer, busy = false, enabled = true, error = '', unavailable = false;
    let lastSuccess = 0, lastLiveQuarter = null, ui, button, status, recovering=false, archiveReady=false, dbPromise, storageError='';
    let recoveryTimer, rateRetryUntil = 0, archiveRead, recoveryMemory={};
    try{enabled=localStorage.getItem('be_afrr_bid_enabled_v1')!=='uit';}catch(_){}
    let customer=(location.pathname.match(/^\/customer\/([^/]+)(?:\/|$)/)||[])[1];
    if(!customer||/^(account|current-prices|current-history|results)$/.test(customer))customer=await window.BEInstallation?.wait();
    if(!customer||window.__beAfrrBid01)return;
    window.__beAfrrBid01 = true;
    const cachePrefix=customer+':';
    const recoveryKey='be_bid_recovery_v1:'+customer;
    const RECOVERY_REVISION='reconstructed-bids-v1';
    const clock = new Intl.DateTimeFormat('nl-NL', {
      timeZone: 'Europe/Amsterdam', hour: '2-digit', minute: '2-digit'
    });
    const euro = n => '€ ' + n.toLocaleString('nl-NL', {minimumFractionDigits: 3, maximumFractionDigits: 3});
    const jsonCache=new Map();
    function read(id) {
      const node=document.getElementById(id),raw=node?.textContent||'null',cached=jsonCache.get(id);
      if(cached?.raw===raw)return cached.value;
      let value=null;try{value=JSON.parse(raw);}catch(_){}
      jsonCache.set(id,{raw,value});return value;
    }
    function quarter(now) { return Math.floor(now / QUARTER) * QUARTER; }

    // API schema/semantics checked against RaginValdr/Balans-energie-Home-assistant-app.
    // Explicit bids have priority. Confirmed quotes may only supply a separately
    // labelled, uncertain reconstruction; never silently turn them into observations.
    function mergeRecord(old, incoming){
      const r={start:incoming.start,end:incoming.end,states:Object.assign({},old?.states,incoming.states)};
      if(old?.quote||incoming.quote)r.quote=!old?.quote?incoming.quote:!incoming.quote?old.quote:
        incoming.quote.seenAt>=old.quote.seenAt?incoming.quote:old.quote;
      const reconstruction={};
      for(const d of directions){
        const a=old?.reconstruction?.[d],b=incoming.reconstruction?.[d];
        if(a||b)reconstruction[d]=!a?b:!b?a:b.at>=a.at?b:a;
      }
      if(Object.keys(reconstruction).length)r.reconstruction=reconstruction;
      for(const d of directions){
        const verdict=reconstruction[d];
        const allowed=value=>!value?.estimated||!verdict||verdict.at<value.observedAt||
          verdict.value!==null&&Math.abs(verdict.value-value.value)<1e-8;
        const a=allowed(old?.[d])?old?.[d]:null,b=allowed(incoming[d])?incoming[d]:null;
        if(a?.estimated&&!b&&incoming.states?.[d]==='missing_bid')continue;
        if(!a&&!b)continue;
        const newest=!a?b:!b?a:!!a.estimated!==!!b.estimated?(a.estimated?b:a):b.observedAt>=a.observedAt?b:a;
        const observations=[a,b].filter(Boolean).flatMap(v=>v.observations||[{value:v.value,observedAt:v.observedAt,...(v.estimated?{estimated:true}:{})}]);
        const seen=new Map();observations.forEach(o=>{
          if(Number.isFinite(o.value)&&Number.isFinite(o.observedAt)&&!!o.estimated===!!newest.estimated)
            seen.set(o.observedAt+':'+o.value,{value:o.value,observedAt:o.observedAt,...(o.estimated?{estimated:true}:{})});
        });
        r[d]=Object.assign({},newest,{observations:[...seen.values()].sort((x,y)=>x.observedAt-y.observedAt)});
      }
      return r;
    }
    function quoteSignature(quote){
      return JSON.stringify([quote.values,quote.states,quote.discovery,quote.available]);
    }
    function reconstructionCandidate(record,direction){
      const quote=record.quote,discovery=quote?.discovery;
      if(!quote||quote.available===false||record.states?.[direction]==='missing_bid'||quote.states?.[direction]!=='confirmed'||discovery?.complete!==true||
        !Number.isFinite(discovery.observedUntil)||discovery.observedUntil<record.start+120000||
        !Array.isArray(discovery.directions)||!Array.isArray(discovery.controlDirections)||
        discovery.directions.includes(direction)||discovery.controlDirections.includes(direction))return null;
      const value=quote.values?.['afrr_'+direction],buy=quote.values?.onbalans_import,sell=quote.values?.onbalans_export;
      if(![value,buy,sell].every(Number.isFinite)||Math.abs(value*100-Math.round(value*100))>1e-7)return null;
      const outside=direction==='import'?value<Math.min(buy,sell)-1e-8:value>Math.max(buy,sell)+1e-8;
      if(!outside)return null;
      const known=record[direction];
      if(known&&!known.estimated&&Math.abs(known.value-value)>1e-8)return null;
      return value;
    }
    function reconstruct(now){
      const records=[...bids.values()],candidates={import:[],export:[]},anchors={import:[],export:[]};
      for(const record of records)for(const direction of directions){
        const known=record[direction],value=reconstructionCandidate(record,direction);
        if(known&&!known.estimated)anchors[direction].push({start:record.start,value:known.value});
        if(value!==null)candidates[direction].push({start:record.start,value});
      }
      for(const record of records){
        const incoming={start:record.start,end:record.end,states:{},reconstruction:{}};
        for(const direction of directions){
          const previous=record[direction];
          if(previous&&!previous.estimated)continue;
          const value=reconstructionCandidate(record,direction);
          // Require another independent quarter nearby, never an earlier estimate.
          const repeated=value!==null&&[...candidates[direction],...anchors[direction]].some(other=>
            other.start!==record.start&&Math.abs(other.start-record.start)<=2*3600000&&Math.abs(other.value-value)<1e-8);
          if(!repeated){
            if(previous?.estimated)incoming.reconstruction[direction]={at:now,value:null};
            continue;
          }
          incoming[direction]=previous?.estimated&&previous.value===value?previous:
            {value,observedAt:now,source:'gereconstrueerd uit API-prijsgrens',estimated:true};
          if(record.reconstruction?.[direction]?.value!==value)incoming.reconstruction[direction]={at:now,value};
        }
        if(!directions.some(d=>incoming[d])&&!Object.keys(incoming.reconstruction).length)continue;
        const merged=mergeRecord(record,incoming);
        if(JSON.stringify(record)!==JSON.stringify(merged)){setBid(record.start,merged);persist(merged);}
      }
    }
    function database(){
      if(!dbPromise)dbPromise=new Promise((resolve,reject)=>{const req=indexedDB.open('balansenergie-bids-v1',1);req.onupgradeneeded=()=>req.result.createObjectStore('kwartieren',{keyPath:'id'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);req.onblocked=()=>reject(Error('BID-archief geblokkeerd'));});
      return dbPromise;
    }
    async function persist(record){
      if(!directions.some(d=>record[d])&&!record.quote)return;
      try{
        const db=await database();await new Promise((resolve,reject)=>{
          const tx=db.transaction('kwartieren','readwrite'),store=tx.objectStore('kwartieren'),id=cachePrefix+record.start,req=store.get(id);
          req.onsuccess=()=>store.put(Object.assign(mergeRecord(req.result,record),{id,customer}));
          tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(tx.error||Error('BID opslaan mislukt'));
        });storageError='';
      }catch(e){storageError='BID-cache niet opgeslagen: '+e.message;}
    }
    function readArchive(){
      if(archiveRead)return archiveRead;
      archiveRead=(async()=>{
        const db=await database();
        const rows=await new Promise((resolve,reject)=>{
          const tx=db.transaction('kwartieren','readonly');
          const req=tx.objectStore('kwartieren').getAll(IDBKeyRange.bound(cachePrefix+(quarter(Date.now())-ARCHIVE_DAYS*DAY),cachePrefix+'9999999999999'));
          req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
        });
        rows.forEach(r=>{if(r.customer===customer&&Number.isFinite(r.start)&&r.end===r.start+QUARTER)setBid(r.start,mergeRecord(r,bids.get(r.start)||r));});
      })().finally(()=>{archiveRead=null;});
      return archiveRead;
    }
    async function hydrate(){
      try{
        await readArchive();
      }catch(e){storageError='BID-cache niet leesbaar: '+e.message;}
      // Oude bronresponsen kunnen nog expliciet gemarkeerde biedprijzen bevatten.
      try{
        const db=await new Promise((resolve,reject)=>{const req=indexedDB.open('balansenergie-bronnen-v1',1);req.onupgradeneeded=()=>req.result.createObjectStore('dagen');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});
        const saved=await new Promise((resolve,reject)=>{const req=db.transaction('dagen','readonly').objectStore('dagen').get(customer+':prijzen');req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});db.close();
        if(saved?.rows)ingest({prices:saved.rows},Date.now(),true);
      }catch(_){}
      reconstruct(Date.now());archiveReady=true;refresh();poll();scheduleRecovery();
    }
    function ingest(payload, now, historical=false) {
      if (!payload || !Array.isArray(payload.prices)) throw Error('Onbekend API-antwoord');
      if(!historical)unavailable = payload.afrrAvailable === false;
      const discovery=new Map((payload.afrrDiscovery||[]).map(row=>[row.start,row]));
      let added=0;
      for(const r of payload.prices){
      const start=r.start;
      if(!Number.isFinite(start)||start%QUARTER!==0||r.end!==start+QUARTER||start>now||r.carried)continue;
      const old=bids.get(start),record={start,end:r.end,states:{}};
      const discovered=discovery.get(start);
      if(discovered){
        const seenAt=Number.isFinite(r.checkedAt)?r.checkedAt:Number.isFinite(payload.generatedAt)?payload.generatedAt:now;
        const quote={values:{...r.values},states:{...r.afrrBidStatus},available:payload.afrrAvailable,
          discovery:{complete:discovered.complete,observedUntil:discovered.observedUntil,
            directions:discovered.directions,controlDirections:discovered.controlDirections},seenAt};
        if(!old?.quote||seenAt>=old.quote.seenAt)
          record.quote=old?.quote&&quoteSignature(old.quote)===quoteSignature(quote)?old.quote:quote;
      }
      for (const direction of directions) {
        const state = r.afrrBidStatus?.[direction];
        const value = r.values?.['afrr_' + direction];
        if(typeof state==='string')record.states[direction] = state;
        if (state === 'bid_fallback' && Number.isFinite(value)) {
          const previous=old?.[direction];
          record[direction] = previous&&!previous.estimated&&previous.value===value?previous:{value, observedAt: now,source:historical?'historische bron':'live'};
          if(!previous)added++;
        }
        // A subsequent confirmed quote must not replace the captured bid.
      }
      const merged=mergeRecord(old,record);setBid(start,merged);
      if(JSON.stringify(old)!==JSON.stringify(merged))persist(merged);
      }
      // Alleen de werkset in geheugen begrenzen; opgeslagen BIDs worden niet verwijderd.
      for (const key of bids.keys()) if (key < quarter(now) - ARCHIVE_DAYS * DAY) {bids.delete(key);bidRevision++;}
      reconstruct(now);
      return added;
    }
    function displayPrice(value, direction, tariff, settings) {
      if (!tariff?.allin) return value;
      if (!settings || !['btw', 'eb', 'opslag'].every(k => Number.isFinite(settings[k])) ||
          typeof settings.saldeert !== 'boolean') return null;
      return direction === 'import'
        ? value * settings.btw + settings.opslag + settings.eb
        : value * settings.btw - settings.opslag + (settings.saldeert ? settings.eb : 0);
    }
    function points(direction, tariff, settings) {
      const out = [];
      if (!enabled || !tariff?.aan) return out;
      for (const r of [...bids.values()].sort((a,b) => a.start - b.start)) {
        if (!r[direction]) continue;
        const y = displayPrice(r[direction].value, direction, tariff, settings);
        if (!Number.isFinite(y)) continue;
        // Explicit gaps: no interpolation or carrying a bid into another quarter.
        const extra = {bidStart: r.start, bidEnd: r.end, observedAt: r[direction].observedAt,estimated:r[direction].estimated===true};
        out.push({x: r.start, y: null}, {x: r.start, y, ...extra},
          {x: r.end, y, ...extra}, {x: r.end, y: null});
      }
      return out;
    }
    // Resolve each series by time: price, BID and EPEX point counts differ.
    function tariffItems(chart, event) {
      const area = chart.chartArea, px = event.x;
      if (!area || !Number.isFinite(px) || px < area.left || px > area.right ||
          (Number.isFinite(event.y) && (event.y < area.top || event.y > area.bottom))) return [];
      const t = chart.scales.x.getValueForPixel(px);
      if (!Number.isFinite(t)) return [];
      chart.$beTariefHoverTime = t;
      const period = (chart.$beKwartieren || []).find(r => r.start <= t && t < r.end);
      const items = [];
      chart.data.datasets.forEach((dataset, datasetIndex) => {
        if (!chart.isDatasetVisible(datasetIndex)) return;
        const data = dataset.data || [];
        let lo = 0, hi = data.length;
        while (lo < hi) {
          const mid = (lo + hi) >> 1;
          if (data[mid].x <= t) lo = mid + 1;
          else hi = mid;
        }
        const index = lo - 1, point = data[index];
        if (!point || !Number.isFinite(point.y)) return;
        if (dataset.beBidDirection) {
          if (!(point.bidStart <= t && t < point.bidEnd)) return;
        } else if (dataset.beEpex) {
          const next = data[index + 1];
          if (!next || !Number.isFinite(next.y) || !(point.x <= t && t < next.x)) return;
        } else {
          if (!period || period.wacht || point.x < period.start || point.x >= period.end || t > data.at(-1).x) return;
        }
        const element = chart.getDatasetMeta(datasetIndex).data[index];
        if (element && !element.skip) items.push({element, datasetIndex, index});
      });
      return items;
    }
    function atHoverTime(chart, items) {
      const t = chart.$beTariefHoverTime;
      return Number.isFinite(t) ? items.map(i => ({...i, parsed: {...i.parsed, x: t}})) : items;
    }
    function overlaySignature(tariff,settings){
      return JSON.stringify([bidRevision,enabled,tariff?.aan,tariff?.allin,
        settings?.btw,settings?.eb,settings?.opslag,settings?.saldeert,bidColour('import'),bidColour('export'),window.BETheme?.isDark()]);
    }
    const overlaySignatures=new WeakMap();
    function prepareOverlay(chart){
      const tariff=read('be-tarief-data'),settings=read('be-actueel-allin-data');
      return overlaySignatures.get(chart)!==overlaySignature(tariff,settings)||directions.some(d=>!chart.data.datasets.some(s=>s.beBidDirection===d));
    }
    const plugin = {
      id: 'beAfrrBidOverlay01',
      beforeUpdate(chart) {
        if (chart.canvas?.id !== 'be-tarief-chart') return;
        const tariff = read('be-tarief-data'), settings = read('be-actueel-allin-data');
        const signature=overlaySignature(tariff,settings),changed=overlaySignatures.get(chart)!==signature;
        for (const direction of directions) {
          let dataset = chart.data.datasets.find(d => d.beBidDirection === direction);
          const created=!dataset;
          if (!dataset) {
            dataset = {
              beBidDirection: direction,
              label: 'BID ' + direction,
              borderColor: bidColour(direction), backgroundColor: bidColour(direction),
              borderDash: [], borderWidth: 1.5, pointRadius: 0,
              pointHitRadius: 8, fill: false, tension: 0, spanGaps: false,
              stepped: false, order: -5,
              tooltip: {callbacks: {
                label: context => 'BID ' + direction + (context.raw?.estimated?' (gereconstrueerd): ~ ':': ') + euro(context.parsed.y) + ' / kWh',
                afterLabel: context => {
                  const r = context.raw;
                  return r?.bidStart == null ? '' : clock.format(r.bidStart) + '–' + clock.format(r.bidEnd) +
                    (r.estimated?' · gereconstrueerde biedgrens, onzeker':' · waargenomen biedprijs');
                }
              }}
            };
            chart.data.datasets.push(dataset);
          }
          if(changed||created)dataset.data = points(direction, tariff, settings);
          dataset.borderWidth=window.BETheme?.isDark()?1:1.5;
          dataset.borderColor=bidColour(direction);
          dataset.backgroundColor=dataset.borderColor;
        }
        overlaySignatures.set(chart,signature);
        const options = chart.config.options;
        options.interaction = {...options.interaction, mode: 'beTariefTime', axis: 'x', intersect: false};
        options.plugins = options.plugins || {};
        const tooltip = options.plugins.tooltip = options.plugins.tooltip || {};
        tooltip.mode = 'beTariefTime';
        const callbacks = tooltip.callbacks = tooltip.callbacks || {};
        if (!callbacks.title?.beBidTimeWrapped) {
          const original = callbacks.title;
          const wrapped = function (items) {
            const timed = atHoverTime(chart, items);
            return original ? original.call(this, timed) : timed.length ? clock.format(timed[0].parsed.x) : '';
          };
          wrapped.beBidTimeWrapped = true;
          callbacks.title = wrapped;
        }
        if (callbacks && !callbacks.afterBody?.beBidWrapped) {
          const original = callbacks.afterBody;
          const wrapped = function (items) {
            const regular = atHoverTime(chart, items.filter(i => !i.dataset.beBidDirection));
            const result = regular.length && original ? original.call(this, regular) : [];
            const lines = Array.isArray(result) ? result : result ? [result] : [];
            if(!items.some(i=>i.dataset.beBidDirection))return lines;
            return lines.concat(items.some(i=>i.dataset.beBidDirection&&i.raw?.estimated)?
              'Gereconstrueerd = vermoedelijke biedgrens; niet rechtstreeks als bod waargenomen.':
              'BID = bod; geen bevestigde handelsprijs.');
          };
          wrapped.beBidWrapped = true;
          callbacks.afterBody = wrapped;
        }
      }
    };
    function ensureUI() {
      const row = document.getElementById('be-tarief-row');
      if (!row) return;
      if (!document.getElementById('be-afrr-bid-style')) {
        const style = document.createElement('style');
        style.id = 'be-afrr-bid-style';
        style.textContent = `
          #be-afrr-bid-status{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:nowrap;width:100%;box-sizing:border-box;font:11px/1.5 system-ui,sans-serif;margin:6px 0;color:inherit}
          #be-afrr-bid-status>[role="status"]{flex:0 1 auto;min-width:0;max-width:100%;text-align:right;overflow-wrap:anywhere}
          #be-afrr-bid-switch{appearance:none;display:inline-flex;align-items:center;gap:9px;flex:0 0 auto;border:0;padding:3px 2px;background:transparent;color:inherit;font:500 11px/1.2 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;white-space:nowrap;cursor:pointer;box-shadow:none;margin:0;min-height:24px}
          #be-afrr-bid-switch:focus-visible{outline:2px solid #429ee8;outline-offset:4px;border-radius:4px}
          #be-afrr-bid-switch .be-afrr-bid-track{position:relative;width:34px;height:18px;flex:none;border-radius:10px;background:#868892;box-shadow:inset 0 0 0 1px rgba(0,0,0,.1)}
          #be-afrr-bid-switch .be-afrr-bid-thumb{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;background:#fff;box-shadow:0 1px 3px #0004;transition:transform .15s}
          #be-afrr-bid-switch[aria-checked="true"] .be-afrr-bid-track{background:#287dbb}
          #be-afrr-bid-switch[aria-checked="true"] .be-afrr-bid-thumb{transform:translateX(16px)}
          #be-afrr-bid-switch .be-afrr-bid-state{min-width:24px;font-size:10px;font-weight:700;letter-spacing:.02em}
          html[data-be-dark="aan"] #be-afrr-bid-switch .be-afrr-bid-track{background:#65615b!important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.25)!important}
          html[data-be-dark="aan"] #be-afrr-bid-switch[aria-checked="true"] .be-afrr-bid-track{background:#287dbb!important}
          html[data-be-dark="aan"] #be-afrr-bid-switch .be-afrr-bid-thumb{background:#fff!important;box-shadow:0 1px 3px #0004!important}
          @media(max-width:700px){#be-afrr-bid-switch{border-left:0}}
          @media(prefers-reduced-motion:reduce){#be-afrr-bid-switch .be-afrr-bid-thumb{transition:none}}
        `;
        document.documentElement.appendChild(style);
      }
      if (ui?.isConnected && ui.parentElement === row) return;
      ui?.remove();
      ui = document.createElement('div');
      ui.id = 'be-afrr-bid-status';
      button = document.createElement('button');
      button.id = 'be-afrr-bid-switch';
      button.type = 'button';
      button.setAttribute('role', 'switch');
      button.setAttribute('aria-label', 'aFRR-biedlijnen');
      button.innerHTML = '<span>aFRR BID</span><span class="be-afrr-bid-track" aria-hidden="true"><span class="be-afrr-bid-thumb"></span></span><span class="be-afrr-bid-state" aria-hidden="true"></span>';
      button.title = 'aFRR-biedlijnen tonen of verbergen. Vastgelegde biedingen blijven bewaard.';
      button.onclick = () => {
        enabled = !enabled;
        try { localStorage.setItem('be_afrr_bid_enabled_v1', enabled ? 'aan' : 'uit'); } catch (_) {}
        refresh();
      };
      status = document.createElement('span');
      status.setAttribute('role', 'status');
      ui.append(status,button); row.appendChild(ui);
    }
    function refresh() {
      ensureUI();
      const C = window.Chart;
      if (C?.register && library !== C) {
        C.Interaction.modes.beTariefTime = tariffItems;
        C.register(plugin); library = C;
      }
      const chart = C?.getChart?.('be-tarief-chart');
      if (chart) beChartRefresh().request(chart,'prepare',()=>prepareOverlay(chart));
      if (!status) return;
      if(button.getAttribute('aria-checked')!==String(enabled))button.setAttribute('aria-checked', String(enabled));
      const state=button.querySelector('.be-afrr-bid-state'),label=enabled?'AAN':'UIT';if(state.textContent!==label)state.textContent=label;
      const now = Date.now(), start = quarter(now), record = bids.get(start);
      const tariff = read('be-tarief-data'), settings = read('be-actueel-allin-data');
      const prefix = clock.format(start) + '–' + clock.format(start + QUARTER) + ' · ';
      const labels = directions.map(direction => {
        const bid = record?.[direction];
        if (bid) {
          const value = displayPrice(bid.value, direction, tariff, settings);
          return direction + ' ' + (Number.isFinite(value) ? (bid.estimated?'~ ':'')+euro(value) + '/kWh' : 'all-in instellingen ontbreken');
        }
        if (record?.states[direction] === 'missing_bid') return direction + ' geen bod';
        return direction + (now - start < 120000 ? ' wachten op bod' : ' bod niet waargenomen');
      });
      const message = prefix + (unavailable ? 'aFRR niet beschikbaar' : labels.join(' · ')) +
        (storageError?' · '+storageError:'')+(error ? ' · ' + error : '') + (!error && lastSuccess && now - lastSuccess > 90000 ? ' · gegevens verouderd' : '');
      if(status.textContent!==message)status.textContent=message;
      ui.title = 'BID = biedprijs; ~ betekent een onzekere reconstructie uit historische prijsgrenzen. Rechtstreeks waargenomen biedingen hebben voorrang. ' +
        (tariff?.allin ? 'All-in, volgens de instellingen van de hoofdplugin.' : 'Kale bedragen.');
    }
    function apiRetryUntil(){
      try{const shared=Number(localStorage.getItem('be_api_retry_until')||0);if(Number.isFinite(shared))rateRetryUntil=Math.max(rateRetryUntil,shared);}catch(_){}
      return rateRetryUntil;
    }
    function request(url) {
      return new Promise((resolve, reject) => {
        if(Date.now()<apiRetryUntil()){
          const failure=Error('API vraagt om even te wachten');failure.status=429;reject(failure);return;
        }
        // Own same-origin read request, unaffected by the main plugin's fetch/cache wrappers.
        const xhr = new XMLHttpRequest();
        xhr.open('GET', url); xhr.timeout = 12000;
        xhr.onload = () => {
          if (xhr.status !== 200) {
            const failure=Error('API HTTP '+xhr.status);
            failure.status=xhr.status;
            if(xhr.status===429){
              const header=xhr.getResponseHeader('Retry-After'),seconds=Number(header);
              const retry=header?(Number.isFinite(seconds)?Date.now()+seconds*1000:Date.parse(header)):NaN;
              rateRetryUntil=Math.max(apiRetryUntil(),Number.isFinite(retry)?Math.max(Date.now()+1000,retry):Date.now()+60000);
              try{localStorage.setItem('be_api_retry_until',String(rateRetryUntil));}catch(_){}
            }
            return reject(failure);
          }
          if (!/json/i.test(xhr.getResponseHeader('content-type') || '')) return reject(Error('API niet beschikbaar; controleer login'));
          try { resolve(JSON.parse(xhr.responseText)); } catch (_) { reject(Error('Ongeldig API-antwoord')); }
        };
        xhr.onerror = () => reject(Error('API niet bereikbaar'));
        xhr.ontimeout = () => reject(Error('API time-out'));
        xhr.send();
      });
    }
    async function poll() {
      if (busy) return;
      clearTimeout(timer);
      busy = true;
      try {
        // Collection is independent of chart visibility, page and the BID switch.
        // Reuse fresh native price responses; closed/suspended browsers cannot poll.
        if (archiveReady && Date.now()>=apiRetryUntil()) {
          const now = Date.now();
          const freshFor=now-quarter(now)<120000?15000:55000;
          if(lastLiveQuarter!==quarter(now)||now-lastSuccess>=freshFor){
            const payload = await request('/customer/current-prices/api/?start=' + quarter(now) + '&end=' + now);
            ingest(payload, Date.now());
            if(payload.prices.some(r=>r.start===quarter(Date.now()))){
              const changed=lastLiveQuarter!==quarter(Date.now());
              lastSuccess=Date.now();lastLiveQuarter=quarter(lastSuccess);
              if(changed)scheduleRecovery(Math.max(4000,lastLiveQuarter+120000-Date.now()));
            }
            error = '';
          }
        }
      } catch (e) { error = e.message; }
      finally {
        busy = false;
        refresh();
        const pos = Date.now() % QUARTER;
        const delay = Math.max(apiRetryUntil()-Date.now(),pos < 120000 ? 15000 - pos % 15000 : Math.min(60000, QUARTER - pos));
        timer = setTimeout(poll, Math.max(1000, delay));
      }
    }
    function scheduleRecovery(delay=4000){
      clearTimeout(recoveryTimer);recoveryTimer=setTimeout(recover,Math.max(1000,delay));
    }
    function latestMissing(from,to){
      for(let t=quarter(to);t>=from;t-=QUARTER){
        if(t>=to)continue;
        const row=bids.get(t);
        if(directions.some(d=>(!row?.[d]||row[d].estimated)&&row?.states?.[d]!=='missing_bid'))return t;
      }
      return null;
    }
    function recoveryState(){
      try{
        const saved=JSON.parse(localStorage.getItem(recoveryKey)||'{}');
        if(saved&&typeof saved==='object'&&!Array.isArray(saved))for(const [key,value] of Object.entries(saved)){
          if(value&&Number.isFinite(value.checkedAt)&&value.checkedAt>(recoveryMemory[key]?.checkedAt||0))recoveryMemory[key]=value;
        }
      }catch(_){}
      return {...recoveryMemory};
    }
    function saveRecovery(saved,now){
      for(const key of Object.keys(saved))if(Number(key)<quarter(now)-ARCHIVE_DAYS*DAY-DAY)delete saved[key];
      recoveryMemory=saved;
      try{localStorage.setItem(recoveryKey,JSON.stringify(saved));}catch(_){}
    }
    async function recover(){
      if(recovering||!archiveReady)return;
      const now=Date.now(),position=now%QUARTER;
      // Reserve the first two minutes for collecting the live bid, not backfill.
      if(position<120000||now<apiRetryUntil()){scheduleRecovery(Math.max(120000-position,apiRetryUntil()-now));return;}
      recovering=true;let delay=4000;
      try{
        const work=async()=>{
          try{await readArchive();}catch(_){} // API recovery still works if local storage is unavailable.
          // 6.8.2: current-prices weigert sinds 17-11-2026 bereiken ouder dan ~27 uur (HTTP 400).
          const at=Date.now(),today=Math.floor(at/DAY)*DAY,horizon=Math.max(quarter(at)-ARCHIVE_DAYS*DAY,quarter(at-RECOVERY_REACH)),saved=recoveryState();
          let range;
          for(let day=today;day+DAY>horizon;day-=DAY){
            const from=Math.max(day,horizon),to=Math.min(day+DAY,at),missing=latestMissing(from,to),previous=saved[day];
            if(missing===null||previous?.revision===RECOVERY_REVISION&&previous.nextAt>at&&previous.until>missing)continue;
            range={day,from,to};break;
          }
          if(!range){delay=3600000;return;}
          try{
            const payload=await request('/customer/current-prices/api/?start='+range.from+'&end='+range.to);
            ingest(payload,Date.now(),true);
            saved[range.day]={revision:RECOVERY_REVISION,until:range.to,checkedAt:Date.now(),nextAt:Date.now()+(range.day===today?3600000:DAY)};
          }catch(failure){
            delay=Math.max(300000,apiRetryUntil()-Date.now());
            // Een geweigerd bereik (400) wordt niet elke 5 minuten opnieuw gevraagd.
            saved[range.day]={revision:RECOVERY_REVISION,until:range.to,checkedAt:Date.now(),nextAt:Date.now()+(failure&&failure.status===400?DAY:delay)};
          }
          saveRecovery(saved,Date.now());
        };
        // Tabs share recovery metadata and, where supported, the request lock.
        if(globalThis.navigator?.locks?.request)await navigator.locks.request('be-bid-recovery:'+customer,{ifAvailable:true},lock=>lock?work():undefined);
        else await work();
      }catch(_){delay=300000;}
      finally{recovering=false;refresh();scheduleRecovery(delay);}
    }
    document.addEventListener('be-afrr-source',e=>{try{
      const now=Date.now();ingest(e.detail,now);
      if(e.detail.prices.some(r=>r.start===quarter(now))){
        const changed=lastLiveQuarter!==quarter(now);
        lastSuccess=now;lastLiveQuarter=quarter(now);error='';
        if(changed)scheduleRecovery(Math.max(4000,lastLiveQuarter+120000-now));
      }
      refresh();
    }catch(_){}});
    document.addEventListener('be-tarief-update', refresh);
    document.addEventListener('be-actueel-allin-update', refresh);
    document.addEventListener('be-dark-change', refresh);
    async function resume(){
      try{await readArchive();}catch(_){}
      reconstruct(Date.now());refresh();poll();scheduleRecovery();
    }
    document.addEventListener('visibilitychange', () => {if (!document.hidden) resume();});
    window.addEventListener('pageshow',resume);
    hydrate();
})();
  }
  if (document.documentElement) beBidMain();
  else document.addEventListener('DOMContentLoaded', beBidMain, {once:true});
})();

// Independent SOC, shared hover, capacity UI and mobile chart recovery.
(function () {
  'use strict';
  function beCoulombMain() {
if(window.__beCoulombPage64)return;window.__beCoulombPage64=true;
(function(){
  'use strict';
  if(window.__beChartVisibility606)return;window.__beChartVisibility606=true;
  const ids=['battery-chart','be-tarief-chart','soc-chart','soc-forecast-chart'],seen=new WeakMap(),watched=new WeakSet();
  let queued=false;
  function schedule(){if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;repair();});}
  const resize=typeof ResizeObserver==='function'?new ResizeObserver(schedule):null;
  const intersect=typeof IntersectionObserver==='function'?new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting))schedule();}):null;
  function repair(){
    if(document.hidden)return;
    const C=window.Chart;if(!C?.getChart)return;
    for(const id of ids){
      const canvas=document.getElementById(id);if(!canvas?.isConnected)continue;
      const parent=canvas.parentElement;if(!parent)continue;
      if(!watched.has(parent)){resize?.observe(parent);intersect?.observe(parent);watched.add(parent);}
      const box=parent.getBoundingClientRect(),chart=C.getChart(canvas),before=seen.get(canvas);
      if(!chart||!(box.width>0&&box.height>0)||canvas.getClientRects().length===0){seen.delete(canvas);continue;}
      const changed=!before||before.chart!==chart||Math.abs(before.w-box.width)>1||Math.abs(before.h-box.height)>1;
      if(changed||!(chart.width>0&&chart.height>0)){
        // Remember first: resize/update may synchronously notify other extensions.
        seen.set(canvas,{chart,w:box.width,h:box.height});
        try{chart.resize();chart.update('none');}catch(e){seen.delete(canvas);console.warn('[BE grafiekherstel]',id,e);}
      }
    }
  }
  new MutationObserver(records=>{
    const added=records.flatMap(r=>Array.from(r.addedNodes));
    if(added.some(n=>n.nodeType===1&&(n.matches?.('canvas')||n.querySelector?.('canvas'))))schedule();
  }).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('visibilitychange',schedule);
  window.addEventListener('pageshow',schedule);
  window.addEventListener('resize',schedule);
  window.addEventListener('orientationchange',schedule);
  window.visualViewport?.addEventListener('resize',schedule);
  setInterval(schedule,2000);schedule();
})();

/* Measured 16S LFP voltage profile: RS232 logs 9–12, 19 and 25 October 2026.
   Reported BMS SOC selects voltage; SOC itself is integrated from estimated Ah.
   No fixed loss factor. This is a voltage estimate, not a voltage sensor. */
(function(root){
  'use strict';
  const profile={"series_cells_per_pack":16,"reference_ah_per_pack":330.0,"models":{"charge":{"soc_percent":[0.0,2.0,5.0,8.0,10.0,15.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,85.0,90.0,95.0,98.0,100.0],"zero_current_voltage_v":[45.04873667,46.21263523,48.01104624,48.01104624,51.33626837,51.63642474,52.110589,52.93937053,52.93937053,53.05079145,53.34006213,53.50776963,53.62106119,54.04416067,54.80427031,55.01987558,55.94997012,55.94997012],"voltage_per_c_rate_v":4.19762928},"discharge":{"soc_percent":[0.0,2.0,5.0,8.0,10.0,15.0,20.0,30.0,40.0,50.0,60.0,70.0,80.0,85.0,90.0,95.0,98.0,100.0],"zero_current_voltage_v":[44.92394152,47.65484755,47.65484755,47.65484755,47.65484755,48.37198358,51.17052752,52.63147204,52.63147204,52.73339626,53.05859432,53.32539778,53.32539778,53.32539778,53.32539778,53.32539778,53.50611041,55.35587888],"voltage_per_c_rate_v":4.64643859}},"id":"rs232-16s-20261026-v1","minimumSoc":4.0024,"minimumVoltage":46.643,"maximumVoltage":56.33};
  const finite=Number.isFinite,clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function base(direction,soc){
    const m=profile.models[direction],s=clamp(finite(soc)?soc:50,profile.minimumSoc,100),x=m.soc_percent,y=m.zero_current_voltage_v;
    let i=1;while(i<x.length-1&&x[i]<s)i++;
    return y[i-1]+(y[i]-y[i-1])*(s-x[i-1])/(x[i]-x[i-1]);
  }
  // Mean of the measured charge/discharge curves, integrated over SOC.
  // Used only for kWh/Ah capacity display; actual counting uses varying voltage.
  const referenceVoltage=(()=>{let total=0;for(let s=0;s<100;s+=.5)total+=(base('charge',s+.25)+base('discharge',s+.25))*.25;return total/100;})();
  // Ah-SOC is not an energy percentage. Integrate the same reference curve
  // over the remaining charge; this estimates energy without changing SOC.
  // Keep the existing measured range and its uncertainty at the bottom.
  const energyCurve=(()=>{const values=[0];for(let s=0;s<100;s+=.5)
    values.push(values.at(-1)+(base('charge',s+.25)+base('discharge',s+.25))*.25);
    return values.map(v=>v/values.at(-1));})();
  function energyKwh(soc,capacity){
    if(!finite(soc)||!finite(capacity)||capacity<=0)return null;
    const position=clamp(soc,0,100)*2,index=Math.floor(position);
    const fraction=index===200?1:energyCurve[index]+(energyCurve[index+1]-energyCurve[index])*(position-index);
    return capacity*fraction;
  }
  function current(powerOut,soc,capacityAh){
    if(!finite(powerOut)||!finite(capacityAh)||capacityAh<=0)return null;
    if(powerOut===0)return 0;
    const p=-powerOut,direction=p>0?'charge':'discharge',u=base(direction,soc),r=profile.models[direction].voltage_per_c_rate_v/capacityAh;
    const discriminant=u*u+4*r*p;
    let i=discriminant>0?2*p/(u+Math.sqrt(discriminant)):p/profile.minimumVoltage;
    const voltage=clamp(i?p/i:u,profile.minimumVoltage,profile.maximumVoltage);
    return p/voltage; // Positive current charges the battery.
  }
  function integrate(p0,p1,ms,s0,s1,capacityAh){
    if(p0*p1<0){const f=Math.abs(p0)/(Math.abs(p0)+Math.abs(p1)),s=s0+(s1-s0)*f;
      const a=integrate(p0,0,ms*f,s0,s,capacityAh),b=integrate(0,p1,ms*(1-f),s,s1,capacityAh);
      return {input:a.input+b.input,output:a.output+b.output};}
    const a=current(p0,s0,capacityAh),b=current(p1,s1,capacityAh);
    if(a===null||b===null)return null;
    const ah=(a+b)*.5*ms/3600000;return {input:Math.max(0,ah),output:Math.max(0,-ah)};
  }
  root.BEMeasuredVoltage={id:profile.id,profile,referenceVoltage,base,current,integrate,energyKwh};
})(typeof window!=='undefined'?window:globalThis);

/* BE-only energy balance. Positive bo is battery output in W. */
(function(root){
  'use strict';
  const defaults={capacity:48.2,chargeEfficiency:1,dischargeEfficiency:1,maxGapMs:360000,auto:true};
  const rawValid=v=>Number.isFinite(v)&&v>=0&&v<=100;
  function valid(r){return Array.isArray(r)&&Number.isFinite(r[0])&&r[0]>0&&(Number.isFinite(r[2])||r[2]===null);}
  function energy(p0,p1,ms){
    if(p0*p1<0){const f=Math.abs(p0)/(Math.abs(p0)+Math.abs(p1)),a=energy(p0,0,ms*f),b=energy(0,p1,ms*(1-f));return {input:a.input+b.input,output:a.output+b.output};}
    const e=(p0+p1)/2*ms/3600000000;return {input:Math.max(0,-e),output:Math.max(0,e)};
  }
  function calculate(rows,settings={},manual=[]){
    const c={...defaults,...settings};if(!(c.capacity>0))throw Error('Ongeldige accucapaciteit');
    rows=[...new Map(rows.filter(valid).map(r=>[r[0],r])).values()].sort((a,b)=>a[0]-b[0]);
    const anchors=new Map(manual.filter(a=>Number.isFinite(a.t)&&rawValid(a.soc)).map(a=>[a.t,a]));
    const voltage=c.voltageProfile&&root.BEMeasuredVoltage,ahMode=!!(voltage&&Number.isFinite(c.capacityAh)&&c.capacityAh>0);
    let stored=null,input=0,output=0,inputAh=0,outputAh=0,gaps=0,uncertain=false,lastAnchor=null,lowMode='ready',lowMinimum=null,highMode='ready',highMaximum=null,lastRaw=null;
    const points=[],events=[];
    for(let i=0;i<rows.length;i++){
      const r=rows[i],prev=rows[i-1],raw=rawValid(r[1])?r[1]:null;let gap=false,change=null;
      if(prev){
        const dt=r[0]-prev[0];
        if(Number.isFinite(prev[2])&&Number.isFinite(r[2])){
          const e=energy(prev[2],r[2],dt);input+=e.input;output+=e.output;change=e.input-e.output;
          if(ahMode){
            const s0=rawValid(prev[1])?prev[1]:lastRaw??stored??50,s1=raw??s0;
            const ah=voltage.integrate(prev[2],r[2],dt,s0,s1,c.capacityAh);
            inputAh+=ah.input;outputAh+=ah.output;
            if(stored!==null)stored+=100*(ah.input-ah.output)/c.capacityAh;
          }else if(stored!==null)stored+=100*change/c.capacity;
          if(dt>c.maxGapMs){gap=true;gaps++;uncertain=true;}
        }else{gap=true;gaps++;uncertain=true;}
      }
      const explicit=anchors.get(r[0]),checkpoint=!!(explicit?.lowState||explicit?.highState||explicit?.boundaryState);
      let anchor=explicit;
      if(stored===null&&!anchor&&raw!==null)anchor={t:r[0],soc:raw,kind:'Start uit BE-SOC'};
      const charging=change!==null?change>0:!prev&&!checkpoint&&Number.isFinite(r[2])&&r[2]<0;
      const discharging=change!==null?change<0:!prev&&!checkpoint&&Number.isFinite(r[2])&&r[2]>0;
      if(checkpoint){
        if(explicit.lowState){lowMode=explicit.lowState.mode;lowMinimum=explicit.lowState.minimum;}
        if(explicit.highState){highMode=explicit.highState.mode;highMaximum=explicit.highState.maximum;}
        if(explicit.boundaryState)lastRaw=explicit.boundaryState.lastRaw;
      }else if(explicit){lowMode=highMode='released';lowMinimum=highMaximum=null;}
      else{
        if(lowMode==='released'&&raw!==null&&raw>10&&change!==null&&change<=0&&r[2]>=0){lowMode='ready';lowMinimum=null;}
        if(highMode==='released'&&raw!==null&&raw<95&&change!==null&&change>=0&&r[2]<=0){highMode='ready';highMaximum=null;}
        if(lowMode==='ready'&&raw!==null&&raw<=10){
          if(charging)lowMode='released';
          else{lowMode='tracking';lowMinimum=raw;anchor={t:r[0],soc:raw,kind:'Laagste BE-SOC · volgen'};}
        }
        if(lowMode==='tracking'){
          if(charging)lowMode='released';
          else if(raw!==null){
            const lower=lowMinimum===null||raw<lowMinimum;if(lower)lowMinimum=raw;
            anchor={t:r[0],soc:lowMinimum,kind:'Laagste BE-SOC · volgen',silent:!lower&&anchor?.kind!=='Laagste BE-SOC · volgen'};
            highMode='ready';highMaximum=null;
          }
        }
        if(highMode==='ready'&&raw!==null&&raw>=95){
          if(discharging)highMode='released';
          else{highMode='tracking';highMaximum=raw;anchor={t:r[0],soc:raw,kind:'Hoogste BE-SOC · volgen'};}
        }
        if(highMode==='tracking'){
          if(discharging)highMode='released';
          else if(raw!==null){
            const higher=highMaximum===null||raw>highMaximum;if(higher)highMaximum=raw;
            anchor={t:r[0],soc:highMaximum,kind:'Hoogste BE-SOC · volgen',silent:!higher&&anchor?.kind!=='Hoogste BE-SOC · volgen'};
            lowMode='ready';lowMinimum=null;
          }
        }
      }
      // A real arrival at 5% or 100% is an independent calibration, even
      // when a prior energy reversal released the broad 10%/95% tracker.
      // A plateau must not pin the counter after charging/discharging reverses.
      if(!explicit&&(raw===5||raw===100)&&raw!==lastRaw){
        anchor={t:r[0],soc:raw,kind:'BE-SOC '+raw+'% · ijking'};
        if(raw===5){lowMode=charging?'released':'tracking';lowMinimum=5;highMode='ready';highMaximum=null;}
        else{highMode=discharging?'released':'tracking';highMaximum=100;lowMode='ready';lowMinimum=null;}
      }
      if(raw!==null)lastRaw=raw;
      if(anchor){
        const before=stored;
        stored=anchor.soc;if(!anchor.silent||raw===anchor.soc)uncertain=false;
        if(anchor.statsReference){
          const saved=anchor.statsReference;
          lastAnchor={...saved.reference,input:input-saved.input,output:output-saved.output};
        }else{
          lastAnchor={...anchor,correction:before===null?null:anchor.soc-before,input,output};
          if(!anchor.silent)events.push(lastAnchor);
        }
      }
      points.push({t:r[0],raw,power:r[2],soc:stored,input,output,inputAh,outputAh,gap,uncertain,anchor:anchor||null,
        lowState:{mode:lowMode,minimum:lowMinimum},highState:{mode:highMode,maximum:highMaximum},boundaryState:{lastRaw},reference:lastAnchor,
        sinceInput:lastAnchor?Math.max(0,input-lastAnchor.input):0,sinceOutput:lastAnchor?Math.max(0,output-lastAnchor.output):0});
    }
    return {points,input,output,inputAh,outputAh,gaps,lastAnchor,events,uncertain};
  }
  function at(points,t,maxGapMs=defaults.maxGapMs){
    let lo=0,hi=points.length-1;while(lo<=hi){const m=(lo+hi)>>1;if(points[m].t<t)lo=m+1;else hi=m-1;}
    if(points[lo]?.t===t)return points[lo].soc;
    const a=points[lo-1],b=points[lo];
    const tracking=a&&b&&((a.lowState?.mode==='tracking'&&b.lowState?.mode==='tracking')||(a.highState?.mode==='tracking'&&b.highState?.mode==='tracking'));
    if(!a||!b||a.soc===null||b.soc===null||b.gap||(b.anchor&&!tracking)||b.t-a.t>maxGapMs)return null;
    return a.soc+(b.soc-a.soc)*(t-a.t)/(b.t-a.t);
  }
  root.BEEnergySOC={defaults,valid,energy,calculate,at};
})(typeof window!=='undefined'?window:globalThis);

(function(root){
  'use strict';
  const clamp=v=>Math.max(5,Math.min(100,v));
  const forecastClock=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Amsterdam',hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});
  function forecastParts(t){
    if(!Number.isFinite(t))return null;
    try{return Object.fromEntries(forecastClock.formatToParts(new Date(t)).map(p=>[p.type,p.value]));}catch(_){return null;}
  }
  function sameForecastDay(a,b=Date.now()){
    const x=forecastParts(a),y=forecastParts(b);
    return !!(a>0&&x&&y&&x.year===y.year&&x.month===y.month&&x.day===y.day);
  }
  function forecastTime(value,t,index){
    const expected=forecastParts(t);
    if(!expected)return {known:false};
    let stamp=null;
    if(Object.prototype.toString.call(value)==='[object Date]')stamp=value.getTime();
    else if(typeof value==='number'&&Number.isFinite(value)&&value>=1e9)stamp=value<1e11?value*1000:value;
    else if(typeof value==='string'){
      const s=value.trim();
      if(/^\d{10}$|^\d{13}$/.test(s)){const n=Number(s);stamp=s.length===10?n*1000:n;}
      else if(/^\d{4}-\d\d-\d\d[T ]\d\d:\d\d(?::\d\d(?:\.\d+)?)?(?:Z|[+-]\d\d:?\d\d)$/i.test(s))stamp=Date.parse(s);
      else{
        const dated=s.match(/^(\d{4})-(\d\d)-(\d\d)[T ](\d{1,2}):(\d\d)(?::(\d\d))?$/);
        if(dated)return {known:true,dated:true,match:dated[1]===expected.year&&dated[2]===expected.month&&dated[3]===expected.day&&Number(dated[4])===Number(expected.hour)&&dated[5]===expected.minute&&(!dated[6]||dated[6]===expected.second)};
        const clock=s.match(/^(\d{1,2}):(\d\d)(?::(\d\d))?$/);
        if(clock)return {known:true,dated:false,match:Number(clock[1])===Number(expected.hour)&&clock[2]===expected.minute&&(!clock[3]||clock[3]===expected.second)};
      }
    }
    if(stamp!==null)return {known:true,dated:true,match:Number.isFinite(stamp)&&Math.abs(stamp-t)<=1};
    if((typeof value==='number'||typeof value==='string')&&String(value).trim()!==''&&Number(value)===index)return {known:false,index:true};
    return {known:false};
  }
  function nativeCandidates(chart){
    return (chart?.data?.datasets||[]).filter(d=>!d.beOwnSOC&&/^socp50$/i.test(String(d.label||'').replace(/[^a-z0-9]/gi,'')));
  }
  function forecastGrid(chart,slots,anchor=null){
    const labels=chart?.data?.labels,candidates=nativeCandidates(chart);
    const invalid=reason=>({valid:false,reason});
    if(!Array.isArray(slots)||!slots.length||!Array.isArray(labels)||labels.length!==slots.length)return invalid('tijdas en prognose hebben verschillende lengtes');
    if(candidates.length>1)return invalid('meerdere SOC p50-bronnen');
    const data=candidates[0]?.data;
    if(candidates.length&&(!Array.isArray(data)||data.length!==slots.length))return invalid('SOC p50 en tijdas komen niet overeen');
    let dated=false,contiguous=true;
    for(let k=0;k<slots.length;k++){
      const q=slots[k];
      if(!q||!Number.isFinite(q.t)||!(q.dt>0)||k&&q.t<=slots[k-1].t)return invalid('ongeldige of verwisselde prognosetijden');
      if(k&&Math.abs(q.t-slots[k-1].t-slots[k-1].dt)>1)contiguous=false;
      const label=forecastTime(labels[k],q.t,k),point=data?.[k];
      const hasX=Array.isArray(point)?point.length>1:point&&typeof point==='object'&&Object.prototype.hasOwnProperty.call(point,'x');
      const x=hasX?forecastTime(Array.isArray(point)?point[0]:point.x,q.t,k):null;
      if(label.known&&!label.match||x?.known&&!x.match)return invalid('tijdstippen van SOC p50 en prognose verschillen');
      if(hasX&&!x.known&&!x.index)return invalid('tijdstip van SOC p50 is niet herkenbaar');
      if(!label.known&&!x?.known)return invalid('tijdas bevat geen herkenbare tijdstippen');
      dated=dated||!!label.dated||!!x?.dated;
    }
    // Clock-only category labels can verify every step and day rollover, but
    // cannot prove an absolute date: a complete 24-hour shift remains ambiguous.
    // Require the current day's fetched payload and a contiguous sequence;
    // explicit dates/x timestamps are always checked when they are available.
    if(!dated&&!contiguous)return invalid('kloktijden vormen geen aaneengesloten prognose');
    if(anchor&&Number.isFinite(anchor.t)&&(anchor.t<slots[0].t||anchor.t>slots.at(-1).t))return invalid('de actuele SOC valt buiten de prognosetijdas');
    return {valid:true,clockOnly:!dated};
  }
  function nativeSOC(chart,slots){
    // Read the already rendered Balans p50 plan, including planned grid flows.
    // Pair category-axis samples with the existing ISO forecast timestamps.
    const candidates=nativeCandidates(chart);
    if(candidates.length!==1||!forecastGrid(chart,slots).valid)return null;
    return candidates[0].data.map(value=>{
      const soc=Array.isArray(value)?value[1]:value&&typeof value==='object'?value.y:value;
      return Number.isFinite(soc)&&soc>=0&&soc<=100?soc:null;
    });
  }
  function projectNative(slots,values,r,c,now=Date.now()){
    if(!Array.isArray(values)||values.length!==slots.length||!r||!Number.isFinite(r.soc)||
       !Number.isFinite(r.t)||now-r.t>120000||r.t>now+10000||!(c.capacity>0))return null;
    const valid=k=>Number.isFinite(values[k])&&values[k]>=0&&values[k]<=100&&Number.isFinite(slots[k]?.t);
    let before=-1;
    for(let k=0;k<slots.length&&slots[k].t<=r.t;k++)before=k;
    if(before<0||!valid(before))return null;
    let previous=values[before];
    if(slots[before].t!==r.t){
      const next=before+1,dt=slots[next]?.t-slots[before].t;
      if(!valid(next)||!(dt>0)||!(slots[before].dt>0)||dt>slots[before].dt+1)return null;
      previous+=(values[next]-previous)*(r.t-slots[before].t)/dt;
    }
    const out=slots.map(()=>null);
    let soc=clamp(r.soc),last=r.t;
    for(let k=before;k<slots.length;k++){
      const t=slots[k].t;if(t<r.t)continue;
      if(!valid(k)||t<last||k>0&&(!(slots[k-1].dt>0)||t-slots[k-1].t>slots[k-1].dt+1))break;
      // Apply each forecast movement once. Clipping each step avoids storing
      // imaginary reserve above 100% or debt below 5% for a later reversal.
      soc=clamp(soc+values[k]-previous);out[k]=soc;
      previous=values[k];last=t;
    }
    return out;
  }
  function project(slots,r,c,power=Infinity,now=Date.now()){
    const out=slots.map(()=>null);
    if(!r||!Number.isFinite(r.soc)||!Number.isFinite(r.t)||now-r.t>120000||r.t>now+10000||!(c.capacity>0))return out;
    let e=clamp(r.soc)/100*c.capacity,last=r.t;
    for(let k=0;k<slots.length;k++){
      const q=slots[k],end=q.t+q.dt;
      if(end<=r.t)continue;
      if(q.t>last+1||!Number.isFinite(q.load)||!Number.isFinite(q.pv)||!(q.dt>0))break;
      if(q.t>=r.t)out[k]=clamp(e/c.capacity*100);
      const fraction=(end-Math.max(q.t,r.t))/q.dt,limit=power*q.dt/3600000;
      const change=Math.max(-limit,Math.min(limit,q.pv-q.load))*fraction;
      if(c.voltageProfile&&root.BEMeasuredVoltage&&c.capacityAh>0){
        let s=e/c.capacity*100,remaining=q.dt*fraction;
        const p=remaining>0?-change*3600000000/remaining:0;
        while(remaining>0){
          const dt=Math.min(remaining,60000),i=root.BEMeasuredVoltage.current(p,s,c.capacityAh),predicted=s+i*dt/3600000/c.capacityAh*100;
          const ah=root.BEMeasuredVoltage.integrate(p,p,dt,s,predicted,c.capacityAh);
          s=clamp(s+100*(ah.input-ah.output)/c.capacityAh);remaining-=dt;
        }
        e=s/100*c.capacity;
      }else e=Math.max(.05*c.capacity,Math.min(c.capacity,e+(change>=0?change*c.chargeEfficiency:change/c.dischargeEfficiency)));
      last=end;
    }
    return out;
  }
  root.BESOCExtras={clamp,project,nativeSOC,projectNative,forecastGrid,sameForecastDay};
})(window);

(function(root){
  'use strict';
  const bindings=new Map(),configs=new WeakMap(),finite=Number.isFinite;
  const supported=c=>['soc-chart','soc-forecast-chart'].includes(c.canvas?.id);
  function parsed(meta,i){return meta.controller?.getParsed?meta.controller.getParsed(i):meta._parsed?.[i];}
  function bracket(meta,x){
    let lo=0,hi=(meta.data?.length||0)-1;
    while(lo<=hi){const m=(lo+hi)>>1,p=parsed(meta,m);if(!finite(p?.x))return null;if(p.x<x)lo=m+1;else hi=m-1;}
    return {left:lo-1,right:lo};
  }
  function validPoint(meta,i){const p=parsed(meta,i),e=meta.data?.[i];return finite(p?.x)&&finite(p?.y)&&e&&!e.skip;}
  function valueAt(meta,x,stepped){
    const b=bracket(meta,x);if(!b)return {value:null};
    if(parsed(meta,b.right)?.x===x)return {value:validPoint(meta,b.right)?parsed(meta,b.right).y:null};
    if(!validPoint(meta,b.left)||!validPoint(meta,b.right)||meta.data[b.right].stop)return {value:null};
    const a=parsed(meta,b.left),z=parsed(meta,b.right);if(!(z.x>a.x))return {value:null};
    const f=(x-a.x)/(z.x-a.x);
    return {value:stepped?(stepped==='after'?z.y:stepped==='middle'&&f>=.5?z.y:a.y):a.y+(z.y-a.y)*f,approx:true};
  }
  function pick(chart,pointer){
    const scale=chart.scales?.x;if(!scale)return null;
    const slots=chart.$beEpexForecastSlots;
    if(chart.canvas?.id==='soc-forecast-chart'&&scale.type==='category'&&Array.isArray(slots)&&slots.length>1&&
       chart.data.datasets.some((d,i)=>d.beEpexForecast&&chart.isDatasetVisible(i))){
      // CategoryScale.getValueForPixel rounds to the native sample (sometimes
      // hourly). Read its pixel spacing directly to retain quarter resolution.
      const end=slots.length-1,left=scale.getPixelForValue(0),right=scale.getPixelForValue(end);
      if(finite(left)&&finite(right)&&right!==left){
        const at=Math.max(0,Math.min(end,(pointer.x-left)/(right-left)*end));
        const k=Math.min(end-1,Math.floor(at)),a=slots[k]?.t,b=slots[k+1]?.t;
        if(finite(a)&&finite(b)&&b>a){
          const time=Math.floor(Math.round(a+(b-a)*(at-k))/900000)*900000;
          if(time>=slots[0].t&&time<=slots[end].t){
            let lo=0,hi=end;
            while(lo<hi){const m=(lo+hi+1)>>1;if(slots[m].t<=time)lo=m;else hi=m-1;}
            const x=lo===end?end:lo+(time-slots[lo].t)/(slots[lo+1].t-slots[lo].t);
            const px=scale.getPixelForValue(x);
            if(finite(px))return {x,px,time,epexQuarter:true};
          }
        }
      }
    }
    let x=scale.getValueForPixel(pointer.x);if(!finite(x))return null;
    if(scale.type==='category')x=Math.round(x);
    // Real-time axes follow the pointer continuously. A sparse native series
    // must not pull the cursor hours away from the position being inspected.
    const px=scale.getPixelForValue(x);return finite(px)?{x,px}:null;
  }
  function info(chart,pointer){
    const selected=pick(chart,pointer);if(!selected)return null;
    const rows=[],groups=new Map(),capacity=configs.get(chart)?.capacity;
    chart.data.datasets.forEach((d,i)=>{
      if(!chart.isDatasetVisible(i))return;
      const meta=chart.getDatasetMeta(i);if(meta.type&&meta.type!=='line')return;
      if(d.borderWidth===0||meta.dataset?.options?.borderWidth===0)return;
      const own=d.beOwnSOC,price=d.beEpexForecast===true,group=own?'be':'native:'+i;
      const quote=price&&finite(selected.time)?(chart.$beEpexForecastRows||[]).find(r=>r.start<=selected.time&&selected.time<r.end&&r.end-r.start===900000):null;
      const sampled=price?{value:finite(quote?.value)?quote.value:null,approx:false}:valueAt(meta,selected.x,d.stepped??meta.dataset?.options?.stepped);
      const baseColor=price&&d.beEpexForecastColor?d.beEpexForecastColor:own?(own==='forecast'?'var(--be-coulomb-forecast,rgba(8,145,178,.55))':'var(--be-coulomb-line,#0891b2)'):meta.dataset?.options?.borderColor||d.borderColor;
      const color=typeof baseColor==='string'?(!own&&!price&&root.BETheme?.isDark?.()?root.BETheme.color(baseColor,'text',true):baseColor):'#6b7280';
      const y=chart.scales[meta.yAxisID||d.yAxisID||'y'];
      const row={label:own?'Coulombtelling in/uit':String(d.label||'Lijn '+(i+1)),color,...sampled,unit:price?'eur-kwh':'soc',
        energyKwh:price?null:root.BEMeasuredVoltage?.energyKwh(sampled.value,capacity)??null,
        py:sampled.value===null?null:y?.getPixelForValue(sampled.value)};
      if(!groups.has(group)){groups.set(group,rows.length);rows.push(row);}
      else if(rows[groups.get(group)].value===null&&row.value!==null)rows[groups.get(group)]=row;
    });
    if (selected.epexQuarter) {
      const wattsByDirection = new Map();
      for (const plan of chart.$beEpexForecastPlans || []) {
        if (plan?.start !== selected.time || plan.end !== selected.time + 900000 ||
            !['import', 'export'].includes(plan.direction) || !finite(plan.quantityW)) continue;
        const watts = Math.abs(plan.quantityW);
        if (!watts) continue;
        const previous = wattsByDirection.get(plan.direction);
        wattsByDirection.set(plan.direction, previous === undefined || previous === watts ? watts : null);
      }
      for (const [direction, watts] of wattsByDirection) {
        if (watts === null) continue;
        rows.push({
          label: 'Geplande EPEX-' + direction,
          color: root.BETheme?.isDark?.() ? '#acd2ef' : '#315b79',
          value: watts / 1000,
          unit: 'kw',
          py: null
        });
      }
    }
    const xScale=chart.scales.x,times=configs.get(chart)?.times;
    const label=times?.[selected.x]??chart.data.labels?.[selected.x]??xScale.getLabelForValue?.(selected.x);
    const time=finite(selected.time)?selected.time:['time','timeseries'].includes(xScale.type)||xScale.type==='linear'&&selected.x>1e11?selected.x:typeof label==='string'&&/^\d{4}-\d\d-\d\d[T ]/.test(label)?Date.parse(label):null;
    let title=finite(time)?new Date(time).toLocaleString('nl-NL',{timeZone:'Europe/Amsterdam',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:xScale.type==='category'?undefined:'2-digit'}):String(label??selected.x);
    if(selected.epexQuarter)title+='–'+new Date(time+900000).toLocaleTimeString('nl-NL',{timeZone:'Europe/Amsterdam',hour:'2-digit',minute:'2-digit'});
    return {...selected,title,rows};
  }
  function format(row){
    if(!finite(row.value))return '—';
    if(row.unit==='eur-kwh')return '€ '+row.value.toLocaleString('nl-NL',{minimumFractionDigits:3,maximumFractionDigits:3})+'/kWh';
    if(row.unit==='kw')return row.value.toLocaleString('nl-NL',{minimumFractionDigits:3,maximumFractionDigits:3})+' kW';
    const energy=finite(row.energyKwh)?'~ '+row.energyKwh.toLocaleString('nl-NL',{minimumFractionDigits:1,maximumFractionDigits:1}):'—';
    return (row.approx?'≈ ':'')+row.value.toLocaleString('nl-NL',{maximumFractionDigits:0})+'% · '+energy+' kWh';
  }
  function hide(state){
    state.tip.style.display='none';state.cursor.style.display='none';state.pointer=null;
    state.markers.style.display='none';
    try{if(state.tooltip){state.tooltip.options.enabled=state.enabled;state.tooltip=null;}}catch{}
  }
  function show(state,event){
    const chart=state.chart,touch=event.touches?.[0]||event;
    if(!finite(touch.clientX)||!finite(touch.clientY)){hide(state);return;}
    const rect=chart.canvas.getBoundingClientRect(),a=chart.chartArea;
    if(!a||!rect.width||!rect.height||!chart.width||!chart.height){hide(state);return;}
    const pointer={x:(touch.clientX-rect.left)*chart.width/rect.width,y:(touch.clientY-rect.top)*chart.height/rect.height};
    if(pointer.x<a.left||pointer.x>a.right||pointer.y<a.top||pointer.y>a.bottom){hide(state);return;}
    const data=info(chart,pointer);if(!data?.rows.length){hide(state);return;}
    // Native index-mode hover joins unrelated sample indices. Our marker layer
    // samples every visible line at data.x instead and leaves the datasets intact.
    if(chart.getActiveElements?.().length){chart.setActiveElements([]);chart.draw();}
    state.pointer={clientX:touch.clientX,clientY:touch.clientY};
    try{if(chart.tooltip&&state.tooltip!==chart.tooltip){state.tooltip=chart.tooltip;state.enabled=chart.tooltip.options.enabled;}if(state.tooltip)state.tooltip.options.enabled=false;}catch{}
    const title=document.createElement('div');title.textContent=data.title;title.style.cssText='font-weight:650;margin-bottom:7px';
    const children=[title];
    for(const row of data.rows){
      const line=document.createElement('div');line.style.cssText='display:flex;align-items:center;gap:8px;min-height:22px';
      const swatch=document.createElement('span');swatch.style.cssText='display:inline-block;width:14px;height:3px;flex:0 0 14px;background:var(--be-soc-tooltip-series);--be-soc-tooltip-series:'+row.color;
      const label=document.createElement('span');label.textContent=row.label;label.style.cssText='flex:1;min-width:0;white-space:normal;overflow-wrap:break-word;line-height:1.35';
      const value=document.createElement('span');value.className='be-soc-tooltip-value';value.textContent=format(row);value.style.cssText='flex:0 0 auto;font-variant-numeric:tabular-nums;white-space:nowrap;text-align:right;margin-left:4px;color:var(--be-soc-tooltip-series)!important;--be-soc-tooltip-series:'+row.color;
      line.append(swatch,label,value);children.push(line);
    }
    state.tip.replaceChildren(...children);state.tip.style.display='block';
    state.markers.replaceChildren(...data.rows.filter(row=>finite(row.py)&&row.py>=a.top&&row.py<=a.bottom).map(row=>{
      const dot=document.createElement('span');
      dot.style.cssText='position:fixed;display:block;width:8px;height:8px;border-radius:50%;border:2px solid #fff;box-sizing:border-box;transform:translate(-50%,-50%);background:var(--be-soc-tooltip-series);--be-soc-tooltip-series:'+row.color+';left:'+(rect.left+data.px*rect.width/chart.width)+'px;top:'+(rect.top+row.py*rect.height/chart.height)+'px';
      return dot;
    }));state.markers.style.display='block';
    const box=state.tip.getBoundingClientRect(),vw=window.innerWidth||document.documentElement.clientWidth,vh=window.innerHeight||document.documentElement.clientHeight;
    const left=Math.max(8,Math.min(touch.clientX+16+box.width<vw-8?touch.clientX+16:touch.clientX-box.width-16,vw-box.width-8));
    const top=Math.max(8,Math.min(touch.clientY+16,vh-box.height-8));state.tip.style.left=left+'px';state.tip.style.top=top+'px';
    state.cursor.style.cssText='position:fixed;pointer-events:none;z-index:2147483645;border-left:1px dashed rgba(100,116,139,.65);display:block;left:'+(rect.left+data.px*rect.width/chart.width)+'px;top:'+(rect.top+a.top*rect.height/chart.height)+'px;height:'+((a.bottom-a.top)*rect.height/chart.height)+'px';
  }
  function detach(canvas,state){
    for(const type of ['mousemove','touchstart','touchmove'])canvas.removeEventListener(type,state.move,true);
    for(const type of ['mouseleave','touchend','touchcancel'])canvas.removeEventListener(type,state.leave,true);
    window.removeEventListener('scroll',state.leave,true);window.removeEventListener('blur',state.leave);hide(state);state.tip.remove();state.cursor.remove();state.markers.remove();bindings.delete(canvas);
  }
  function attach(chart,config={}){
    if(!supported(chart))return;
    // Never enter Chart.js' render/plugin lifecycle: tooltip errors stay local.
    try{
      configs.set(chart,config);
      for(const [canvas,state] of bindings)if(canvas.isConnected===false)detach(canvas,state);
      let state=bindings.get(chart.canvas);
      if(state){state.chart=chart;if(state.pointer)Promise.resolve().then(()=>state.move(state.pointer));return;}
      const tip=document.createElement('div'),cursor=document.createElement('div'),markers=document.createElement('div');
      tip.setAttribute('role','tooltip');tip.setAttribute('data-be-soc-tooltip','');tip.style.cssText='position:fixed;display:none;pointer-events:none;z-index:2147483646;background:#fff;color:#111827;border:1px solid #cbd5e1;border-radius:7px;padding:10px 12px;box-shadow:0 3px 12px rgba(0,0,0,.2);font:12px/1.4 system-ui,-apple-system,sans-serif;max-width:calc(100vw - 16px);box-sizing:border-box';
      cursor.style.display='none';markers.style.cssText='display:none;pointer-events:none;position:fixed;inset:0;z-index:2147483645';
      (document.body||document.documentElement).append(tip,cursor,markers);
      state={chart,tip,cursor,markers,tooltip:null,pointer:null};
      state.move=e=>{try{show(state,e);}catch(error){hide(state);if(!state.warned){state.warned=true;console.warn('[SOC hover]',error);}}};state.leave=()=>hide(state);
      for(const type of ['mousemove','touchstart','touchmove'])chart.canvas.addEventListener(type,state.move,{capture:true,passive:true});
      for(const type of ['mouseleave','touchend','touchcancel'])chart.canvas.addEventListener(type,state.leave,{capture:true,passive:true});
      window.addEventListener('scroll',state.leave,{capture:true,passive:true});window.addEventListener('blur',state.leave);bindings.set(chart.canvas,state);
    }catch(error){console.warn('[SOC hover] Koppelen mislukt:',error);}
  }
  const plugin={id:'beSocSynchronizedHover',beforeEvent(chart,args){
    if(bindings.has(chart.canvas)&&/^(mousemove|mouseout|touchstart|touchmove|touchend|touchcancel)$/.test(args.event.type))return false;
  },afterDestroy(chart){const state=bindings.get(chart.canvas);if(state)detach(chart.canvas,state);}};
  root.BESocHover={attach,info,valueAt,plugin};
})(typeof window!=='undefined'?window:globalThis);

(function(root){
  'use strict';
  const numeric=v=>typeof v==='number'?v:typeof v==='string'&&/^\d+(?:[.,]\d+)?$/.test(v.trim())?Number(v.trim().replace(',','.')):NaN;
  function resolve(value){
    const c=value&&typeof value==='object'?value:{};
    if(c.capacityMode==='fcc'){
      const fccAh=Math.min(330,numeric(c.fccAh)),packCount=numeric(c.packCount);
      if(!(fccAh>0&&Number.isInteger(packCount)&&packCount>=1&&packCount<=100))return null;
      const capacityAh=fccAh*packCount,capacity=capacityAh*root.BEMeasuredVoltage.referenceVoltage/1000;
      return capacity>=.01&&capacity<=1000?{mode:'fcc',capacity,capacityAh,fccAh,packCount}:null;
    }
    if(c.capacityMode&&c.capacityMode!=='kwh')return null;
    const capacity=numeric(c.capacityKwh??c.capacity);
    return capacity>=.01&&capacity<=1000?{mode:'kwh',capacity,capacityAh:capacity*1000/root.BEMeasuredVoltage.referenceVoltage}:null;
  }
  function readForm(form,previous={}){
    const {nominalVoltage,...retained}=previous;
    const next={...retained,capacityMode:form.elements.capacityMode.value,
      capacityKwh:numeric(form.elements.capacity.value),fccAh:Math.min(330,numeric(form.elements.fccAh.value)),
      packCount:numeric(form.elements.packCount.value)};
    const resolved=resolve(next);return resolved?{...next,capacity:resolved.capacity}:null;
  }
  root.BECapacity={numeric,resolve,readForm};
})(typeof window!=='undefined'?window:globalThis);

(function(root){
  'use strict';
  const id='be-coulomb-native-readout',own='.be-own-soc,[data-be-coulomb-readout]';
  const text=e=>(e.textContent||'').replace(/\s+/g,' ').trim();
  const percent=e=>/^\d+(?:[.,]\d+)?\s*%$/.test(text(e));
  function metric(label){
    for(let e=label,depth=0;e&&depth<4;e=e.parentElement,depth++){
      if(e.matches?.('body,main,section,aside,form')||e.querySelector?.('canvas'))break;
      const leaves=[...e.querySelectorAll('span,div,p,strong,b')].filter(n=>!n.children.length&&!n.closest(own));
      if(leaves.some(percent)&&!/\d\s*(?:kWh|kW|W|€)\b/.test(text(e)))return e;
    }
    return null;
  }
  function target(){
    const header=document.querySelector('#power-chart-content .energy-chart-soc-header');
    if(header?.querySelector('.energy-chart-soc-value'))return header;
    const labels=[...document.querySelectorAll('span,div,p,dt,label')].filter(e=>!e.children.length&&!e.closest(own)&&/^(?:SOC|SOC\s*\(%\)|Laadtoestand(?:\s*\(SOC\))?|State of charge(?:\s*\(SOC\))?)$/i.test(text(e)));
    for(const label of labels){const row=metric(label);if(row)return row;}
    for(const selector of ['#current-soc','#battery-soc','#soc-value','[data-metric="soc"]','[data-soc-value]']){
      const value=document.querySelector(selector);
      if(value&&!value.closest(own)&&percent(value))return value.closest('.summary-compact-metric')||value.parentElement;
    }
    return null;
  }
  function render(view){
    const row=target();let el=document.getElementById(id);
    if(!row){el?.remove();return;}
    if(!el){
      el=document.createElement('div');el.id=id;el.setAttribute('data-be-coulomb-readout','');
      el.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:12px;flex:0 0 100%;grid-column:1 / -1;min-width:0;margin-top:0;color:#0891b2;font:inherit;font-variant-numeric:tabular-nums';
      const label=document.createElement('span'),value=document.createElement('strong');
      label.className='energy-chart-soc-label be-own-soc-label';label.textContent='Coulombtelling in/uit';label.style.color='#0891b2';
      value.className='energy-chart-soc-value';value.style.cssText='color:#0891b2;white-space:nowrap';
      el.append(label,value);
    }
    if(el.parentElement!==row){row.style.flexWrap='wrap';row.style.rowGap='4px';row.append(el);}
    if(typeof getComputedStyle==='function'){
      const label=row.querySelector('.energy-chart-soc-label'),value=row.querySelector('.energy-chart-soc-value');
      for(const [original,copy] of [[label,el.querySelector('span')],[value,el.querySelector('strong')]]){
        if(original&&original!==copy){const font=getComputedStyle(original).font;if(font&&copy.style.font!==font)copy.style.font=font;}
      }
    }
    const shown=view.compactSoc??view.soc;
    const value=el.querySelector('strong');if(value.textContent!==shown)value.textContent=shown;
    if(el.title!==view.state)el.title=view.state;
  }
  root.BESocNativeReadout={render,target};
})(window);

(function(root){
  'use strict';
  const active=chart=>chart.canvas?.id==='soc-chart'&&/\/customer\/[^/]+\/history\/?$/.test(location.pathname);
  function linuxChromium(){
    const ua=root.navigator?.userAgent||'';
    return /Linux|X11/.test(ua)&&!/Android/.test(ua)&&/(?:Chrome|Chromium|Edg)\//.test(ua);
  }
  function range(chart){
    // Read the current native input, never the previous, already expanded axis
    // or parsed metadata from the period that was just replaced.
    const native=chart.data.datasets.filter(d=>!d.beOwnSOC);
    const axis=native[0]?.xAxisID||'x',scale=chart.scales?.[axis];
    const options=(chart.config?.options||chart.options)?.scales?.[axis]||{};
    function time(value){
      if(value==null||value==='')return NaN;
      if(Number.isFinite(value))return value;
      if(value instanceof Date)return +value;
      const parsed=scale?.parse?.(value);
      return Number.isFinite(parsed)?parsed:typeof value==='string'?Date.parse(value):NaN;
    }
    let min=Infinity,max=-Infinity;
    for(const d of native){
      if((d.xAxisID||'x')!==axis)continue;
      const data=linuxChromium()?(d._data||d.data):d.data;
      for(let i=0;i<(data?.length||0);i++){
        const p=data[i],x=time(Array.isArray(p)?p[0]:p&&typeof p==='object'?p.x:chart.data.labels?.[i]);
        if(Number.isFinite(x)){min=Math.min(min,x);max=Math.max(max,x);}
      }
    }
    const start=time(options.min),end=time(options.max);
    if(Number.isFinite(start))min=start;
    if(Number.isFinite(end))max=end;
    return Number.isFinite(min)&&Number.isFinite(max)&&min<=max?{min,max}:null;
  }
  // Chart.js' generic decimator mixes null boundaries into pixel buckets and
  // moves their timestamps. Keep each uninterrupted run separate on Linux
  // Chromium, retaining original first/min/max/last samples per screen column.
  function project(chart,points,extent){
    if(!active(chart)||!linuxChromium())return points;
    const width=Math.max(1,Math.ceil(chart.chartArea?.width||chart.width||chart.canvas?.clientWidth||1000));
    if(points.length<=width*4||!extent||!(extent.max>extent.min))return points;
    const out=[];let bucket=null,group=[];
    function flush(){
      if(!group.length)return;
      let min=0,max=0;
      for(let i=1;i<group.length;i++){if(group[i].y<group[min].y)min=i;if(group[i].y>group[max].y)max=i;}
      [...new Set([0,min,max,group.length-1])].sort((a,b)=>a-b).forEach(i=>out.push(group[i]));group=[];
    }
    for(const p of points){
      if(!Number.isFinite(p.x))continue;
      if(!Number.isFinite(p.y)){
        flush();bucket=null;
        const gap=p.y===null?p:{x:p.x,y:null};
        if(out.length&&out[out.length-1].y===null)out[out.length-1]=gap;else out.push(gap);
        continue;
      }
      const column=Math.floor((p.x-extent.min)/(extent.max-extent.min)*width);
      if(column!==bucket){flush();bucket=column;}
      group.push(p);
    }
    flush();return out;
  }
  const controllers=new WeakMap();
  const plugin={id:'beSocHistoryRendering',beforeUpdate(chart){
    if(!active(chart))return;
    // The native SOC and our archive have independent timestamps. With
    // normalized:true Chart.js takes time ticks from the first sorted dataset
    // only (our foreground line), hiding morning ticks when it starts later.
    const options=chart.config?.options||chart.options;
    if(options)options.normalized=false;
    // Scale.init already ran for this update; also correct its cached flag so
    // the very first render uses all series instead of waiting for a refresh.
    for(const scale of Object.values(chart.scales||{})){
      if(scale.axis==='x'&&'_normalized' in scale)scale._normalized=false;
    }
  },beforeElementsUpdate(chart){
    const protect=active(chart)&&linuxChromium();
    chart.data.datasets.forEach((d,index)=>{
      if(!d.beOwnSOC)return;
      const controller=chart.getDatasetMeta(index)?.controller;
      if(!protect){
        if(controller&&controllers.has(controller)){controller.supportsDecimation=controllers.get(controller);controllers.delete(controller);}
        return;
      }
      // The built-in decimator runs first. Restore only our own original input
      // before Chart.js builds elements; leave native SOC and its options alone.
      if(d._data&&Object.getOwnPropertyDescriptor(d,'data')?.get){
        const original=d._data;delete d._decimated;delete d._data;
        Object.defineProperty(d,'data',{configurable:true,enumerable:true,writable:true,value:original});
      }
      if(controller){if(!controllers.has(controller))controllers.set(controller,controller.supportsDecimation);controller.supportsDecimation=false;}
      d.spanGaps=false;d.stepped=false;d.tension=0;
    });
  }};
  function legend(chart,visible,toggle){
    const frame=chart.canvas.closest('.history-chart-soc-row');
    const header=frame?.querySelector('.history-chart-soc-header');
    if(!header)return;
    const label=header.querySelector('.history-chart-soc-label:not([data-be-history-coulomb])');
    let button=header.querySelector('[data-be-history-coulomb]');
    if(!button){
      button=document.createElement('button');button.type='button';
      button.dataset.beHistoryCoulomb='';button.className='history-chart-soc-label';
      button.textContent='Coulombtelling in/uit';
      button.style.cssText='border:0;background:transparent;color:inherit;padding:6px 0;min-height:44px;cursor:pointer;font:inherit;white-space:normal;text-align:left';
      header.style.display='flex';header.style.flexWrap='wrap';header.style.alignItems='center';header.style.gap='6px 24px';
      header.append(button);
    }
    const styleId='be-history-soc-legend-style';
    if(!document.getElementById(styleId)){
      const style=document.createElement('style');style.id=styleId;
      style.textContent=':root :is(#be-soc-colour-priority,[data-be-history-coulomb])[aria-pressed]::before{background:var(--be-coulomb-line,#0891b2)!important;box-shadow:0 0 0 3px color-mix(in srgb,var(--be-coulomb-line,#0891b2) 14%,transparent)!important}[data-be-history-coulomb][aria-pressed="false"]{opacity:.5;text-decoration:line-through}[data-be-history-coulomb]:focus-visible{outline:2px solid var(--be-coulomb-line,#0891b2);outline-offset:3px}';
      (document.head||document.documentElement).append(style);
    }
    if(label)button.style.font=getComputedStyle(label).font;
    button.setAttribute('aria-pressed',String(visible));button.setAttribute('aria-controls',chart.canvas.id);
    button.title=visible?'Coulombtelling verbergen':'Coulombtelling tonen';
    button.onclick=toggle;
  }
  root.BESocHistory={active,range,project,plugin,legend};
})(window);

(async function () {
  'use strict';
  if(window.__beCoulombInOut6)return;
  let id=location.pathname.match(/^\/customer\/([^/]+)(?:\/|$)/)?.[1];
  if(!id||['account','current-history','current-prices','results'].includes(id))id=await window.BEInstallation?.wait();
  if(!id||window.__beCoulombInOut6)return;
  window.__beCoulombInOut6=true;
  const ext=window.BESOCExtras;
  const pastColorsPlugin={id:'beOwnSocPastColors',afterDraw(chart){
    const area=chart.chartArea,x=chart.scales.x;if(!area||!x)return;
    const slots=(payload?.items||[]).flatMap(i=>(i.hours||[]).map(t=>Date.parse(t)));
    if(slots.length!==chart.data.labels?.length)return;
    const ctx=chart.ctx,now=Date.now();ctx.save();ctx.beginPath();
    ctx.rect(area.left,area.top,area.right-area.left,area.bottom-area.top);ctx.clip();
    chart.data.datasets.forEach((d,i)=>{
      if(!d.beOwnSOC||!chart.isDatasetVisible(i))return;
      const meta=chart.getDatasetMeta(i);
      const color='#0891b2';
      ctx.strokeStyle=color;ctx.lineWidth=1.6;ctx.setLineDash([]);ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();
      let started=false;
      for(let k=0;k<slots.length;k++){
        const point=meta.data[k],raw=d.data[k];
        if(slots[k]>now||raw==null||point?.skip||!Number.isFinite(point?.x)||!Number.isFinite(point?.y)){started=false;continue;}
        if(started)ctx.lineTo(point.x,point.y);else{ctx.moveTo(point.x,point.y);started=true;}
      }
      ctx.stroke();
    });ctx.restore();
  }};

  const core=window.BEEnergySOC, key='be-own-soc-settings:'+id, DAY=86400000;
  let cfg={},record={rows:[],manual:[]},result=null,payload=null,db=null,busy=false,error='',storageError='',lastFetch=0,forecastFetch=0;
  let recordVersion=0,resultVersion=0,payloadVersion=0,computedVersion=-1,computedSettings='',pruneAttempt=null;
  try{cfg=JSON.parse(localStorage.getItem(key)||'{}')||{};delete cfg.nominalVoltage;}catch{}
  const settings=()=>{const r=window.BECapacity.resolve(cfg);return {...core.defaults,...cfg,capacity:r?.capacity??NaN,capacityAh:r?.capacityAh??NaN,voltageProfile:window.BEMeasuredVoltage.id,chargeEfficiency:1,dischargeEfficiency:1,auto:true};};
  const number=(v,n=1)=>Number.isFinite(v)?v.toLocaleString('nl-NL',{maximumFractionDigits:n,minimumFractionDigits:n}):'—';
  const date=t=>new Date(t).toLocaleString('nl-NL',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
  const latest=()=>result?.points.at(-1);
  const followsOriginal=p=>p?.lowState?.mode==='tracking'||p?.highState?.mode==='tracking';
  const visualSoc=p=>p?.soc??null;

  const displayKey=key+':last-display:v4';
  let lastDisplay=null,displaySaved='';
  try{const saved=JSON.parse(localStorage.getItem(displayKey)||'null');if(validDisplay(saved))lastDisplay=saved;}catch{}
  function validDisplay(v){return v&&Number.isFinite(v.t)&&v.t>0&&v.t<=Date.now()+10000&&Number.isFinite(v.soc)&&Number.isFinite(v.capacity)&&v.capacity>0&&Number.isFinite(v.input)&&Number.isFinite(v.output)&&v.capacity===settings().capacity&&v.voltageProfile===settings().voltageProfile;}
  function display(){
    const r=latest(),c=settings(),current=r&&Number.isFinite(r.soc);
    if(current){
      lastDisplay={...r,capacity:c.capacity,voltageProfile:c.voltageProfile,input:result.input,output:result.output,start:record.rows[0]?.[0],gaps:result.gaps};
      const saved=JSON.stringify(lastDisplay);
      if(saved!==displaySaved){try{localStorage.setItem(displayKey,saved);displaySaved=saved;}catch{}}
    }else if(!validDisplay(lastDisplay))lastDisplay=null;
    const shown=lastDisplay,stale=shown&&Date.now()-shown.t>120000;
    const soc=shown?number(visualSoc(shown),1)+'%':'—';
    const compactSoc=shown?number(visualSoc(shown),0)+'%':'—';
    const chemicalKwh=shown?window.BEMeasuredVoltage.energyKwh(visualSoc(shown),shown.capacity):null;
    const chemicalContent=Number.isFinite(chemicalKwh)?'~ '+number(chemicalKwh,1)+' kWh':'— kWh';
    const energy=shown?.reference?'Sinds ijkpunt '+date(shown.reference.t)+': in '+number(shown.sinceInput,2)+' kWh · uit '+number(shown.sinceOutput,2)+' kWh':'';
    const history=shown?'Bewaarde historie: in '+number(shown.input,2)+' kWh · uit '+number(shown.output,2)+' kWh'+(Number.isFinite(shown.start)?' sinds '+date(shown.start):''):'';
    let state=shown?(current?'Bijgewerkt t/m ':'Laatste geldige berekening: ')+date(shown.t):'Wachten op eerste geldige meting';
    if(shown&&Number.isFinite(shown.raw))state+=' · gemeld '+number(shown.raw,0)+'% · verschil '+number(visualSoc(shown)-shown.raw)+' procentpunt';
    if(shown?.lowState?.mode==='tracking')state+=' · volgt laagste originele SOC';
    else if(shown?.highState?.mode==='tracking')state+=' · volgt hoogste originele SOC';
    if(shown?.uncertain)state+=' · onzekere meetintervallen';
    if(stale)state+=' · metingen verouderd';
    if(!current&&shown)state+=' · wacht op nieuwe metingen';
    if(!(c.capacity>0))state='Kies de rekencapaciteit bij Herijken en instellingen';
    if(error)state+=' · bronmelding: '+error;
    if(storageError)state+=' · '+storageError;
    return {soc,compactSoc,chemicalContent,energy,history,state};
  }
  function textIfChanged(el,value){if(el.textContent!==value)el.textContent=value;}
  function openDB(){return new Promise((resolve,reject)=>{
    const req=indexedDB.open('be-own-energy-soc-v1',1);
    req.onupgradeneeded=()=>req.result.createObjectStore('installations');
    req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);req.onblocked=()=>reject(Error("Lokale historie geblokkeerd"));
  });}
  // Merge in one read/write transaction: simultaneous dashboard tabs cannot overwrite observations.
  const sameRows=(a,b)=>a===b||(a.length===b.length&&a.every((r,i)=>Array.isArray(r)&&Array.isArray(b[i])&&r.length===b[i].length&&r.every((v,k)=>Object.is(v,b[i][k]))));
  const sameManual=(a,b)=>a===b||JSON.stringify(a)===JSON.stringify(b);
  function containsRows(rows,incoming){
    return incoming.every(r=>{
      let lo=0,hi=rows.length-1;
      while(lo<=hi){const mid=(lo+hi)>>1;if(rows[mid][0]<r[0])lo=mid+1;else hi=mid-1;}
      const old=rows[lo];return old&&r.length===old.length&&r.every((v,k)=>Object.is(v,old[k]));
    });
  }
  function useRecord(old,rows,manual){
    const changed=!sameRows(record.rows,rows)||!sameManual(record.manual,manual);
    if(!changed){rows=record.rows;manual=record.manual;}
    record={...old,rows,manual};if(changed)recordVersion++;
  }
  function persist(incoming=[],anchor=null){return new Promise((resolve,reject)=>{
    incoming=incoming.filter(core.valid);
    if(!db){
      const rows=containsRows(record.rows,incoming)?record.rows:[...new Map([...record.rows,...incoming].filter(core.valid).map(r=>[r[0],r])).values()].sort((a,b)=>a[0]-b[0]);
      const manual=anchor?[...record.manual.filter(a=>a.t!==anchor.t),anchor]:record.manual;
      useRecord(record,rows,manual);resolve();return;
    }
    const tx=db.transaction('installations','readwrite'),store=tx.objectStore('installations'),req=store.get(id);
    req.onsuccess=()=>{
      try {
        const old=req.result||{rows:[],manual:[]};
        const unchanged=sameRows(record.rows,old.rows||[])&&sameManual(record.manual,old.manual||[]);
        let rows=unchanged&&containsRows(record.rows,incoming)?record.rows:[...new Map([...record.rows,...(old.rows||[]),...incoming].filter(core.valid).map(r=>[r[0],r])).values()].sort((a,b)=>a[0]-b[0]);
        let manual=unchanged?record.manual:[...new Map([...record.manual,...(old.manual||[])].map(a=>[a.t,a])).values()];
        if(anchor)manual=[...manual.filter(a=>a.t!==anchor.t),anchor];
        // Preserve the integrated state when old observations are removed.
        const cutoff=Date.now()-30*DAY,index=rows.findIndex(r=>r[0]>=cutoff);
        const c=settings(),pruneKey=JSON.stringify(c);
        if(index>0&&c.capacity>0&&!(pruneAttempt?.rows===rows&&pruneAttempt.manual===manual&&pruneAttempt.index===index&&pruneAttempt.settings===pruneKey)){
          pruneAttempt={rows,manual,index,settings:pruneKey};
          const prior=core.calculate(rows.slice(0,index+1),c,manual).points.at(-1);
          // Retain unresolved gaps or out-of-range drift until a valid anchor exists.
          if(prior&&!prior.uncertain&&prior.soc!==null&&prior.soc>=0&&prior.soc<=100){
            rows=rows.slice(index);manual=manual.filter(a=>a.t>=rows[0][0]);
            if(!manual.some(a=>a.t===prior.t))manual.unshift({t:prior.t,soc:prior.soc,kind:'bewaard telpunt',lowState:prior.lowState,highState:prior.highState,boundaryState:prior.boundaryState,statsReference:prior.reference?{reference:prior.reference,input:prior.sinceInput,output:prior.sinceOutput}:undefined});
            pruneAttempt=null;
          }
        }
        const changed=!sameRows(old.rows||[],rows)||!sameManual(old.manual||[],manual);
        useRecord(old,rows,manual);
        if(changed)store.put(record,id);
      }catch(e){reject(e);tx.abort();}
    };
    tx.oncomplete=()=>resolve();tx.onerror=tx.onabort=()=>reject(tx.error||Error('Transactie afgebroken'));
  });}
  async function request(url){
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),12000);
    try{const r=await fetch(url,{credentials:'same-origin',cache:'no-store',signal:ctl.signal});
      if(!r.ok)throw Error('Bron geeft HTTP '+r.status);return await r.json();
    }finally{clearTimeout(timer);}
  }
  function compute(){
    const c=settings(),signature=JSON.stringify(c);
    if(computedVersion===recordVersion&&computedSettings===signature)return;
    result=c.capacity>0?core.calculate(record.rows,c,record.manual):null;
    computedVersion=recordVersion;computedSettings=signature;resultVersion++;
  }
  async function poll(){
    if(busy)return;busy=true;
    try {
      const now=Date.now(),last=record.rows.at(-1)?.[0];
      const u=new URL('/customer/current-history/api/',location.origin);
      u.searchParams.set('installation',id);u.searchParams.set('start',String(Math.max(now-DAY,last?last-300000:0)));u.searchParams.set('end',String(now));
      const j=await request(u.href);
      if(!Array.isArray(j.rows))throw Error('Onbekend historieformaat');
      // Public meter data only; the TenneT API key stays in private GM storage.
      const net=[...j.rows,...(j.latest?[j.latest]:[]),...(j.priceSamples||[]).map(p=>({t:p.x,po:p.y,detail:2}))]
        .filter(r=>Number.isFinite(r.t)&&r.t<=now&&Number.isFinite(r.po))
        .map(r=>({t:r.t,po:r.po,detail:r.detail===2?2:1,...(Number.isFinite(r.bo)?{bo:r.bo}:{})}));
      if(typeof CustomEvent==='function')document.dispatchEvent(new CustomEvent('be-installation-power',{detail:JSON.stringify({installation:id,rows:net})}));
      const rows=[...j.rows,...(j.latest?[j.latest]:[])].filter(r=>Number.isFinite(r.t)&&r.t<=now).map(r=>[r.t,Number.isFinite(r.s)?r.s:null,Number.isFinite(r.bo)?r.bo:null]);
      await persist(rows);compute();lastFetch=now;error='';
      if(!payload||now-forecastFetch>300000||!ext.sameForecastDay(forecastFetch,now)){
        try{payload=await request('/customer/'+encodeURIComponent(id)+'/forecast_api/');forecastFetch=Date.now();payloadVersion++;
        }catch(e){error='Forecast tijdelijk niet beschikbaar';}
      }
    }catch(e){error=e.message||String(e);}
    finally{busy=false;render();}
  }
  const style=document.createElement('style');
  style.textContent=`.be-own-soc{margin:12px 0;padding:14px 16px;border:1px solid #c4dde1;border-radius:12px;background:rgba(8,145,178,.045);font:13px system-ui;color:inherit}.be-own-soc header{display:flex;align-items:center;gap:14px;flex-wrap:wrap}.be-own-soc strong{font-size:21px;color:#0891b2}.be-own-soc small{opacity:.75}.be-own-soc details{margin-top:10px}.be-own-soc summary{cursor:pointer}.be-own-soc form{display:flex;gap:10px;align-items:end;flex-wrap:wrap;margin-top:12px}.be-own-soc label{display:flex;flex-direction:column;gap:4px}.be-own-soc input[type=number]{width:90px;padding:6px;border:1px solid #aaa;border-radius:6px;background:inherit;color:inherit}.be-own-soc button{padding:7px 10px;border:1px solid #7cb9c5;border-radius:7px;background:transparent;color:inherit;cursor:pointer}.be-own-soc p{margin:8px 0}.be-own-soc output{display:block;margin-top:7px;min-height:1.4em}.be-own-soc [data-energy]{min-height:1.4em}.be-own-soc .be-soc-line{color:#0891b2;font-weight:650}.be-own-soc ul{padding-left:20px;max-height:150px;overflow:auto}`;
  style.textContent+=`[data-be-soc-compact]{display:flex!important;flex-direction:row!important;flex-wrap:wrap!important;align-items:center!important;gap:6px!important}[data-be-soc-legend]{display:inline-flex!important;flex-direction:row!important;flex-wrap:nowrap!important;width:max-content!important;max-width:100%;gap:6px!important;align-items:center!important;margin:6px 0!important}[data-be-soc-compact]>[data-be-soc-legend]{display:contents!important}[data-be-soc-compact] button,[data-be-soc-legend] button{display:inline-flex!important;flex:0 0 auto!important;width:auto!important;min-width:0!important;max-width:none!important;min-height:0!important;height:28px!important;white-space:nowrap!important;padding:4px 9px!important;font-size:12px!important;line-height:18px!important}`;
  style.textContent+=`.be-own-soc{--be-cap-border:#d4d9e1;--be-cap-surface:rgba(255,255,255,.7);--be-cap-control:#fff;--be-cap-muted:#687280;--be-cap-accent:#6b3f8d}
.be-own-soc form[data-settings]{display:grid;grid-template-columns:minmax(0,1fr);gap:14px;align-items:start;max-width:760px;box-sizing:border-box;margin:16px 0 0;padding:16px;border:1px solid var(--be-cap-border);border-radius:12px;background:var(--be-cap-surface)}
.be-own-soc [data-settings] .be-capacity-title{font-size:14px;font-weight:650;line-height:1.3}
.be-own-soc [data-settings] label{display:flex;flex-direction:column;min-width:0;gap:6px;font-size:12px;font-weight:550;line-height:1.4}
.be-own-soc [data-settings] .be-capacity-method{max-width:280px}
.be-own-soc [data-cap-kwh]{max-width:260px}
.be-own-soc [data-cap-fcc]{display:grid;grid-template-columns:1fr .8fr;gap:12px;align-items:end;min-width:0}
.be-own-soc [data-cap-fcc][hidden],.be-own-soc [data-cap-kwh][hidden]{display:none!important}
.be-own-soc [data-settings] .be-cap-input{display:flex;align-items:center;min-width:0;width:100%;height:40px;box-sizing:border-box;border:1px solid var(--be-cap-border);border-radius:8px;background:var(--be-cap-control);overflow:hidden}
.be-own-soc [data-settings] input[type=number]{flex:1 1 0;min-width:0;width:100%;height:100%;box-sizing:border-box;margin:0;padding:8px 10px;border:0;border-radius:0;outline:none;box-shadow:none;background:transparent;color:inherit;font:inherit;font-size:14px;font-variant-numeric:tabular-nums}
.be-own-soc [data-settings] .be-cap-unit{flex:none;padding:0 10px 0 4px;color:var(--be-cap-muted);font-size:12px;font-weight:400}
.be-own-soc [data-settings] select{min-width:0;width:100%;height:40px;box-sizing:border-box;padding:8px 10px;border:1px solid var(--be-cap-border);border-radius:8px;background:var(--be-cap-control);color:inherit;font:inherit;font-size:14px}
.be-own-soc [data-settings] .be-cap-input:focus-within,.be-own-soc [data-settings] select:focus-visible{outline:2px solid var(--be-cap-accent);outline-offset:2px}
.be-own-soc [data-settings] .be-capacity-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;min-width:0;padding-top:2px}
.be-own-soc [data-settings] [data-capacity-preview]{flex:1 1 auto;min-width:0;margin:0;min-height:0;font-size:14px;font-weight:650;line-height:1.4}
.be-own-soc [data-settings] button{flex:none;min-height:40px;padding:8px 14px;border:1px solid var(--be-cap-accent);border-radius:8px;background:var(--be-cap-accent);color:#fff;font:inherit;font-size:12px;font-weight:600;line-height:1.4;cursor:pointer}
.be-own-soc [data-settings] button:hover{filter:brightness(1.08)}
.be-own-soc [data-settings] [data-capacity-help]{margin:0;color:var(--be-cap-muted);font-size:11px;line-height:1.55;overflow-wrap:anywhere}
.be-own-soc form[data-manual]{max-width:760px;display:flex;align-items:end;gap:10px;flex-wrap:wrap;margin-top:14px}
.be-own-soc [data-manual] label{min-width:0;gap:6px;font-size:12px;font-weight:550}
.be-own-soc [data-manual] input[type=number]{height:40px;width:116px;box-sizing:border-box;padding:8px 10px;border:1px solid var(--be-cap-border);border-radius:8px;background:var(--be-cap-control);color:inherit;font-size:14px;font-variant-numeric:tabular-nums}
.be-own-soc [data-manual] button{min-height:40px;box-sizing:border-box;padding:8px 14px;border:1px solid var(--be-cap-border);border-radius:8px;font-size:12px;line-height:1.4}
html[data-be-dark="aan"] .be-own-soc{--be-cap-border:#5a5561;--be-cap-surface:rgba(0,0,0,.12);--be-cap-control:#28252e;--be-cap-muted:#beb7c6;--be-cap-accent:#8253a5}
@media(max-width:560px){.be-own-soc form[data-settings]{gap:13px;padding:14px}.be-own-soc [data-cap-fcc]{grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.be-own-soc [data-cap-fcc]>label:last-child{grid-column:1 / -1}.be-own-soc [data-settings] .be-capacity-method,.be-own-soc [data-cap-kwh]{max-width:none}.be-own-soc [data-settings] .be-capacity-footer{flex-direction:column;align-items:stretch;gap:12px;padding-top:3px}.be-own-soc [data-settings] button{width:100%}.be-own-soc [data-settings] .be-cap-input,.be-own-soc [data-settings] select,.be-own-soc [data-settings] button{min-height:44px;height:44px}}
@media(max-width:560px){.be-own-soc [data-settings] input[type=number],.be-own-soc [data-settings] select,.be-own-soc [data-manual] input[type=number]{font-size:16px}.be-own-soc [data-manual] input[type=number],.be-own-soc [data-manual] button{min-height:44px}}
`;
  style.textContent+=`.be-soc-legend{display:flex;align-items:center;gap:12px;flex-wrap:wrap;box-sizing:border-box;width:100%;margin:0;padding:8px 0 4px;color:inherit;font:11px/1.3 system-ui,sans-serif}
.be-soc-legend[data-be-soc-inline]{display:inline-flex;width:auto;padding:0;font:inherit}
.be-soc-legend .be-soc-series-toggle{display:inline-flex;align-items:center;gap:5px;border:0;border-radius:0;padding:3px 0;margin:0;background:transparent;color:inherit;font:inherit;cursor:pointer;box-shadow:none;min-height:0}
.be-soc-legend .be-soc-series-toggle[aria-pressed="false"]{opacity:.5;text-decoration:line-through}
.be-soc-legend .be-soc-series-toggle:focus-visible{outline:2px solid var(--be-coulomb-line,#0891b2);outline-offset:3px}
.be-soc-legend .be-soc-series-swatch{width:13px;height:3px;display:inline-block;flex:none}
:root :is(#be-soc-colour-priority,[data-be-coulomb-readout]) .be-own-soc-label::before{background:var(--be-coulomb-line,#0891b2)!important;box-shadow:0 0 0 3px color-mix(in srgb,var(--be-coulomb-line,#0891b2) 14%,transparent)!important}

.be-soc-legend .be-soc-series-toggle{font:11px/1.3 system-ui,sans-serif!important;font-weight:400!important;border:0!important;border-radius:0!important;padding:3px 0!important;margin:0!important;min-height:0!important;background:transparent!important;box-shadow:none!important}
.be-soc-legend .be-soc-series-toggle>span{font:inherit!important}
`;
  style.textContent+=`
.be-own-soc>header{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:start;column-gap:16px;row-gap:8px}
.be-own-soc .be-soc-current{display:flex;align-items:baseline;flex-wrap:wrap;gap:6px 14px;min-width:0}
.be-own-soc .be-soc-chemical{display:flex;flex-direction:column;align-items:flex-end;gap:3px;min-width:0;text-align:right;font-variant-numeric:tabular-nums}
.be-own-soc .be-soc-chemical-label{font-size:11px;line-height:1.3;opacity:.8}
.be-own-soc [data-chemical]{font-size:21px;line-height:1.2;white-space:nowrap}
.be-own-soc header>[data-energy]{grid-column:1 / -1;min-width:0}
.be-own-soc header>[data-energy]:empty{display:none}
#be-own-soc-panel [data-chemical]{color:var(--be-coulomb-line,#0891b2)!important}
`;
  document.head.append(style);
  function panel(canvas){
    let p=document.getElementById('be-own-soc-panel');if(p)return p;
    p=document.createElement('section');p.id='be-own-soc-panel';p.className='be-own-soc';
    p.innerHTML=`<header><div class="be-soc-current"><span class="be-soc-line">Coulombtelling in/uit</span><strong data-soc>—</strong></div><div class="be-soc-chemical"><span class="be-soc-chemical-label">Chemische inhoud</span><strong data-chemical aria-live="polite" title="Geschatte resterende energie uit coulombtelling en het gemeten spanningsprofiel. Geen directe energiemeting; bij lage SOC is de onzekerheid groter.">— kWh</strong></div><span data-energy></span></header><output data-state></output><output data-forecast-state hidden role="status"></output><details><summary>Herijken en instellingen</summary><form data-manual><label>Nieuwe SOC %<input name="soc" type="number" min="0" max="100" step="0.1" required></label><button>Herijk alleen de blauwe telling</button></form><form data-settings class="be-capacity-card">
  <div class="be-capacity-title">Accucapaciteit</div>
  <label class="be-capacity-method">Invoermethode
    <select name="capacityMode"><option value="kwh">kWh handmatig</option><option value="fcc">FCC per accu (Ah)</option></select>
  </label>
  <div data-cap-kwh>
    <label>Totale capaciteit
      <span class="be-cap-input"><input name="capacity" type="number" inputmode="decimal" min="0.01" max="1000" step="any" required><span class="be-cap-unit">kWh</span></span>
    </label>
  </div>
  <div data-cap-fcc hidden>
    <label>Gemiddelde FCC
      <span class="be-cap-input"><input name="fccAh" type="number" inputmode="decimal" min="0.01" max="330" step="any"><span class="be-cap-unit">Ah</span></span>
    </label>
    <label>Aantal accu’s
      <span class="be-cap-input"><input name="packCount" type="number" inputmode="numeric" min="1" max="100" step="1"><span class="be-cap-unit">stuks</span></span>
    </label>
  </div>
  <div class="be-capacity-footer"><output data-capacity-preview aria-live="polite"></output><button type="submit">Capaciteit opslaan</button></div>
  <small data-capacity-help></small>
</form><p>Blauw telt Ah in/uit. De accustroom wordt geschat uit BE-accuvermogen en het gemeten 16S-LiFePO₄-spanningsprofiel: afhankelijk van gemelde SOC, belasting en laad-/ontlaadrichting. SOC = start-SOC + 100 × (Ah in − Ah uit) / Ah-capaciteit. Dit profiel schat de spanning; er wordt geen vaste laadverliescorrectie toegepast. Bij ontbrekende gemelde SOC blijft de telling lopen met de laatst bekende SOC voor het spanningsprofiel. De gemeten kWh-in/uitmeters lopen ook bij herijking door.</p><p>Chemische inhoud (~ kWh) is een schatting op basis van de spanning over de resterende Ah. Daarvoor wordt het gemiddelde van de gemeten laad- en ontlaadcurve gebruikt. De schatting gebruikt dezelfde SOC-telling; een afwijkend SOC-nulpunt wordt hiermee niet gecorrigeerd. Bij lage SOC is de onzekerheid groter.</p><p>Bij dalen naar 10% en lager volgt blauw de laagste originele SOC; zodra de telling stijgt, gaat hij zelfstandig verder. Bij stijgen naar 95% en hoger volgt blauw de hoogste originele SOC; zodra de telling daalt, gaat hij zelfstandig verder. De terugweg langs 10% of 95% herijkt niet opnieuw. Bij het bereiken van precies 5% of 100% BE-SOC wordt altijd opnieuw geijkt, ook na een eerdere richtingswisseling; een blijvend eindpunt blokkeert daarna geen nieuwe in-/uittelling. De getoonde kWh in/uit zijn sinds het laatste ijkpunt; de volledige telling blijft doorlopen.</p><p>De blauwe vooruitblik volgt de verwachte SOC-beweging van Balans SOC p50, inclusief gepland laden en ontladen, vanaf de actuele eigen coulombtelling. Dit is een prognose, geen gemeten Ah-telling. PV en huisverbruik worden daarin niet nogmaals opgeteld. Ontbreekt een bruikbare p50-bron, dan wordt alleen PV/verbruik geraamd; meet- en prognosegaten worden niet overbrugd. Bij ontbrekende of tegenstrijdige tijdinformatie wacht de vooruitblik op vernieuwde prognosegegevens.</p><button type="button" data-export>Exporteer telgegevens</button><output data-history></output><p data-log></p><ul data-events></ul></details>`;
    canvas.parentElement.insertAdjacentElement('afterend',p);
    const f=p.querySelector('[data-settings]'),resolved=window.BECapacity.resolve(cfg);
    f.elements.capacityMode.value=cfg.capacityMode==='fcc'?'fcc':'kwh';
    f.elements.capacity.value=cfg.capacityKwh??(resolved?.mode==='kwh'?resolved.capacity:'');
    f.elements.fccAh.value=cfg.fccAh==null?'':Math.min(330,cfg.fccAh);
    f.elements.packCount.value=cfg.packCount??'';
    function preview(){
      const ah=window.BECapacity.numeric(f.elements.fccAh.value);if(ah>330)f.elements.fccAh.value=330;
      const fcc=f.elements.capacityMode.value==='fcc';
      f.querySelector('[data-cap-kwh]').hidden=fcc;f.querySelector('[data-cap-fcc]').hidden=!fcc;
      f.elements.capacity.disabled=fcc;f.elements.capacity.required=!fcc;
      for(const name of ['fccAh','packCount']){f.elements[name].disabled=!fcc;f.elements[name].required=fcc;}
      const next=window.BECapacity.readForm(f,cfg),cap=next&&window.BECapacity.resolve(next);
      textIfChanged(f.querySelector('[data-capacity-preview]'),cap?'Rekencapaciteit: '+number(cap.capacity,2)+' kWh':'Vul de capaciteit in');
      textIfChanged(f.querySelector('[data-capacity-help]'),fcc?'Ah per accu (maximaal 330) × aantal parallelle accu’s. Spanning automatisch uit het gemeten 16S-LiFePO₄-profiel.':'Je eigen kWh-capaciteit voor het hele systeem; Ah-equivalent uit het gemeten 16S-LiFePO₄-profiel.');
    }
    f.oninput=preview;f.onchange=preview;preview();
    f.onsubmit=async e=>{
      e.preventDefault();preview();if(!f.reportValidity())return;
      const next=window.BECapacity.readForm(f,cfg);
      if(!next){error='Vul een geldige rekencapaciteit in';render();return;}
      try{localStorage.setItem(key,JSON.stringify(next));cfg=next;f.elements.fccAh.value=next.fccAh||'';error='';compute();render();}catch(e){error='Opslaan mislukt: '+e.message;render();}
    };
    p.querySelector('[data-manual]').onsubmit=async e=>{
      e.preventDefault();const form=e.currentTarget,r=latest();if(!r||!form.reportValidity())return;
      if(Date.now()-r.t>120000){error='Laatste meetpunt is te oud om nu te herijken';render();return;}
      try{await persist([],{t:r.t,soc:+form.elements.soc.value,kind:'handmatig'});compute();render();}catch(e){error='Herijken niet opgeslagen: '+e.message;render();}
    };
    p.querySelector('[data-export]').onclick=()=>{
      const blob=new Blob([JSON.stringify({version:'7.1',installation:id,settings:settings(),...record,events:result?.events},null,2)],{type:'application/json'});
      const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Balansenergie-coulombtelling-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    };return p;
  }
  function dataset(chart,tag,label,points,extra={}){
    let d=chart.data.datasets.find(d=>d.beOwnSOC===tag);
    if(!d){d={beOwnSOC:tag,label,type:'line',order:-20,borderColor:'#0891b2',backgroundColor:'#0891b2',borderWidth:1.6,pointRadius:0,pointHitRadius:8,fill:false,tension:0,spanGaps:false,...extra};chart.data.datasets.push(d);}
    const series=tag==='forecast'?'coulomb-forecast':'coulomb';
    const color=window.BETheme?.seriesColor(series)||(tag==='forecast'?'rgba(8,145,178,.55)':'#0891b2');
    Object.assign(d,extra,{label,borderColor:color,backgroundColor:color});d.data=points;
    d.borderDash=[];
    // 6.8.2: geen segment-opties. Chart.js vergelijkt die per punt via JSON.stringify bij
    // elke update (~30.000x/s bij 14.000 punten en Balans' update per seconde: geheugen liep op
    // tot GB's). false blokkeert ook overgeërfde segment-opties; kleur en dikte blijven gelijk.
    d.segment=false;
  }
  function forecastValues(chart){
    const pending=(notice,keepPrices=false)=>{if(!keepPrices){chart.$beEpexForecastSlots=[];chart.$beEpexForecastPlans=[];}return {actual:[],future:[],basis:'Wachten op tijdkoppeling',pending:true,notice};};
    const items=payload?.items;if(!items?.length)return pending('Vooruitblik wacht op prognosegegevens.');
    if(!ext.sameForecastDay(forecastFetch))return pending('Vooruitblik wacht op vernieuwde prognosegegevens voor vandaag.');
    const slots=items.flatMap(i=>(i.hours||[]).map((t,k)=>({t:Date.parse(t),dt:(i.interval_minutes||15)*60000,
      load:i.usage_kwh?.[k],pv:i.pv_production_kwh?.[k]})));
    const c=settings(),power=Number.isFinite(payload.battery_power_kw)?payload.battery_power_kw:Infinity;
    const visible=result?.points||[],last=latest();
    const anchor=last?{...last,soc:visualSoc(last)}:null;
    const nativeGrid=ext.forecastGrid(chart,slots);
    if(!nativeGrid.valid)return pending('Vooruitblik wacht op een geldige tijdkoppeling: '+nativeGrid.reason+'.');
    chart.$beEpexForecastSlots=slots;
    chart.$beEpexForecastPlans=Array.isArray(payload.day_ahead_plans)?payload.day_ahead_plans:[];
    const grid=ext.forecastGrid(chart,slots,anchor);
    if(!grid.valid)return pending('Vooruitblik wacht op een geldige tijdkoppeling: '+grid.reason+'.',true);
    const native=ext.nativeSOC(chart,slots),planned=native&&ext.projectNative(slots,native,anchor,c);
    return {actual:slots.map(q=>core.at(visible,q.t,c.maxGapMs)),
      future:planned||ext.project(slots,anchor,c,power),basis:planned?'BE-planning':'PV/verbruik',notice:''};
  }
  function applyVisibility(chart){
    chart.data.datasets.forEach((d,i)=>{
      if(!d.beOwnSOC)return;
      const visible=cfg.show_kwh!==false;
      d.hidden=!visible;
      if(chart.setDatasetVisibility)chart.setDatasetVisibility(i,visible);
    });
  }
  function filterNativeLegend(chart){
    const native=(chart.config?.options||chart.options)?.plugins?.legend;
    if(!native)return;
    const labels=native.labels||(native.labels={});
    if(labels.filter?.beOwnSocLegendFilter)return;
    const previous=labels.filter;
    function filter(item,data){
      return !data.datasets[item.datasetIndex]?.beOwnSOC&&!data.datasets[item.datasetIndex]?.beEpexForecast&&(!previous||previous.call(this,item,data));
    }
    filter.beOwnSocLegendFilter=true;
    labels.filter=filter;
  }
  function legend(chart){
    const canvas=chart.canvas;
    let row=document.querySelector('[data-be-soc-legend="'+canvas.id+'"]');
    if(window.BESocHistory?.active(chart)){
      document.querySelectorAll('[data-be-soc-legend="soc-chart"]').forEach(node=>node.remove());
      window.BESocHistory.legend(chart,cfg.show_kwh!==false,()=>{
        cfg.show_kwh=cfg.show_kwh===false;localStorage.setItem(key,JSON.stringify(cfg));render();
      });
      return;
    }
    // Actueel already has the full-size Coulomb readout beside the SOC value.
    if(canvas.id==='soc-chart'){
      document.querySelectorAll('[data-be-soc-legend="soc-chart"]').forEach(node=>node.remove());
      return;
    }
    if(!row){
      let host=canvas.parentElement,existing=null;
      for(let depth=0;host&&depth<3;depth++,host=host.parentElement){
        const candidate=host.querySelector('[class*="legend-soc"], [id*="soc-legend"], [aria-label="SOC reeksen"]');
        if(candidate){existing=candidate;break;}
      }
      row=document.createElement('span');row.dataset.beSocLegend=canvas.id;row.className='be-soc-legend';
      if(existing){existing.dataset.beSocCompact='';row.dataset.beSocInline='';existing.append(row);}
      else canvas.parentElement.insertAdjacentElement('beforebegin',row);
      for(const [group,label,color] of [['kwh','Coulombtelling in/uit','var(--be-coulomb-line,#0891b2)']]){
        const button=document.createElement('button');button.type='button';button.className='be-soc-series-toggle';
        button.dataset.beSocGroup=group;
        button.innerHTML='<span class="be-soc-series-swatch" aria-hidden="true" style="background:'+color+'"></span><span>'+label+'</span>';
        button.onclick=()=>{cfg['show_'+group]=cfg['show_'+group]===false;localStorage.setItem(key,JSON.stringify(cfg));render();};
        row.append(button);
      }
    }
    if(!row.hasAttribute('data-be-soc-inline')){
      const rect=canvas.getBoundingClientRect(),scale=chart.width>0?rect.width/chart.width:1;
      row.style.paddingLeft=Math.max(0,(chart.chartArea?.left||0)*scale)+'px';
    }
    for(const button of row.querySelectorAll('button[data-be-soc-group]')){
      const visible=cfg['show_'+button.dataset.beSocGroup]!==false;
      button.setAttribute('aria-pressed',String(visible));
    }
  }
  const chartVersions=new WeakMap(),eventVersions=new WeakMap();
  function chartVersion(chart){
    const forecast=chart.canvas.id==='soc-forecast-chart',now=Date.now(),last=latest();
    const native=chart.data.datasets.filter(d=>!d.beOwnSOC);
    // Native updates still run decorate through Chart.js. These inexpensive
    // signatures avoid requesting a second full chart update between samples.
    const input=forecast?[chart.data.labels,native.filter(d=>/^socp50$/i.test(String(d.label||'').replace(/[^a-z0-9]/gi,''))).map(d=>d._data||d.data)]:
      native.map(d=>{const a=d._data||d.data||[];return [d.label,d.yAxisID,a.length,a[0],a.at(-1)];});
    const slots=forecast?(payload?.items||[]).flatMap(i=>i.hours||[]):[];
    const past=forecast?slots.reduce((n,t)=>n+(Date.parse(t)<=now?1:0),0):0;
    return JSON.stringify([resultVersion,payloadVersion,cfg.show_kwh!==false,
      document.documentElement.getAttribute('data-be-dark'),document.documentElement.getAttribute('data-be-dark-style'),
      chart.width,chart.height,chart.scales.x?.min,chart.scales.x?.max,input,
      forecast&&ext.sameForecastDay(forecastFetch,now),forecast&&!!last&&now-last.t<=120000,past]);
  }
  function rememberChart(chart){
    if(chart.canvas.id==='soc-chart'||chart.canvas.id==='soc-forecast-chart')chartVersions.set(chart,chartVersion(chart));
  }
  function render(){
    // Keep collecting measurements while a tab is hidden; defer its canvas and
    // DOM work until the existing visibility/pageshow handlers run again.
    if(document.hidden)return;
    const C=window.Chart;if(!C?.getChart)return;
    register();
    const cv=document.getElementById('soc-chart')||document.getElementById('soc-forecast-chart');if(!cv)return;
    const chart=C.getChart(cv);if(!chart)return;
    const p=panel(cv),view=display();
    textIfChanged(p.querySelector('[data-soc]'),view.soc);
    textIfChanged(p.querySelector('[data-chemical]'),view.chemicalContent);
    textIfChanged(p.querySelector('[data-energy]'),view.energy);
    textIfChanged(p.querySelector('[data-state]'),view.state);
    textIfChanged(p.querySelector('[data-history]'),view.history);
    try{window.BESocNativeReadout?.render(view);}catch(e){console.warn('[SOC waarde]',e);}
    textIfChanged(p.querySelector('[data-log]'),result?.lastAnchor?'Laatste anker: '+date(result.lastAnchor.t)+' · '+result.lastAnchor.kind+' · '+number(result.lastAnchor.soc)+'% · '+result.gaps+' meetgaten in archief.':'');
    const ul=p.querySelector('[data-events]'),events=(result?.events||[]).slice(-10).reverse().map(a=>date(a.t)+' · '+a.kind+' → '+number(a.soc)+'%'+(a.correction!==null?' (correctie '+number(a.correction)+' pp)':''));
    const eventVersion=JSON.stringify(events);
    if(eventVersions.get(ul)!==eventVersion){ul.replaceChildren(...events.map(value=>{const li=document.createElement('li');li.textContent=value;return li;}));eventVersions.set(ul,eventVersion);}
    for(const name of ['soc-chart','soc-forecast-chart']){const c=C.getChart(name);if(c){
      legend(c);
      const own=c.data.datasets.filter(d=>d.beOwnSOC),expected=name==='soc-chart'?1:2;
      if(own.length<expected||chartVersions.get(c)!==chartVersion(c)){
        // beforeUpdate owns decoration, including native data replacements.
        c.update('none');rememberChart(c);
      }
    }}
    const forecastState=p.querySelector('[data-forecast-state]');
    if(forecastState){
      const notice=chart.canvas.id==='soc-forecast-chart'?chart.$beForecastNotice||'':'';
      textIfChanged(forecastState,notice);forecastState.hidden=!notice;
    }
  }
  function decorate(chart){

    if(chart.canvas.id==='soc-chart'){
      const history=window.BESocHistory.active(chart),range=history?window.BESocHistory.range(chart):null;
      // 6.8.3: bereik op 5 minuten afgerond, zodat een meeschuivende x-as de cache niet elke seconde breekt;
      // punten buiten beeld knipt Chart.js weg.
      const STEP=300000;
      const a=history?(range?.min??Infinity):Math.floor(((chart.scales.x?.min??0)-120000)/STEP)*STEP;
      const b=history?(range?.max??-Infinity):Math.ceil(((chart.scales.x?.max??Infinity)+120000)/STEP)*STEP;
      const axis=chart.data.datasets.find(d=>!d.beOwnSOC)?.yAxisID||'y';
      // 6.8.3: Balans werkt soc-chart elke seconde bij. Bouw de lijn (~15.000 punten) alleen opnieuw
      // bij een nieuwe berekening of een ander bereik; anders hetzelfde array hergebruiken.
      const key=a+'|'+b+'|'+(history?JSON.stringify([range,chart.width]):''),cache=chart.$beMeasuredCache;
      let points;
      if(cache&&cache.result===result&&cache.key===key)points=cache.points;
      else{
        points=(result?.points||[]).filter(p=>p.t>=a&&p.t<=b).map(p=>({x:p.t,y:p.gap&&!p.anchor&&!followsOriginal(p)?null:visualSoc(p)}));
        if(history)points=window.BESocHistory.project(chart,points,range);
        chart.$beMeasuredCache={result,key,points};
      }
      dataset(chart,'measured','Coulombtelling in/uit',points,{yAxisID:axis,parsing:false});
    }else if(chart.canvas.id==='soc-forecast-chart'){
      const f=forecastValues(chart);
      chart.$beForecastNotice=f?.notice||'';
      // These category-axis arrays are projections into the current native grid.
      // Clear both when the grid is unverified; stored measured SOC is untouched.
      dataset(chart,'measured','Coulombtelling in/uit gemeten',f&&!f.pending?f.actual:[],{yAxisID:'y'});
      dataset(chart,'forecast','Coulombtelling in/uit verwachting · '+(f?.basis||'Wachten op tijdkoppeling'),f&&!f.pending?f.future:[],{yAxisID:'y',borderDash:[],borderWidth:1.2,beForecastBasis:f?.basis||'Wachten op tijdkoppeling'});
    }
    if(chart.canvas.id==='soc-forecast-chart')attachPastColors(chart);
    applyVisibility(chart);
    filterNativeLegend(chart);
    try{window.BESocHover?.attach(chart,{times:(payload?.items||[]).flatMap(i=>i.hours||[]),capacity:settings().capacity});}catch(e){console.warn("[SOC hover]",e);}
  }
  function attachPastColors(chart){
    const raw=chart.config._config||chart.config;const plugins=chart.config.plugins||(raw.plugins=[]);
    if(!plugins.some(p=>p?.id===pastColorsPlugin.id))plugins.push(pastColorsPlugin);
  }
  // The dashboard refreshes and sometimes replaces its datasets. Restore only our own series.
  let renderPending=false,started=false;
  function scheduleRender(){if(renderPending)return;renderPending=true;setTimeout(()=>{renderPending=false;register();render();},0);}
  let library;
  function register(){const C=window.Chart;if(C?.register&&C!==library){C.register(window.BESocHover.plugin,window.BESocHistory.plugin,{id:'beOwnEnergySoc',beforeUpdate:decorate,afterUpdate:rememberChart,afterInit:scheduleRender});library=C;}}
  new MutationObserver(records=>{
    const added=records.flatMap(r=>Array.from(r.addedNodes));
    if(added.some(n=>n.nodeType===1&&(n.matches?.('canvas')||n.querySelector?.('canvas'))))scheduleRender();
  }).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('be-dark-change',scheduleRender);
  window.addEventListener('pageshow',()=>{scheduleRender();if(started&&Date.now()-lastFetch>14000)poll();});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)scheduleRender();});
  let startupTries=0;
  const startupTimer=setInterval(()=>{register();scheduleRender();const C=window.Chart,ready=C?.getChart&&(C.getChart('soc-chart')||C.getChart('soc-forecast-chart'));if(ready||++startupTries>=40)clearInterval(startupTimer);},500);
  register();compute();render();
  setInterval(()=>{register();render();},5000);
  let storageTimer;
  try{db=await Promise.race([openDB(),new Promise((_,reject)=>{storageTimer=setTimeout(()=>reject(Error('Opslag reageert niet')),3000);})]);await persist();}
  catch(e){storageError='Lokale opslag niet beschikbaar: '+e.message;}
  finally{clearTimeout(storageTimer);started=true;compute();await poll();}
  setInterval(()=>{if(Date.now()-lastFetch>14000)poll();},15000);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)poll();});
  window.addEventListener('storage',e=>{if(e.key===key){try{cfg=JSON.parse(e.newValue||'{}');compute();render();}catch{}}});
})();

  }
  if (document.readyState !== 'loading') beCoulombMain();
  else document.addEventListener('DOMContentLoaded', beCoulombMain, {once:true});
})();
