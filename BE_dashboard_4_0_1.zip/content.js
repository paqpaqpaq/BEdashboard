// ==UserScript==
// @name         Balansenergie All-in v4
// @namespace    paq.balansenergie
// @version      4.0.1
// @description  Wat je stroom werkelijk kost: vier regels en een saldo, met prijsopbouw, accu, aFRR en saldering achter knoppen, en het contractjaar in beeld.
// @match        *://dashboard.balansenergie.nl/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

/*
 *  ── De rekenbasis ─────────────────────────────────────────────
 *
 *  Balans vernieuwde het Resultaten-dashboard in september 2026. Alles komt
 *  nu uit één endpoint:
 *
 *      results-v2-api/?interval=day|month|year&period=…
 *                     &include_vat=0|1&include_delivery_cost=0|1
 *
 *  Met beide vlaggen aan rekent Balans zo, nagerekend over augustus en
 *  december 2026:
 *
 *      inkoop  = kaal x 1,21 + 0,02 x import_kWh
 *      verkoop = kaal x 1,21 - 0,02 x export_kWh
 *
 *      Aug: 12,98 x 1,21 + 200,219 x 0,02 = 19,71   (dashboard 19,70)
 *      Dec: 87,387 x 1,21 + 1509,654 x 0,02 = 135,93 (dashboard 135,88)
 *
 *  Die getallen zijn het uitgangspunt. Ze zijn compleet op één post na: de
 *  energiebelasting. Het woord "belasting" komt nul keer voor op de pagina.
 *
 *      stroom all-in = wat Balans toont + EB over het netto verbruik
 *
 *  EB is btw-plichtig, dus 0,111 x 1,21 = 0,13431 per kWh. Netto verbruik is
 *  import min de export die binnen de saldeerruimte valt; saldering loopt over
 *  het hele contractjaar, dus die berekening gaat cumulatief door de twaalf
 *  maanden en niet per maand opnieuw.
 *
 *  ── De opzet ─────────────────────────────────────────────────
 *
 *  Eén kaart, van boven naar beneden te lezen. Geen tabbladen, geen knoppen
 *  die iets verborgen houden.
 *
 *      Afname van het net    200 kWh a EUR 0,233     -  46,59
 *      Teruglevering         767 kWh a EUR 0,370     + 283,60
 *      Netbeheer             31 dagen                +   3,68
 *      Voorschot                                     +  42,98
 *      ------------------------------------------------------
 *      Saldo                                         + 283,66
 *
 *      Prijsopbouw per kWh      waar die 23,3 en 37,0 ct vandaan komen
 *      Accu                     FPR, per dag berekend en opgeteld
 *      Contractjaar             twaalf maanden, geschiedenis en prognose
 *      Salderingsbalans         import tegen export
 *
 *  De prijsopbouw is de enige plek waar staat waarin de all-in prijs afwijkt
 *  van het cijfer van Balans. Daarbuiten wordt dat nergens herhaald.
 *
 *  De schakelaar in de kaartkop werkt als in v3: aan zet de KPI-kaarten, de
 *  kWh-prijzen en de staafgrafiek van Balans zelf op all-in. Uit zet ze exact
 *  terug — de originele waarden komen uit de API, niet uit een DOM-snapshot.
 *
 *  Het blok "Balans Systeem resultaat" wordt ingeklapt. Dat is een verschil
 *  tegenover een vast contract, en in een verschil valt de energiebelasting
 *  aan beide kanten tegen elkaar weg; er valt dus niets all-in aan te maken.
 *  Schakelaar in de instellingen om het terug te halen.
 *
 */

(function () {
  'use strict';

  // ══════════════════════════════════════════════════════════════════════
  //  Constanten
  // ══════════════════════════════════════════════════════════════════════

  // Energiebelasting elektriciteit 2026, schijf 1 en 2 (tot 10.000 kWh):
  // EUR 0,09161 per kWh excl. btw, EUR 0,11085 incl. 21% btw.
  //
  // Let op: de EUR 0,111 die sinds v3 in dit script stond is het tarief
  // ínclusief btw, niet exclusief. Er nog eens 21% overheen zetten gaf
  // 0,13431 en dat is een vijfde te hoog. Over elf maanden scheelde dat
  // bijna zestig euro in de jaarprognose.
  var EB_BASIS = 0.09161;                  // excl. btw
  var BTW      = 1.21;
  var EB       = 0.11085;                  // incl. btw, wat er hier bij hoort
  var OPSLAG   = 0.02;                     // leverkosten Balans, zit al in hun cijfer

  // Vaste posten per dag, incl. BTW. Levering en transport zijn kosten, de
  // vermindering energiebelasting is een teruggave die groter is dan beide.
  var LEV_DAG = 0.2184;
  var TRA_DAG = 1.3861;
  var VER_DAG = 628.96 / 365;   // vermindering energiebelasting 2026, incl. btw
  var VAST_DAG = VER_DAG - LEV_DAG - TRA_DAG;    // +0,1187 per dag

  var LS = {
    voorschot:  'be_cfg_voorschot',
    startdatum: 'be_cfg_startdatum',
    saldering:  'be_cfg_saldering',
    balansBlok: 'be_cfg_balansblok',
    allin:      'be_cfg_allin_aan'
  };

  var MND_KORT = ['Jan', 'Feb', 'Mrt', 'Apr', 'Mei', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];
  var MND_LANG = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli',
                  'augustus', 'september', 'oktober', 'november', 'december'];

  var D = {
    rand:       '#e8e2f0',
    label:      '#8c6fb5',
    paars:      '#6B3FA0',
    paarsLicht: '#9b7ec8',
    rood:       '#dc3545',
    groen:      '#198754',
    oranje:     '#e07b00',
    grijs:      '#6c757d',
    inkt:       '#2b2733',
    roodZacht:  '#c8a0a0',
    groenZacht: '#90c8a0'
  };

  // ══════════════════════════════════════════════════════════════════════
  //  Instellingen
  // ══════════════════════════════════════════════════════════════════════

  var cfg = {
    voorschot: parseFloat(localStorage.getItem(LS.voorschot) || '42.98'),
    start: (function () {
      var s = localStorage.getItem(LS.startdatum);
      if (s) { var d = new Date(s); if (!isNaN(d)) return d; }
      return new Date('2025-11-04');
    })(),
    saldering:  localStorage.getItem(LS.saldering) !== 'uit',
    balansBlok: localStorage.getItem(LS.balansBlok) === 'aan',
    allin:      localStorage.getItem(LS.allin) === 'aan'
  };

  var salderingPrognose = false;   // schakelaar binnen de salderingskaart

  // ══════════════════════════════════════════════════════════════════════
  //  Opmaak
  // ══════════════════════════════════════════════════════════════════════

  function n2(v) { return String(v).padStart(2, '0'); }
  function iso(d) { return d.getFullYear() + '-' + n2(d.getMonth() + 1) + '-' + n2(d.getDate()); }
  function getal(v) { return (typeof v === 'number' && isFinite(v)) ? v : 0; }

  function eur(v, dec) {
    if (dec === undefined) dec = 2;
    return '\u20ac\u00a0' + Math.abs(v).toLocaleString('nl-NL',
      { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }
  function eurT(v, dec) {
    if (dec === undefined) dec = 2;
    return (v < 0 ? '\u2212' : '+') + '\u00a0\u20ac\u00a0' + Math.abs(v).toLocaleString('nl-NL',
      { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }
  function eurCent(v) {
    return (v < 0 ? '\u2212' : '+') + '\u20ac' + Math.abs(v).toLocaleString('nl-NL',
      { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  function eurKort(v) {
    return (v < 0 ? '\u2212' : '+') + '\u20ac' + Math.round(Math.abs(v)).toLocaleString('nl-NL');
  }
  function num(v, dec) {
    return getal(v).toLocaleString('nl-NL', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }
  function kwh(v) { return num(v, 0) + ' kWh'; }
  function ct(v) { return num(v * 100, 1) + ' ct'; }
  function prijs(v) { return eur(v, 3) + ' / kWh'; }
  function kleur(v) { return v < 0 ? D.rood : D.groen; }
  function kleurZacht(v) { return v < 0 ? D.roodZacht : D.groenZacht; }

  function maandLabel(mk) {
    var p = String(mk).split('-');
    return MND_KORT[parseInt(p[1], 10) - 1] + ' ' + p[0];
  }
  function maandNaam(mk) {
    return MND_LANG[parseInt(String(mk).split('-')[1], 10) - 1];
  }
  function dagenInMaand(mk) {
    var p = String(mk).split('-');
    return new Date(parseInt(p[0], 10), parseInt(p[1], 10), 0).getDate();
  }
  /** Hoeveel dagen van deze maand zijn er werkelijk verwerkt?
   *
   *  Niet de kalender. Stond hier de datum van vandaag, dan telde
   *  "berekend t/m 4 september" dagen mee waarvoor geen cijfers bestaan, en
   *  liepen de netbeheerkosten voor op de stroomkosten in dezelfde regel.
   *
   *  `results-bounds-data` in de HTML is er ook niet goed voor: die gaf
   *  max_day 1 september terwijl de API al twee dagregels teruggaf. Die grens
   *  loopt zelf een dag achter. Daarom tellen we de dagregels van de lopende
   *  maand, want die levert Balans alleen voor verwerkte dagen. */
  var dagenLopend = null;

  function haalLopendeDagen() {
    if (dagenLopend !== null) return Promise.resolve(dagenLopend);
    var mk = iso(new Date()).slice(0, 7);
    var u = new URL(location.origin + '/customer/' + KLANT + '/results-v2-api/');
    u.searchParams.set('interval', 'month');
    u.searchParams.set('period', mk);
    u.searchParams.set('include_vat', '1');
    u.searchParams.set('include_delivery_cost', '1');
    return origFetch(u, { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        dagenLopend = (j && Array.isArray(j.series)) ? j.series.length : 0;
        return dagenLopend;
      })
      .catch(function () { dagenLopend = 0; return 0; });
  }

  function dagenVerstreken(mk) {
    var nu = new Date();
    var lopend = iso(nu).slice(0, 7);
    if (mk === lopend) return dagenLopend !== null ? dagenLopend : nu.getDate();
    if (mk > lopend) return 0;
    return dagenInMaand(mk);
  }

  /** Het voorschot naar rato van de verwerkte dagen.
   *
   *  Alleen voor de maandkaart bovenaan. Daar staat wat er nú tegenover
   *  elkaar staat, en dan is een vol voorschot van EUR 42,98 tegenover twee
   *  dagen kosten misleidend: september kwam zo op + EUR 53,89 terwijl er
   *  + EUR 13,77 tegenover die twee dagen staat.
   *
   *  Niet voor de maandstaat van het contractjaar. Die kijkt vooruit: elke
   *  maand levert uiteindelijk een heel voorschot op, dus daar telt het volle
   *  bedrag en loopt het cumulatieve saldo naar het jaareinde toe.
   *
   *  De andere posten hoefden niet: netbeheer en de vermindering
   *  energiebelasting rekenen al per dag, de energiebelasting per kWh.
   */
  function voorschotVoor(mk, dagen, geschat) {
    if (geschat || !mk || !/^\d{4}-\d{2}$/.test(String(mk))) return cfg.voorschot;
    var totaal = dagenInMaand(mk);
    if (!(dagen > 0) || dagen >= totaal) return cfg.voorschot;
    return cfg.voorschot * dagen / totaal;
  }

  function isLopendeMaand(mk) { return mk === iso(new Date()).slice(0, 7); }
  function naSaldering(mk) { return parseInt(String(mk).slice(0, 4), 10) >= 2027; }

  function contractMaanden() {
    var uit = [];
    for (var i = 0; i < 12; i++) {
      var d = new Date(cfg.start.getFullYear(), cfg.start.getMonth() + i, 1);
      uit.push(d.getFullYear() + '-' + n2(d.getMonth() + 1));
    }
    return uit;
  }

  function el(tag, css, html) {
    var e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (html !== undefined) e.innerHTML = html;
    return e;
  }
  function kaart(id, titel, rechts) {
    var c = el('div', 'background:#fff;border:1px solid ' + D.rand + ';border-radius:10px;' +
      'padding:15px 18px 17px;margin-top:14px;box-shadow:0 1px 4px rgba(107,63,160,.06);');
    c.id = id;
    if (titel) {
      c.appendChild(el('div',
        'display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px;',
        '<span style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:' +
        D.label + ';">' + titel + '</span>' + (rechts || '')));
    }
    return c;
  }

  /** Een blok binnen de hoofdkaart. Geen eigen rand of schaduw: alleen een
   *  haarlijn en een kopje, zodat alles in één kaart blijft. */
  function sectie(id, titel, rechts) {
    var c = el('div', 'margin-top:20px;padding-top:17px;border-top:1px solid ' + D.rand + ';');
    c.id = id;
    if (titel) {
      c.appendChild(el('div',
        'display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px;',
        '<span style="font-size:10px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:' +
        D.label + ';">' + titel + '</span>' + (rechts || '')));
    }
    return c;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Datalaag
  // ══════════════════════════════════════════════════════════════════════

  var klantMatch = location.pathname.match(/^\/customer\/([^/]+)\//);
  var KLANT = klantMatch ? klantMatch[1] : null;
  var origFetch = window.fetch.bind(window);

  /** Een regel uit results-v2-api normaliseren naar de incl-variant.
   *
   *  De API biedt maar twee varianten: beide vlaggen aan, of beide uit. Om
   *  van kaal naar incl te komen moeten de stappen in de volgorde van Balans:
   *  eerst BTW over de stroom, dan de 2 ct erbij (die staat buiten de BTW).
   */
  function naarIncl(rij, pv) {
    var imp = getal(rij.import_kwh), exp = getal(rij.export_kwh);
    var buy = getal(rij.total_buy_eur), sell = getal(rij.total_sell_eur);
    if (!pv.include_vat) { buy *= BTW; sell *= BTW; }
    if (!pv.include_delivery_cost) { buy += imp * OPSLAG; sell -= exp * OPSLAG; }
    return {
      key: rij.month || rij.date || null,
      status: rij.status || null,
      imp: imp, exp: exp,
      inkoop: buy, verkoop: sell,
      afrrImp: getal(rij.afrr_import_kwh), afrrExp: getal(rij.afrr_export_kwh),
      laden: getal(rij.battery_charged_kwh), ontladen: getal(rij.battery_discharged_kwh),
      pv: getal(rij.pv_estimated_kwh),
      afrrVergoeding: getal(rij.balance_energie_eur) + getal(rij.deal_customer_share_eur),
      dealsAantal: getal(rij.deals_count),
      // wat de pagina zelf laat zien, om de schakelaar terug te kunnen zetten
      ruwInkoop: getal(rij.total_buy_eur), ruwVerkoop: getal(rij.total_sell_eur),
      ruwPrijsInk: rij.avg_buy_price_eur_per_kwh, ruwPrijsVerk: rij.avg_sell_price_eur_per_kwh
    };
  }

  var cacheJaar = {};
  function haalJaar(jaar) {
    if (cacheJaar[jaar]) return Promise.resolve(cacheJaar[jaar]);
    var u = new URL(location.origin + '/customer/' + KLANT + '/results-v2-api/');
    u.searchParams.set('interval', 'year');
    u.searchParams.set('period', String(jaar));
    u.searchParams.set('include_vat', '1');
    u.searchParams.set('include_delivery_cost', '1');
    return origFetch(u, { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        var rijen = (j && Array.isArray(j.series))
          ? j.series.map(function (s) { return naarIncl(s, j.pricing || {}); }) : [];
        cacheJaar[jaar] = rijen;
        return rijen;
      })
      .catch(function () { cacheJaar[jaar] = []; return []; });
  }

  var contractCache = null;
  function haalContractjaar() {
    if (contractCache) return Promise.resolve(contractCache);
    var jaren = {};
    contractMaanden().forEach(function (mk) { jaren[mk.slice(0, 4)] = true; });
    return Promise.all(Object.keys(jaren).map(haalJaar)).then(function (sets) {
      var op = {};
      sets.forEach(function (rijen) {
        rijen.forEach(function (r) { if (r.key) op[r.key] = r; });
      });
      contractCache = contractMaanden().map(function (mk) {
        return op[mk] || { key: mk, leeg: true, imp: 0, exp: 0, inkoop: 0, verkoop: 0,
                           laden: 0, ontladen: 0, pv: 0, afrrImp: 0, afrrExp: 0,
                           afrrVergoeding: 0, dealsAantal: 0 };
      });
      return contractCache;
    });
  }

  function grenzen() {
    try {
      var e = document.getElementById('results-bounds-data');
      return e ? JSON.parse(e.textContent) : null;
    } catch (e) { return null; }
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Prognose voor maanden die Balans nog niet heeft
  //
  //  Twee lagen. De kWh-schatting schaalt bekende maanden om met een
  //  seizoensfactor, zodat de salderingsbalans vooruit kan kijken. De
  //  bedragschatting interpoleert tussen drie ankers uit de eigen
  //  geschiedenis: de slechtste wintermaand, het gemiddelde van de
  //  tussenmaanden en de beste zomermaand.
  // ══════════════════════════════════════════════════════════════════════

  var IMP_FACTOR = { Jan: 1.00, Feb: 0.62, Mrt: 0.25, Apr: 0.09, Mei: 0.02, Jun: 0.01,
                     Jul: 0.02, Aug: 0.03, Sep: 0.10, Okt: 0.32, Nov: 0.57, Dec: 0.87 };
  var EXP_FACTOR = { Jan: 0.10, Feb: 0.18, Mrt: 0.45, Apr: 1.00, Mei: 1.30, Jun: 1.32,
                     Jul: 1.18, Aug: 0.96, Sep: 0.74, Okt: 0.28, Nov: 0.12, Dec: 0.08 };
  var PROFIEL = {
    Jan: { w: 1.00, z: 0.00 }, Feb: { w: 0.72, z: 0.00 }, Mrt: { w: 0.28, z: 0.10 },
    Apr: { w: 0.08, z: 0.28 }, Mei: { w: 0.00, z: 0.62 }, Jun: { w: 0.00, z: 1.00 },
    Jul: { w: 0.00, z: 0.86 }, Aug: { w: 0.04, z: 0.52 }, Sep: { w: 0.14, z: 0.24 },
    Okt: { w: 0.26, z: 0.08 }, Nov: { w: 0.64, z: 0.00 }, Dec: { w: 0.90, z: 0.00 }
  };
  function mk3(mk) { return MND_KORT[parseInt(String(mk).split('-')[1], 10) - 1]; }

  function schatKwh(mk, bekend, factoren, terugval) {
    var doelF = factoren[mk3(mk)] || 0.5;
    if (!bekend.length) return terugval * doelF;
    var gew = 0, som = 0;
    bekend.forEach(function (b) {
      var ankerF = factoren[mk3(b.key)] || 0.1;
      if (ankerF < 0.05) return;
      var vergelijkbaar = Math.min(ankerF, doelF) / Math.max(ankerF, doelF);
      var g = 0.3 + vergelijkbaar * 0.7;
      gew += g;
      som += b.waarde * (doelF / ankerF) * g;
    });
    return gew > 0 ? som / gew : 0;
  }

  function ankers(bedragPerMaand) {
    var bekend = Object.keys(bedragPerMaand).map(function (k) {
      return { m: mk3(k), v: bedragPerMaand[k] };
    });
    function kies(namen) { return bekend.filter(function (b) { return namen.indexOf(b.m) !== -1; }); }
    var winterSet = kies(['Nov', 'Dec', 'Jan', 'Feb']);
    var zomerSet  = kies(['Mei', 'Jun', 'Jul', 'Aug']);
    var tussenSet = kies(['Mrt', 'Apr', 'Sep', 'Okt']);
    var winter = winterSet.length ? Math.min.apply(null, winterSet.map(function (b) { return b.v; })) : -260;
    var zomer  = zomerSet.length  ? Math.max.apply(null, zomerSet.map(function (b) { return b.v; }))  : 110;
    var tussen = tussenSet.length
      ? tussenSet.reduce(function (a, b) { return a + b.v; }, 0) / tussenSet.length : 25;
    if (tussen < winter) tussen = winter + 40;
    if (zomer < tussen) zomer = tussen + 40;
    return { winter: winter, tussen: tussen, zomer: zomer };
  }

  function prognoseBedrag(mk, a) {
    var p = PROFIEL[mk3(mk)] || { w: 0.25, z: 0.20 };
    return a.tussen - (a.tussen - a.winter) * p.w + (a.zomer - a.tussen) * p.z;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Saldering over het contractjaar
  //
  //  Export is gesaldeerd zolang de cumulatieve export de cumulatieve import
  //  niet voorbij is. Per maand kloppen die grenzen niet — het is één pot per
  //  verbruiksjaar — dus dit loopt cumulatief door de twaalf maanden.
  // ══════════════════════════════════════════════════════════════════════

  function salderingReeks(rijen, metPrognose) {
    var bekendImp = [], bekendExp = [];
    rijen.forEach(function (r) {
      if (r.leeg) return;
      if (r.imp > 0) bekendImp.push({ key: r.key, waarde: r.imp });
      if (r.exp > 0) bekendExp.push({ key: r.key, waarde: r.exp });
    });

    var cumImp = 0, cumExp = 0;
    return rijen.map(function (r) {
      var geschat = !!r.leeg;
      var imp = r.imp, exp = r.exp;
      if (geschat) {
        if (metPrognose) {
          imp = schatKwh(r.key, bekendImp, IMP_FACTOR, 150);
          exp = schatKwh(r.key, bekendExp, EXP_FACTOR, 0);
        } else { imp = 0; exp = 0; }
      }
      var impVoor = cumImp, expVoor = cumExp;
      cumImp += imp; cumExp += exp;

      var onges;
      if (naSaldering(r.key)) onges = exp;
      else if (cumExp <= cumImp) onges = 0;
      else if (expVoor >= impVoor && impVoor > 0) onges = exp;
      else {
        var ruimte = Math.max(0, impVoor - expVoor) + imp;
        onges = Math.max(0, exp - Math.min(exp, ruimte));
      }
      return {
        key: r.key, imp: imp, exp: exp, cumImp: cumImp, cumExp: cumExp,
        ongesaldeerd: onges, gesaldeerd: exp - onges,
        geschat: geschat, overgeslagen: geschat && !metPrognose,
        naSaldering: naSaldering(r.key)
      };
    });
  }

  // ══════════════════════════════════════════════════════════════════════
  //  De rekenregel
  //
  //      stroom all-in = cijfer van Balans (incl. BTW en 2 ct)
  //                    + EB over het netto verbruik, incl. BTW
  //
  //  Tekenafspraak: alles is een bijdrage aan het resultaat. Kosten negatief,
  //  opbrengsten positief. Elke regel telt gewoon op tot het totaal.
  // ══════════════════════════════════════════════════════════════════════

  function bereken(r, expOngesaldeerd, dagen) {
    var imp = r.imp, exp = r.exp;
    var onges = Math.min(getal(expOngesaldeerd), exp);
    var ges = Math.max(0, exp - onges);

    var balansInk  = -r.inkoop;      // hun inkoop is een positief bedrag = kosten
    var balansVerk =  r.verkoop;
    var balansNetto = balansInk + balansVerk;

    var ebInk  = -imp * EB;
    var ebVerk =  ges * EB;
    var eb = ebInk + ebVerk;

    var stroom = balansNetto + eb;
    var vast = getal(dagen) * VAST_DAG;

    var allinInk  = balansInk + ebInk;
    var allinVerk = balansVerk + ebVerk;

    return {
      key: r.key,
      imp: imp, exp: exp,
      balansInk: balansInk, balansVerk: balansVerk, balansNetto: balansNetto,
      eb: eb, ebInk: ebInk, ebVerk: ebVerk,
      ongesaldeerd: onges, gesaldeerd: ges,
      allinInk: allinInk, allinVerk: allinVerk,
      stroom: stroom,
      vast: vast,
      voorschot: voorschotVoor(r.key, getal(dagen), false),
      totaal: stroom + vast,
      saldo: stroom + vast + voorschotVoor(r.key, getal(dagen), false),
      dagen: getal(dagen),
      prijsInk:  imp > 0 ? Math.abs(allinInk) / imp : 0,
      prijsVerk: exp > 0 ? allinVerk / exp : 0,
      prijsInkBalans:  imp > 0 ? r.inkoop / imp : 0,
      prijsVerkBalans: exp > 0 ? r.verkoop / exp : 0,
      laden: r.laden, ontladen: r.ontladen, pv: r.pv,
      afrrImp: r.afrrImp, afrrExp: r.afrrExp,
      afrrVergoeding: r.afrrVergoeding, dealsAantal: r.dealsAantal,
      geschat: !!r.leeg
    };
  }

  /** FPR: wat is een euro aan laadkosten waard geworden bij ontladen?
   *
   *  Per deelperiode uitrekenen en dan pas optellen. Op één maandgemiddelde
   *  rekenen wist het verschil tussen goedkope en dure dagen uit, en dat is
   *  precies waar de accu op verdient: augustus 2026 gaf 1,37 op het
   *  maandgemiddelde tegen 1,19 per dag opgeteld.
   *
   *  Laden gaat tegen de all-in inkoopprijs. Dat is een keuze, geen wet: van
   *  de 1.093 kWh die in augustus geladen werd kwam maar een klein deel van
   *  het net, de rest uit eigen PV. Wie die PV waardeert tegen de misgelopen
   *  teruglevering komt lager uit.
   */
  function fpr(rijen) {
    if (!rijen || !rijen.length) return null;
    var laad = 0, ont = 0, laadKwh = 0, ontKwh = 0, meegeteld = 0;
    rijen.forEach(function (a) {
      if (!a.laden && !a.ontladen) return;
      if (!a.prijsInk && !a.prijsVerk) return;
      var viaNet = Math.min(a.exp, a.ontladen);
      var viaHuis = Math.max(0, a.ontladen - viaNet);
      laad += a.laden * a.prijsInk;
      ont  += viaNet * a.prijsVerk + viaHuis * a.prijsInk;
      laadKwh += a.laden;
      ontKwh  += a.ontladen;
      meegeteld++;
    });
    if (laad <= 0) return null;
    return {
      ratio: ont / laad,
      laadKwh: laadKwh, ontlaadKwh: ontKwh,
      gemLaad: laadKwh > 0 ? laad / laadKwh : 0,
      gemOntlaad: ontKwh > 0 ? ont / ontKwh : 0,
      netto: ont - laad,
      retour: laadKwh > 0 ? ontKwh / laadKwh : 0,
      perioden: meegeteld
    };
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Hoofdkaart: de opbouw van het bedrag
  // ══════════════════════════════════════════════════════════════════════

  function regel(label, waarde, o) {
    o = o || {};
    var kl = o.neutraal ? D.inkt : kleur(waarde);
    var fs = o.groot ? '15.5px' : '12.5px';
    var streep = o.streep ? 'border-top:1px solid ' + D.rand + ';margin-top:8px;padding-top:9px;' : '';
    var sub = o.sub
      ? '<div style="font-size:10.5px;color:' + D.grijs + ';margin-top:2px;line-height:1.4;">' + o.sub + '</div>'
      : '';
    return '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px;padding:4px 0;' + streep + '">' +
      '<div style="font-size:' + fs + ';font-weight:' + (o.dik ? '600' : '400') + ';color:' +
        (o.dik ? D.inkt : '#4a4453') + ';">' + label + sub + '</div>' +
      '<div style="font-size:' + fs + ';font-weight:' + (o.dik ? '700' : '500') + ';color:' + kl +
        ';white-space:nowrap;font-variant-numeric:tabular-nums;">' + eurT(waarde) + '</div>' +
    '</div>';
  }

  function vakje(kop, groot, klein, kl) {
    return '<div style="padding:10px 12px;border:1px solid ' + D.rand + ';border-radius:8px;">' +
      '<div style="font-size:10px;text-transform:uppercase;letter-spacing:.06em;color:' + D.grijs + ';">' + kop + '</div>' +
      '<div style="font-size:17px;font-weight:700;margin-top:2px;color:' + (kl || D.inkt) +
        ';font-variant-numeric:tabular-nums;">' + groot + '</div>' +
      '<div style="font-size:10.5px;color:' + D.grijs + ';margin-top:2px;">' + klein + '</div>' +
    '</div>';
  }

  function bouwHoofdkaart(a, ctx) {
    var c = kaart('be-hoofd', null);
    var perMaand = ctx.interval === 'month';
    // Loopt de maand nog? Dan is alles naar rato van de verwerkte dagen, ook
    // het voorschot. Dat moet je kunnen zien, anders lijkt het bedrag gewoon
    // laag in plaats van afgeknipt.
    var volDagen = perMaand && a.key ? dagenInMaand(a.key) : 0;
    var deelPeriode = perMaand && volDagen > 0 && a.dagen > 0 && a.dagen < volDagen;

    function rij(label, detail, bedrag, o) {
      o = o || {};
      var streep = o.streep ? 'border-top:1px solid ' + (o.dik ? D.rand : D.rand) + ';' : '';
      var gew = o.dik ? '600' : '400';
      return '<tr>' +
        '<td style="padding:8px 0;' + streep + 'font-size:13.5px;font-weight:' + gew + ';color:' + D.inkt + ';">' +
          label + '</td>' +
        '<td style="padding:8px 0;' + streep + 'font-size:12px;color:' + D.grijs + ';white-space:nowrap;">' +
          (detail || '') + '</td>' +
        '<td style="padding:8px 0;' + streep + 'text-align:right;font-size:13.5px;font-weight:' +
          (o.dik ? '700' : '500') + ';white-space:nowrap;font-variant-numeric:tabular-nums;color:' +
          (o.neutraal ? D.inkt : kleur(bedrag)) + ';">' + eurT(bedrag) + '</td></tr>';
    }

    var tabel =
      '<table style="width:100%;border-collapse:collapse;table-layout:fixed;">' +
        '<colgroup><col style="width:40%"><col style="width:30%"><col style="width:30%"></colgroup>' +
        rij('Afname van het net', kwh(a.imp) + ' \u00e0 ' + eur(a.prijsInk, 3), a.allinInk) +
        rij('Teruglevering', kwh(a.exp) + ' \u00e0 ' + eur(a.prijsVerk, 3), a.allinVerk) +
        rij('Netbeheer', num(a.dagen, 0) + ' dagen', a.vast, { streep: true }) +
        (perMaand ? rij('Voorschot', deelPeriode ? a.dagen + ' van ' + volDagen + ' dagen' : '',
              a.voorschot, { neutraal: true }) : '') +
        rij(perMaand ? 'Saldo' : 'Totaal', '', perMaand ? a.saldo : a.totaal, { dik: true, streep: true }) +
      '</table>';

    var eindbedrag = perMaand ? a.saldo : a.totaal;
    var kop =
      '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px;' +
          'flex-wrap:wrap;margin-bottom:14px;">' +
        '<div><div style="font-size:17px;font-weight:600;color:' + D.inkt + ';">' + ctx.naam + '</div>' +
        '<div style="font-size:12px;color:' + D.grijs + ';margin-top:2px;">' +
          (deelPeriode
            ? num(a.dagen, 0) + ' van ' + volDagen + ' dagen \u00b7 alles naar rato'
            : (a.dagen ? num(a.dagen, 0) + ' dagen \u00b7 ' : '') + 'alles inbegrepen') +
        '</div></div>' +
        '<div style="text-align:right;"><div style="font-size:27px;font-weight:700;line-height:1.1;color:' +
          kleur(eindbedrag) + ';font-variant-numeric:tabular-nums;">' + eurT(eindbedrag) + '</div>' +
        '<div style="font-size:12px;color:' + D.grijs + ';">' +
          (perMaand ? (eindbedrag < 0 ? 'nog te betalen' : 'te ontvangen')
                    : (eindbedrag < 0 ? 'kosten' : 'opbrengst')) + '</div></div>' +
      '</div>';

    c.innerHTML = kop + tabel;
    if (deelPeriode) {
      c.appendChild(el('div', 'margin-top:10px;font-size:11px;color:' + D.grijs + ';line-height:1.5;',
        'Balans heeft ' + a.dagen + ' van de ' + volDagen + ' dagen verwerkt. Netbeheer en voorschot ' +
        'tellen naar rato mee, zodat er niet een hele maand voorschot tegenover ' + a.dagen +
        ' dagen kosten staat. Het resterende deel van het voorschot is wel betaald en schuift mee ' +
        'zodra de maand compleet is.'));
    }
    return c;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Paneel: prijsopbouw
  //
  //  Dit is de enige plek waar het onderscheid tussen de cijfers van Balans
  //  en de all-in prijs wordt uitgelegd. Eén keer, hier, en verder nergens.
  // ══════════════════════════════════════════════════════════════════════

  function bouwPrijsopbouw(a) {
    var c = sectie('be-prijs', 'Prijsopbouw per kWh');

    function kolomPrijs(titel, balansPrijs, ebDeel, allinPrijs, kl, voet) {
      return '<div style="padding:12px 14px;border:1px solid ' + D.rand + ';border-radius:9px;">' +
        '<div style="font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:' + D.grijs +
          ';margin-bottom:9px;">' + titel + '</div>' +
        '<div style="display:flex;justify-content:space-between;font-size:12.5px;padding:3px 0;">' +
          '<span style="color:#4a4453;">Volgens Balans</span>' +
          '<span style="font-variant-numeric:tabular-nums;">' + eur(balansPrijs, 3) + '</span></div>' +
        '<div style="display:flex;justify-content:space-between;font-size:12.5px;padding:3px 0;">' +
          '<span style="color:#4a4453;">Energiebelasting</span>' +
          '<span style="font-variant-numeric:tabular-nums;color:' + kl + ';">' +
            (ebDeel < 0 ? '\u2212' : '+') + ' ' + eur(Math.abs(ebDeel), 3) + '</span></div>' +
        '<div style="display:flex;justify-content:space-between;font-size:14px;font-weight:700;padding:7px 0 0;' +
          'margin-top:5px;border-top:1px solid ' + D.rand + ';"><span>All-in</span>' +
          '<span style="font-variant-numeric:tabular-nums;color:' + kl + ';">' + eur(allinPrijs, 3) + '</span></div>' +
        '<div style="font-size:11px;color:' + D.grijs + ';margin-top:6px;line-height:1.45;">' + voet + '</div>' +
      '</div>';
    }

    var ebVerkPerKwh = a.exp > 0 ? a.ebVerk / a.exp : 0;
    c.appendChild(el('div', 'display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px;',
      kolomPrijs('Afname', a.prijsInkBalans, EB, a.prijsInk, D.rood,
        'Het cijfer van Balans is inclusief BTW en de 2 ct leverkosten. Daar komt ' + eur(EB_BASIS, 3) +
        ' energiebelasting plus 21% BTW bij, dus ' + eur(EB, 5) + '.') +
      kolomPrijs('Teruglevering', a.prijsVerkBalans, ebVerkPerKwh, a.prijsVerk, D.groen,
        a.ongesaldeerd > 0.5
          ? kwh(a.gesaldeerd) + ' van de ' + kwh(a.exp) + ' valt binnen de saldering en krijgt EB terug; ' +
            kwh(a.ongesaldeerd) + ' niet. Gemiddeld dus minder dan ' + eur(EB, 5) + '.'
          : 'Alle teruglevering valt binnen de saldeerruimte, dus over elke kWh komt ' + eur(EB, 5) +
            ' energiebelasting terug.')));

    c.appendChild(el('div', 'margin-top:12px;padding-top:12px;border-top:1px solid ' + D.rand +
      ';display:flex;gap:24px;flex-wrap:wrap;row-gap:12px;',
      kolom('Spread all-in', ct(a.prijsVerk - a.prijsInk) + ' / kWh', 'verkoop \u2212 inkoop', D.paars) +
      kolom('Energiebelasting', eurT(a.eb), kwh(a.imp) + ' af, ' + kwh(a.gesaldeerd) + ' terug', kleur(a.eb)) +
      kolom('Netbeheer', eurT(a.vast),
        'levering ' + eur(LEV_DAG, 4) + ' + transport ' + eur(TRA_DAG, 4) +
        ' \u2212 vermindering ' + eur(VER_DAG, 4) + ' per dag', kleur(a.vast))));
    return c;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  FPR
  // ══════════════════════════════════════════════════════════════════════

  function fprKleur(r) {
    if (r >= 1.6) return D.groen;
    if (r >= 1.05) return D.paars;
    if (r >= 1.0) return D.oranje;
    return D.rood;
  }
  function fprWoord(r) {
    if (r >= 1.8) return 'Uitstekend';
    if (r >= 1.6) return 'Zeer goed';
    if (r >= 1.4) return 'Goed';
    if (r >= 1.2) return 'Redelijk';
    if (r >= 1.05) return 'Matig';
    if (r >= 1.0) return 'Break-even';
    return 'Verlies';
  }

  function kolom(kop, groot, klein, kl) {
    return '<div style="min-width:96px;">' +
      '<div style="font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:' + D.grijs + ';">' + kop + '</div>' +
      '<div style="font-size:13.5px;font-weight:600;margin-top:2px;color:' + D.inkt +
        ';font-variant-numeric:tabular-nums;">' + groot + '</div>' +
      '<div style="font-size:11px;font-weight:700;color:' + kl + ';">' + klein + '</div></div>';
  }

  function bouwFpr(f, periodeWoord) {
    if (!f) return null;
    var c = sectie('be-fpr', 'Accu \u00b7 financial performance ratio');
    var kl = fprKleur(f.ratio);
    var pct = Math.min(100, Math.max(0, (f.ratio / 2) * 100));
    c.appendChild(el('div', 'display:flex;gap:28px;flex-wrap:wrap;align-items:center;row-gap:18px;',
      '<div style="display:flex;align-items:center;gap:13px;">' +
        '<div style="font-size:40px;font-weight:700;line-height:1;color:' + kl +
          ';font-variant-numeric:tabular-nums;">' + num(f.ratio, 2) + '</div>' +
        '<div><div style="font-size:13px;font-weight:700;color:' + kl + ';">' +
          (f.ratio >= 1 ? '+' : '') + num((f.ratio - 1) * 100, 0) + '% rendement</div>' +
          '<div style="font-size:11px;font-weight:600;color:' + kl + ';opacity:.85;">' + fprWoord(f.ratio) + '</div>' +
          '<div style="font-size:10px;color:' + D.grijs + ';">waarde ontladen \u00f7 waarde laden</div></div>' +
      '</div>' +
      '<div style="width:1px;align-self:stretch;background:' + D.rand + ';"></div>' +
      '<div style="display:flex;gap:26px;flex-wrap:wrap;flex:1;row-gap:12px;">' +
        kolom('Laden', kwh(f.laadKwh), ct(f.gemLaad) + '/kWh', D.rood) +
        kolom('Ontladen', kwh(f.ontlaadKwh), ct(f.gemOntlaad) + '/kWh', D.groen) +
        kolom('Netto', eurT(f.netto), num(f.retour * 100, 0) + '% retour', kleur(f.netto)) +
        kolom('Spread', ct(f.gemOntlaad - f.gemLaad), 'per kWh all-in', D.paars) +
      '</div>' +
      '<div style="min-width:180px;flex:1;">' +
        '<div style="height:8px;border-radius:4px;position:relative;background:linear-gradient(to right,' +
          D.rood + ',' + D.oranje + ' 25%,' + D.paars + ' 50%,' + D.groen + ');">' +
          '<div style="position:absolute;top:-3px;left:' + pct + '%;transform:translateX(-50%);width:14px;' +
            'height:14px;border-radius:50%;background:#fff;border:2.5px solid ' + kl +
            ';box-shadow:0 1px 4px rgba(0,0,0,.15);"></div></div>' +
        '<div style="display:flex;justify-content:space-between;font-size:9px;color:' + D.grijs +
          ';margin-top:4px;"><span>0</span><span>1,0</span><span>2,0+</span></div>' +
      '</div>'));
    return c;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  aFRR
  // ══════════════════════════════════════════════════════════════════════

  // ══════════════════════════════════════════════════════════════════════
  //  Maandstaat: geschiedenis en prognose
  //
  //  Maanden die Balans heeft komen uit de API. De rest wordt geschat: kWh
  //  via de seizoensfactoren, het bedrag via de drie ankers uit de eigen
  //  geschiedenis. Prognoseregels staan cursief en gedempt met een tilde,
  //  zodat een schatting nooit voor een afrekening doorgaat.
  // ══════════════════════════════════════════════════════════════════════

  // Eén kolomdefinitie voor de maandstaat, en dezelfde eerste kolom in de
  // salderingstabel eronder, zodat de twee tabellen links uitlijnen.
  var KOL1 = '92px';
  var STAAT_GRID = 'grid-template-columns:' + KOL1 + ' minmax(60px,1fr) 104px 84px 84px 96px;gap:12px;';

  function staatKop() {
    return '<div style="display:grid;' + STAAT_GRID + 'padding:0 6px 7px;margin-bottom:5px;' +
      'border-bottom:1px solid ' + D.rand + ';font-size:9.5px;text-transform:uppercase;' +
      'letter-spacing:.05em;color:' + D.grijs + ';white-space:nowrap;">' +
      '<div>Maand</div><div></div>' +
      '<div style="text-align:right;">All-in</div>' +
      '<div style="text-align:right;">Vschot</div>' +
      '<div style="text-align:right;">Vaste k.</div>' +
      '<div style="text-align:right;">Saldo</div></div>';
  }

  /** Eén regel van de maandstaat. Opmaak volgt v3: bekende maanden vol,
   *  prognose gedempt en cursief met een tilde, en onder de balk de regel
   *  "berekend t/m …" zodra een maand nog niet af is. */
  /** Eén regel van de maandstaat, opgemaakt zoals v3: bekende maanden vol,
   *  prognose gedempt en cursief met een tilde, en onder de balk de regel
   *  "berekend t/m …" zolang een maand nog loopt.
   *
   *  De kolom Vaste k. toont dagen x (levering + transport - vermindering).
   *  Dat is een negatief getal, want de vermindering energiebelasting is
   *  groter dan levering en transport samen; het verlaagt dus je rekening,
   *  ook al staat er een min voor. Zo stond het in v3 en zo blijft het.
   */
  function staatRij(o) {
    var bg = o.nu ? 'rgba(107,63,160,.06)' : (o.even ? 'rgba(107,63,160,.02)' : 'transparent');
    var dim = o.geschat ? 'opacity:.6;' : '';
    var cur = o.geschat ? 'font-style:italic;' : '';
    var t = o.geschat ? '~' : '';
    // v3 tekende de lopende maand in twee stukken: het werkelijke deel vol,
    // de rest tot aan de prognose in een zachte tint. Zo zie je in één blik
    // hoever de maand is én waar hij naartoe gaat.
    var balk = Math.min(100, Math.abs(o.stroom) / 4);
    var balkRest = 0;
    if (o.naast) {
      var balkProg = Math.min(100, Math.abs(o.naast) / 4);
      balkRest = Math.max(0, balkProg - balk);
    }
    var vastWeergave = -o.vast;   // v3-notatie: als kostenregel geschreven
    var sub = o.sub
      ? '<div style="font-size:10px;font-weight:600;margin-top:4px;white-space:nowrap;color:' +
        (o.subKleur || D.paars) + ';">' + o.sub + '</div>'
      : '';

    return '<div style="display:grid;' + STAAT_GRID + 'align-items:start;padding:8px 6px;' +
        'border-radius:5px;background:' + bg + ';' + dim + 'font-variant-numeric:tabular-nums;">' +
      '<div style="font-size:12px;padding-top:1px;' + cur + 'color:' +
        (o.geschat ? D.paarsLicht : D.inkt) + ';font-weight:' + (o.nu ? '600' : '400') + ';">' +
        maandLabel(o.key) + '</div>' +
      '<div><div style="height:7px;border-radius:4px;background:#eeebf4;overflow:hidden;' +
          'margin-top:4px;display:flex;">' +
        '<div style="height:100%;width:' + balk + '%;flex-shrink:0;border-radius:4px 0 0 4px;background:' +
          (o.geschat ? kleurZacht(o.stroom) : kleur(o.stroom)) + ';"></div>' +
        (balkRest > 0
          ? '<div style="height:100%;width:' + balkRest + '%;flex-shrink:0;background:' +
            kleurZacht(o.naast) + ';"></div>'
          : '') +
        '</div>' + sub + '</div>' +
      '<div style="text-align:right;font-size:12px;font-weight:600;padding-top:1px;' + cur + 'color:' +
        (o.geschat ? kleurZacht(o.stroom) : kleur(o.stroom)) + ';">' + t + eurCent(o.stroom) +
        (o.naast ? '<span style="color:' + D.paarsLicht + ';font-weight:400;"> / ~' +
          eurKort(o.naast) + '</span>' : '') + '</div>' +
      '<div style="text-align:right;font-size:12px;padding-top:1px;color:' + D.grijs + ';">+\u20ac' +
        num(o.voorschot, 2) + '</div>' +
      '<div style="text-align:right;font-size:12px;padding-top:1px;' + cur + 'color:' +
        (o.geschat ? kleurZacht(vastWeergave) : kleur(vastWeergave)) + ';">' + eurCent(vastWeergave) + '</div>' +
      '<div style="text-align:right;font-size:12px;font-weight:600;padding-top:1px;' + cur + 'color:' +
        (o.geschat ? kleurZacht(o.cum) : kleur(o.cum)) + ';">' + t + eurKort(o.cum) + '</div>' +
    '</div>';
  }

  /**
   *  Voorschot en verrekening. Voorschotten en prognose exact als in v3:
   *
   *   - de ankers komen uit de eigen geschiedenis: slechtste wintermaand,
   *     gemiddelde tussenmaand, beste zomermaand, en het maandprofiel
   *     interpoleert daartussen;
   *   - het cumulatieve saldo telt per maand het werkelijke bedrag als dat
   *     er is en anders de prognose, plus voorschot en vaste posten;
   *   - de regel "Prognose jaar" neemt voor een maand die nog loopt het
   *     hoogste van werkelijk en prognose, zodat een maand die pas een paar
   *     dagen oud is de jaarprognose niet omlaagtrekt.
   */
  function bouwMaandstaat(rijen, sald, saldProg, huidigeKey) {
    var c = sectie('be-staat', 'Voorschot &amp; verrekening');

    var werkelijkPer = {}, bekendBedrag = {};
    rijen.forEach(function (r, i) {
      if (r.leeg) return;
      var a = bereken(r, sald[i].ongesaldeerd, dagenVerstreken(r.key));
      werkelijkPer[r.key] = a;
      // Alleen volledige maanden mogen anker zijn. September met twee dagen
      // data telde als volle tussenmaand mee en trok het tussenanker van
      // EUR 101 naar EUR 71, waardoor de oktoberprognose twintig euro
      // omlaagging. Een maand die nog loopt zegt niets over een hele maand.
      if (a.dagen >= dagenInMaand(r.key)) bekendBedrag[r.key] = a.stroom;
    });
    var ank = ankers(bekendBedrag);

    var cum = 0, betaald = 0, werkelijk = 0, vastTot = 0, maandenBekend = 0;
    var jaarStroom = 0, jaarVast = 0;
    var html = staatKop();

    rijen.forEach(function (r, i) {
      var a = werkelijkPer[r.key];
      var loopt = isLopendeMaand(r.key);

      var prog = prognoseBedrag(r.key, ank);
      if (naSaldering(r.key) && saldProg[i]) prog -= saldProg[i].exp * EB;

      var stroom, vast, geschat, vs, sub = null, subKleur = null, naast = null;

      if (a) {
        geschat = false;
        stroom = a.stroom;
        vast = a.vast;
        // In de staat telt het volle voorschot. Dit is de prognosekant van het
        // contractjaar: elke maand levert uiteindelijk een heel voorschot op,
        // en het cumulatieve saldo moet daar naartoe rekenen. Het naar rato
        // afknippen hoort in de maandkaart bovenaan, waar je de stand van nu
        // ziet — niet hier.
        vs = cfg.voorschot;
        betaald += vs;
        werkelijk += stroom;
        vastTot += vast;
        maandenBekend++;
        if (loopt) {
          sub = 'berekend t/m ' + a.dagen + ' ' + maandNaam(r.key);
          if (Math.abs(stroom) < Math.abs(prog)) naast = prog;
        } else if (a.dagen < dagenInMaand(r.key)) {
          sub = 'nog ' + (dagenInMaand(r.key) - a.dagen) + ' dagen open';
          subKleur = D.oranje;
        }
        if (loopt && Math.abs(prog) > Math.abs(stroom)) {
          jaarStroom += prog;
          jaarVast += dagenInMaand(r.key) * VAST_DAG;
        } else {
          jaarStroom += stroom;
          jaarVast += vast;
        }
      } else {
        geschat = true;
        stroom = prog;
        vast = dagenInMaand(r.key) * VAST_DAG;
        vs = cfg.voorschot;                // een prognosemaand wordt uiteindelijk heel
        jaarStroom += stroom;
        jaarVast += vast;
      }

      cum += stroom + vast + vs;
      html += staatRij({ key: r.key, nu: r.key === huidigeKey, even: i % 2 === 0, geschat: geschat,
        stroom: stroom, vast: vast, voorschot: vs, cum: cum,
        sub: sub, subKleur: subKleur, naast: naast });
    });

    var jaarVoorschot = 12 * cfg.voorschot;
    var jaarSaldo = jaarStroom + jaarVast + jaarVoorschot;
    html += '<div style="display:grid;' + STAAT_GRID + 'align-items:center;padding:11px 6px 3px;' +
        'margin-top:6px;border-top:1.5px solid ' + D.rand + ';font-variant-numeric:tabular-nums;">' +
      '<div style="font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:' +
        D.label + ';">Prognose jaar</div><div></div>' +
      '<div style="text-align:right;font-size:12px;font-weight:700;color:' + kleur(jaarStroom) + ';">' +
        eurKort(jaarStroom) + '</div>' +
      '<div style="text-align:right;font-size:12px;font-weight:700;color:' + D.inkt + ';">+\u20ac' +
        num(jaarVoorschot, 0) + '</div>' +
      '<div style="text-align:right;font-size:12px;font-weight:700;color:' + kleur(-jaarVast) + ';">' +
        eurKort(-jaarVast) + '</div>' +
      '<div style="text-align:right;font-size:12px;font-weight:700;color:' + kleur(jaarSaldo) + ';">' +
        eurKort(jaarSaldo) + '</div></div>';

    var werkelijkTot = werkelijk + vastTot;
    var saldoNu = werkelijkTot + betaald;
    var pct = Math.round((maandenBekend / 12) * 100);
    var eind = new Date(cfg.start.getFullYear(), cfg.start.getMonth() + 12, cfg.start.getDate() - 1);

    c.appendChild(el('div',
      'display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));border:1px solid ' + D.rand +
      ';border-radius:9px;overflow:hidden;margin-bottom:14px;',
      cel('Betaald t/m nu', '+' + eur(betaald), maandenBekend + ' \u00d7 ' + eur(cfg.voorschot), D.inkt) +
      cel('Werkelijk t/m nu', eurT(werkelijkTot), 'stroom + netbeheer + belastingen', kleur(werkelijkTot)) +
      cel('Huidig saldo', eurT(saldoNu), saldoNu < 0 ? 'nog te betalen' : 'te ontvangen', kleur(saldoNu))));

    c.appendChild(el('div', 'margin-bottom:14px;',
      '<div style="display:flex;justify-content:space-between;font-size:10px;color:' + D.grijs +
        ';margin-bottom:4px;"><span>' + cfg.start.getDate() + ' ' + MND_LANG[cfg.start.getMonth()] + ' ' +
        cfg.start.getFullYear() + '</span><span style="color:' + D.paars + ';font-weight:600;">\u25cf nu (' +
        maandenBekend + ' mnd)</span><span>' + eind.getDate() + ' ' + MND_LANG[eind.getMonth()] + ' ' +
        eind.getFullYear() + '</span></div>' +
      '<div style="height:8px;background:#ede8f5;border-radius:4px;position:relative;">' +
        '<div style="height:100%;width:' + pct + '%;background:' + D.paars + ';border-radius:4px;"></div>' +
        '<div style="position:absolute;top:-3px;left:' + pct + '%;transform:translateX(-50%);width:14px;' +
          'height:14px;border-radius:50%;background:#fff;border:2.5px solid ' + D.paars +
          ';box-shadow:0 1px 3px rgba(0,0,0,.15);"></div></div>' +
      '<div style="font-size:10px;color:' + D.grijs + ';margin-top:4px;">' + maandenBekend +
        ' van 12 maanden \u00b7 ' + pct + '% van contractjaar</div>'));

    var det = el('details', '');
    det.open = true;
    det.innerHTML = '<summary style="cursor:pointer;font-size:11.5px;color:' + D.grijs +
      ';list-style:none;">\u25bc Maanddetails verbergen</summary>' +
      '<div style="margin-top:11px;">' + html + '</div>' +
      '<div style="margin-top:12px;font-size:10.5px;color:' + D.grijs + ';line-height:1.5;">' +
      'Cursief met ~ is prognose, geschat uit de eigen geschiedenis. De rest komt rechtstreeks uit ' +
      'results-v2-api. Een maand die nog loopt telt in de jaarprognose mee voor het hoogste van ' +
      'werkelijk en verwacht.</div>';
    det.addEventListener('toggle', function () {
      var sum = det.querySelector('summary');
      if (sum) sum.textContent = det.open ? '\u25bc Maanddetails verbergen' : '\u25b6 Maanddetails tonen';
    });
    c.appendChild(det);
    return c;
  }

  function cel(kop, groot, klein, kl) {
    return '<div style="padding:11px 14px;border-right:1px solid ' + D.rand + ';">' +
      '<div style="font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:' + D.grijs + ';">' +
        kop + '</div>' +
      '<div style="font-size:20px;font-weight:700;margin-top:2px;color:' + kl +
        ';font-variant-numeric:tabular-nums;">' + groot + '</div>' +
      '<div style="font-size:10.5px;color:' + D.grijs + ';margin-top:2px;">' + klein + '</div></div>';
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Salderingsbalans
  // ══════════════════════════════════════════════════════════════════════

  var SALD_GRID = 'grid-template-columns:' + KOL1 + ' 1fr 1fr 1fr 1fr 1.1fr;gap:12px;';

  function bouwSaldering(sald) {
    if (!cfg.saldering) return null;
    var gevuld = sald.filter(function (s) { return !s.overgeslagen && (s.imp > 0 || s.exp > 0); });
    if (!gevuld.length) return null;
    var laatsteRij = gevuld[gevuld.length - 1];
    var totImp = laatsteRij.cumImp, totExp = laatsteRij.cumExp;
    var over = Math.max(0, totExp - totImp);
    var ruimte = Math.max(0, totImp - totExp);
    var naald = Math.min(98, Math.max(2, (totImp > 0 ? totExp / totImp : 0) * 50));
    var kl = over > 0 ? D.rood : D.groen;

    var schakelaar =
      '<label id="be-sald-prog" style="display:flex;align-items:center;gap:7px;cursor:pointer;flex-shrink:0;">' +
        '<span style="font-size:10px;font-weight:500;color:' +
          (salderingPrognose ? D.paars : D.grijs) + ';">incl. prognose</span>' +
        '<span style="position:relative;display:block;width:36px;height:20px;border-radius:10px;' +
          'background:' + (salderingPrognose ? D.paars : D.rand) + ';transition:background .2s;">' +
          '<span style="position:absolute;top:3px;left:' + (salderingPrognose ? '18px' : '3px') +
            ';width:14px;height:14px;border-radius:7px;background:#fff;transition:left .2s;' +
            'box-shadow:0 1px 3px rgba(0,0,0,.2);"></span></span></label>';

    var c = sectie('be-sald', 'Salderingsbalans contractjaar', schakelaar);

    var tabel = '<div style="display:grid;' + SALD_GRID + 'padding:0 6px 7px;margin-bottom:5px;' +
      'border-bottom:1px solid ' + D.rand + ';font-size:9.5px;text-transform:uppercase;letter-spacing:.05em;' +
      'color:' + D.grijs + ';white-space:nowrap;"><div>Maand</div>' +
      '<div style="text-align:right;">Import</div><div style="text-align:right;">Export</div>' +
      '<div style="text-align:right;">Cum. imp</div><div style="text-align:right;">Cum. exp</div>' +
      '<div style="text-align:right;">Ongesaldeerd</div></div>';

    sald.forEach(function (s, i) {
      if (s.overgeslagen) {
        tabel += '<div style="display:grid;' + SALD_GRID + 'padding:6px;font-size:11px;opacity:.3;">' +
          '<div style="font-style:italic;color:' + D.paarsLicht + ';">' + maandLabel(s.key) + '</div>' +
          '<div style="text-align:right;">\u2013</div><div style="text-align:right;">\u2013</div>' +
          '<div style="text-align:right;">\u2013</div><div style="text-align:right;">\u2013</div>' +
          '<div style="text-align:right;">\u2013</div></div>';
        return;
      }
      var kantel = !s.naSaldering && s.ongesaldeerd > 0 && (s.cumExp - s.exp) <= (s.cumImp - s.imp);
      var bg = s.naSaldering ? 'rgba(220,53,69,.05)'
             : kantel ? 'rgba(220,53,69,.07)'
             : (s.geschat ? 'rgba(107,63,160,.03)' : (i % 2 === 0 ? 'rgba(107,63,160,.02)' : 'transparent'));
      var stijl = s.geschat ? 'opacity:.65;font-style:italic;' : '';
      tabel += '<div style="display:grid;' + SALD_GRID + 'padding:6px;border-radius:5px;font-size:11.5px;' +
          'background:' + bg + ';' + stijl + 'font-variant-numeric:tabular-nums;">' +
        '<div style="color:' + D.inkt + ';">' + maandLabel(s.key) +
          (kantel ? ' <span style="color:' + D.rood + ';font-size:9px;">\u25c0</span>' : '') +
          (s.naSaldering ? ' <span style="color:' + D.rood + ';font-size:9px;">\u26a0</span>' : '') + '</div>' +
        '<div style="text-align:right;color:' + D.grijs + ';">' + num(s.imp, 0) + '</div>' +
        '<div style="text-align:right;color:' + D.grijs + ';">' + num(s.exp, 0) + '</div>' +
        '<div style="text-align:right;">' + num(s.cumImp, 0) + '</div>' +
        '<div style="text-align:right;color:' + (s.cumExp > s.cumImp ? D.rood : D.inkt) + ';">' +
          num(s.cumExp, 0) + '</div>' +
        '<div style="text-align:right;font-weight:' + (s.ongesaldeerd > 0 ? '700' : '400') + ';color:' +
          (s.ongesaldeerd > 0 ? D.rood : D.grijs) + ';">' +
          (s.ongesaldeerd > 0 ? num(s.ongesaldeerd, 0) + ' kWh' : '\u2013') + '</div></div>';
    });

    c.appendChild(el('div',
      'display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));border:1px solid ' + D.rand +
      ';border-radius:9px;overflow:hidden;margin-bottom:13px;',
      cel('Import', kwh(totImp), 'contractjaar', D.inkt) +
      cel('Export', kwh(totExp), 'contractjaar', kl) +
      cel(over > 0 ? 'Buiten saldering' : 'Saldeerruimte over', kwh(over > 0 ? over : ruimte),
          over > 0 ? 'geen EB-teruggave hierop' : 'nog te benutten', kl)));

    c.appendChild(el('div', 'margin-bottom:13px;',
      '<div style="display:flex;justify-content:space-between;font-size:10px;color:' + D.grijs +
        ';margin-bottom:5px;"><span>\u2190 import overheerst</span><span>break-even</span>' +
        '<span>export overschot \u2192</span></div>' +
      '<div style="height:8px;border-radius:4px;border:1px solid ' + D.rand + ';position:relative;' +
        'background:linear-gradient(to right,' + D.groen + ' 0%,#a8d5b5 45%,#f0edf7 50%,#f5c0c0 55%,' +
        D.rood + ' 100%);">' +
        '<div style="position:absolute;top:0;left:50%;width:2px;height:100%;background:' + D.paars +
          ';opacity:.3;"></div>' +
        '<div style="position:absolute;top:-3px;left:' + naald + '%;transform:translateX(-50%);width:14px;' +
          'height:14px;border-radius:50%;background:#fff;border:2.5px solid ' + kl +
          ';box-shadow:0 1px 4px rgba(0,0,0,.15);"></div></div>'));

    if (over > 0) {
      c.appendChild(el('div', 'margin-bottom:12px;padding:7px 10px;border-radius:7px;font-size:11px;' +
        'background:rgba(220,53,69,.06);color:' + D.rood + ';',
        kwh(over) + ' export valt buiten de saldering \u2014 daarover komt geen ' + eur(EB, 5) +
        '/kWh energiebelasting terug, dus ' + eur(over * EB) + ' minder dan wanneer er ruimte was.'));
    }

    var det = el('details', '');
    det.innerHTML = '<summary style="cursor:pointer;font-size:11.5px;color:' + D.grijs +
      ';list-style:none;">\u25b6 Maand voor maand</summary><div style="margin-top:11px;">' + tabel + '</div>' +
      '<div style="margin-top:10px;font-size:10.5px;color:' + D.grijs + ';line-height:1.5;">' +
      (salderingPrognose ? 'Cursief = prognose \u00b7 ' : 'Alleen maanden met echte cijfers \u00b7 ') +
      '\u25c0 kantelpunt saldering \u00b7 \u26a0 na 31 december 2026, geen saldering meer</div>';
    det.addEventListener('toggle', function () {
      var s = det.querySelector('summary');
      if (s) s.textContent = det.open ? '\u25bc Maand voor maand verbergen' : '\u25b6 Maand voor maand';
    });
    c.appendChild(det);
    return c;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  De schakelaar op de kaarten van Balans zelf
  //
  //  Aan betekent: de KPI-kaarten, de gemiddelde kWh-prijzen en de
  //  staafgrafiek van Balans tonen all-in bedragen. Uit zet alles terug op
  //  hun eigen cijfers. De waarden komen uit de API, niet uit het DOM, dus
  //  terugzetten is exact en niet afhankelijk van een snapshot.
  // ══════════════════════════════════════════════════════════════════════

  function zetKaartTekst(id, tekst, kl) {
    var e = document.getElementById(id);
    if (!e) return null;
    e.textContent = tekst;
    if (kl) e.style.setProperty('color', kl, 'important');
    else e.style.removeProperty('color');
    return e;
  }

  function zetSubInfo(id, html) {
    var e = document.getElementById(id);
    if (!e) return;
    var houder = e.parentElement;
    var oud = houder.querySelector('.be-sub');
    if (oud) oud.remove();
    if (!html) return;
    houder.appendChild(el('div', 'margin-top:6px;font-size:11px;color:' + D.grijs + ';', html));
    houder.lastElementChild.className = 'be-sub';
  }

  /** De ⓘ-popovers van Balans meeschrijven met de all-in weergave.
   *
   *  Het zijn Bootstrap 5.3-popovers met data-bs-title en data-bs-content en
   *  trigger "focus", en er hangt al een instantie aan.
   *
   *  Niet doen: de instantie weggooien en opnieuw aanmaken. Dat lijkt te
   *  werken — er staat daarna gewoon een instantie op het element — maar de
   *  knop reageert niet meer op een echte klik. Met een echte muisklik
   *  nagemeten: vóór dispose opent hij, erna niet meer.
   *
   *  Wel doen: de attributen bijwerken en de bestaande instantie zijn inhoud
   *  laten vervangen met setContent(). Alle bindingen blijven staan.
   *
   *  Bestaat er nog geen instantie, dan zetten we alleen de attributen; de
   *  eigen init van de pagina leest die daarna vanzelf.
   */
  function zetPopover(id, titel, inhoud) {
    var e = document.getElementById(id);
    var m = e && e.closest('.summary-compact-metric');
    var b = m && m.querySelector('button.help-popover');
    if (!b) return;

    if (!b.getAttribute('data-be-orig-titel')) {
      b.setAttribute('data-be-orig-titel', b.getAttribute('data-bs-title') || '');
      b.setAttribute('data-be-orig-inhoud', b.getAttribute('data-bs-content') || '');
    }
    var t = titel === null ? b.getAttribute('data-be-orig-titel') : titel;
    var c = inhoud === null ? b.getAttribute('data-be-orig-inhoud') : inhoud;
    if (b.getAttribute('data-bs-title') === t && b.getAttribute('data-bs-content') === c) return;

    b.setAttribute('data-bs-title', t);
    b.setAttribute('data-bs-content', c);
    b.setAttribute('aria-label', t);
    try {
      var BS = window.bootstrap;
      var inst = (BS && BS.Popover) ? BS.Popover.getInstance(b) : null;
      if (inst && typeof inst.setContent === 'function') {
        inst.setContent({ '.popover-header': t, '.popover-body': c });
      }
    } catch (err) {}
  }

  function pasPopoversAan(a, aan) {
    if (!aan) {
      ['summary-stroom-voordeel', 'summary-deal-result', 'summary-buy-price', 'summary-sell-price']
        .forEach(function (id) { zetPopover(id, null, null); });
      return;
    }

    var ebPerKwhVerk = a.exp > 0 ? a.ebVerk / a.exp : 0;
    var buiten = a.ongesaldeerd > 0.5
      ? ' Van de ' + kwh(a.exp) + ' valt ' + kwh(a.ongesaldeerd) +
        ' buiten de saldeerruimte; daarover komt geen energiebelasting terug.'
      : ' Alle teruglevering valt binnen de saldeerruimte, dus over elke kWh komt de volle ' +
        eur(EB, 5) + ' terug.';

    zetPopover('summary-stroom-voordeel', 'Kosten stroomafname all-in',
      eur(Math.abs(a.balansInk)) + ' volgens Balans, inclusief btw en \u20ac 0,02 leverkosten per kWh. ' +
      'Daar hoort ' + eur(Math.abs(a.ebInk)) + ' energiebelasting bij: ' + kwh(a.imp) + ' \u00d7 ' +
      eur(EB, 5) + ' per kWh (\u20ac 0,111 plus 21% btw). Samen ' + eur(Math.abs(a.allinInk)) + '. ' +
      'Balans laat die belasting weg, terwijl je hem wel betaalt.');

    zetPopover('summary-deal-result', 'Opbrengst teruglevering all-in',
      eur(a.balansVerk) + ' volgens Balans, inclusief btw en minus \u20ac 0,02 leverkosten per kWh. ' +
      'Door saldering krijg je daarnaast ' + eur(a.ebVerk) + ' energiebelasting terug over ' +
      kwh(a.gesaldeerd) + '. Samen ' + eur(a.allinVerk) + '.' + buiten);

    zetPopover('summary-buy-price', 'Gem. inkoopprijs all-in',
      ct(a.prijsInkBalans) + ' per kWh volgens Balans, plus ' + ct(EB) +
      ' energiebelasting inclusief btw, is ' + ct(a.prijsInk) + ' per kWh. ' +
      'Dit is het bedrag dat je werkelijk kwijt bent voor een kilowattuur van het net.');

    zetPopover('summary-sell-price', 'Gem. verkoopprijs all-in',
      ct(a.prijsVerkBalans) + ' per kWh volgens Balans, plus ' + ct(ebPerKwhVerk) +
      ' energiebelasting die je via saldering terugkrijgt, is ' + ct(a.prijsVerk) + ' per kWh. ' +
      'Het verschil met de inkoopprijs is ' + ct(a.prijsVerk - a.prijsInk) + ' per kWh.');
  }

  function zetKaartLabel(aan) {
    var e = document.getElementById('summary-stroom-voordeel');
    if (!e) return;
    var kaartEl = e.closest('.summary-compact-metric');
    var lbl = kaartEl ? kaartEl.querySelector('.summary-compact-label') : null;
    if (!lbl) return;
    var tekstNode = Array.prototype.filter.call(lbl.childNodes, function (n) { return n.nodeType === 3; })[0];
    if (tekstNode) tekstNode.nodeValue = aan ? 'Kosten stroomafname all-in' : 'Kosten stroomafname';
  }

  function pasBalansKaartenAan(a, ruw, aan) {
    if (!aan) {
      zetKaartTekst('summary-stroom-voordeel', eur(ruw.inkoop));
      zetKaartTekst('summary-deal-result', eur(ruw.verkoop));
      zetKaartTekst('summary-buy-price', prijs(ruw.prijsInk));
      zetKaartTekst('summary-sell-price', prijs(ruw.prijsVerk));
      zetSubInfo('summary-stroom-voordeel', null);
      zetSubInfo('summary-deal-result', null);
      zetKaartLabel(false);
      pasPopoversAan(a, false);
      return;
    }
    zetKaartTekst('summary-stroom-voordeel', eur(Math.abs(a.allinInk)), D.rood);
    zetKaartTekst('summary-deal-result', eur(a.allinVerk), D.groen);
    zetKaartTekst('summary-buy-price', prijs(a.prijsInk));
    zetKaartTekst('summary-sell-price', prijs(a.prijsVerk));
    zetSubInfo('summary-stroom-voordeel', kwh(a.imp) + ' \u00b7 waarvan ' +
      '<span style="color:' + D.rood + ';font-weight:600;">' + eur(Math.abs(a.ebInk)) + '</span> energiebelasting');
    zetSubInfo('summary-deal-result', kwh(a.exp) + ' \u00b7 waarvan ' +
      '<span style="color:' + D.groen + ';font-weight:600;">' + eur(a.ebVerk) + '</span> energiebelasting terug');
    zetKaartLabel(true);
    pasPopoversAan(a, true);
  }

  // ── Staafgrafiek ──────────────────────────────────────────────────────

  var chartOrig = null;
  var CHART_SETS = ['Inkoop kosten', 'Verkoop opbrengsten', 'Totaal'];

  function pasGrafiekAan(perPeriode, aan) {
    if (!window.Chart) return;
    var chart = Chart.getChart('summary-chart');
    if (!chart || !chart.data.labels) return;
    var n = chart.data.labels.length;
    if (!n) return;

    if (!chartOrig || chartOrig.n !== n) {
      chartOrig = { n: n, sets: chart.data.datasets
        .filter(function (d) { return CHART_SETS.indexOf(d.label) !== -1; })
        .map(function (d) { return { label: d.label, data: d.data.slice() }; }) };
    }

    chart.data.datasets = chart.data.datasets.filter(function (d) {
      return d.label !== 'Energiebelasting';
    });

    if (!aan || !perPeriode || perPeriode.length !== n) {
      chartOrig.sets.forEach(function (o) {
        var ds = chart.data.datasets.find(function (d) { return d.label === o.label; });
        if (ds) ds.data = o.data.slice();
      });
      chart.update('none');
      return;
    }

    chart.data.datasets.forEach(function (ds) {
      if (ds.label === 'Inkoop kosten')       ds.data = perPeriode.map(function (a) { return Math.abs(a.allinInk); });
      if (ds.label === 'Verkoop opbrengsten') ds.data = perPeriode.map(function (a) { return a.allinVerk; });
      if (ds.label === 'Totaal')              ds.data = perPeriode.map(function (a) { return a.stroom; });
    });
    chart.data.datasets.push({
      label: 'Energiebelasting',
      data: perPeriode.map(function (a) { return a.eb; }),
      backgroundColor: '#1D9E75', borderRadius: 0, order: 2
    });
    if (chart.options.scales && chart.options.scales.y) {
      chart.options.scales.y.min = undefined;
      chart.options.scales.y.max = undefined;
    }
    chart.update('none');
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Onderschepping van het antwoord
  //
  //  We rekenen met de cijfers waaruit het DOM gevuld wordt, niet met het DOM
  //  zelf. `@run-at document-start` is daarvoor nodig, anders staat de hook er
  //  pas ná het eerste verzoek van de pagina.
  // ══════════════════════════════════════════════════════════════════════

  var laatste = null;
  var timer = null;

  /** Welke periode staat er op de pagina ingesteld? */
  function actievePeriode() {
    var knop = document.querySelector('.summary-granularity.active');
    var g = knop ? knop.textContent.trim().toLowerCase() : 'maand';
    var interval = g === 'dag' ? 'day' : (g === 'jaar' ? 'year' : 'month');
    var picker = document.getElementById(
      interval === 'day' ? 'dayPicker' : interval === 'year' ? 'summary-year-picker' : 'summary-month-picker');
    return { interval: interval, periode: picker ? picker.value : null };
  }

  function onthoud(j, valInterval) {
    if (!j || !Array.isArray(j.series)) return false;

    // Alleen wat bij de gekozen periode hoort. Anders kaapt elk ander verzoek
    // op dit endpoint de weergave — de jaaropvragingen voor het contractjaar
    // gaan daarom sowieso langs de originele fetch, maar een losse call uit de
    // console of uit een ander script moet de kaarten ook niet omgooien.
    var actief = actievePeriode();
    var interval = j.interval || valInterval || 'month';
    if (actief.interval && interval !== actief.interval) return false;
    if (actief.periode && j.period && String(j.period) !== String(actief.periode)) return false;

    var pv = j.pricing || {};
    var tot = j.totals || {};
    laatste = {
      rijen: j.series.map(function (s) { return naarIncl(s, pv); }),
      totaal: naarIncl(tot, pv),
      ruw: {
        inkoop: getal(tot.total_buy_eur), verkoop: getal(tot.total_sell_eur),
        prijsInk: getal(tot.avg_buy_price_eur_per_kwh), prijsVerk: getal(tot.avg_sell_price_eur_per_kwh)
      },
      interval: interval,
      periode: j.period || actief.periode
    };
    return true;
  }

  if (KLANT && KLANT !== 'account') {
    window.fetch = function (input, init) {
      var url = typeof input === 'string' ? input
              : (input && typeof input.url === 'string') ? input.url : '';
      var p = origFetch(input, init);
      if (url.indexOf('results-v2-api') === -1) return p;
      return p.then(function (resp) {
        if (!resp.ok) return resp;
        resp.clone().json().then(function (j) {
          if (onthoud(j)) plan();
        }).catch(function () {});
        return resp;
      });
    };
  }

  function plan() {
    clearTimeout(timer);
    timer = setTimeout(function () {
      if (laatste) herteken();
      else zelfHalen().then(function (ok) { if (ok) herteken(); });
    }, 90);
  }

  /** Zelf ophalen als de hook het verzoek gemist heeft: bij een verse
   *  installatie zonder herladen, of bij injecteren via de console. De
   *  gekozen periode staat in de pickers van de pagina zelf. */
  var bezig = false;
  function zelfHalen() {
    if (bezig || !KLANT) return Promise.resolve(false);
    var actief = actievePeriode();
    if (!actief.periode) return Promise.resolve(false);

    bezig = true;
    var u = new URL(location.origin + '/customer/' + KLANT + '/results-v2-api/');
    u.searchParams.set('interval', actief.interval);
    u.searchParams.set('period', actief.periode);
    u.searchParams.set('include_vat', '1');
    u.searchParams.set('include_delivery_cost', '1');
    return origFetch(u, { credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { bezig = false; return onthoud(j, actief.interval); })
      .catch(function () { bezig = false; return false; });
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Opbouw van de pagina
  // ══════════════════════════════════════════════════════════════════════

  function anker() {
    var k = document.querySelector('.results-summary-card');
    return k ? k.closest('.row') : null;
  }

  function houder() {
    var h = document.getElementById('be-panelen');
    if (h) return h;
    var a = anker();
    if (!a || !a.parentElement) return null;
    h = el('div', '');
    h.id = 'be-panelen';
    a.parentElement.insertBefore(h, a.nextSibling);
    return h;
  }

  /** Het vergelijkingsblok van Balans inklappen. Wat het systeem zou
   *  besparen tegenover een vast contract is een andere vraag dan wat je
   *  betaalt, en die vergelijking laat de energiebelasting ook nog buiten
   *  beschouwing. Terug te halen in de instellingen. */
  function regelBalansBlok() {
    var b = document.querySelector('.results-trade-savings-card');
    if (b) {
      var r = b.closest('.row') || b;
      r.style.display = cfg.balansBlok ? '' : 'none';
    }
    var intro = document.querySelector('.results-intro-card');
    if (intro) {
      var ir = intro.closest('.row') || intro;
      ir.style.display = 'none';
    }
  }

  function periodeNaam() {
    var t = document.getElementById('summary-title');
    return t ? t.textContent.trim() : (laatste ? laatste.periode : '');
  }

  function herteken() {
    if (!laatste) return;
    var h = houder();
    if (!h) return;
    regelBalansBlok();

    Promise.all([haalContractjaar(), haalLopendeDagen()]).then(function (res) {
      var jaar = res[0];
      var sald = salderingReeks(jaar, false);
      var saldProg = salderingReeks(jaar, true);
      var tot = laatste.totaal;
      var huidigeKey = null, ongesaldeerd, dagen, periodeWoord;

      if (laatste.interval === 'month' && laatste.periode) {
        huidigeKey = laatste.periode;
        // Het totals-object van de API heeft geen month- of date-veld, dus
        // komt er geen sleutel uit naarIncl(). Zonder sleutel kan het
        // voorschot niet naar rato: september kreeg het volle bedrag terwijl
        // de maandstaat er wel twee dertigsten van maakte.
        tot.key = huidigeKey;
        var s = sald.find(function (x) { return x.key === huidigeKey; });
        ongesaldeerd = s ? s.ongesaldeerd : Math.max(0, tot.exp - tot.imp);
        dagen = dagenVerstreken(huidigeKey);
        periodeWoord = 'deze maand';
      } else if (laatste.interval === 'day') {
        ongesaldeerd = Math.max(0, tot.exp - tot.imp);
        dagen = 1;
        periodeWoord = 'deze dag';
      } else {
        // Jaarweergave. Dagen en saldering moeten over de maanden gaan die
        // dit antwoord bevat, niet over het contractjaar — anders telt een
        // kalenderjaar de netbeheerdagen van november en december ervoor mee.
        var eigenKeys = {};
        laatste.rijen.forEach(function (r) { if (r.key) eigenKeys[r.key] = true; });
        dagen = laatste.rijen.reduce(function (a, r) {
          return a + (r.key ? dagenVerstreken(r.key) : 0);
        }, 0);
        ongesaldeerd = sald.reduce(function (a, x) {
          return a + ((x.overgeslagen || !eigenKeys[x.key]) ? 0 : x.ongesaldeerd);
        }, 0);
        periodeWoord = 'deze periode';
      }

      var a = bereken(tot, ongesaldeerd, dagen);

      // De dagstaven moeten optellen tot de maand. Saldering is een jaarpot,
      // geen dagafrekening: een dag met 46 kWh export en 0,3 kWh import krijgt
      // gewoon EB terug zolang er ruimte in het jaar is. Daarom wordt het
      // ongesaldeerde deel van de periode evenredig over de dagen verdeeld in
      // plaats van per dag opnieuw te salderen — anders staan de staven samen
      // tientallen euro's naast het totaal erboven.
      var fractieOnges = tot.exp > 0 ? ongesaldeerd / tot.exp : 0;
      var perPeriode = laatste.rijen.map(function (r) {
        return bereken(r, r.exp * fractieOnges, 1);
      });

      pasBalansKaartenAan(a, laatste.ruw, cfg.allin);
      pasGrafiekAan(perPeriode, cfg.allin && laatste.interval !== 'day');

      h.innerHTML = '';
      if (!cfg.allin) {
        h.appendChild(el('div', 'margin-top:14px;padding:11px 14px;border:1px dashed ' + D.rand +
          ';border-radius:9px;font-size:12px;color:' + D.grijs + ';',
          'All-in staat uit \u2014 dit zijn de cijfers van Balans zelf, zonder energiebelasting. ' +
          'Zet de schakelaar <b style="color:' + D.paars + ';">All-in</b> in de kaartkop aan.'));
        return;
      }

      var kaartEl = bouwHoofdkaart(a, {
        naam: periodeNaam(), interval: laatste.interval, periodeWoord: periodeWoord });

      // Alles in dezelfde kaart, van boven naar beneden: eerst wat het kost,
      // dan waar de prijs vandaan komt, dan de accu, dan aFRR, dan het jaar.
      kaartEl.appendChild(bouwPrijsopbouw(a));

      var f = fpr(perPeriode);
      var fprSectie = bouwFpr(f, periodeWoord);
      if (fprSectie) kaartEl.appendChild(fprSectie);

      kaartEl.appendChild(bouwMaandstaat(jaar, sald, saldProg, huidigeKey));

      var saldSectie = bouwSaldering(salderingPrognose ? saldProg : sald);
      if (saldSectie) kaartEl.appendChild(saldSectie);

      h.appendChild(kaartEl);

      var knop = document.getElementById('be-sald-prog');
      if (knop) knop.addEventListener('click', function (e) {
        e.preventDefault();
        salderingPrognose = !salderingPrognose;
        herteken();
      });

      var g = grenzen();
      if (g && g.max_day) h.appendChild(bouwVerwerkt(g));
    });
  }

  function bouwVerwerkt(g) {
    var laatsteDag = new Date(g.max_day + 'T12:00:00');
    var achter = Math.round((new Date(iso(new Date()) + 'T12:00:00') - laatsteDag) / 86400000);
    var laat = achter > 3;
    var c = el('div', 'margin-top:14px;padding:9px 13px;border-radius:8px;font-size:11.5px;line-height:1.55;' +
      'background:' + (laat ? 'rgba(224,123,0,.08)' : '#f6f4fa') + ';border:1px solid ' +
      (laat ? 'rgba(224,123,0,.35)' : D.rand) + ';color:' + (laat ? '#5a4a33' : D.grijs) + ';',
      'Balans heeft verwerkt tot en met <b>' + laatsteDag.getDate() + ' ' + MND_LANG[laatsteDag.getMonth()] +
      '</b> \u2014 ' + achter + ' dag' + (achter === 1 ? '' : 'en') + ' achterstand. ' +
      (laat ? 'Dat is meer dan de gebruikelijke twee dagen.' : 'Dat is normaal.'));
    c.id = 'be-verwerkt';
    return c;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Schakelaar en instellingen in de kaartkop
  // ══════════════════════════════════════════════════════════════════════

  function injecteerKop() {
    if (document.getElementById('be-kop')) return;
    var k = document.querySelector('.results-summary-card');
    var hdr = k ? k.querySelector('.card-header') : null;
    if (!hdr) return;

    // De kop heeft één kind-div met de titel; er flex van maken zet onze
    // schakelaar netjes rechts zonder de titelopmaak aan te tasten.
    var cs = getComputedStyle(hdr);
    if (cs.display !== 'flex') {
      hdr.style.display = 'flex';
      hdr.style.alignItems = 'center';
      hdr.style.flexWrap = 'wrap';
      hdr.style.gap = '12px';
    }

    var wrap = el('div', 'display:flex;align-items:center;gap:11px;margin-left:auto;user-select:none;');
    wrap.id = 'be-kop';

    var lbl = el('span', 'font-size:13px;font-weight:600;letter-spacing:.03em;transition:color .2s;color:' +
      (cfg.allin ? D.paars : D.paarsLicht) + ';', 'All-in');
    var track = el('div', 'position:relative;width:44px;height:24px;border-radius:12px;flex-shrink:0;' +
      'border:1.5px solid ' + D.paarsLicht + ';transition:background .25s;background:' +
      (cfg.allin ? D.paars : D.rand) + ';');
    var thumb = el('div', 'position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;' +
      'background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25);transition:transform .25s;transform:translateX(' +
      (cfg.allin ? '20px' : '0') + ');');
    track.appendChild(thumb);

    var schakel = el('label', 'display:flex;align-items:center;gap:9px;cursor:pointer;');
    schakel.appendChild(lbl);
    schakel.appendChild(track);
    schakel.addEventListener('click', function (e) {
      e.preventDefault();
      cfg.allin = !cfg.allin;
      localStorage.setItem(LS.allin, cfg.allin ? 'aan' : 'uit');
      lbl.style.color = cfg.allin ? D.paars : D.paarsLicht;
      track.style.background = cfg.allin ? D.paars : D.rand;
      thumb.style.transform = cfg.allin ? 'translateX(20px)' : 'translateX(0)';
      herteken();
    });
    wrap.appendChild(schakel);

    var gear = el('div', 'width:18px;height:18px;cursor:pointer;opacity:.6;flex-shrink:0;transition:opacity .2s;');
    gear.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="' + D.paars + '" stroke-width="2" ' +
      'stroke-linecap="round" stroke-linejoin="round" style="width:100%;height:100%;"><circle cx="12" cy="12" r="3"/>' +
      '<path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 ' +
      '1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 ' +
      '1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 ' +
      '9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 ' +
      '1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 ' +
      '2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>';
    gear.addEventListener('mouseenter', function () { gear.style.opacity = '1'; });
    gear.addEventListener('mouseleave', function () { gear.style.opacity = '.6'; });
    gear.addEventListener('click', function (e) {
      e.stopPropagation();
      var p = document.getElementById('be-paneel');
      if (p) { p.remove(); return; }
      openInstellingen(hdr);
    });
    wrap.appendChild(gear);

    hdr.appendChild(wrap);
  }

  function veld(id, label, waarde, type) {
    return '<div style="margin-bottom:13px;">' +
      '<label style="font-size:10.5px;color:#555;display:block;margin-bottom:5px;text-transform:uppercase;' +
        'letter-spacing:.04em;">' + label + '</label>' +
      '<input id="' + id + '" type="' + type + '" step="0.01" value="' + waarde + '" style="width:100%;' +
      'box-sizing:border-box;padding:8px 10px;border:1px solid ' + D.rand + ';border-radius:6px;font-size:13px;">' +
    '</div>';
  }

  function knopje(id, titel, uitleg, aan) {
    return '<div style="margin-bottom:11px;padding:10px 12px;background:#faf9fd;border:1px solid ' + D.rand +
      ';border-radius:8px;display:flex;align-items:center;justify-content:space-between;gap:12px;">' +
      '<div><div style="font-size:11px;color:#555;font-weight:600;">' + titel + '</div>' +
      '<div style="font-size:10px;color:' + D.paarsLicht + ';margin-top:3px;line-height:1.4;">' + uitleg + '</div></div>' +
      '<div id="' + id + '" style="position:relative;width:36px;height:20px;border-radius:10px;cursor:pointer;' +
      'flex-shrink:0;transition:background .2s;background:' + (aan ? D.paars : D.rand) + ';">' +
      '<div style="position:absolute;top:3px;left:' + (aan ? '18px' : '3px') + ';width:14px;height:14px;' +
      'border-radius:7px;background:#fff;transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.2);"></div></div></div>';
  }

  function hangKnopje(id, staat, sleutel) {
    var e = document.getElementById(id);
    if (!e) return;
    e.addEventListener('click', function () {
      staat[sleutel] = !staat[sleutel];
      e.style.background = staat[sleutel] ? D.paars : D.rand;
      e.firstElementChild.style.left = staat[sleutel] ? '18px' : '3px';
    });
  }

  function openInstellingen(hdr) {
    var p = el('div', 'position:absolute;z-index:9999;background:#fff;border:1px solid ' + D.rand +
      ';border-radius:10px;padding:17px 19px;width:330px;box-shadow:0 6px 22px rgba(107,63,160,.16);');
    p.id = 'be-paneel';
    var r = hdr.getBoundingClientRect();
    p.style.top = (window.scrollY + r.bottom + 6) + 'px';
    p.style.left = Math.max(12, window.scrollX + r.right - 340) + 'px';

    p.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:15px;">' +
        '<div style="font-size:12px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:' +
          D.paars + ';">Instellingen v4.0.1</div>' +
        '<span id="be-p-sluit" style="cursor:pointer;font-size:19px;color:#aaa;line-height:1;">\u00d7</span></div>' +
      veld('be-p-voorschot', 'Voorschot per maand (\u20ac)', cfg.voorschot.toFixed(2), 'number') +
      veld('be-p-start', 'Startdatum contract (dd-mm-jjjj)',
        n2(cfg.start.getDate()) + '-' + n2(cfg.start.getMonth() + 1) + '-' + cfg.start.getFullYear(), 'text') +
      knopje('be-p-sald', 'Salderingsbalans tonen', 'Import tegen export over het contractjaar', cfg.saldering) +
      knopje('be-p-balans', 'Blok "Balans Systeem resultaat" tonen',
        'Besparing tegenover een vast contract, exclusief energiebelasting', cfg.balansBlok) +
      '<div style="display:flex;gap:8px;margin-top:4px;">' +
        '<button id="be-p-op" style="flex:1;padding:9px;background:' + D.paars +
          ';color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">Opslaan</button>' +
        '<button id="be-p-wis" title="Wis restanten van eerdere versies uit localStorage" ' +
          'style="padding:9px 12px;background:#fff;color:' + D.rood + ';border:1px solid ' + D.rood +
          ';border-radius:6px;font-size:12px;cursor:pointer;">Wis data</button>' +
      '</div>' +
      '<div id="be-p-melding" style="margin-top:11px;font-size:11px;display:none;"></div>';

    document.body.appendChild(p);
    document.getElementById('be-p-sluit').addEventListener('click', function () { p.remove(); });

    var staat = { sald: cfg.saldering, balans: cfg.balansBlok };
    hangKnopje('be-p-sald', staat, 'sald');
    hangKnopje('be-p-balans', staat, 'balans');

    document.getElementById('be-p-wis').addEventListener('click', function () {
      var m = document.getElementById('be-p-melding');
      if (!confirm('Restanten van eerdere versies uit localStorage wissen? De instellingen blijven staan.')) return;
      var n = wisOpslag();
      m.style.color = n > 0 ? D.oranje : D.grijs;
      m.textContent = n > 0
        ? n + ' oude sleutel' + (n === 1 ? '' : 's') + ' gewist.'
        : 'Niets te wissen \u2014 er stond niets ouds meer in.';
      m.style.display = 'block';
      herteken();
    });

    document.getElementById('be-p-op').addEventListener('click', function () {
      var m = document.getElementById('be-p-melding');
      function fout(t) { m.style.color = D.rood; m.textContent = t; m.style.display = 'block'; }
      var v = parseFloat(document.getElementById('be-p-voorschot').value);
      var s = document.getElementById('be-p-start').value.trim().split('-');
      if (isNaN(v) || v < 0) return fout('Ongeldig voorschotbedrag.');
      if (s.length !== 3) return fout('Datum moet dd-mm-jjjj zijn.');
      var d = new Date(parseInt(s[2], 10), parseInt(s[1], 10) - 1, parseInt(s[0], 10));
      if (isNaN(d.getTime())) return fout('Ongeldige datum.');

      cfg.voorschot = v;
      cfg.start = d;
      cfg.saldering = staat.sald;
      cfg.balansBlok = staat.balans;
      localStorage.setItem(LS.voorschot, v.toFixed(2));
      localStorage.setItem(LS.startdatum, iso(d));
      localStorage.setItem(LS.saldering, staat.sald ? 'aan' : 'uit');
      localStorage.setItem(LS.balansBlok, staat.balans ? 'aan' : 'uit');
      contractCache = null;
      dagenLopend = null;
      m.style.color = D.groen; m.textContent = 'Opgeslagen.'; m.style.display = 'block';
      herteken();
    });
  }

  /** Opgeslagen gegevens wissen.
   *
   *  v4 rekent alles uit results-v2-api en bewaart zelf niets meer per maand.
   *  Wat er nog wél staat zijn de restanten van v3: be_allin_*, be_ontbrekend_*
   *  en be_afrr_*. Die worden nergens meer gelezen maar blijven anders eeuwig
   *  in localStorage hangen. De instellingen (be_cfg_*) blijven staan; die
   *  wijzig je met de velden hierboven, niet met deze knop.
   */
  function wisOpslag() {
    var weg = [];
    try {
      Object.keys(localStorage).forEach(function (k) {
        if (k.indexOf('be_') === 0 && k.indexOf('be_cfg_') !== 0) weg.push(k);
      });
      weg.forEach(function (k) { localStorage.removeItem(k); });
    } catch (e) {}
    contractCache = null;
    dagenLopend = null;
    cacheJaar = {};
    return weg.length;
  }

  // ══════════════════════════════════════════════════════════════════════
  //  Start
  // ══════════════════════════════════════════════════════════════════════

  function pols() {
    if (location.pathname.indexOf('/results') === -1) return;
    injecteerKop();
    regelBalansBlok();
  }

  function start() {
    new MutationObserver(pols).observe(document.body, { childList: true, subtree: true });
    pols();
    // Als de pagina zijn verzoek al deed vóór de hook stond, alsnog ophalen.
    setTimeout(plan, 400);
    setTimeout(plan, 1600);
  }

  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start);
})();