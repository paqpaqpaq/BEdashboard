chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(message.type!=='be-epex-fetch')return;
  try{
    const url=new URL(message.url);
    if(new URL(sender.url).origin!=='https://dashboard.balansenergie.nl' || url.origin!=='https://api.energy-charts.info' || url.pathname!=='/price' || url.searchParams.get('bzn')!=='NL')throw Error('Invalid request');
    fetch(url.href,{credentials:'omit',signal:AbortSignal.timeout(20000)})
      .then(async r=>reply({status:r.status,text:await r.text()})).catch(()=>reply({error:true}));
    return true;
  }catch(_){reply({error:true});}
});
