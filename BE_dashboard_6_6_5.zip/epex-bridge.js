(function chartBridge(){
    if(window.__beEpexBridge)return;window.__beEpexBridge=true;
    let data={enabled:false,rows:[]},library=null,attachedChart=null,attachedForecast=null;
    const forecastPending=new WeakSet();
    const forecastPaints=new WeakMap();
    const dayClock=new Intl.DateTimeFormat('en-GB',{timeZone:'Europe/Amsterdam',day:'2-digit',month:'2-digit',year:'numeric'});
    function config(){try{data=JSON.parse(document.getElementById('be-epex-addon').textContent);}catch(_){}}
    function points(c){
      const x=c.options.scales?.x||{},min=x.min??-Infinity,max=x.max??Infinity,out=[];
      let previous=null;
      for(const r of data.rows||[]){
        if(r.end<min||r.start>max)continue;
        if(previous!==null&&r.start>previous)out.push({x:previous,y:null});
        const y=data.allin?r.price*data.btw+data.opslag+data.eb:r.price;
        out.push({x:r.start,y},{x:r.end,y});previous=r.end;
      }
      return out;
    }
    function forecastSlots(c){
      const slots=c.$beEpexForecastSlots||[];
      return slots.length&&window.BESOCExtras?.forecastGrid(c,slots).valid?slots:[];
    }
    function indexAt(slots,t){
      if(!slots.length||t<slots[0].t||t>slots.at(-1).t+slots.at(-1).dt)return null;
      let lo=0,hi=slots.length;
      while(lo<hi){const mid=(lo+hi)>>>1;if(slots[mid].t<=t)lo=mid+1;else hi=mid;}
      const i=Math.max(0,lo-1),step=slots[i+1]?slots[i+1].t-slots[i].t:slots[i].dt;
      if(!(step>0)||step>slots[i].dt+1)return null;
      return i+(t-slots[i].t)/step;
    }
    function forecastSignature(c){
      return JSON.stringify([data.forecastEnabled,data.allin,data.btw,data.opslag,data.eb,data.forecastRows,
        forecastSlots(c).map(s=>[s.t,s.dt]),document.documentElement.getAttribute('data-be-dark'),document.documentElement.getAttribute('data-be-dark-style')]);
    }
    function requestForecast(c){
      if(document.hidden||forecastPending.has(c))return;
      forecastPending.add(c);
      (typeof requestAnimationFrame==='function'?requestAnimationFrame:f=>setTimeout(f,0))(()=>{
        forecastPending.delete(c);if(c.canvas.isConnected===false||document.hidden)return;
        if(c.$beEpexForecastSignature!==forecastSignature(c)){
          if(window.BEChartRefresh)window.BEChartRefresh.request(c,'update');else c.update('none');
        }
      });
    }
    function announceForecast(c){
      const dates=[...new Set(forecastSlots(c).map(s=>dayClock.format(new Date(s.t)).replace(/\//g,'-')))];
      let n=document.getElementById('be-epex-forecast-range');
      if(!n){n=document.createElement('script');n.type='application/json';n.id='be-epex-forecast-range';document.documentElement.appendChild(n);}
      const text=JSON.stringify(dates);if(n.textContent!==text){n.textContent=text;document.dispatchEvent(new Event('be-epex-forecast-range'));}
    }
    function forecastColor(c){
      function lighter(channels){return 'rgb('+channels.map(v=>Math.round(Number(v)+(255-Number(v))*.12)).join(',')+')';}
      const annotations=c.config.options.plugins?.annotation?.annotations||{};
      for(const [key,a] of Object.entries(annotations)){
        if(!a||typeof a!=='object')continue;
        if(!/day[ _-]?ahead|epex|dynamisch/i.test(key+' '+(a?.label?.content||'')))continue;
        for(const candidate of [a.borderColor,a.backgroundColor]){
          if(typeof candidate!=='string')continue;
          const rgb=candidate.match(/^rgba?\(\s*([\d.]+)[, ]+([\d.]+)[, ]+([\d.]+)/i);
          if(rgb)return lighter(rgb.slice(1,4));
          if(/^#[\da-f]{6}(?:[\da-f]{2})?$/i.test(candidate))return lighter([1,3,5].map(i=>parseInt(candidate.slice(i,i+2),16)));
        }
      }
      return '#9ccced';
    }
    function forecastPaint(c,color){
      if(!c.ctx?.createLinearGradient)return color;
      let saved=forecastPaints.get(c.ctx);
      if(!saved||saved.color!==color){const paint=c.ctx.createLinearGradient(0,0,1,0);paint.addColorStop(0,color);paint.addColorStop(1,color);saved={color,paint};forecastPaints.set(c.ctx,saved);}
      return saved.paint;
    }
    function forecast(c){
      const slots=forecastSlots(c),opts=c.config.options,active=!!data.forecastEnabled&&slots.length>1;
      opts.scales=opts.scales||{};
      const color=forecastColor(c),paint=forecastPaint(c,color);
      const swatch=document.getElementById('be-epex-forecast-switch');if(swatch)swatch.style.setProperty('--be-epex-forecast-color',color);
      opts.scales.beEpex={type:'linear',axis:'y',display:false,
        grid:{display:false,drawOnChartArea:false},border:{display:false},
        title:{display:false},ticks:{display:false}};
      let ds=c.data.datasets.find(d=>d.beEpexForecast);
      if(!active){c.data.datasets=c.data.datasets.filter(d=>!d.beEpexForecast);c.$beEpexForecastRows=[];c.$beEpexForecastSignature=forecastSignature(c);return;}
      if(!ds){ds={beEpexForecast:true,type:'line',yAxisID:'beEpex',parsing:false,pointRadius:0,pointHitRadius:6,fill:false,spanGaps:false,order:-30};c.data.datasets.push(ds);}
      const rows=[...new Map((data.forecastRows||[]).filter(r=>Number.isFinite(r.start)&&r.end-r.start===900000&&Number.isFinite(r.price)).map(r=>[r.start,r])).values()].sort((a,b)=>a.start-b.start);
      const out=[],quoted=[];let end=null,lastValue=null;
      for(const r of rows){
        const from=Math.max(r.start,slots[0].t),to=Math.min(r.end,slots.at(-1).t+slots.at(-1).dt);
        if(to<=from)continue;
        const x=indexAt(slots,from),z=indexAt(slots,to);if(x===null||z===null)continue;
        const value=data.allin?r.price*data.btw+data.opslag+data.eb:r.price;
        if(end!==null&&from>end){out.push({x:indexAt(slots,end),y:lastValue},{x:indexAt(slots,end),y:null});}
        out.push({x,y:value});end=to;lastValue=value;quoted.push({...r,value});
      }
      if(end!==null)out.push({x:indexAt(slots,end),y:lastValue});
      Object.assign(ds,{label:data.allin?'EPEX · all-in':'EPEX · kaal',borderColor:paint,backgroundColor:paint,beEpexForecastColor:color,borderWidth:1,stepped:false,tension:.3,cubicInterpolationMode:'monotone',data:out});
      c.$beEpexForecastRows=quoted;c.$beEpexForecastSignature=forecastSignature(c);
    }
    function install(force=false){
      const C=typeof Chart!=='undefined'?Chart:window.Chart;if(!C)return;
      if(C!==library){C.register({id:'beEpexOverlay',beforeUpdate(c){
        if(c.canvas.id==='soc-forecast-chart'){forecast(c);return;}
        if(c.canvas.id!=='be-tarief-chart')return;
        // Write raw configuration, never assign Chart.js option resolvers to themselves.
        const opts=c.config.options;
        opts.plugins=opts.plugins||{};
        opts.plugins.legend=opts.plugins.legend||{};
        opts.plugins.legend.display=false;
        let ds=c.data.datasets.find(d=>d.beEpex);
        if(!data.enabled){c.data.datasets=c.data.datasets.filter(d=>!d.beEpex);return;}
        if(!ds){ds={beEpex:true,label:'EPEX NL',borderColor:'#429ee8',backgroundColor:'#429ee8',borderWidth:2,pointRadius:0,pointHitRadius:8,fill:false,spanGaps:false,stepped:'before',tension:0,order:-10};c.data.datasets.push(ds);}
        ds.label=data.allin?'EPEX · all-in':'EPEX · kaal';ds.data=points(c);
        ds.tooltip={callbacks:{label:z=>ds.label+': € '+z.parsed.y.toLocaleString('nl-NL',{minimumFractionDigits:3,maximumFractionDigits:5})+'/kWh'}};
      },afterUpdate(c){
        if(c.canvas.id==='soc-forecast-chart'){announceForecast(c);requestForecast(c);return;}
        if(c.canvas.id!=='be-tarief-chart')return;
        const host=document.getElementById('be-epex-legend');if(!host)return;
        const bar=host.parentElement,rect=c.canvas.getBoundingClientRect(),barRect=bar.getBoundingClientRect();
        if(c.chartArea&&c.width&&rect.width){
          const left=Math.max(0,rect.left+c.chartArea.left*rect.width/c.width-barRect.left);
          const padding=left.toFixed(2)+'px';
          if(bar.style.paddingLeft!==padding)bar.style.paddingLeft=padding;
        }
        const items=c.data.datasets.map((d,i)=>({label:d.label,color:d.borderColor,index:i,visible:c.isDatasetVisible(i)}));
        const key=JSON.stringify(items);if(host.dataset.key===key)return;host.dataset.key=key;
        host.replaceChildren();
        items.forEach(item=>{
          const button=document.createElement('button');button.type='button';button.setAttribute('aria-pressed',String(item.visible));
          const swatch=document.createElement('span');swatch.className='swatch';swatch.style.backgroundColor=typeof item.color==='string'?item.color:'#888';swatch.setAttribute('aria-hidden','true');
          const label=document.createElement('span');label.textContent=item.label;button.append(swatch,label);
          button.addEventListener('click',()=>{c.setDatasetVisibility(item.index,!c.isDatasetVisible(item.index));c.update('none');});host.append(button);
        });
      }});library=C;}
      const c=C.getChart('be-tarief-chart');if(c&&(force||c!==attachedChart)){attachedChart=c;c.update('none');}
      const f=C.getChart('soc-forecast-chart');attachedForecast=f;if(f)requestForecast(f);
    }
    document.addEventListener('be-epex-data',()=>{config();install(true);});
    document.addEventListener('be-tarief-update',()=>{config();install(true);});
    document.addEventListener('be-dark-change',()=>{config();install(true);});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden){config();install();}});
    config();install();
    setInterval(()=>{const C=window.Chart;if(C?.getChart&&(C!==library||C.getChart('be-tarief-chart')!==attachedChart||C.getChart('soc-forecast-chart')!==attachedForecast)){config();install();}},1000);
  })();
